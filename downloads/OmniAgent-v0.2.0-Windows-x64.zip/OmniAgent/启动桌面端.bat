@echo off
setlocal
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\win_bootstrap.ps1" desktop %*
if errorlevel 1 pause
