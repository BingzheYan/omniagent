# OmniAgent Web 应用 API 契约（v2，多用户）

所有 REST 接口返回 JSON；认证使用 httpOnly Cookie `omni_token`（登录后由服务器设置）。
未登录访问受保护接口返回 `401 {"detail": "未登录"}`；权限不足 `403`。
错误统一为 `{"detail": "中文错误信息"}`。时间戳均为 Unix 秒（float）。

## 认证 Auth
| 方法 | 路径 | 请求 | 响应 |
|---|---|---|---|
| GET | `/api/auth/status` | – | `{has_users, registration_open, invite_required}`（公开） |
| POST | `/api/auth/register` | `{username, password, email?, display_name?, invite_code?}` | `{user}`（同时登录、设置 Cookie；第一个注册的用户自动成为管理员） |
| POST | `/api/auth/login` | `{username, password, remember?: bool}` | `{user}` + Set-Cookie；失败 401；连续失败过多 429 |
| POST | `/api/auth/logout` | – | `{ok:true}` |
| GET | `/api/auth/me` | – | `{user}` |

`user` 对象：`{id, username, display_name, email, role: "admin"|"user", status, created, last_login, settings}`

`settings` 对象：`{default_model, default_mode: "auto"|"code"|"office", default_approval: "auto"|"smart"|"always", theme: "light"|"dark"|"system", custom_instructions: str, notify_on_done: bool}`

## 个人中心 Me
| 方法 | 路径 | 请求 | 响应 |
|---|---|---|---|
| PATCH | `/api/me` | `{display_name?, email?}` | `{user}` |
| POST | `/api/me/password` | `{old_password, new_password}` | `{ok}`（其他设备登录失效） |
| GET | `/api/me/settings` | – | `settings` |
| PUT | `/api/me/settings` | `settings` 的任意子集 | `settings` |
| GET | `/api/me/keys` | – | `[{model, provider, has_key, masked}]` 个人模型 API Key（加密存储） |
| PUT | `/api/me/keys/{model}` | `{api_key, base_url?}` | `{ok}` |
| DELETE | `/api/me/keys/{model}` | – | `{ok}` |
| GET | `/api/me/usage?days=30` | – | `{daily:[{date:"2026-11-22", input_tokens, output_tokens, tasks}], total:{input_tokens, output_tokens, tasks, conversations}, by_model:[{model, input_tokens, output_tokens}]}` |
| GET | `/api/me/devices` | – | `[{id, created, last_seen, user_agent, ip, current}]` |
| DELETE | `/api/me/devices/{id}` | – | `{ok}`（踢下线；id 为 `all_others` 时注销其他所有设备） |

## 配置
| GET | `/api/config` | – | `{models:[{name, model, provider, available, personal_key}], default_model, user, version, features:{web_search}}` |

## 对话 Conversations
| 方法 | 路径 | 请求 | 响应 |
|---|---|---|---|
| GET | `/api/conversations?q=&archived=0&limit=200` | – | `[{id, title, created, updated, pinned, archived, model, mode, running, message_count, snippet?}]`（q 为全文搜索，按 pinned desc, updated desc 排序） |
| GET | `/api/conversations/{id}` | – | `{id, title, todos, history, running, model, mode, usage}` |
| PATCH | `/api/conversations/{id}` | `{title?, pinned?, archived?}` | `{conversation}` |
| DELETE | `/api/conversations/{id}` | – | `{ok}` |
| GET | `/api/conversations/{id}/export?format=md|json|docx` | – | 文件下载 |
| POST | `/api/conversations/{id}/share` | – | `{share_url, token}` |
| DELETE | `/api/conversations/{id}/share` | – | `{ok}` |
| GET | `/api/share/{token}` | – | `{title, history, created}`（公开只读） |
| GET | `/share/{token}` | – | 公开只读分享页（HTML） |

`history` 元素：
- `{role:"user", content}`
- `{role:"assistant", content, tool_calls:[{id, name, arguments, result, is_error}]}`
- `{role:"note", content}`

## 文件（每个用户独立工作区）
| 方法 | 路径 | 请求 | 响应 |
|---|---|---|---|
| GET | `/api/files?path=.` | – | `{path, items:[{name, path, is_dir, size, mtime}]}` |
| GET | `/api/file?path=&download=0` | – | 原始文件 |
| GET | `/api/preview?path=` | – | `{kind: image|html|pdf|table|markdown|code|binary, content?, rows?, total?, ...}` |
| POST | `/api/upload` | multipart: `files[]`, `dir`(默认 uploads) | `{saved:[path]}` |
| DELETE | `/api/files?path=` | – | `{ok}` |
| POST | `/api/files/rename` | `{path, new_name}` | `{path}` |
| POST | `/api/files/mkdir` | `{path}` | `{path}` |
| GET | `/api/files/zip?path=outputs` | – | zip 下载 |
| GET | `/api/files/storage` | – | `{used_bytes, quota_bytes}` |

## 管理员 Admin（role=admin）
| 方法 | 路径 | 请求 | 响应 |
|---|---|---|---|
| GET | `/api/admin/stats` | – | `{users, active_users_7d, conversations, tasks_running, tokens:{input, output}, daily:[{date, tasks, input_tokens, output_tokens}]}` |
| GET | `/api/admin/users` | – | `[user + {conversations, input_tokens, output_tokens, storage_bytes}]` |
| POST | `/api/admin/users` | `{username, password, role?, display_name?, email?}` | `{user}` |
| PATCH | `/api/admin/users/{id}` | `{role?, status?: "active"|"disabled", password?, token_quota?}` | `{user}` |
| DELETE | `/api/admin/users/{id}` | – | `{ok}` |
| GET | `/api/admin/settings` | – | `{allow_registration, invite_code, max_concurrent_tasks_per_user, default_model, storage_quota_mb, enabled_models:[...]}` |
| PUT | `/api/admin/settings` | 上述子集 | 同上 |
| GET | `/api/admin/audit?limit=200` | – | `[{ts, username, action, detail, ip}]` |

## WebSocket `/ws`（Cookie 认证，未登录直接关闭 code=4401）
客户端 → 服务器：
- `{type:"init", conversation_id?}` 绑定/恢复对话（不传则新建草稿对话）
- `{type:"task", content, attachments?:[path], model?, mode?, approval?}`
- `{type:"stop"}` 中断
- `{type:"approval", id, approved, always?}` / `{type:"answer", id, text}`
- `{type:"new"}` 新对话
- `{type:"regenerate"}` 删除最后一轮回复并重新执行最后一条用户消息
- `{type:"edit_last", content}` 修改最后一条用户消息并重新执行
- `{type:"ping"}`

服务器 → 客户端：
- `{type:"ready", conversation_id, title, model, mode, approval, running, history, todos}`
- Agent 事件：`task_start step text_delta thinking_delta assistant_message tool_start tool_end plan_update approval_request approval_result ask_user review subagent_start subagent_end compact status usage done cancelled error`（字段见 README；每个事件带 `depth`）
- `{type:"idle"}` 任务结束
- `{type:"conversation_updated", id, title}` 标题等变化
- `{type:"pong"}`
