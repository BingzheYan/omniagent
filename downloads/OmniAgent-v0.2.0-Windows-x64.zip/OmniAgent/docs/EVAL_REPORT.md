# OmniAgent 评测报告

- **运行模式**：Oracle 脚本轨迹 (MockProvider)
- **总体通过率**：**9/9 (100.0%)**
- **平均得分**：100.0/100
- **总耗时**：10.4s

## 分类汇总

| 类别 | 通过数 / 总数 | 通过率 |
| :--- | :---: | :---: |
| coding | 5/5 | 100.0% |
| office | 4/4 | 100.0% |

## 任务明细

| 任务 ID | 类别 | 状态 | 得分 | 步数 | 耗时 | 核验说明 |
| :--- | :---: | :---: | :---: | :---: | :---: | :--- |
| `coding_expr_evaluator` | coding | PASS | 100.0 | 7 | 0.3s | 35 passed in 0.07s |
| `coding_interval_scheduler` | coding | PASS | 100.0 | 23 | 0.3s | 37 passed in 0.07s |
| `coding_lru_ttl_cache` | coding | PASS | 100.0 | 8 | 0.3s | 32 passed in 0.14s |
| `coding_multi_file_refactor` | coding | PASS | 100.0 | 9 | 0.3s | 65 passed in 0.12s |
| `coding_pandas_pipeline_debug` | coding | PASS | 100.0 | 8 | 1.1s | 6 passed in 0.32s |
| `office_doc_rewrite` | office | PASS | 100.0 | 6 | 0.2s | 文档修订核验通过：原稿完好无损，修订版 check_document=100/100，全部事实数字保留且口语化表达清零，回复包含 4 条修订说明。 |
| `office_excel_merge` | office | PASS | 100.0 | 6 | 0.7s | Excel 清洗合并核验通过：共 3 个工作表，唯一有效订单 11 笔，销售总额 669,900.50 元与真值完全一致。 |
| `office_fiscal_paper` | office | PASS | 100.0 | 8 | 5.2s | 财政论文核验通过：check_document=100/100，图 4 幅，表 6 张，基准双向FE系数=0.343*** 与面板真值完全吻合。 |
| `office_sales_report` | office | PASS | 100.0 | 8 | 1.8s | 报告核验通过：check_document=100/100，内嵌图 2 幅，表 2 张，核心指标与真值一致。 |
