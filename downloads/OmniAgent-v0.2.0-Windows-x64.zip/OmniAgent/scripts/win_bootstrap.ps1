﻿param(
    [Parameter(Position = 0)]
    [string]$Mode = "desktop",
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$ExtraArgs
)

$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8

$Root = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
Set-Location -LiteralPath $Root

# 严格屏蔽宿主环境 ANTHROPIC_* 凭据，仅使用 DeepSeek 或用户显式配置的模型
Remove-Item Env:ANTHROPIC_AUTH_TOKEN -ErrorAction SilentlyContinue
Remove-Item Env:ANTHROPIC_API_KEY -ErrorAction SilentlyContinue
Remove-Item Env:ANTHROPIC_BASE_URL -ErrorAction SilentlyContinue
$env:PYTHONUTF8 = "1"
$env:PYTHONIOENCODING = "utf-8"

function Write-Step([string]$Msg) {
    Write-Host "[OmniAgent] $Msg" -ForegroundColor Cyan
}

function Test-Python310Plus([string]$Exe, [string[]]$PrefixArgs = @()) {
    try {
        if (-not $Exe) { return $false }
        if ($Exe -like "*WindowsApps*") { return $false }
        $out = & $Exe @PrefixArgs -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}' if sys.version_info >= (3,10) else 'OLD')" 2>$null
        if ($LASTEXITCODE -eq 0 -and $out -and ($out.Trim() -ne "OLD")) {
            return $true
        }
    } catch {}
    return $false
}

function Find-SystemPython {
    foreach ($ver in @("-3.12", "-3.11", "-3.13", "-3.10", "-3")) {
        $pyLauncher = Get-Command py -ErrorAction SilentlyContinue
        if ($pyLauncher -and (Test-Python310Plus $pyLauncher.Source @($ver))) {
            return @{ Exe = $pyLauncher.Source; Args = @($ver) }
        }
    }
    foreach ($cmdName in @("python", "python3")) {
        $cmd = Get-Command $cmdName -ErrorAction SilentlyContinue
        if ($cmd -and (Test-Python310Plus $cmd.Source)) {
            return @{ Exe = $cmd.Source; Args = @() }
        }
    }
    $searchDirs = @(
        "$env:LOCALAPPDATA\Programs\Python",
        "$env:ProgramFiles\Python*",
        "C:\Python*",
        "$env:USERPROFILE\miniconda3",
        "$env:USERPROFILE\anaconda3",
        "C:\ProgramData\miniconda3",
        "C:\ProgramData\anaconda3"
    )
    foreach ($pat in $searchDirs) {
        $dirs = Get-ChildItem -Path $pat -Directory -ErrorAction SilentlyContinue | Sort-Object Name -Descending
        foreach ($d in $dirs) {
            $cand = Join-Path $d.FullName "python.exe"
            if ((Test-Path $cand) -and (Test-Python310Plus $cand)) {
                return @{ Exe = $cand; Args = @() }
            }
            $subDirs = Get-ChildItem -Path $d.FullName -Filter "Python3*" -Directory -ErrorAction SilentlyContinue | Sort-Object Name -Descending
            foreach ($sd in $subDirs) {
                $cand2 = Join-Path $sd.FullName "python.exe"
                if ((Test-Path $cand2) -and (Test-Python310Plus $cand2)) {
                    return @{ Exe = $cand2; Args = @() }
                }
            }
        }
    }
    return $null
}

function Install-Python312 {
    Write-Step "未检测到 Python 3.10+，正在自动为当前 Windows 安装 Python 3.12..."
    $winget = Get-Command winget -ErrorAction SilentlyContinue
    if ($winget) {
        try {
            & $winget.Source install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
            $env:Path = [System.Environment]::GetEnvironmentVariable("Path", "User") + ";" + [System.Environment]::GetEnvironmentVariable("Path", "Machine")
            $found = Find-SystemPython
            if ($found) { return $found }
        } catch {
            Write-Host "winget 安装未完成，切换至官方安装包直连下载..." -ForegroundColor Yellow
        }
    }
    $arch = if ([Environment]::Is64BitOperatingSystem) { "amd64" } else { "win32" }
    $installer = Join-Path $env:TEMP "python-3.12.8-$arch.exe"
    $urls = @(
        "https://registry.npmmirror.com/-/binary/python/3.12.8/python-3.12.8-$arch.exe",
        "https://www.python.org/ftp/python/3.12.8/python-3.12.8-$arch.exe"
    )
    $downloaded = $false
    foreach ($u in $urls) {
        try {
            Write-Step "正在下载 Python 3.12 安装程序: $u"
            Invoke-WebRequest -Uri $u -OutFile $installer -UseBasicParsing -TimeoutSec 180
            if ((Test-Path $installer) -and ((Get-Item $installer).Length -gt 10000000)) {
                $downloaded = $true
                break
            }
        } catch {}
    }
    if (-not $downloaded) {
        throw "自动下载 Python 失败，请访问 https://www.python.org/downloads/ 安装 Python 3.12（勾选 Add python.exe to PATH）后重新双击运行。"
    }
    Write-Step "正在静默安装 Python 3.12（仅当前用户，无需管理员权限）..."
    $p = Start-Process -FilePath $installer -ArgumentList "/quiet InstallAllUsers=0 PrependPath=1 Include_test=0 Include_launcher=1" -Wait -PassThru
    Remove-Item $installer -Force -ErrorAction SilentlyContinue
    $env:Path = [System.Environment]::GetEnvironmentVariable("Path", "User") + ";" + [System.Environment]::GetEnvironmentVariable("Path", "Machine")
    $found2 = Find-SystemPython
    if (-not $found2) {
        throw "Python 安装后仍未检测到解释器（退出码 $($p.ExitCode)），请重新打开终端或重启电脑后再试。"
    }
    return $found2
}

function Ensure-Venv {
    $venvDir = Join-Path $Root ".venv"
    $venvPy = Join-Path $venvDir "Scripts\python.exe"
    $marker = Join-Path $venvDir ".omni_win_ready"

    # 若存在残余的 macOS/Linux .venv（含 bin/python 而无 Scripts\python.exe），自动清理重建
    if ((Test-Path $venvDir) -and (-not (Test-Path $venvPy))) {
        Write-Step "检测到非 Windows 虚拟环境目录（可能来自 macOS），正在自动清理并重建 Windows 虚拟环境..."
        Remove-Item -LiteralPath $venvDir -Recurse -Force
    }

    $ready = $false
    if ((Test-Path $venvPy) -and (Test-Path $marker)) {
        try {
            & $venvPy -c "import omniagent, fastapi, uvicorn, openai, httpx, pandas, openpyxl, docx, pptx, fitz" 2>$null
            if ($LASTEXITCODE -eq 0) { $ready = $true }
        } catch {}
    }

    if (-not $ready) {
        $sysPy = Find-SystemPython
        if (-not $sysPy) {
            $sysPy = Install-Python312
        }
        if (-not (Test-Path $venvPy)) {
            Write-Step "正在创建 Windows 独立虚拟环境 (.venv)..."
            & $sysPy.Exe @($sysPy.Args) -m venv $venvDir
            if (-not (Test-Path $venvPy)) {
                throw "创建 .venv 失败，请检查磁盘空间与目录读写权限。"
            }
        }
        Write-Step "正在安装 OmniAgent 及其依赖包（首次运行约需 1-2 分钟，请稍候）..."
        $mirrors = @(
            @("-i", "https://pypi.tuna.tsinghua.edu.cn/simple", "--trusted-host", "pypi.tuna.tsinghua.edu.cn"),
            @("-i", "https://mirrors.aliyun.com/pypi/simple/", "--trusted-host", "mirrors.aliyun.com"),
            @()
        )
        $installed = $false
        foreach ($m in $mirrors) {
            try {
                & $venvPy -m pip install --upgrade pip @m | Out-Host
                & $venvPy -m pip install -e $Root @m | Out-Host
                if ($LASTEXITCODE -eq 0) {
                    $installed = $true
                    break
                }
            } catch {}
        }
        if (-not $installed) {
            throw "依赖包安装失败，请检查网络连接后重试。"
        }
        Set-Content -LiteralPath $marker -Value (Get-Date -Format "o") -Encoding UTF8
        Write-Host "[OmniAgent] Windows 环境配置完成！" -ForegroundColor Green
    }

    $envFile = Join-Path $Root ".env"
    $envExample = Join-Path $Root ".env.example"
    if ((-not (Test-Path $envFile)) -and (Test-Path $envExample)) {
        Copy-Item -LiteralPath $envExample -Destination $envFile
    }
    return $venvPy
}

function Create-DesktopShortcut {
    try {
        $desk = [Environment]::GetFolderPath("Desktop")
        $lnkPath = Join-Path $desk "OmniAgent.lnk"
        $vbsTarget = Join-Path $Root "启动桌面端(无黑框).vbs"
        if (-not (Test-Path $vbsTarget)) {
            $vbsTarget = Join-Path $Root "启动桌面端.bat"
        }
        $wsh = New-Object -ComObject WScript.Shell
        $sc = $wsh.CreateShortcut($lnkPath)
        $sc.TargetPath = $vbsTarget
        $sc.WorkingDirectory = $Root
        $sc.Description = "OmniAgent 自主执行型 AI 智能体工作台"
        $edgeIcon = "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe"
        if (Test-Path $edgeIcon) {
            $sc.IconLocation = "$edgeIcon,0"
        }
        $sc.Save()
        Write-Step "已在 Windows 桌面生成快捷方式: $lnkPath"
    } catch {}
}

function Get-FreePort([int[]]$Preferred = @(8765, 8766, 8767, 0)) {
    foreach ($p in $Preferred) {
        $listener = $null
        try {
            $listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $p)
            $listener.Start()
            $actual = ([System.Net.IPEndPoint]$listener.LocalEndpoint).Port
            $listener.Stop()
            return $actual
        } catch {
            if ($listener) { try { $listener.Stop() } catch {} }
        }
    }
    return 8765
}

try {
    $VenvPy = Ensure-Venv
    $DemoData = Join-Path $Root "demo_data"
    $DataArgs = if (Test-Path $DemoData) { @("--data-dir", $DemoData) } else { @() }

    switch ($Mode.ToLower()) {
        "setup" {
            & $VenvPy -m omniagent desktop --build-app dist
            Create-DesktopShortcut
            Write-Step "正在执行功能自检..."
            & $VenvPy -m omniagent --version
            & $VenvPy -m omniagent models
            & $VenvPy -m omniagent agents
            Write-Host "`n✅ OmniAgent Windows 版环境就绪！可直接双击「启动桌面端.bat」或桌面「OmniAgent」快捷方式启动。" -ForegroundColor Green
        }
        "web" {
            $Port = Get-FreePort
            $Url = "http://127.0.0.1:$Port"
            Write-Step "正在启动 OmniAgent Web 工作台 -> $Url ..."
            Start-Job -ScriptBlock {
                param($u)
                for ($i = 0; $i -lt 30; $i++) {
                    Start-Sleep -Milliseconds 500
                    try {
                        $r = Invoke-WebRequest -Uri "$u/api/health" -UseBasicParsing -TimeoutSec 1
                        if ($r.StatusCode -eq 200) {
                            Start-Process $u
                            break
                        }
                    } catch {}
                }
            } -ArgumentList $Url | Out-Null
            & $VenvPy -m omniagent web -m deepseek --host 127.0.0.1 --port $Port @DataArgs @ExtraArgs
        }
        "cli" {
            Write-Step "正在进入 OmniAgent 交互式终端（输入 /exit 退出）..."
            & $VenvPy -m omniagent chat -m deepseek @ExtraArgs
        }
        default {
            Write-Step "正在启动 OmniAgent Windows 桌面端..."
            & $VenvPy -m omniagent desktop -m deepseek @DataArgs @ExtraArgs
        }
    }
} catch {
    Write-Host "`n[OmniAgent 启动出错] $($_.Exception.Message)" -ForegroundColor Red
    if ($Host.Name -eq "ConsoleHost") {
        Read-Host "按回车键退出"
    }
    exit 1
}
