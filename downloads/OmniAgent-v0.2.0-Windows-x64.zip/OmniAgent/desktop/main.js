// OmniAgent 跨平台 Electron 桌面主进程（支持 Windows / macOS / Linux）
const { app, BrowserWindow, shell } = require("electron");
const { spawn } = require("child_process");
const net = require("net");
const fs = require("fs");
const path = require("path");
const http = require("http");

let backend = null;
let mainWindow = null;

function getFreePort() {
  return new Promise((resolve, reject) => {
    const srv = net.createServer();
    srv.listen(0, "127.0.0.1", () => {
      const port = srv.address().port;
      srv.close(() => resolve(port));
    });
    srv.on("error", reject);
  });
}

function waitReady(url, timeoutMs = 15000) {
  const start = Date.now();
  return new Promise((resolve, reject) => {
    const check = () => {
      http.get(url, (res) => {
        if (res.statusCode === 200) resolve();
        else retry();
      }).on("error", retry);
    };
    const retry = () => {
      if (Date.now() - start > timeoutMs) reject(new Error("OmniAgent 后端启动超时"));
      else setTimeout(check, 150);
    };
    check();
  });
}

async function createWindow() {
  const port = await getFreePort();
  const root = path.resolve(__dirname, "..");
  const venvPy = path.join(root, ".venv", process.platform === "win32" ? "Scripts\\python.exe" : "bin/python");
  const py = process.env.OMNI_PYTHON || (fs.existsSync(venvPy) ? venvPy : "python");
  const env = { ...process.env, PYTHONUTF8: "1", PYTHONIOENCODING: "utf-8" };
  delete env.ANTHROPIC_AUTH_TOKEN;
  delete env.ANTHROPIC_API_KEY;
  delete env.ANTHROPIC_BASE_URL;
  const args = ["-m", "omniagent", "web", "-m", "deepseek", "--host", "127.0.0.1", "--port", String(port)];
  const demoData = path.join(root, "demo_data");
  if (fs.existsSync(demoData)) {
    args.push("--data-dir", demoData);
  }

  backend = spawn(py, args, {
    cwd: root,
    env,
    stdio: "inherit",
  });

  await waitReady(`http://127.0.0.1:${port}/api/health`);

  mainWindow = new BrowserWindow({
    width: 1440,
    height: 920,
    minWidth: 960,
    minHeight: 640,
    backgroundColor: "#0d1117",
    title: "OmniAgent",
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  mainWindow.loadURL(`http://127.0.0.1:${port}/`);
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: "deny" };
  });
}

app.whenReady().then(createWindow);

app.on("window-all-closed", () => {
  if (backend) backend.kill();
  app.quit();
});

app.on("before-quit", () => {
  if (backend) backend.kill();
});
