# OmniAgent v0.2 · 自主执行型 AI 智能体系统

> 对标 **Claude Code / Codex / WorkBuddy** 的全栈自主执行型 AI 智能体平台：
> 用户只需提出目标，系统自动完成 **理解目标 → 拆解计划 → 委派专业子智能体 → 读取外部软件/数据库/网页 → 编写与运行代码 → 统计计量建模 → 图表绘制与视觉核查 → 学术论文/报告生成 → 逐项自检修正**，直到交付。

三种客户端形态，共用同一自主执行内核：

| 形态 | 启动方式 | 适用场景与核心体验 |
|---|---|---|
| 🖥 **电脑桌面端（Desktop）** | Windows 双击 `启动桌面端.bat` / `启动桌面端(无黑框).vbs`；macOS 双击 `启动桌面端.command` / `dist/OmniAgent.app`；或命令行 `omni desktop` | macOS 原生 `WKWebView` 窗口 / Windows 独立 Edge·Chrome App 窗口、免密本机自动登录、本机应用与剪贴板联动 |
| 🌐 **Web 工作台（Workbench）** | `omni web` → `http://127.0.0.1:8765` | Claude Code / Codex 风格深色三栏工作台、**实时思维链（CoT）轨迹**、**`N files changed +A -R [Review]` 变更卡片**、**可拖拽伸缩的 Diff 审阅与在线代码编辑侧边栏**、多用户登录/历史搜索/分享导出/管理后台 |
| ⌨️ **命令行终端（CLI）** | `omni` / `omni run "任务"` | 极客终端流式交互、彩色 Diff、审批确认、子智能体与评测基准调用 |

---

## ✨ 核心架构与能力矩阵

### 1. Claude Code / Codex 级自主执行内核（`omniagent/agent/`）
- **闭环自主循环**：ReAct 循环 + **完成前强制自检（Self-Review）** + **死循环检测（Doom-Loop Detector）** + **长上下文智能瘦身与摘要压缩**。
- **精确文件编辑保障**：强制“先读后改（Read-Before-Edit）”+ 磁盘时间戳防陈旧检查（Stale Check）+ 唯一性空白/缩进容错匹配（Fuzzy Match）+ 逐行 Unified Diff 统计。
- **多模态视觉自检（`view_image`）**：智能体可亲自“看”自己生成的统计图、网页截图与论文排版页，自动发现文字遮挡、乱码或排版瑕疵并重绘。
- **实时思维链与文件变更追踪**：完整流式推送并持久化每一步 `thinking` 思维链、子智能体状态（`Started ∷ ...` / `Completed ∷ ...`）与 `file_changes` 统计。

### 2. 配齐的专业智能体与并行子智能体体系（Agents & Subagents）
通过 `omni agents` 或界面顶栏 **「🤖 智能体」** 查看、切换主智能体或创建自定义智能体；主智能体可通过 `delegate_task` 或 **`delegate_parallel`（并行多子智能体）** 协同调度：
- `general`（◆ 全能主控智能体）：任务拆解、多子智能体编排与整体交付核验
- `coder`（💻 软件架构与开发工程师）：复现 → 根因定位 → 最小改动 → 回归测试
- `researcher`（🔎 代码库与资料调研专家）：只读高速检索代码库、网页与外部数据源
- `analyst`（📊 数据科学与计量经济分析师）：Python 内核、面板固定效应/DID/稳健性回归与学术绘图
- `writer`（🖋 学术论文与公文报告主笔）：《财政研究》等期刊级论文、GB/T 9704 党政公文、商业报告
- `connector`（🔌 外部应用与网页连接专家）：跨软件 API、数据库、MCP 与动态网页数据提取
- `reviewer`（🛡 质量与安全审查员）：独立测试运行、`check_document` 规范打分与图表视觉审查
- **自定义智能体**：支持在界面创建，或放置于 `~/.omniagent/agents/*.md` 与 `<workspace>/.omniagent/agents/*.md`。

### 3. 外部软件自主发现、双向读写联动与持续追踪中心（Autonomous External Actions & Connectors）
不仅支持人工预配置，智能体还可通过 `connector_manage(action="discover" | "register")` **自主探测 OpenAPI/Swagger 接口规范并动态接入外部软件**，并内置 **9 类双向外部系统协议**与持续状态追踪：
1. **`email`（`email_ops` 双向邮件自动化）**：连接 IMAP/SMTP 邮箱（或本地沙箱邮箱），自动读取未读邮件、提取附件、草拟或发送保持 `In-Reply-To / References` 线程的回复，并自动开启后续回信动态追踪。
2. **`calendar`（`calendar_ops` 日历排期与防冲突提醒）**：支持 CalDAV 与 RFC 5545 `.ics` 标准，自动核查会议冲突、创建/改期活动、设置提前提醒并导出 `.ics` 邀请函。
3. **`web_app` & `browser_session`（有状态交互式网页操作与投递）**：跨步保持登录 Cookie、解析表单字段 `[e1]..[eN]`、结合长期记忆个人履历针对不同岗位定制 Cover Letter（Word/PDF）、自动填写申请信息、挂载简历文件并投递（对求职系统、企业 OA、CRM、工单系统通用）。
4. **`http_api` / `graphql` / `webhook`**：对接任意 REST、GraphQL、飞书/钉钉/企微/Slack 机器人接口（高风险外发与写操作在 `smart` 审批模式下自动触发人工确认门控）。
5. **`sqlite` / `local_folder` / `mcp` / `desktop_inspect` & `desktop_action`**：数据库读写、外部目录导入导出、标准 MCP 工具服务及本机系统提醒通知/剪贴板联动。
6. **`tracker_manage`（跨会话外部事项持续追踪器）**：持久化追踪邮件往来回信、求职投递流水线、日程到期提醒与外部 API 状态异动。

### 4. 学术科研（《财政研究》/《财政科学》标准）与办公文档流水线
- **9 大内置专业技能（`omni skills` / `load_skill`）**：`fiscal-paper`（财税实证论文全流程规范）、`data-analysis-report`、`official-document`（GB/T 9704 党政机关公文红头模板）、`presentation`、`debugging`、`code-review`、`new-project`。
- **计量与学术图表库（`omniagent.research`）**：`academic_style()` 中文字体与期刊配色、`describe_table()`、`corr_table()`、`vif_table()`、`regtable()`（支持 `statsmodels` OLS/WLS 与 `linearmodels` 双向固定效应 `PanelOLS` 三线表）、`event_study_plot()`（平行趋势图）与 `coef_plot()`。
- **国标学术排版与 PPT/PDF 原地改写（`create_document` / `edit_presentation` / `pdf_ops`）**：支持《财政研究》级三线表与双格式论文输出；支持对已有 `.pptx` 批量替换文案、增删修改指定页幻灯片；支持 `.pdf` 合并、拆分提取、斜向水印/页眉加盖与交互式 AcroForm 表单自动填报。
- **交付前全链路实测验收引擎（`verify_deliverable` + `check_document`）**：对代码工程扫描 AST 语法与单测；对 Web/API 应用自动分配空闲沙箱端口真实拉起服务、并发探测路由状态与截图验收；对 Word/PPT/Excel/PDF 校验零空页、零公式错误（`#REF!`/`#DIV/0!`）与版面完整性。
- 示例成品见 [`examples/sample_fiscal_paper.docx`](examples/sample_fiscal_paper.docx) 与 [`examples/sample_fiscal_paper.pdf`](examples/sample_fiscal_paper.pdf)。

### 5. 多维长期记忆、动态用户画像与在办文稿连续性（Long-Term Memory & Persona Studio）
通过左侧栏 **「记忆与画像」** 或命令行 `omni memory` 管理（多用户物理隔离存储于 `<workspace>/.omniagent/memory.db`，SQLite WAL + FTS5 + CJK 二/三元组混合检索，自动对 API Key / 密码脱敏）：
- **6 大维度用户画像（User Persona Portrait）**：从日常指令、审改纠错与高频工具使用统计中自动描绘**身份背景与业务领域**、**公文与正式文书规范**（如 GB/T 9704 二号小标宋/三号仿宋）、**学术论文与期刊体例**（如《财政研究》三线表、括号聚类稳健标准误）、**写作风格与表达禁忌**、**编程架构与工程习惯**、**数据口径与协作工作流**（如金额单位亿元/万元、小数位数、双格式交付）。
- **跨会话在办工作与文稿连续性（Ongoing Projects）**：针对同一篇论文、研究报告、公文或代码工程，自动汇总记录 **已完成内容（`completed_items`）**、**待完善事项（`pending_items`，源自未完计划、`check_document` 质检项、用户“后面再补充…”指令及后续建议）**、**跨轮锁定口径（`key_facts`）** 与关联文件，支持一键续写并在完成后自动核销待办。
- **原子长期记忆库与冲突演化**：支持 `format_spec`、`correction`、`preference`、`domain_fact`、`episodic` 五类记忆；当用户习惯改变时按 `topic_key` 自动覆盖旧规则，并在每轮新对话开始时动态注入系统提示词；同时提供 `memory_upsert`、`memory_search`、`memory_delete`、`portrait_update`、`project_memory` 5 项智能体主动记忆工具。

### 6. 智能报销与需登录业务系统的真实浏览器操作（Expense & Web Automation）
- **`expense_reimburse`**：上传票据或直接给出本机路径（如 `~/Downloads/11月报销`），自动识别增值税/全电发票（PDF/OFD/XML/扫描件与照片——macOS 系统 Vision 离线 OCR）、铁路电子客票、航空行程单、网约车行程单、酒店水单、支付凭证、出差审批单与费用清单；检查材料齐全性（打车发票需行程单、差旅需审批单等）、重复/历史已报销发票、金额 + 税额 = 价税合计、大小写一致、抬头税号、出差期间、住宿与餐饮标准；输出 **报销单 Excel、金额核对报告、报销内容审核报告（md + docx）、按序号重命名的附件包与网页填报数据**。识别存疑时智能体会亲自查看原件，用 `overrides / manual_items / exclude` 更正后重算——工具只提供证据，判断由智能体根据实际情况做出。
- **`web_automation`**：Playwright 驱动本机 Chrome（登录态按系统持久保存），可操作报销 / OA / ERP / CRM / 招聘等 JS 渲染的业务系统，支持 iframe 内表单、自定义下拉、附件上传、表格读取。**遇到登录页会在对话中弹出「🔐 需要你登录」卡片 + 系统通知，并把浏览器窗口置前，由用户亲自登录**（不代填密码、不绕过验证码），检测到登录成功或用户点击「我已完成登录」后才继续；最终提交在任何审批策略下都需用户确认。
- **工作台右侧「操作」栏**：凡是接入外部系统/应用的步骤（网页、邮箱、日历、连接器、报销核对等）都会实时同步到该栏——直播式页面截图、网址、动作、填写字段、耗时与成功/失败状态，可回看任意一步，对话切换与刷新后完整恢复。
- 内置技能 `expense-reimbursement` 只规定交付标准与判断原则，不写死操作流程。

### 7. 完整多用户应用能力
- **账号与安全**：首个注册用户自动成为管理员；`scrypt` 密码哈希、登录防暴力限流、设备会话管理与远程踢下线、个人模型 API Key 加密存储。
- **历史对话管理**：SQLite FTS5 全文搜索、置顶/归档/重命名、Markdown / JSON / Word 导出、公开只读分享页（`/share/{token}`）、重新生成与编辑重发。
- **管理员后台（`#/admin`）**：全站活跃与 Token 统计图表、用户启停/角色/月度配额管理、注册开关与邀请码、操作审计日志。

---

## 🚀 快速开始

### Windows 一键启动（开箱即用）
1. 解压 `OmniAgent.zip` 到任意目录（如桌面 `OmniAgent` 文件夹）。
2. 直接双击 **`启动桌面端.bat`**（或 **`启动桌面端(无黑框).vbs`** / **`启动Web工作台.bat`**）：
   - 首次运行会自动检测/安装 Python 3.12、创建 Windows 独立 `.venv` 虚拟环境并安装全部依赖；
   - 如需自检或生成桌面快捷方式，可双击 **`环境安装与自检.bat`**。

### macOS / Linux 命令行启动

```bash
cd ~/.gemini/antigravity/scratch/omniagent
source .venv/bin/activate

# 1. 启动电脑桌面端（macOS 原生窗口，自动登录）
omni desktop
# 或构建可双击运行的 macOS 应用包 dist/OmniAgent.app：
omni desktop --build-app

# 2. 启动 Web 工作台（Claude Code / Codex 深色布局）
omni web --port 8765              # 配置真实模型 Key 后使用
omni web -m mock --port 8765      # 无 API Key 时使用离线模拟模型体验全部界面与工具链

# 3. 命令行模式与管理命令
omni                              # 交互式编程/办公终端
omni --agent coder run "修复 bug 并跑通测试" -y
omni agents                       # 查看所有智能体与子智能体
omni skills                       # 查看所有专业技能包
omni connectors                   # 查看已配置的外部连接器
omni user list                    # 管理 Web 用户

# 4. 运行自动化能力评测基准（5 项复杂编程 + 4 项办公与财政科研论文）
omni eval --oracle                # 使用内置标准轨迹离线验证全套工具与评分器
pytest -q                         # 运行完整单元测试与集成测试套件
```
