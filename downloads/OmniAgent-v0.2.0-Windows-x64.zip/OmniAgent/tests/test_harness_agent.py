"""Harness：防死循环、系统提示词稳定性（提示缓存）、工作区快照、后台进程管理、配置。"""
import asyncio
import shutil
import subprocess
import sys

import pytest

from omniagent.agent import Agent
from omniagent.agent.context import workspace_snapshot
from omniagent.agent.core import LoopDetector
from omniagent.config import ModelProfile, Settings, load_settings, profile_with_key
from omniagent.llm.mock_provider import MockProvider
from omniagent.llm.types import LLMResponse, Message, ToolCall
from omniagent.tools import ToolContext, ToolError, build_default_registry
from omniagent.tools.shell import cleanup_background


class RecordingMock(MockProvider):
    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.systems: list[str] = []

    async def _complete(self, system, messages, tools, on_delta):
        self.systems.append(system)
        return await super()._complete(system, messages, tools, on_delta)


def make_agent(tmp_path, script, **kw):
    events = []

    async def on_event(e):
        events.append(e)

    llm = RecordingMock(ModelProfile("mock", "mock", "mock"), script)
    return Agent(llm, Settings(), tmp_path, on_event=on_event, **kw), llm, events


# ---------------------------------------------------------------- 防死循环
async def test_repeated_failures_trigger_reminder(tmp_path):
    bad = {"path": "missing.txt"}
    script = [LLMResponse("", [ToolCall(str(i), "read_file", bad)]) for i in range(3)]
    script.append(lambda msgs: LLMResponse("换思路" if "陷入了循环" in msgs[-1].content else "??", []))
    agent, llm, events = make_agent(tmp_path, script)
    assert await agent.run("读文件") == "换思路"
    warn = [e for e in events if e["type"] == "loop_warning"]
    assert len(warn) == 1 and "连续失败 3 次" in warn[0]["reason"]
    reminder = [m for m in agent.messages if m.meta.get("loop_warning")]
    assert reminder and reminder[0].role == "user" and "<system-reminder>" in reminder[0].content


async def test_identical_successful_calls_trigger_reminder(tmp_path):
    script = [LLMResponse("", [ToolCall(str(i), "list_dir", {"path": "."})]) for i in range(4)]
    script.append(LLMResponse("done", []))
    agent, _, events = make_agent(tmp_path, script)
    await agent.run("看目录")
    warn = [e for e in events if e["type"] == "loop_warning"]
    assert len(warn) == 1 and "重复 4 次" in warn[0]["reason"]


async def test_varied_calls_do_not_trigger(tmp_path):
    script = [LLMResponse("", [ToolCall(str(i), "read_file", {"path": f"m{i}.txt"})]) for i in range(5)]
    script.append(LLMResponse("done", []))
    agent, _, events = make_agent(tmp_path, script)
    await agent.run("x")
    assert not [e for e in events if e["type"] == "loop_warning"]


def test_loop_detector_unit():
    d = LoopDetector()
    ok = Message("tool", "ok")
    err = Message("tool", "err", is_error=True)
    tc = ToolCall("1", "run_shell", {"command": "pytest"})
    assert d.observe([tc], [err]) is None
    assert d.observe([tc], [err]) is None
    assert "连续失败" in d.observe([tc], [err])
    assert d.history == []  # 触发后重置
    # 失败中间夹着一次成功 → 不算连续失败
    for res in (err, ok, err):
        assert d.observe([tc], [res]) is None
    # 一次回复中的并行调用也会计入
    d.reset()
    calls = [ToolCall(str(i), "glob", {"pattern": "*.py"}) for i in range(4)]
    assert "重复 4 次" in d.observe(calls, [ok] * 4)


# ---------------------------------------------------------------- 系统提示词稳定 + 工作区快照
async def test_system_prompt_stable_within_run(tmp_path):
    (tmp_path / "pyproject.toml").write_text("[project]\nname='x'\n")
    script = [
        LLMResponse("", [ToolCall("1", "write_file", {"path": "new_dir/a.txt", "content": "a"})]),
        LLMResponse("", [ToolCall("2", "list_dir", {})]),
        LLMResponse("完成", []),
        LLMResponse("确认完成", []),
    ]
    agent, llm, _ = make_agent(tmp_path, script)
    await agent.run("x")
    assert len(llm.systems) == 4 and len(set(llm.systems)) == 1
    sp = llm.systems[0]
    assert "工作区快照" in sp and "pyproject.toml" in sp
    assert "new_dir" not in sp  # 快照在任务开始时采集
    # 下一次 run 会重新采集
    llm.script = [LLMResponse("ok", [])]
    await agent.run("y")
    assert "new_dir/" in llm.systems[-1]


@pytest.mark.skipif(shutil.which("git") is None, reason="需要 git")
def test_workspace_snapshot_git(tmp_path):
    def git(*a):
        subprocess.run(["git", *a], cwd=tmp_path, check=True, capture_output=True)

    git("init", "-q", "-b", "main")
    git("config", "user.email", "t@example.com")
    git("config", "user.name", "t")
    (tmp_path / "package.json").write_text("{}")
    (tmp_path / "README.md").write_text("# x")
    git("add", ".")
    git("commit", "-q", "-m", "init project")
    (tmp_path / "dirty.py").write_text("x")
    for i in range(45):
        (tmp_path / f"f{i:02d}.txt").write_text("x")
    snap = workspace_snapshot(tmp_path)
    assert "Git 分支: main" in snap
    assert "init project" in snap
    assert "?? dirty.py" in snap and "另有" in snap  # status 截断到 30 行
    assert "package.json" in snap and "README.md" in snap
    assert "共 4" in snap  # 顶层目录超过 40 项时截断


def test_workspace_snapshot_non_git(tmp_path):
    (tmp_path / "go.mod").write_text("module x")
    snap = workspace_snapshot(tmp_path)
    assert "Git" not in snap and "go.mod" in snap


# ---------------------------------------------------------------- 后台进程
async def test_process_tool_lifecycle(tmp_path):
    async def noop(e):
        return None

    ctx = ToolContext(tmp_path.resolve(), Settings(), noop)
    reg = build_default_registry(Settings())
    proc_tool = reg.get("process")
    assert "没有后台进程" in (await proc_tool.run({"action": "list"}, ctx)).content
    code = "import time\nfor i in range(1000):\n    print('tick', i, flush=True)\n    time.sleep(0.1)\n"
    (tmp_path / "loop.py").write_text(code)
    r = await reg.get("run_shell").run({"command": f"{sys.executable} loop.py", "background": True}, ctx)
    pid = r.data["pid"]
    assert "process(action='output'" in r.content
    try:
        lst = (await proc_tool.run({"action": "list"}, ctx)).content
        assert str(pid) in lst and "运行中" in lst
        await asyncio.sleep(0.5)
        out = (await proc_tool.run({"action": "output", "pid": pid, "lines": 3}, ctx)).content
        assert "tick" in out and "最后 3 行" in out
        # 只有一个进程时 pid 可省略
        assert "tick" in (await proc_tool.run({"action": "output"}, ctx)).content
        with pytest.raises(ToolError):
            await proc_tool.run({"action": "output", "pid": 1}, ctx)
        k = (await proc_tool.run({"action": "kill", "pid": pid}, ctx)).content
        assert "已停止" in k
        assert "没有后台进程" in (await proc_tool.run({"action": "list"}, ctx)).content
    finally:
        await cleanup_background(ctx.state)


# ---------------------------------------------------------------- 配置
def test_claude_auth_token_availability(monkeypatch):
    s = load_settings()
    assert not s.models["claude"].available
    monkeypatch.setenv("ANTHROPIC_AUTH_TOKEN", "tok-test")
    monkeypatch.setenv("ANTHROPIC_BASE_URL", "http://proxy.invalid")
    s = load_settings()
    c = s.models["claude"]
    assert c.available and c.resolve_auth_token() == "tok-test" and c.resolve_api_key() is None
    assert c.resolve_base_url() == "http://proxy.invalid"
    assert s.get_model("auto").name == "claude"


def _capture_anthropic(monkeypatch):
    import omniagent.llm.anthropic_provider as ap

    captured = {}

    class FakeClient:
        def __init__(self, **kw):
            captured.update(kw)

    monkeypatch.setattr(ap, "AsyncAnthropic", FakeClient)
    return ap, captured


def test_anthropic_provider_uses_auth_token(monkeypatch):
    ap, captured = _capture_anthropic(monkeypatch)
    monkeypatch.setenv("ANTHROPIC_AUTH_TOKEN", "tok-test")
    monkeypatch.setenv("ANTHROPIC_BASE_URL", "http://proxy.invalid")
    prof = load_settings().models["claude"]
    ap.AnthropicProvider(prof)
    assert captured.get("auth_token") == "tok-test" and "api_key" not in captured
    assert captured["base_url"] == "http://proxy.invalid"


def test_profile_with_key_overrides_env_token(monkeypatch):
    ap, captured = _capture_anthropic(monkeypatch)
    monkeypatch.setenv("ANTHROPIC_AUTH_TOKEN", "tok-test")
    base = load_settings().models["claude"]
    personal = profile_with_key(base, "sk-user", base_url="https://api.anthropic.com")
    assert personal is not base and base.api_key is None
    assert personal.available and personal.resolve_auth_token() is None
    ap.AnthropicProvider(personal)
    assert captured.get("api_key") == "sk-user" and "auth_token" not in captured
    assert captured["base_url"] == "https://api.anthropic.com"
    ds = profile_with_key(load_settings().models["deepseek"], "sk-ds")
    assert ds.base_url == "https://api.deepseek.com/v1" and ds.resolve_api_key() == "sk-ds" and not ds.vision


def test_yaml_model_override_reinfers_vision(tmp_path):
    cfg = tmp_path / ".omniagent"
    cfg.mkdir()
    (cfg / "config.yaml").write_text("models:\n  qwen:\n    model: qwen-vl-max\n  kimi:\n    temperature: 0.3\n")
    s = load_settings(tmp_path)
    assert s.models["qwen"].vision is True
    assert s.models["kimi"].vision is False and s.models["kimi"].temperature == 0.3
