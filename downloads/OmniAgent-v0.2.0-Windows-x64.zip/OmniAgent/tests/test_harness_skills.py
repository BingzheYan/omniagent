"""Harness：技能系统（发现 / 覆盖 / load_skill / 技能目录只读访问 / 系统提示词）。"""
import pytest

from omniagent.agent import Agent
from omniagent.config import ModelProfile, Settings
from omniagent.llm.mock_provider import MockProvider
from omniagent.llm.types import LLMResponse
from omniagent.tools import ToolContext, ToolError, build_default_registry
from omniagent.tools.skills import BUILTIN_SKILLS_DIR, discover_skills, parse_skill_file


async def _noop(e):
    return None


def write_skill(root, name, desc, body="正文", extra=None):
    d = root / name
    d.mkdir(parents=True, exist_ok=True)
    (d / "SKILL.md").write_text(f"---\nname: {name}\ndescription: {desc}\n---\n\n{body}\n", encoding="utf-8")
    for rel, content in (extra or {}).items():
        f = d / rel
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text(content, encoding="utf-8")
    return d


def test_builtin_coding_skills_present():
    skills = discover_skills(None)
    for name in ("debugging", "code-review", "new-project"):
        assert name in skills, name
        sk = skills[name]
        assert sk.source == "builtin" and len(sk.description) > 20
        assert len(sk.body()) > 500


def test_parse_frontmatter():
    meta, body = parse_skill_file("---\nname: a\ndescription: 描述\n---\n# 标题\n内容")
    assert meta == {"name": "a", "description": "描述"} and body.startswith("# 标题")
    meta, body = parse_skill_file("# 无 frontmatter\n内容")
    assert meta == {} and "内容" in body


def test_override_order(tmp_path):
    home_skills = tmp_path / "home" / ".omniagent" / "skills"
    write_skill(home_skills, "debugging", "用户版调试")
    write_skill(home_skills, "mine", "用户技能")
    ws = tmp_path / "ws"
    write_skill(ws / ".omniagent" / "skills", "mine", "工作区覆盖")
    skills = discover_skills(ws)
    assert skills["debugging"].description == "用户版调试" and skills["debugging"].source == "user"
    assert skills["mine"].description == "工作区覆盖" and skills["mine"].source == "workspace"


async def test_load_skill_and_read_extra_files(tmp_path):
    home_skills = tmp_path / "home" / ".omniagent" / "skills"
    d = write_skill(home_skills, "report", "写报告", body="步骤一\n步骤二", extra={"templates/t.md": "模板内容"})
    ws = tmp_path / "ws"
    ws.mkdir()
    ctx = ToolContext(ws.resolve(), Settings(), _noop)
    reg = build_default_registry(Settings())
    r = await reg.get("load_skill").run({"name": "report"}, ctx)
    assert "步骤一" in r.content and str((d / "templates" / "t.md").resolve()) in r.content
    assert ctx.state["loaded_skills"] == ["report"]
    # 技能目录虽在工作区外，但允许只读访问
    r = await reg.get("read_file").run({"path": str(d / "templates" / "t.md")}, ctx)
    assert "模板内容" in r.content
    r = await reg.get("read_file").run({"path": str(BUILTIN_SKILLS_DIR / "debugging" / "SKILL.md")}, ctx)
    assert "复现" in r.content
    # 但不允许写入
    with pytest.raises(ToolError):
        await reg.get("write_file").run({"path": str(d / "x.md"), "content": "x"}, ctx)
    # 其他工作区外路径仍然禁止读取
    (tmp_path / "secret.txt").write_text("s")
    with pytest.raises(ToolError):
        await reg.get("read_file").run({"path": str(tmp_path / "secret.txt")}, ctx)
    # 宽松匹配 & 未知技能
    r = await reg.get("load_skill").run({"name": "Code_Review"}, ctx)
    assert "代码审查" in r.content
    with pytest.raises(ToolError, match="可用技能"):
        await reg.get("load_skill").run({"name": "nope"}, ctx)


async def test_system_prompt_lists_skills(tmp_path):
    write_skill(tmp_path / ".omniagent" / "skills", "ws-skill", "工作区专用技能描述")
    agent = Agent(MockProvider(ModelProfile("mock", "mock", "mock"), [LLMResponse("ok", [])]), Settings(), tmp_path)
    prompt = agent.build_system_prompt()
    assert "可用技能" in prompt and "load_skill" in prompt
    assert "ws-skill" in prompt and "工作区专用技能描述" in prompt
    assert "debugging" in prompt
    # 去掉 load_skill 工具后不再列出技能
    agent.tools.unregister("load_skill")
    assert "可用技能" not in agent.build_system_prompt()
