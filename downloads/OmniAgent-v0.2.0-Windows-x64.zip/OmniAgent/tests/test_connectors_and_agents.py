"""测试专业智能体/并行子智能体、五类外部应用连接器（SQLite / HTTP API / 目录 / 网页表格 / MCP）以及 Web 接口。"""
from __future__ import annotations

import json
import sqlite3
import sys
from pathlib import Path

from fastapi.testclient import TestClient

from omniagent.agent import Agent
from omniagent.agent.profiles import discover_agents
from omniagent.config import ModelProfile, Settings, load_settings
from omniagent.connectors import ConnectorSpec, execute_mcp, test_connector as verify_connector
from omniagent.llm.mock_provider import MockProvider
from omniagent.llm.types import LLMResponse, ToolCall
from omniagent.tools import ToolContext, build_default_registry
from omniagent.web.server import create_app


async def _noop(e):
    return None


def test_builtin_and_custom_agents(tmp_path: Path):
    agents_dir = tmp_path / ".omniagent" / "agents"
    agents_dir.mkdir(parents=True)
    (agents_dir / "auditor.md").write_text(
        "---\nname: auditor\ntitle: 财税合规审计员\ndescription: 专项财税审计\nicon: 🧾\nallowed_tools: read_file, grep\n---\n严格核查财税凭证。",
        encoding="utf-8",
    )
    found = discover_agents(tmp_path)
    assert {"general", "coder", "researcher", "analyst", "writer", "connector", "reviewer", "auditor"} <= set(found)
    assert found["auditor"].allowed_tools == ["read_file", "grep"]
    assert "write_file" not in (found["researcher"].allowed_tools or [])


async def test_parallel_subagents_and_file_changes(tmp_path: Path):
    script = [
        LLMResponse(
            thinking="先并行派出两名子智能体分别生成两个模块文件",
            content="",
            tool_calls=[ToolCall("p1", "delegate_parallel", {"tasks": [
                {"agent_type": "coder", "role": "后端子智能体", "task": "创建 a.py"},
                {"agent_type": "writer", "role": "文档子智能体", "task": "创建 b.md"},
            ]})],
        ),
        # 子智能体 1
        LLMResponse("写 a.py", [ToolCall("s1", "write_file", {"path": "a.py", "content": "x = 1\ny = 2\n"})], thinking="写代码"),
        LLMResponse("a.py 完成", []),
        LLMResponse("a.py 已验证", []),
        # 子智能体 2
        LLMResponse("写 b.md", [ToolCall("s2", "write_file", {"path": "b.md", "content": "# 文档\n内容\n"})], thinking="写文档"),
        LLMResponse("b.md 完成", []),
        LLMResponse("b.md 已验证", []),
        # 主智能体
        LLMResponse("微调 a.py", [ToolCall("r1", "read_file", {"path": "a.py"}),
                               ToolCall("e1", "edit_file", {"path": "a.py", "old_string": "y = 2", "new_string": "y = 3\nz = 4"})]),
        LLMResponse("全部完成", []),
        LLMResponse("全部验证通过", []),
    ]
    events = []

    async def on_event(e):
        events.append(e)

    agent = Agent(MockProvider(ModelProfile("mock", "mock", "mock"), script), Settings(), tmp_path, on_event=on_event)
    try:
        out = await agent.run("并行开发")
    finally:
        await agent.close()

    assert out == "全部验证通过"
    assert sum(1 for e in events if e["type"] == "subagent_start") == 2
    fc_events = [e for e in events if e["type"] == "file_changes" and e.get("final")]
    assert fc_events
    by_path = {f["path"]: f for f in fc_events[-1]["files"]}
    assert set(by_path) == {"a.py", "b.md"}
    assert by_path["a.py"]["added"] == 4 and by_path["a.py"]["removed"] == 1


async def test_sqlite_and_folder_connectors(tmp_path: Path):
    ext_dir = tmp_path / "external_erp"
    ext_dir.mkdir()
    db_file = ext_dir / "erp.sqlite"
    conn = sqlite3.connect(str(db_file))
    conn.execute("CREATE TABLE orders (id INT, dept TEXT, amount REAL)")
    conn.executemany("INSERT INTO orders VALUES (?,?,?)", [(1, "财政局", 120.5), (2, "税务局", 260.0)])
    conn.commit()
    conn.close()
    (ext_dir / "note.md").write_text("# 外部系统说明\n季度结算正常。", encoding="utf-8")

    ws = tmp_path / "workspace"
    ws.mkdir()
    conns = [
        ConnectorSpec("erp_db", "ERP 数据库", "sqlite", "外部订单库", {"db_path": str(db_file)}),
        ConnectorSpec("erp_docs", "ERP 导出目录", "local_folder", "外部说明目录", {"folder_path": str(ext_dir)}),
    ]
    assert (await verify_connector(conns[0]))["ok"]
    assert (await verify_connector(conns[1]))["ok"]

    ctx = ToolContext(ws, Settings(), _noop, state={"extra_connectors": conns})
    reg = build_default_registry(Settings())
    r_list = await reg.get("list_connectors").run({}, ctx)
    assert "erp_db" in r_list.content and "erp_docs" in r_list.content

    r_schema = await reg.get("connector_query").run({"connector": "erp_db", "action": "schema"}, ctx)
    assert "orders" in r_schema.content

    r_q = await reg.get("connector_query").run(
        {"connector": "erp_db", "action": "query", "sql": "SELECT dept, amount FROM orders", "save_to": "uploads/orders.csv"},
        ctx,
    )
    assert "财政局" in r_q.content and (ws / "uploads" / "orders.csv").is_file()

    # 拒绝写操作
    r_bad = None
    try:
        await reg.get("connector_query").run({"connector": "erp_db", "action": "query", "sql": "DROP TABLE orders"}, ctx)
    except Exception as e:  # noqa: BLE001
        r_bad = str(e)
    assert r_bad and "只读" in r_bad

    r_doc = await reg.get("connector_query").run({"connector": "erp_docs", "action": "read", "subpath": "note.md"}, ctx)
    assert "季度结算正常" in r_doc.content


async def test_mcp_stdio_connector(tmp_path: Path):
    mcp_server = tmp_path / "tiny_mcp.py"
    mcp_server.write_text(
        "import json, sys\n"
        "for line in sys.stdin:\n"
        "    req = json.loads(line)\n"
        "    m, i = req.get('method'), req.get('id')\n"
        "    if i is None: continue\n"
        "    if m == 'initialize': res = {'protocolVersion': '2024-11-05', 'serverInfo': {'name': 'tiny'}}\n"
        "    elif m == 'tools/list': res = {'tools': [{'name': 'crm_stats', 'description': 'CRM 统计'}]}\n"
        "    elif m == 'tools/call': res = {'content': [{'type': 'text', 'text': '活跃客户 428 家'}]}\n"
        "    else: res = {}\n"
        "    sys.stdout.write(json.dumps({'jsonrpc': '2.0', 'id': i, 'result': res}) + '\\n')\n"
        "    sys.stdout.flush()\n",
        encoding="utf-8",
    )
    spec = ConnectorSpec("tiny_mcp", "Tiny MCP", "mcp", "测试 MCP", {"command": sys.executable, "args": [str(mcp_server)]})
    t = await verify_connector(spec)
    assert t["ok"] and "crm_stats" in t["summary"]
    res = await execute_mcp(spec, action="call_tool", tool_name="crm_stats", arguments={})
    assert "428" in json.dumps(res, ensure_ascii=False)


def test_web_agents_connectors_and_file_save(tmp_path: Path):
    db_file = tmp_path / "ext.db"
    c = sqlite3.connect(str(db_file))
    c.execute("CREATE TABLE t (k TEXT, v INT)")
    c.execute("INSERT INTO t VALUES ('x', 9)")
    c.commit()
    c.close()

    app = create_app(tmp_path / "data", load_settings(tmp_path), default_model="mock", desktop_token="desk-secret")
    with TestClient(app) as client:
        # 桌面免密令牌登录
        r = client.get("/api/auth/desktop-login", params={"token": "desk-secret"}, follow_redirects=False)
        assert r.status_code == 302
        assert client.get("/api/auth/me").json()["user"]["username"] == "desktop"

        # 智能体列表与自定义智能体
        ag = client.get("/api/agents").json()
        assert any(a["name"] == "analyst" for a in ag["agents"])
        r = client.post("/api/agents", json={
            "name": "tax_expert", "title": "税务筹划专家", "description": "地方税制分析", "mode": "office",
            "system_prompt": "专注增值税与转移支付分析。",
        })
        assert r.status_code == 200 and r.json()["agent"]["name"] == "tax_expert"

        # 连接器创建与连通性测试
        r = client.post("/api/connectors", json={
            "name": "local_db", "title": "测试数据库", "kind": "sqlite",
            "config": {"db_path": str(db_file)},
        })
        assert r.status_code == 200
        chk = client.post("/api/connectors/local_db/test").json()
        assert chk["ok"] and "1 张表" in chk["summary"]

        # 在线保存文件（右侧可伸缩审阅/编辑器栏使用）
        sv = client.put("/api/file", json={"path": "src/demo.py", "content": "print('edited')\n"})
        assert sv.status_code == 200 and sv.json()["ok"]
        assert client.get("/api/preview", params={"path": "src/demo.py"}).json()["content"] == "print('edited')\n"
