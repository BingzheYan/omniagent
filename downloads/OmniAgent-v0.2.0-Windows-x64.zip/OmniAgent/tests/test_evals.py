"""Tests for the OmniAgent evaluation suite (5 coding + 4 office tasks, all MockProvider/--oracle)."""
from __future__ import annotations

from pathlib import Path

import pytest

from omniagent.evals import TASKS_ROOT, discover_tasks, main, run_eval_suite, select_tasks


def test_discover_and_select_all_nine_tasks():
    specs = discover_tasks()
    ids = [s.id for s in specs]
    assert set(ids) == {
        "coding_interval_scheduler",
        "coding_lru_ttl_cache",
        "coding_multi_file_refactor",
        "coding_pandas_pipeline_debug",
        "coding_expr_evaluator",
        "office_sales_report",
        "office_fiscal_paper",
        "office_doc_rewrite",
        "office_excel_merge",
    }
    for s in specs:
        assert (s.path / "oracle.py").is_file(), f"Missing oracle.py in {s.id}"

    coding = select_tasks(specs, "coding")
    office = select_tasks(specs, "office")
    assert len(coding) == 5 and all(s.category == "coding" for s in coding)
    assert len(office) == 4 and all(s.category == "office" for s in office)

    picked = select_tasks(specs, "coding_expr_evaluator,office_excel_merge")
    assert [p.id for p in picked] == ["coding_expr_evaluator", "office_excel_merge"]

    with pytest.raises(ValueError, match="未知评测任务"):
        select_tasks(specs, "nonexistent_task_id")


def test_protected_file_tamper_detected(tmp_path: Path):
    task_dir = tmp_path / "tasks" / "tamper_case"
    (task_dir / "workspace").mkdir(parents=True)
    (task_dir / "workspace" / "locked.txt").write_text("immutable", encoding="utf-8")
    (task_dir / "task.yaml").write_text(
        "id: tamper_case\n"
        "category: office\n"
        "title: Protected file tamper test\n"
        "mode: office\n"
        "prompt: Do not touch locked.txt\n"
        "check:\n"
        "  type: python\n"
        "  protected: [locked.txt]\n",
        encoding="utf-8",
    )
    (task_dir / "checker.py").write_text(
        "def check(ws, agent_result, events, task_dir):\n"
        "    return {'passed': True, 'score': 1.0, 'details': 'ok'}\n",
        encoding="utf-8",
    )
    (task_dir / "oracle.py").write_text(
        "from omniagent.llm.types import LLMResponse, ToolCall\n"
        "def build_script(ws):\n"
        "    return [\n"
        "        LLMResponse('tamper', [ToolCall('w1', 'write_file', {'path': 'locked.txt', 'content': 'hacked'})]),\n"
        "        LLMResponse('done', []),\n"
        "        LLMResponse('done2', []),\n"
        "    ]\n",
        encoding="utf-8",
    )
    import asyncio

    suite = asyncio.run(run_eval_suite("tamper_case", oracle=True, tasks_dir=tmp_path / "tasks", quiet=True))
    assert suite.total == 1 and suite.passed == 0
    assert "受保护文件" in suite.results[0].details


async def test_full_oracle_suite_passes_all_nine_tasks(tmp_path: Path):
    report_path = tmp_path / "eval_report.md"
    suite = await run_eval_suite("all", oracle=True, out=report_path, tasks_dir=TASKS_ROOT, quiet=True)
    failures = [(r.id, r.error or r.details) for r in suite.results if not r.passed]
    assert failures == [], f"Unexpected eval failures: {failures}"
    assert suite.total == 9
    assert suite.passed == 9
    assert suite.pass_rate == 1.0

    md = report_path.read_text(encoding="utf-8")
    assert "9/9 (100.0%)" in md
    for r in suite.results:
        assert r.id in md


def test_cli_main_entrypoint(tmp_path: Path):
    out_md = tmp_path / "cli_single.md"
    rc = main(["--oracle", "--tasks", "coding_expr_evaluator", "--out", str(out_md), "--quiet"])
    assert rc == 0
    assert out_md.exists()
    assert "coding_expr_evaluator" in out_md.read_text(encoding="utf-8")
