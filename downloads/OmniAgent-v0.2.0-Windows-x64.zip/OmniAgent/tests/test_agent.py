from pathlib import Path

from omniagent.agent import Agent
from omniagent.config import ModelProfile, Settings
from omniagent.llm.mock_provider import MockProvider
from omniagent.llm.types import LLMResponse, Message, ToolCall


def make_agent(tmp_path: Path, script, **kw):
    settings = Settings()
    prof = ModelProfile(name="mock", provider="mock", model="mock", context_window=kw.pop("window", 32000))
    events = []

    async def on_event(e):
        events.append(e)

    agent = Agent(MockProvider(prof, script), settings, tmp_path, on_event=on_event, **kw)
    return agent, events


async def test_loop_with_review(tmp_path):
    script = [
        LLMResponse("写文件", [ToolCall("1", "write_file", {"path": "hello.txt", "content": "hi"})]),
        LLMResponse("完成了", []),  # 触发自检
        LLMResponse("检查一下", [ToolCall("2", "read_file", {"path": "hello.txt"})]),
        LLMResponse("已验证，任务完成", []),
    ]
    agent, events = make_agent(tmp_path, script)
    result = await agent.run("写 hello.txt")
    assert result == "已验证，任务完成"
    assert (tmp_path / "hello.txt").read_text() == "hi"
    types = [e["type"] for e in events]
    assert "review" in types and types[-1] == "done"
    # 会话已持久化
    assert list((tmp_path / ".omniagent" / "sessions").glob("*.json"))


async def test_no_review_for_readonly(tmp_path):
    script = [LLMResponse("", [ToolCall("1", "list_dir", {})]), LLMResponse("目录是空的", [])]
    agent, events = make_agent(tmp_path, script)
    assert await agent.run("看看目录") == "目录是空的"
    assert "review" not in [e["type"] for e in events]


async def test_unknown_tool_and_bad_args_recover(tmp_path):
    script = [
        LLMResponse("", [ToolCall("1", "nope", {}), ToolCall("2", "write_file", {}, parse_error="bad json")]),
        lambda msgs: LLMResponse("好的" if all(m.is_error for m in msgs if m.role == "tool") else "??", []),
    ]
    agent, _ = make_agent(tmp_path, script)
    assert await agent.run("x") == "好的"


async def test_blocked_and_denied(tmp_path):
    async def deny(req):
        return False

    script = [
        LLMResponse("", [ToolCall("1", "run_shell", {"command": "rm -rf /"})]),
        LLMResponse("", [ToolCall("2", "run_shell", {"command": "rm -rf build"})]),
        lambda msgs: LLMResponse(msgs[-1].content[:6], []),
    ]
    agent, events = make_agent(tmp_path, script, approver=deny)
    out = await agent.run("清理")
    assert out.startswith("用户拒绝")
    assert any(e["type"] == "approval_request" for e in events)


async def test_subagent(tmp_path):
    script = [
        LLMResponse("", [ToolCall("1", "delegate_task", {"task": "写 sub.txt", "role": "写手"})]),
        # 子智能体
        LLMResponse("", [ToolCall("s1", "write_file", {"path": "sub.txt", "content": "sub"})]),
        LLMResponse("子任务完成", []),
        LLMResponse("子任务确认完成", []),  # 子智能体自检
        # 回到主智能体
        LLMResponse("全部完成", []),
        LLMResponse("全部完成（已验证）", []),
    ]
    agent, events = make_agent(tmp_path, script)
    out = await agent.run("委派")
    assert (tmp_path / "sub.txt").exists()
    assert out.startswith("全部完成")
    assert any(e["type"] == "subagent_start" for e in events)
    assert any(e.get("depth") == 1 for e in events)


async def test_compaction(tmp_path):
    big = "数据" * 3000
    script = [LLMResponse("", [ToolCall(str(i), "list_dir", {})]) for i in range(8)]
    script.insert(0, LLMResponse("", [ToolCall("w", "write_file", {"path": "big.txt", "content": big})]))
    script += [LLMResponse("摘要：已写入 big.txt", []), LLMResponse("完成", []), LLMResponse("确认完成", [])]
    agent, events = make_agent(tmp_path, script, window=6000)
    agent.messages = [Message("user", "历史" * 1500), Message("assistant", "好的" * 1500)]
    await agent.run("继续")
    assert any(e["type"] == "compact" for e in events)


async def test_resume_repairs_history(tmp_path):
    agent, _ = make_agent(tmp_path, [LLMResponse("ok", [])])
    agent.messages = [Message("user", "a"), Message("assistant", "", [ToolCall("x", "list_dir", {})])]
    agent.save()
    agent2, _ = make_agent(tmp_path, [LLMResponse("ok", [])])
    assert agent2.load(agent.session_id)
    assert agent2.messages[-1].role == "tool" and agent2.messages[-1].tool_call_id == "x"
