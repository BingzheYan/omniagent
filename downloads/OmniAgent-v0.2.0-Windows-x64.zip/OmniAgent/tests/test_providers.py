"""用 httpx MockTransport 模拟真实 API 的流式响应，验证 OpenAI 兼容 / Anthropic 两条链路的解析逻辑。"""
import json

import httpx

from omniagent.config import ModelProfile
from omniagent.llm.anthropic_provider import AnthropicProvider
from omniagent.llm.openai_provider import OpenAIProvider
from omniagent.llm.types import Message, ToolCall, ToolSchema

TOOLS = [ToolSchema("read_file", "读文件", {"type": "object", "properties": {"path": {"type": "string"}}})]
HISTORY = [
    Message("user", "读 a.txt"),
    Message("assistant", "好的", [ToolCall("c1", "read_file", {"path": "a.txt"})]),
    Message("tool", "内容", tool_call_id="c1", name="read_file"),
    Message("user", "<system-reminder>自检</system-reminder>"),
]


def sse(events, named=False):
    out = []
    for e in events:
        if named:
            out.append(f"event: {e['type']}\ndata: {json.dumps(e)}\n\n")
        else:
            out.append(f"data: {json.dumps(e)}\n\n")
    if not named:
        out.append("data: [DONE]\n\n")
    return "".join(out).encode()


async def test_openai_stream_tool_calls():
    captured = {}

    def handler(request: httpx.Request):
        captured["body"] = json.loads(request.content)
        chunks = [
            {"choices": [{"index": 0, "delta": {"reasoning_content": "想一想"}}]},
            {"choices": [{"index": 0, "delta": {"content": "我来"}}]},
            {"choices": [{"index": 0, "delta": {"tool_calls": [{"index": 0, "id": "t1", "type": "function",
                                                               "function": {"name": "read_file", "arguments": "{\"pa"}}]}}]},
            {"choices": [{"index": 0, "delta": {"tool_calls": [{"index": 0, "function": {"arguments": "th\": \"b.txt\"}"}}]}}]},
            {"choices": [{"index": 0, "delta": {}, "finish_reason": "tool_calls"}]},
            {"choices": [], "usage": {"prompt_tokens": 100, "completion_tokens": 20}},
        ]
        return httpx.Response(200, content=sse(chunks), headers={"content-type": "text/event-stream"})

    prof = ModelProfile("t", "openai", "gpt-x", base_url="http://fake/v1", api_key="k")
    p = OpenAIProvider(prof)
    from openai import AsyncOpenAI

    p.client = AsyncOpenAI(api_key="k", base_url="http://fake/v1",
                           http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler)))
    deltas = []

    async def on_delta(kind, text):
        deltas.append((kind, text))

    r = await p.complete("sys", HISTORY, TOOLS, on_delta)
    assert r.content == "我来" and r.thinking == "想一想"
    assert r.tool_calls[0].name == "read_file" and r.tool_calls[0].arguments == {"path": "b.txt"}
    assert r.usage.input_tokens == 100
    msgs = captured["body"]["messages"]
    assert msgs[0]["role"] == "system" and msgs[2]["tool_calls"][0]["id"] == "c1" and msgs[3]["role"] == "tool"
    assert ("text", "我来") in deltas


async def test_anthropic_stream_and_conversion():
    captured = {}

    def handler(request: httpx.Request):
        captured["body"] = json.loads(request.content)
        msg = {"id": "m", "type": "message", "role": "assistant", "model": "claude", "content": [],
               "stop_reason": None, "stop_sequence": None, "usage": {"input_tokens": 50, "output_tokens": 1}}
        events = [
            {"type": "message_start", "message": msg},
            {"type": "content_block_start", "index": 0, "content_block": {"type": "text", "text": ""}},
            {"type": "content_block_delta", "index": 0, "delta": {"type": "text_delta", "text": "检查中"}},
            {"type": "content_block_stop", "index": 0},
            {"type": "content_block_start", "index": 1,
             "content_block": {"type": "tool_use", "id": "tu1", "name": "read_file", "input": {}}},
            {"type": "content_block_delta", "index": 1, "delta": {"type": "input_json_delta", "partial_json": "{\"path\":\"c.txt\"}"}},
            {"type": "content_block_stop", "index": 1},
            {"type": "message_delta", "delta": {"stop_reason": "tool_use", "stop_sequence": None}, "usage": {"output_tokens": 30}},
            {"type": "message_stop"},
        ]
        return httpx.Response(200, content=sse(events, named=True), headers={"content-type": "text/event-stream"})

    prof = ModelProfile("c", "anthropic", "claude-x", api_key="k")
    p = AnthropicProvider(prof)
    from anthropic import AsyncAnthropic

    try:  # 新版 anthropic SDK 基于 httpx2
        import httpx2 as hx
    except ImportError:
        hx = httpx

    def handler2(request):
        resp = handler(request)
        return hx.Response(resp.status_code, content=resp.content, headers=dict(resp.headers))

    p.client = AsyncAnthropic(api_key="k", http_client=hx.AsyncClient(transport=hx.MockTransport(handler2)))
    r = await p.complete("sys", HISTORY, TOOLS)
    assert r.content == "检查中"
    assert r.tool_calls[0].id == "tu1" and r.tool_calls[0].arguments == {"path": "c.txt"}
    msgs = captured["body"]["messages"]
    # user / assistant / user(tool_result + 文本合并) 严格交替
    assert [m["role"] for m in msgs] == ["user", "assistant", "user"]
    assert msgs[2]["content"][0]["type"] == "tool_result" and msgs[2]["content"][1]["type"] == "text"
    assert captured["body"]["tools"][0]["input_schema"]["type"] == "object"
