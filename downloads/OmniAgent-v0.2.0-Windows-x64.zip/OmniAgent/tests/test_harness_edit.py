"""Harness：编辑健壮性（读后编辑、过期检测、空白容错匹配）。"""
import os
import time

import pytest
import pytest_asyncio

from omniagent.config import Settings
from omniagent.tools import ToolContext, ToolError, build_default_registry
from omniagent.tools.files import fuzzy_replace


async def _noop(e):
    return None


@pytest_asyncio.fixture
async def ctx(tmp_path):
    yield ToolContext(tmp_path.resolve(), Settings(), _noop)


@pytest.fixture
def reg():
    return build_default_registry(Settings())


async def run(reg, name, args, ctx):
    return await reg.get(name).run(args, ctx)


async def test_edit_requires_read_first(reg, ctx):
    f = ctx.workspace / "a.py"
    f.write_text("x = 1\n")
    with pytest.raises(ToolError, match="尚未被读取"):
        await run(reg, "edit_file", {"path": "a.py", "old_string": "x = 1", "new_string": "x = 2"}, ctx)
    await run(reg, "read_file", {"path": "a.py"}, ctx)
    await run(reg, "edit_file", {"path": "a.py", "old_string": "x = 1", "new_string": "x = 2"}, ctx)
    assert f.read_text() == "x = 2\n"
    # 连续编辑无需重新读取（编辑后状态已更新）
    await run(reg, "edit_file", {"path": "a.py", "old_string": "x = 2", "new_string": "x = 3"}, ctx)
    assert f.read_text() == "x = 3\n"


async def test_write_counts_as_read(reg, ctx):
    await run(reg, "write_file", {"path": "b.txt", "content": "hello\n"}, ctx)
    await run(reg, "edit_file", {"path": "b.txt", "old_string": "hello", "new_string": "bye"}, ctx)
    assert (ctx.workspace / "b.txt").read_text() == "bye\n"


async def test_stale_file_detected(reg, ctx):
    f = ctx.workspace / "c.txt"
    f.write_text("one\n")
    await run(reg, "read_file", {"path": "c.txt"}, ctx)
    f.write_text("one\ntwo (外部修改)\n")
    st = f.stat()
    os.utime(f, ns=(st.st_atime_ns, st.st_mtime_ns + 5_000_000))
    with pytest.raises(ToolError, match="已在磁盘上被修改"):
        await run(reg, "edit_file", {"path": "c.txt", "old_string": "one", "new_string": "1"}, ctx)
    await run(reg, "read_file", {"path": "c.txt"}, ctx)
    await run(reg, "edit_file", {"path": "c.txt", "old_string": "one", "new_string": "1"}, ctx)
    assert f.read_text().startswith("1\n")


async def test_shell_modification_makes_stale(reg, ctx):
    await run(reg, "write_file", {"path": "d.txt", "content": "a\n"}, ctx)
    time.sleep(0.01)
    await run(reg, "run_shell", {"command": "echo b >> d.txt"}, ctx)
    with pytest.raises(ToolError, match="重新 read_file"):
        await run(reg, "edit_file", {"path": "d.txt", "old_string": "a", "new_string": "z"}, ctx)


async def test_crlf_preserved_and_matched(reg, ctx):
    f = ctx.workspace / "w.txt"
    f.write_bytes(b"line1\r\nline2\r\nline3\r\n")
    await run(reg, "read_file", {"path": "w.txt"}, ctx)
    r = await run(reg, "edit_file", {"path": "w.txt", "old_string": "line1\nline2", "new_string": "L1\nL2"}, ctx)
    assert f.read_bytes() == b"L1\r\nL2\r\nline3\r\n"
    assert "模糊匹配" in r.content and r.data["fuzzy"]


async def test_trailing_whitespace_fuzzy(reg, ctx):
    f = ctx.workspace / "t.py"
    f.write_text("def f():   \n    return 1  \n\nprint(f())\n")
    await run(reg, "read_file", {"path": "t.py"}, ctx)
    r = await run(reg, "edit_file", {"path": "t.py", "old_string": "def f():\n    return 1",
                                     "new_string": "def f():\n    return 2"}, ctx)
    assert f.read_text() == "def f():\n    return 2\n\nprint(f())\n"
    assert "行尾空白" in r.content


async def test_indentation_fuzzy_reindents(reg, ctx):
    f = ctx.workspace / "k.py"
    f.write_text("class A:\n    def m(self):\n        x = 1\n        return x\n")
    await run(reg, "read_file", {"path": "k.py"}, ctx)
    r = await run(reg, "edit_file", {"path": "k.py", "old_string": "x = 1\nreturn x",
                                     "new_string": "x = 2\nif x:\n    x += 1\nreturn x"}, ctx)
    assert f.read_text() == "class A:\n    def m(self):\n        x = 2\n        if x:\n            x += 1\n        return x\n"
    assert "缩进" in r.content


async def test_fuzzy_ambiguous_rejected(reg, ctx):
    f = ctx.workspace / "m.py"
    f.write_text("if a:\n    go()   \nif b:\n  go()  \n")
    await run(reg, "read_file", {"path": "m.py"}, ctx)
    with pytest.raises(ToolError, match="无法唯一定位"):
        await run(reg, "edit_file", {"path": "m.py", "old_string": "go() \n", "new_string": "stop()\n"}, ctx)
    assert f.read_text() == "if a:\n    go()   \nif b:\n  go()  \n"


async def test_not_found_still_errors(reg, ctx):
    await run(reg, "write_file", {"path": "n.txt", "content": "alpha\nbeta\n"}, ctx)
    with pytest.raises(ToolError, match="找不到"):
        await run(reg, "edit_file", {"path": "n.txt", "old_string": "gamma", "new_string": "x"}, ctx)


def test_fuzzy_line_number_prefix():
    text = "a = 1\nb = 2\n"
    res = fuzzy_replace(text, "     1\ta = 1\n     2\tb = 2", "     1\ta = 10\n     2\tb = 20")
    assert res is not None and res[0] == "a = 10\nb = 20\n" and "行号" in res[1]
    assert fuzzy_replace(text, "zzz", "y") is None
    assert fuzzy_replace(text, "   \n", "y") is None
