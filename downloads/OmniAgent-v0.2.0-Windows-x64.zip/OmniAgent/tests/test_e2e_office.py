"""端到端：用脚本化模型模拟一次真实的“数据分析 → 图表 → Word 报告 → 自检”办公工作流。"""
import shutil
from pathlib import Path

from omniagent.agent import Agent
from omniagent.config import ModelProfile, Settings
from omniagent.llm.mock_provider import MockProvider
from omniagent.llm.types import LLMResponse, ToolCall

EXAMPLE = Path(__file__).parent.parent / "examples" / "sales_2025.csv"

ANALYSIS = """
import pandas as pd
import matplotlib.pyplot as plt
df = pd.read_csv('uploads/sales_2025.csv')
print('缺失值:', int(df['销量'].isna().sum()))
df['销量'] = df['销量'].fillna(df['销量'].median())
by_region = df.groupby('地区')['销售额'].sum().sort_values(ascending=False)
ax = by_region.plot(kind='bar', title='各地区销售额')
ax.set_ylabel('销售额（元）')
by_region.round(0)
"""


def last_tool_output(msgs):
    return next(m.content for m in reversed(msgs) if m.role == "tool")


async def test_office_workflow(tmp_path):
    (tmp_path / "uploads").mkdir()
    shutil.copy(EXAMPLE, tmp_path / "uploads" / "sales_2025.csv")

    def write_report(msgs):
        out = last_tool_output(msgs)
        fig = out.split("已保存图像: ")[1].split(",")[0].strip()
        top = "华东" if "华东" in out.split("Out:")[1].splitlines()[1] else "?"
        md = f"# 销售分析报告\n\n## 摘要\n\n销售额最高的地区是 **{top}**。\n\n![各地区销售额]({fig})\n"
        return LLMResponse("生成报告", [ToolCall("3", "create_document", {"output_path": "outputs/报告.docx", "markdown": md})])

    script = [
        LLMResponse("先规划", [ToolCall("1", "todo_write", {"todos": [
            {"content": "分析数据", "status": "in_progress"}, {"content": "生成报告", "status": "pending"}]})]),
        LLMResponse("分析", [ToolCall("2", "python", {"code": ANALYSIS})]),
        write_report,
        LLMResponse("完成", []),  # -> 自检
        LLMResponse("检查报告", [ToolCall("4", "read_file", {"path": "outputs/报告.docx"}),
                             ToolCall("5", "todo_write", {"todos": [
                                 {"content": "分析数据", "status": "completed"},
                                 {"content": "生成报告", "status": "completed"}]})]),
        lambda msgs: LLMResponse("报告已验证" if "华东" in msgs[-2].content else "报告有误", []),
    ]
    events = []

    async def on_event(e):
        events.append(e)

    agent = Agent(MockProvider(ModelProfile("mock", "mock", "mock"), script), Settings(), tmp_path, on_event=on_event)
    try:
        result = await agent.run("分析销售数据并生成 Word 报告")
    finally:
        await agent.close()
    assert result == "报告已验证"
    assert (tmp_path / "outputs" / "报告.docx").exists()
    assert list((tmp_path / "outputs" / "figures").glob("*.png"))
    py_end = next(e for e in events if e["type"] == "tool_end" and e["name"] == "python")
    assert not py_end["is_error"] and "缺失值: 1" in py_end["content"]
