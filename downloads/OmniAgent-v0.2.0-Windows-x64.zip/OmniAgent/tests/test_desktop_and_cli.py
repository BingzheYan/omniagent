"""测试 CLI 子命令（agents / skills / connectors / user / desktop --build-app）与桌面端打包。"""
from __future__ import annotations

import platform
from pathlib import Path

from omniagent.cli import main as cli_main
from omniagent.desktop import _spawn_detached_desktop, _write_ready_signal, build_macos_app_bundle


def test_cli_agents_skills_connectors_user(tmp_path: Path, capsys):
    cli_main(["agents", "-w", str(tmp_path)])
    out = capsys.readouterr().out
    assert "coder" in out and "analyst" in out and "connector" in out

    cli_main(["skills", "-w", str(tmp_path)])
    out = capsys.readouterr().out
    assert "fiscal-paper" in out and "debugging" in out

    cli_main(["connectors", "-w", str(tmp_path)])
    out = capsys.readouterr().out
    assert "连接器" in out

    data_dir = tmp_path / "srv"
    try:
        cli_main(["user", "--data-dir", str(data_dir), "add", "admin1", "--admin", "--password", "password123"])
    except SystemExit as e:
        assert e.code == 0
    try:
        cli_main(["user", "--data-dir", str(data_dir), "list"])
    except SystemExit as e:
        assert e.code == 0
    out = capsys.readouterr().out
    assert "admin1" in out


def test_desktop_app_bundle_builder(tmp_path: Path):
    app_dir = build_macos_app_bundle(tmp_path / "dist")
    plist_file = app_dir / "Contents" / "Info.plist"
    launcher_file = app_dir / "Contents" / "MacOS" / "OmniAgent"
    assert plist_file.is_file()
    assert launcher_file.is_file()
    plist_txt = plist_file.read_text(encoding="utf-8")
    assert "NSDesktopFolderUsageDescription" in plist_txt
    launcher_txt = launcher_file.read_text(encoding="utf-8")
    assert "CAN_DIRECT" in launcher_txt and "osascript" in launcher_txt
    if platform.system() == "Darwin":
        assert (app_dir / "Contents" / "MacOS" / "OmniAgentDesktopShell").is_file()

    repo_root = Path(__file__).resolve().parent.parent
    cmd_txt = (repo_root / "启动桌面端.command").read_text(encoding="utf-8")
    assert 'open "./OmniAgent.app"' not in cmd_txt
    assert "--detach" in cmd_txt


def test_detached_desktop_ready_handshake(tmp_path: Path, monkeypatch):
    ready_p = tmp_path / "ready_test.json"
    monkeypatch.setenv("OMNIAGENT_READY_FILE", str(ready_p))
    _write_ready_signal("http://127.0.0.1:9999")
    assert ready_p.is_file()

    class DummyProc:
        returncode = None

        def poll(self):
            return None

    def fake_popen(cmd, **kwargs):
        env = kwargs["env"]
        Path(env["OMNIAGENT_READY_FILE"]).write_text('{"ok": true, "url": "http://127.0.0.1:8899"}', encoding="utf-8")
        return DummyProc()

    monkeypatch.setattr("omniagent.desktop.subprocess.Popen", fake_popen)
    rc = _spawn_detached_desktop(port=0, data_dir=tmp_path, default_model="mock", auto_login=True)
    assert rc == 0
