"""Web 应用（多用户）后端测试：认证、对话、搜索、分享、导出、文件、管理后台、WebSocket 任务流。"""
import pytest
from fastapi.testclient import TestClient

from omniagent.config import load_settings
from omniagent.web.server import create_app


@pytest.fixture
def app(tmp_path):
    settings = load_settings(tmp_path / "ws")
    return create_app(tmp_path / "data", settings, default_model="mock")


def register(client, username="alice", password="password123", **kw):
    return client.post("/api/auth/register", json={"username": username, "password": password, **kw})


def run_task(ws, content="生成报告", **kw):
    ws.send_json({"type": "task", "content": content, **kw})
    types = []
    while True:
        e = ws.receive_json()
        types.append(e["type"])
        if e["type"] == "idle":
            return types


def test_auth_flow(app):
    with TestClient(app) as c:
        st = c.get("/api/auth/status").json()
        assert st["has_users"] is False and st["registration_open"]
        assert c.get("/api/auth/me").status_code == 401
        r = register(c)
        assert r.status_code == 200 and r.json()["user"]["role"] == "admin"  # 首位用户为管理员
        assert c.get("/api/auth/me").json()["user"]["username"] == "alice"
        assert c.post("/api/auth/logout").json()["ok"]
        assert c.get("/api/auth/me").status_code == 401
        assert c.post("/api/auth/login", json={"username": "alice", "password": "wrong-pass"}).status_code == 401
        assert c.post("/api/auth/login", json={"username": "alice", "password": "password123"}).status_code == 200
        # 第二个用户是普通用户
        c2 = TestClient(app)
        assert register(c2, "bob").json()["user"]["role"] == "user"
        assert c2.get("/api/admin/users").status_code == 403
        # 验证：重复用户名、弱密码
        assert register(TestClient(app), "bob").status_code == 409
        assert register(TestClient(app), "carol", "short").status_code == 400


def test_login_rate_limit(app):
    with TestClient(app) as c:
        register(c)
        c.post("/api/auth/logout")
        for _ in range(5):
            c.post("/api/auth/login", json={"username": "alice", "password": "nope-nope"})
        assert c.post("/api/auth/login", json={"username": "alice", "password": "password123"}).status_code == 429


def test_registration_controls(app):
    with TestClient(app) as admin:
        register(admin)
        admin.put("/api/admin/settings", json={"invite_code": "OMNI2026"})
        assert register(TestClient(app), "bob").status_code == 403
        assert register(TestClient(app), "bob", invite_code="OMNI2026").status_code == 200
        admin.put("/api/admin/settings", json={"allow_registration": False})
        assert register(TestClient(app), "carol", invite_code="OMNI2026").status_code == 403
        assert TestClient(app).get("/api/auth/status").json()["registration_open"] is False


def test_settings_password_keys_devices(app):
    with TestClient(app) as c:
        register(c)
        s = c.put("/api/me/settings", json={"theme": "dark", "custom_instructions": "回答要简洁", "bogus": 1}).json()
        assert s["theme"] == "dark" and "bogus" not in s
        assert c.patch("/api/me", json={"display_name": "爱丽丝"}).json()["user"]["display_name"] == "爱丽丝"
        assert c.post("/api/me/password", json={"old_password": "x", "new_password": "newpassword1"}).status_code == 400
        assert c.post("/api/me/password", json={"old_password": "password123", "new_password": "newpassword1"}).json()["ok"]
        assert c.put("/api/me/keys/deepseek", json={"api_key": "sk-test-1234567890"}).json()["ok"]
        keys = {k["model"]: k for k in c.get("/api/me/keys").json()}
        assert keys["deepseek"]["has_key"] and "sk-t" in keys["deepseek"]["masked"] and "1234567890" not in keys["deepseek"]["masked"]
        models = {m["name"]: m for m in c.get("/api/config").json()["models"]}
        assert models["deepseek"]["available"] and models["deepseek"]["personal_key"]
        assert len(c.get("/api/me/devices").json()) == 1


def test_conversations_and_ws(app):
    with TestClient(app) as c:
        register(c)
        c.post("/api/upload", files={"files": ("data.csv", b"a,b\n1,2\n", "text/csv")})
        with c.websocket_connect("/ws") as ws:
            ws.send_json({"type": "init"})
            ready = ws.receive_json()
            assert ready["type"] == "ready"
            cid = ready["conversation_id"]
            types = run_task(ws, "生成季度销售报告", attachments=["uploads/data.csv"])
            assert {"tool_start", "plan_update", "done", "conversation_updated"} <= set(types)
            # 重新生成
            ws.send_json({"type": "regenerate"})
            assert ws.receive_json()["type"] == "ready"
            types = []
            while (e := ws.receive_json())["type"] != "idle":
                types.append(e["type"])
            assert "done" in types

        convs = c.get("/api/conversations").json()
        assert convs[0]["id"] == cid and convs[0]["title"].startswith("生成季度销售报告")
        detail = c.get(f"/api/conversations/{cid}").json()
        assert sum(1 for h in detail["history"] if h["role"] == "user") == 1  # regenerate 没有重复用户消息
        # 搜索（标题与内容）
        assert c.get("/api/conversations", params={"q": "季度销售"}).json()
        assert c.get("/api/conversations", params={"q": "演示完成"}).json()
        assert not c.get("/api/conversations", params={"q": "不存在的词语xyz"}).json()
        # 重命名 / 置顶 / 归档
        assert c.patch(f"/api/conversations/{cid}", json={"title": "Q3 报告", "pinned": True}).json()["conversation"]["pinned"]
        c.patch(f"/api/conversations/{cid}", json={"archived": True})
        assert not c.get("/api/conversations").json()
        assert c.get("/api/conversations", params={"archived": 1}).json()[0]["title"] == "Q3 报告"
        # 导出
        md = c.get(f"/api/conversations/{cid}/export", params={"format": "md"})
        assert md.status_code == 200 and "Q3 报告" in md.text
        assert c.get(f"/api/conversations/{cid}/export", params={"format": "json"}).json()["messages"]
        assert c.get(f"/api/conversations/{cid}/export", params={"format": "docx"}).content[:2] == b"PK"
        # 分享（匿名可读）
        share = c.post(f"/api/conversations/{cid}/share").json()
        anon = TestClient(app)
        assert anon.get(f"/api/share/{share['token']}").json()["title"] == "Q3 报告"
        assert anon.get(f"/share/{share['token']}").status_code == 200
        c.delete(f"/api/conversations/{cid}/share")
        assert anon.get(f"/api/share/{share['token']}").status_code == 404
        # 用量
        u = c.get("/api/me/usage").json()
        assert u["total"]["tasks"] == 2 and len(u["daily"]) == 30
        # 删除
        assert c.delete(f"/api/conversations/{cid}").json()["ok"]
        assert c.get(f"/api/conversations/{cid}").status_code == 404


def test_user_isolation(app):
    with TestClient(app) as alice, TestClient(app) as bob:
        register(alice)
        register(bob, "bob")
        alice.post("/api/upload", files={"files": ("secret.txt", b"top secret", "text/plain")})
        with alice.websocket_connect("/ws") as ws:
            ws.send_json({"type": "init"})
            cid = ws.receive_json()["conversation_id"]
            run_task(ws)
        assert bob.get(f"/api/conversations/{cid}").status_code == 404
        assert bob.get("/api/file", params={"path": "uploads/secret.txt"}).status_code == 404
        assert bob.get("/api/files", params={"path": "../u1"}).status_code == 403
        with bob.websocket_connect("/ws") as ws:  # 不能通过 WS 接管别人的对话
            ws.send_json({"type": "init", "conversation_id": cid})
            ready = ws.receive_json()
            assert ready.get("type") == "error" or ready["conversation_id"] != cid


def test_ws_requires_login(app):
    with TestClient(app) as c:
        with c.websocket_connect("/ws") as ws:
            with pytest.raises(Exception):
                ws.receive_json()


def test_files_api(app):
    with TestClient(app) as c:
        register(c)
        assert c.post("/api/files/mkdir", json={"path": "docs/sub"}).json()["path"] == "docs/sub"
        c.post("/api/upload", files={"files": ("a.md", b"# hi", "text/markdown")}, data={"dir": "docs"})
        assert c.get("/api/preview", params={"path": "docs/a.md"}).json()["kind"] == "markdown"
        assert c.post("/api/files/rename", json={"path": "docs/a.md", "new_name": "b.md"}).json()["path"] == "docs/b.md"
        assert c.get("/api/files/zip", params={"path": "docs"}).content[:2] == b"PK"
        assert c.get("/api/files/storage").json()["used_bytes"] > 0
        assert c.delete("/api/files", params={"path": "docs"}).json()["ok"]
        assert c.delete("/api/files", params={"path": "."}).status_code == 400
        assert c.delete("/api/files", params={"path": "../../etc"}).status_code == 403


def test_admin(app):
    with TestClient(app) as admin:
        register(admin)
        r = admin.post("/api/admin/users", json={"username": "dave", "password": "password123"})
        uid = r.json()["user"]["id"]
        dave = TestClient(app)
        assert dave.post("/api/auth/login", json={"username": "dave", "password": "password123"}).status_code == 200
        admin.patch(f"/api/admin/users/{uid}", json={"status": "disabled"})
        assert dave.get("/api/auth/me").status_code == 401  # 禁用后令牌失效
        assert dave.post("/api/auth/login", json={"username": "dave", "password": "password123"}).status_code == 403
        assert admin.patch("/api/admin/users/1", json={"role": "user"}).status_code == 400  # 不能降级自己
        assert len(admin.get("/api/admin/users").json()) == 2
        assert admin.get("/api/admin/stats").json()["users"] == 2
        st = admin.put("/api/admin/settings", json={"max_concurrent_tasks_per_user": 1, "enabled_models": ["mock", "nope"]}).json()
        assert st["enabled_models"] == ["mock"]
        assert any(a["action"] == "user_create" for a in admin.get("/api/admin/audit").json())
        assert admin.delete(f"/api/admin/users/{uid}").json()["ok"]


def test_quota(app):
    with TestClient(app) as admin:
        register(admin)
        uid = admin.get("/api/auth/me").json()["user"]["id"]
        admin.patch(f"/api/admin/users/{uid}", json={"token_quota": 1})
        with admin.websocket_connect("/ws") as ws:
            ws.send_json({"type": "init"})
            ws.receive_json()
            run_task(ws)  # 第一次可以执行（额度在执行后才累积）
            ws.send_json({"type": "task", "content": "再来一次"})
            e = ws.receive_json()
            assert e["type"] == "error" and "额度" in e["message"]
