"""Harness：图像查看（view_image）+ 各 provider 的图片消息转换。全部使用 Mock，不调用真实 API。"""
import base64
import json

import httpx
import pytest
from PIL import Image

from omniagent.agent import Agent
from omniagent.agent.context import drop_old_images, message_tokens
from omniagent.config import ModelProfile, Settings
from omniagent.llm.anthropic_provider import AnthropicProvider
from omniagent.llm.mock_provider import MockProvider
from omniagent.llm.openai_provider import OpenAIProvider
from omniagent.llm.types import LLMResponse, Message, ToolCall
from omniagent.tools import ToolContext, build_default_registry


async def _noop(e):
    return None


def make_png(path, size=(64, 48), color=(200, 30, 30)):
    path.parent.mkdir(parents=True, exist_ok=True)
    Image.new("RGB", size, color).save(path)
    return path


def make_agent(tmp_path, script, vision=True, model="mock"):
    prof = ModelProfile(name="mock", provider="mock", model=model, vision=vision)
    events = []

    async def on_event(e):
        events.append(e)

    llm = MockProvider(prof, script)
    return Agent(llm, Settings(), tmp_path, on_event=on_event), llm, events


async def test_view_image_returns_base64(tmp_path):
    make_png(tmp_path / "outputs" / "chart.png")
    ctx = ToolContext(tmp_path.resolve(), Settings(), _noop)
    reg = build_default_registry(Settings())
    r = await reg.get("view_image").run({"path": "outputs/chart.png"}, ctx)
    assert not r.is_error and r.images
    img = r.images[0]
    assert img["media_type"] == "image/png" and img["path"] == "outputs/chart.png"
    raw = base64.b64decode(img["data"])
    assert raw.startswith(b"\x89PNG")
    assert "64×48" in r.content


async def test_view_image_resizes_large(tmp_path):
    make_png(tmp_path / "big.png", size=(4000, 1000))
    ctx = ToolContext(tmp_path.resolve(), Settings(), _noop)
    r = await build_default_registry(Settings()).get("view_image").run({"path": "big.png"}, ctx)
    from io import BytesIO

    im = Image.open(BytesIO(base64.b64decode(r.images[0]["data"])))
    assert max(im.size) == 1568 and im.size == (1568, 392)
    assert "已缩放" in r.content


async def test_view_image_errors(tmp_path):
    (tmp_path / "a.svg").write_text("<svg/>")
    (tmp_path / "bad.png").write_bytes(b"not an image")
    ctx = ToolContext(tmp_path.resolve(), Settings(), _noop)
    tool = build_default_registry(Settings()).get("view_image")
    from omniagent.tools import ToolError

    with pytest.raises(ToolError, match="SVG"):
        await tool.run({"path": "a.svg"}, ctx)
    with pytest.raises(ToolError, match="无法打开"):
        await tool.run({"path": "bad.png"}, ctx)
    with pytest.raises(ToolError):
        await tool.run({"path": "../outside.png"}, ctx)


async def test_agent_attaches_images_to_tool_message(tmp_path):
    make_png(tmp_path / "c.png")
    seen = {}

    def check(msgs):
        tool_msg = next(m for m in msgs if m.role == "tool")
        seen["images"] = tool_msg.meta.get("images")
        return LLMResponse("图表正常", [])

    agent, llm, events = make_agent(tmp_path, [LLMResponse("", [ToolCall("1", "view_image", {"path": "c.png"})]), check])
    assert await agent.run("看图") == "图表正常"
    assert seen["images"] and seen["images"][0]["data"]
    end = next(e for e in events if e["type"] == "tool_end")
    assert end["images_attached"] == 1
    b64 = seen["images"][0]["data"]
    assert all(b64 not in json.dumps(e, ensure_ascii=False) for e in events)  # 事件中不含 base64


async def test_non_vision_model_gets_text_note(tmp_path):
    make_png(tmp_path / "c.png", size=(300, 200))
    agent, llm, _ = make_agent(tmp_path, [
        LLMResponse("", [ToolCall("1", "view_image", {"path": "c.png"})]),
        lambda msgs: LLMResponse(msgs[-1].content, []),
    ], vision=False, model="deepseek-chat")
    out = await agent.run("看图")
    assert "不支持图像输入" in out and "300×200" in out
    assert not any(m.meta.get("images") for m in agent.messages)


def _history_with_image():
    img = {"media_type": "image/png", "data": base64.b64encode(b"\x89PNGfake").decode(), "path": "c.png"}
    return [
        Message("user", "看图"),
        Message("assistant", "", [ToolCall("t1", "view_image", {"path": "c.png"}), ToolCall("t2", "read_file", {"path": "x"})]),
        Message("tool", "[图片] c.png", tool_call_id="t1", name="view_image", meta={"images": [img]}),
        Message("tool", "内容", tool_call_id="t2", name="read_file"),
    ]


def test_openai_convert_images_after_tool_group():
    out = OpenAIProvider._convert("sys", _history_with_image(), vision=True)
    roles = [m["role"] for m in out]
    # tool 消息必须紧跟 assistant，图片作为额外 user 消息放在整组 tool 消息之后
    assert roles == ["system", "user", "assistant", "tool", "tool", "user"]
    parts = out[-1]["content"]
    urls = [p["image_url"]["url"] for p in parts if p["type"] == "image_url"]
    assert urls and urls[0].startswith("data:image/png;base64,")
    # 不支持视觉时不发图片
    out2 = OpenAIProvider._convert("sys", _history_with_image(), vision=False)
    assert [m["role"] for m in out2][-1] == "tool" and "未发送" in out2[3]["content"]


def test_anthropic_convert_image_blocks():
    out = AnthropicProvider._convert(_history_with_image(), vision=True)
    tr = out[-1]["content"][0]
    assert tr["type"] == "tool_result" and isinstance(tr["content"], list)
    assert tr["content"][0]["type"] == "text"
    assert tr["content"][1]["type"] == "image" and tr["content"][1]["source"]["type"] == "base64"
    out2 = AnthropicProvider._convert(_history_with_image(), vision=False)
    assert isinstance(out2[-1]["content"][0]["content"], str)


async def test_openai_request_body_contains_image():
    captured = {}

    def handler(request: httpx.Request):
        captured["body"] = json.loads(request.content)
        chunks = [{"choices": [{"index": 0, "delta": {"content": "ok"}, "finish_reason": "stop"}]}]
        body = "".join(f"data: {json.dumps(c)}\n\n" for c in chunks) + "data: [DONE]\n\n"
        return httpx.Response(200, content=body.encode(), headers={"content-type": "text/event-stream"})

    prof = ModelProfile("t", "openai", "gpt-4o", base_url="http://fake/v1", api_key="k")
    assert prof.vision is True
    p = OpenAIProvider(prof)
    from openai import AsyncOpenAI

    p.client = AsyncOpenAI(api_key="k", base_url="http://fake/v1",
                           http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler)))
    r = await p.complete("sys", _history_with_image())
    assert r.content == "ok"
    last = captured["body"]["messages"][-1]
    assert last["role"] == "user" and any(x["type"] == "image_url" for x in last["content"])


def test_drop_old_images_and_token_estimate():
    msgs = []
    for i in range(5):
        msgs.append(Message("tool", f"img{i}", tool_call_id=str(i), name="view_image",
                            meta={"images": [{"media_type": "image/png", "data": "QUJD", "path": f"{i}.png"}]}))
    assert message_tokens(msgs[0]) > 1000
    assert drop_old_images(msgs, keep_recent=2) == 3
    assert [bool(m.meta.get("images")) for m in msgs] == [False, False, False, True, True]
    assert "已移除" in msgs[0].content and "0.png" in msgs[0].content


def test_vision_profile_defaults():
    from omniagent.config import load_settings

    s = load_settings()
    assert s.models["claude"].vision and s.models["openai"].vision
    assert not s.models["deepseek"].vision and not s.models["glm"].vision and not s.models["ollama"].vision
    assert ModelProfile("x", "openai", "qwen-vl-max").vision is True
    assert ModelProfile("x", "openai", "qwen2.5-coder").vision is False
    assert ModelProfile("x", "openai", "qwen2.5-coder", vision=True).vision is True


async def test_anthropic_request_body_contains_image():
    captured = {}

    def handler(request):
        captured["body"] = json.loads(request.content)
        msg = {"id": "m", "type": "message", "role": "assistant", "model": "claude", "content": [],
               "stop_reason": None, "stop_sequence": None, "usage": {"input_tokens": 5, "output_tokens": 1}}
        events = [
            {"type": "message_start", "message": msg},
            {"type": "content_block_start", "index": 0, "content_block": {"type": "text", "text": ""}},
            {"type": "content_block_delta", "index": 0, "delta": {"type": "text_delta", "text": "看到了"}},
            {"type": "content_block_stop", "index": 0},
            {"type": "message_delta", "delta": {"stop_reason": "end_turn", "stop_sequence": None},
             "usage": {"output_tokens": 3}},
            {"type": "message_stop"},
        ]
        body = "".join(f"event: {e['type']}\ndata: {json.dumps(e)}\n\n" for e in events).encode()
        return body

    try:
        import httpx2 as hx
    except ImportError:
        hx = httpx

    def transport_handler(request):
        return hx.Response(200, content=handler(request), headers={"content-type": "text/event-stream"})

    from anthropic import AsyncAnthropic

    p = AnthropicProvider(ModelProfile("c", "anthropic", "claude-x", api_key="k"))
    p.client = AsyncAnthropic(api_key="k", http_client=hx.AsyncClient(transport=hx.MockTransport(transport_handler)))
    r = await p.complete("sys", _history_with_image())
    assert r.content == "看到了"
    last = captured["body"]["messages"][-1]
    tr = last["content"][0]
    assert tr["type"] == "tool_result" and tr["content"][1]["type"] == "image"
    assert tr["content"][1]["source"]["media_type"] == "image/png"
