"""测试全局配置：禁止任何测试意外调用真实模型 API。"""
import os

import pytest

for _k in list(os.environ):
    if _k.startswith(("ANTHROPIC_", "OPENAI_", "DEEPSEEK_", "DASHSCOPE_", "MOONSHOT_", "ZHIPUAI_", "TAVILY_", "OMNI_")):
        os.environ.pop(_k, None)


@pytest.fixture(autouse=True)
def _no_real_keys(monkeypatch, tmp_path):
    monkeypatch.setenv("HOME", str(tmp_path / "home"))  # 隔离 ~/.omniagent
    yield
