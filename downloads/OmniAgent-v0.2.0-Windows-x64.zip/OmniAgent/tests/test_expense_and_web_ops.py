"""智能报销引擎、外部系统操作栏事件、登录提示与真实浏览器自动化的测试。"""
from __future__ import annotations

import asyncio
import json
import platform
import threading
from decimal import Decimal
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import pytest

from expense_fixtures import BUYER, BUYER_ID, make_fixture_set
from omniagent.agent import Agent
from omniagent.config import ModelProfile, Settings
from omniagent.expense import amount_to_chinese, analyze_claim, chinese_to_amount, collect_files, load_policy
from omniagent.llm.mock_provider import MockProvider
from omniagent.llm.types import LLMResponse, ToolCall
from omniagent.safety import approval_reason
from omniagent.tools import ToolContext
from omniagent.tools.expense import expense_reimburse


def _rel(ws: Path):
    return lambda p: str(Path(p).resolve().relative_to(ws.resolve()))


@pytest.fixture()
def claim_ws(tmp_path):
    fx = make_fixture_set(tmp_path / "uploads" / "报销材料")
    if platform.system() != "Darwin":  # 非 macOS 无系统 OCR：去掉图片水单
        fx["folio"].unlink()
    return tmp_path, fx


def test_amount_conversion_roundtrip():
    cases = {"1000": "壹仟元整", "1234.5": "壹仟贰佰叁拾肆元伍角整", "100500.07": "壹拾万零伍佰元零柒分",
             "0.05": "伍分", "10000001": "壹仟万零壹元整", "2841": "贰仟捌佰肆拾壹元整"}
    for num, words in cases.items():
        assert amount_to_chinese(num) == words
        assert chinese_to_amount(words) == Decimal(num).quantize(Decimal("0.01"))
    assert chinese_to_amount("⊗捌拾捌圆整") == Decimal("88.00")


def test_analyze_claim_full_package(claim_ws):
    ws, fx = claim_ws
    files, _ = collect_files([ws / "uploads"])
    pol = load_policy(ws, {"company_name": BUYER, "company_tax_id": BUYER_ID})
    r = analyze_claim(files, workspace=ws, out_dir=ws / "outputs" / "报销" / "BX1",
                      info={"claimant": "张三", "department": "交付部", "purpose": "上海差旅", "claimed_total": 2841},
                      policy=pol, rel=_rel(ws))
    assert r["grand_total"] == Decimal("2841.00")
    assert r["grand_total_words"] == "贰仟捌佰肆拾壹元整"
    assert r["invoice_count"] == 4
    assert set(r["summary_by_category"]) == {"住宿费", "市内交通费", "餐饮费", "城际交通费"}
    # 可抵扣：住宿专票 56.60 + 网约车 2.56 + 高铁 45.66
    assert r["deductible_total"] == Decimal("104.82")
    titles = [x["title"] for x in r["issues"]]
    assert "重复上传同一文件" in titles
    assert "餐饮费超提示阈值" in titles
    assert "缺少打车行程单" not in titles and "发票与行程单金额不一致" not in titles
    assert "缺少出差审批单" not in titles and "发票抬头不符" not in titles
    assert r["reconciliation"]["diff"] == Decimal("0.00")
    assert r["status"] == "review"  # 只有需人工确认项
    for key in ("expense_form_xlsx", "amount_report_docx", "content_report_docx", "portal_fill_json"):
        assert (ws / r["outputs"][key]).is_file()
    fill = json.loads((ws / r["outputs"]["portal_fill_json"]).read_text(encoding="utf-8"))
    assert fill["header"]["报销总金额"] == 2841.0 and len(fill["lines"]) == 4
    md = (ws / r["outputs"]["amount_report_md"]).read_text(encoding="utf-8")
    assert "2,841.00" in md and "贰仟捌佰肆拾壹元整" in md
    assert len(list((ws / "outputs" / "报销" / "BX1" / "附件").iterdir())) == r["attachment_count"]


def test_missing_itinerary_wrong_title_and_resubmission(claim_ws):
    ws, fx = claim_ws
    fx["taxi_itinerary"].unlink()
    files, _ = collect_files([ws / "uploads"])
    pol = load_policy(ws, {"company_name": "另一家公司有限公司"})
    r = analyze_claim(files, workspace=ws, out_dir=ws / "outputs" / "BX2", info={}, policy=pol, rel=_rel(ws))
    titles = [x["title"] for x in r["issues"]]
    assert "缺少打车行程单" in titles and "发票抬头不符" in titles
    assert r["status"] == "blocked"


@pytest.mark.asyncio
async def test_expense_tool_overrides_manual_items_and_duplicate_guard(claim_ws):
    ws, fx = claim_ws
    events = []

    async def emit(e):
        events.append(e)

    ctx = ToolContext(ws, Settings(), emit, None, {})
    res = await expense_reimburse.run({
        "action": "analyze", "paths": ["uploads/报销材料"], "claimant": "张三", "purpose": "上海差旅",
        "exclude": ["餐饮发票.pdf"],
        "overrides": {"高铁票_北京南-上海虹桥.pdf": {"fields": {"total": "600.00"}, "note": "原件票价为 600 元"}},
        "manual_items": [{"doc_type": "vat_invoice", "category": "办公用品费", "invoice_no": "99990000111122223333",
                          "date": "2026-11-12", "total": 66.5, "amount_ex_tax": 58.85, "tax": 7.65, "note": "纸质发票照片人工读取"}],
    }, ctx)
    assert not res.is_error, res.content
    assert res.data["grand_total"] == pytest.approx(1000 + 88 + 600 + 66.5)
    assert "餐饮费" not in res.content.split("### 分类汇总")[1].split("###")[0]
    batch = res.data["batch_id"]
    mk = await expense_reimburse.run({"action": "mark_submitted", "batch_id": batch, "note": "BX-0001"}, ctx)
    assert "已提交" in mk.content
    again = await expense_reimburse.run({"action": "analyze", "paths": ["uploads/报销材料"]}, ctx)
    assert "发票已报销过" in again.content
    hist = await expense_reimburse.run({"action": "history"}, ctx)
    assert batch in hist.content
    pol = await expense_reimburse.run({"action": "set_policy", "policy": {"hotel_cap_per_night": 300}}, ctx)
    assert "hotel_cap_per_night=300" in pol.content
    assert load_policy(ws)["hotel_cap_per_night"] == 300


def test_final_submit_always_requires_user_confirmation():
    for policy in ("auto", "smart", "always"):
        assert approval_reason("web_automation", "exec", {"action": "submit", "target": "提交"}, policy)
    assert approval_reason("web_automation", "exec", {"action": "fill"}, "auto") is None


@pytest.mark.asyncio
async def test_external_ops_events_and_persistence(claim_ws):
    ws, _ = claim_ws
    script = [
        LLMResponse(content="", tool_calls=[ToolCall("t1", "expense_reimburse",
                                                      {"action": "analyze", "paths": ["uploads/报销材料"], "claimant": "张三"})]),
        LLMResponse(content="初步完成", tool_calls=[]),
        LLMResponse(content="报销核对完成", tool_calls=[]),  # 自检轮后的最终汇报
    ]
    events = []

    async def on_event(e):
        events.append(e)

    agent = Agent(MockProvider(ModelProfile("mock", "mock", "mock"), script), Settings(), ws, on_event=on_event,
                  memory_enabled=False)
    try:
        out = await agent.run("帮我报销")
    finally:
        await agent.close()
    assert out == "报销核对完成"
    ops = [e for e in events if e["type"] == "external_op"]
    assert [o["status"] for o in ops][0] == "running" and ops[-1]["status"] == "done"
    assert ops[-1]["system"] == "智能报销" and "报销核对完成" in ops[-1]["detail"]
    saved = json.loads(next((ws / ".omniagent" / "sessions").glob("*.json")).read_text(encoding="utf-8"))
    assert saved["external_ops"] and saved["external_ops"][-1]["tool"] == "expense_reimburse"
    paths = {f["path"] for f in saved["file_changes"]}
    assert any(p.endswith(".xlsx") for p in paths) and any("金额核对报告" in p for p in paths)


# ---------------------------------------------------------------- 真实浏览器自动化（本地模拟报销系统）
PORTAL_HTML = """<!doctype html><html><head><meta charset='utf-8'><title>模拟报销系统</title></head><body>
<div id='app'></div>
<script>
const logged = document.cookie.includes('sid=ok');
const app = document.getElementById('app');
if (!logged) {
  app.innerHTML = "<h2>用户登录</h2><label for='u'>账号</label><input id='u'><label for='p'>密码</label><input id='p' type='password'>"
    + "<button id='login'>登录</button>";
  document.getElementById('login').onclick = () => { document.cookie = 'sid=ok; path=/'; location.reload(); };
} else {
  app.innerHTML = "<h2>差旅报销单</h2><form method='post' action='/submit' enctype='multipart/form-data'>"
    + "<div class='form-item'><label for='who'>报销人</label><input id='who' name='claimant'></div>"
    + "<div class='form-item'><label for='why'>报销事由</label><input id='why' name='purpose'></div>"
    + "<div class='form-item'><label for='amt'>报销金额</label><input id='amt' name='amount'></div>"
    + "<div class='form-item'><label for='typ'>费用类型</label><select id='typ' name='type'><option>请选择</option><option>差旅费</option><option>日常费用</option></select></div>"
    + "<div class='form-item'><label for='att'>附件</label><input id='att' type='file' name='att' multiple></div>"
    + "<button type='submit'>提交报销</button></form>";
}
</script></body></html>"""


class _Portal(BaseHTTPRequestHandler):
    received: dict = {}

    def log_message(self, *a):
        pass

    def do_GET(self):
        body = PORTAL_HTML.encode()
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(n)
        _Portal.received["body"] = raw
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write("<html><body><h2>提交成功</h2><p>单据号 BX-20261124-001</p></body></html>".encode())


@pytest.fixture()
def portal():
    srv = ThreadingHTTPServer(("127.0.0.1", 0), _Portal)
    th = threading.Thread(target=srv.serve_forever, daemon=True)
    th.start()
    yield f"http://127.0.0.1:{srv.server_address[1]}/lczPortal/home"
    srv.shutdown()


@pytest.mark.asyncio
async def test_web_automation_login_prompt_fill_upload_submit(tmp_path, portal):
    pytest.importorskip("playwright")
    from omniagent.tools.web_automation import close_web_sessions, web_automation

    (tmp_path / "附件.pdf").write_bytes(b"%PDF-1.4 test")
    events = []

    async def emit(e):
        events.append(e)

    state: dict = {"_active_tool_id": "op1"}
    ctx = ToolContext(tmp_path, Settings(), emit, None, state)
    try:
        try:
            r = await web_automation.run({"action": "open", "url": portal, "session": "bx", "note": "打开报销系统"}, ctx)
        except Exception as e:  # noqa: BLE001
            pytest.skip(f"浏览器不可用: {e}")
        if r.is_error and "无法启动浏览器" in r.content:
            pytest.skip(r.content)
        assert "需要登录" in r.content and r.data["screenshot"]
        # 无界面模式下 wait_login 必须如实告知用户无法登录，而不是假装成功
        w = await web_automation.run({"action": "wait_login", "session": "bx", "seconds": 5}, ctx)
        assert w.is_error and "无界面" in w.content
        # 模拟“用户亲自登录”（测试中由脚本点击登录按钮代替人）
        sess = state["_pw_sessions"]["bx"]
        await sess.page.click("#login")
        await sess._settle()
        w2 = await web_automation.run({"action": "wait_login", "session": "bx", "seconds": 5}, ctx)
        assert not w2.is_error and "已处于登录状态" in w2.content
        snap = await web_automation.run({"action": "snapshot", "session": "bx"}, ctx)
        assert "报销事由" in snap.content and "需要登录" not in snap.content
        f = await web_automation.run({"action": "fill", "session": "bx", "fields": {
            "报销人": "张三", "报销事由": "上海差旅", "报销金额": "2841.00", "密码": "x"}}, ctx)
        assert "张三" in f.content and "密码字段" in f.content
        s = await web_automation.run({"action": "select", "session": "bx", "target": "费用类型", "value": "差旅费"}, ctx)
        assert "差旅费" in s.content
        u = await web_automation.run({"action": "upload", "session": "bx", "target": "附件", "files": ["附件.pdf"]}, ctx)
        assert "已上传 1 个附件" in u.content
        sub = await web_automation.run({"action": "submit", "session": "bx", "target": "提交报销"}, ctx)
        assert "提交成功" in sub.content and "BX-20261124-001" in sub.content
        body = _Portal.received["body"].decode("utf-8", "replace")
        assert "上海差旅" in body and "2841.00" in body and "差旅费" in body and "附件.pdf" in body
        assert any(e.get("type") == "external_op" and e.get("id") == "op1" for e in events)  # 填写进度实时推送
        assert sub.data["screenshot"] and (tmp_path / sub.data["screenshot"]).is_file()
        assert len(list((tmp_path / "outputs" / "web_ops").rglob("*.jpg"))) >= 5
    finally:
        await close_web_sessions(state)


@pytest.mark.asyncio
async def test_wait_login_prompts_user_and_continues_after_confirmation(tmp_path, portal, monkeypatch):
    pytest.importorskip("playwright")
    from omniagent.tools import web_automation as wa

    events = []
    state: dict = {"_active_tool_id": "op2"}

    async def emit(e):
        events.append(e)
        if e.get("type") == "login_required":
            # 用户在界面点击「我已完成登录」
            state.setdefault("_login_confirmed", set()).add(e["id"])

    ctx = ToolContext(tmp_path, Settings(), emit, None, state)
    try:
        try:
            await wa.web_automation.run({"action": "open", "url": portal, "session": "bx2"}, ctx)
        except Exception as e:  # noqa: BLE001
            pytest.skip(f"浏览器不可用: {e}")
        sess = state["_pw_sessions"]["bx2"]
        sess.headless = False  # 模拟有界面窗口（实际仍为无头，避免测试弹窗）
        r = await wa.web_automation.run({"action": "wait_login", "session": "bx2", "seconds": 20, "note": "报销系统"}, ctx)
        assert not r.is_error, r.content
        types = [e["type"] for e in events]
        assert "login_required" in types and "login_resolved" in types
        req = next(e for e in events if e["type"] == "login_required")
        assert "报销系统" in req["message"] and "亲自完成登录" in req["message"]
        assert state.get("_login_pending") is None
    finally:
        await wa.close_web_sessions(state)
