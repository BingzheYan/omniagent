import asyncio
from pathlib import Path

import pytest
import pytest_asyncio

from omniagent.config import Settings
from omniagent.safety import approval_reason, check_blocked
from omniagent.tools import ToolContext, ToolError, build_default_registry


async def _noop(e):
    return None


@pytest_asyncio.fixture
async def ctx(tmp_path: Path):
    c = ToolContext(tmp_path.resolve(), Settings(), _noop)
    yield c
    from omniagent.tools.python_exec import shutdown_kernel

    await shutdown_kernel(c.state)


@pytest.fixture
def reg():
    return build_default_registry(Settings())


async def run(reg, name, args, ctx):
    return await reg.get(name).run(args, ctx)


async def test_write_read_edit(reg, ctx):
    r = await run(reg, "write_file", {"path": "a/b.py", "content": "x = 1\ny = 2\n"}, ctx)
    assert "已创建" in r.content
    r = await run(reg, "read_file", {"path": "a/b.py"}, ctx)
    assert "x = 1" in r.content and "     1\t" in r.content
    r = await run(reg, "edit_file", {"path": "a/b.py", "old_string": "y = 2", "new_string": "y = 3"}, ctx)
    assert "+1 -1" in r.content
    assert (ctx.workspace / "a/b.py").read_text() == "x = 1\ny = 3\n"


async def test_edit_requires_unique(reg, ctx):
    await run(reg, "write_file", {"path": "f.txt", "content": "a\na\n"}, ctx)
    with pytest.raises(ToolError):
        await run(reg, "edit_file", {"path": "f.txt", "old_string": "a", "new_string": "b"}, ctx)
    await run(reg, "edit_file", {"path": "f.txt", "old_string": "a", "new_string": "b", "replace_all": True}, ctx)
    assert (ctx.workspace / "f.txt").read_text() == "b\nb\n"


async def test_sandbox_blocks_outside(reg, ctx):
    with pytest.raises(ToolError):
        await run(reg, "write_file", {"path": "../escape.txt", "content": "x"}, ctx)


async def test_glob_grep_list(reg, ctx):
    await run(reg, "write_file", {"path": "src/m.py", "content": "def hello():\n    pass\n"}, ctx)
    assert "src/m.py" in (await run(reg, "glob", {"pattern": "**/*.py"}, ctx)).content
    assert "hello" in (await run(reg, "grep", {"pattern": "def hel"}, ctx)).content
    assert "m.py" in (await run(reg, "list_dir", {}, ctx)).content


async def test_shell(reg, ctx):
    r = await run(reg, "run_shell", {"command": "echo hi && exit 3"}, ctx)
    assert "hi" in r.content and r.is_error and "exit code: 3" in r.content


async def test_python_persistent_and_figure(reg, ctx):
    r = await run(reg, "python", {"code": "import pandas as pd\ndf = pd.DataFrame({'a':[1,2,3]})\ndf['a'].sum()"}, ctx)
    assert "Out: 6" in r.content, r.content
    r = await run(reg, "python", {"code": "import matplotlib.pyplot as plt\nplt.plot(df['a'])\nprint('ok')"}, ctx)
    assert "ok" in r.content and r.data["images"], r.content
    assert (ctx.workspace / r.data["images"][0]).exists()
    r = await run(reg, "python", {"code": "1/0"}, ctx)
    assert r.is_error and "ZeroDivisionError" in r.content


async def test_documents_roundtrip(reg, ctx):
    md = "# 报告\n\n## 摘要\n\n这是**重点**内容。\n\n- 要点一\n- 要点二\n\n| 地区 | 销售额 |\n|---|---|\n| 华东 | 100 |\n"
    r = await run(reg, "create_document", {"output_path": "out/r.docx", "markdown": md}, ctx)
    assert not r.is_error
    text = (await run(reg, "read_file", {"path": "out/r.docx"}, ctx)).content
    assert "摘要" in text and "华东" in text and "重点" in text
    await run(reg, "create_document", {"output_path": "out/r.html", "markdown": md}, ctx)
    assert "<table>" in (ctx.workspace / "out/r.html").read_text()
    await run(reg, "create_presentation", {"output_path": "out/p.pptx", "title": "汇报",
                                           "slides": [{"title": "背景", "bullets": ["a", "  b"]}]}, ctx)
    assert "背景" in (await run(reg, "read_file", {"path": "out/p.pptx"}, ctx)).content
    await run(reg, "create_spreadsheet", {"output_path": "out/s.xlsx", "sheets": [{"name": "数据", "rows": [["名称", "值"], ["x", 1]]}]}, ctx)
    assert "名称" in (await run(reg, "read_file", {"path": "out/s.xlsx"}, ctx)).content


def test_safety():
    assert check_blocked("run_shell", {"command": "rm -rf /"})
    assert check_blocked("run_shell", {"command": "sudo shutdown -h now"})
    assert not check_blocked("run_shell", {"command": "rm -rf build/"})
    assert approval_reason("run_shell", "exec", {"command": "rm -rf build"}, "smart")
    assert approval_reason("run_shell", "exec", {"command": "pytest -q"}, "smart") is None
    assert approval_reason("run_shell", "exec", {"command": "rm -rf build"}, "auto") is None
    assert approval_reason("write_file", "write", {}, "always")
