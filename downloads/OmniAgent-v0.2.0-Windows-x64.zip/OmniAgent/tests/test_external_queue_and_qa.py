"""外部系统双向联动（邮件/日历/求职投递/OpenAPI探测）、PPT/PDF改写、全链路实测验收与多问题排队测试。
全程基于本地沙箱与模拟模型运行，零真实外部大模型调用。
"""
from __future__ import annotations

import socket
import sys
import threading
import time
from pathlib import Path

import pytest
import uvicorn
from fastapi import FastAPI, File, Form, UploadFile
from fastapi.responses import HTMLResponse
from fastapi.testclient import TestClient

from omniagent.agent import Agent
from omniagent.config import load_settings
from omniagent.connectors.protocols import parse_ics_text
from omniagent.llm.mock_provider import MockProvider
from omniagent.llm.types import LLMResponse, ToolCall
from omniagent.tools import ToolContext, build_default_registry
from omniagent.web.server import create_app


def _make_ctx(workspace: Path) -> ToolContext:
    settings = load_settings(workspace)

    async def _noop_emit(_ev):
        return None

    return ToolContext(workspace=workspace, settings=settings, emit=_noop_emit, state={})


@pytest.mark.asyncio
async def test_email_thread_reply_and_continuous_tracking(tmp_path: Path):
    """验证邮箱自动读取未读来信、发送保持线程的回复，并在对方回信后由 tracker_manage 自动感知新动态。"""
    reg = build_default_registry()
    ctx = _make_ctx(tmp_path)
    email_tool = reg.get("email_ops")
    tracker_tool = reg.get("tracker_manage")
    assert email_tool and tracker_tool

    # 1. 收到外部合作方来信
    inbound = await email_tool.run({
        "action": "seed_inbound",
        "to": "director@partner.org",
        "subject": "关于2026年度预算评审会的议程确认",
        "body": "您好，请确认本周五下午是否有空参加预算评审会，并请回复参会回执。",
    }, ctx)
    msg_id = inbound.data["email"]["id"]
    raw_msgid = inbound.data["email"]["message_id"]

    # 2. 读取未读邮件列表与详情
    listed = await email_tool.run({"action": "list", "unread_only": True}, ctx)
    assert "预算评审会" in listed.content

    detail = await email_tool.run({"action": "read", "message_id": msg_id}, ctx)
    assert "director@partner.org" in detail.content

    # 3. 发送线程回复（自动开启 email_thread 跟踪器）
    replied = await email_tool.run({
        "action": "send_reply",
        "message_id": msg_id,
        "body": "已确认日程无冲突，周五下午准时出席评审会。",
        "auto_track": True,
    }, ctx)
    assert not replied.is_error
    reply_msgid = replied.data["result"]["message_id"]

    # 此时尚未收到对方二次回信，poll 应无新邮件告警
    poll_1 = await tracker_tool.run({"action": "poll"}, ctx)
    assert "暂无新邮件回复" in poll_1.content

    # 4. 模拟外部合作方针对我们的回复再次回信（同一线程）
    await email_tool.run({
        "action": "seed_inbound",
        "to": "director@partner.org",
        "subject": "Re: 关于2026年度预算评审会的议程确认",
        "body": "收到您的确认！会议室定在 A302，期待周五见。",
        "message_id": reply_msgid or raw_msgid,
    }, ctx)

    # 5. 巡检跟踪器：自动发现对方已回信并更新状态
    poll_2 = await tracker_tool.run({"action": "poll"}, ctx)
    assert "邮件线程有新回复" in poll_2.content
    assert "A302" in poll_2.content


@pytest.mark.asyncio
async def test_calendar_conflict_detection_ics_and_reminders(tmp_path: Path):
    """验证日历排期、时间冲突检测、标准 .ics 导出及即将到期提醒。"""
    reg = build_default_registry()
    ctx = _make_ctx(tmp_path)
    cal = reg.get("calendar_ops")
    assert cal

    soon_start = time.strftime("%Y-%m-%dT%H:%M", time.localtime(time.time() + 1800))
    soon_end = time.strftime("%Y-%m-%dT%H:%M", time.localtime(time.time() + 5400))

    added = await cal.run({
        "action": "add",
        "title": "核心架构代码审查会",
        "start_time": soon_start,
        "end_time": soon_end,
        "location": "线上会议室 801",
        "reminder_minutes": 45,
        "export_ics_path": "outputs/review_invite.ics",
    }, ctx)
    assert not added.is_error
    assert (tmp_path / "outputs" / "review_invite.ics").is_file()

    # 解析导出的 .ics 验证标准兼容性
    parsed = parse_ics_text((tmp_path / "outputs" / "review_invite.ics").read_text(encoding="utf-8"))
    assert len(parsed) == 1
    assert parsed[0]["title"] == "核心架构代码审查会"

    # 冲突检测：同一时间段应检出冲突
    conflict = await cal.run({
        "action": "check_conflicts",
        "start_time": soon_start,
        "end_time": soon_end,
    }, ctx)
    assert "时间冲突" in conflict.content

    # 到期提醒检查：未来 60 分钟内应触发提醒
    rems = await cal.run({"action": "reminders", "within_minutes": 60}, ctx)
    assert "核心架构代码审查会" in rems.content


@pytest.mark.asyncio
async def test_job_portal_discovery_cover_letter_and_submission(tmp_path: Path):
    """端到端模拟招聘平台：自动探测 OpenAPI -> 打开岗位页 -> 定制 Cover Letter PDF -> 填写表单上传简历并投递 -> 登记跟踪。"""
    submitted_records: list[dict] = []
    portal = FastAPI(title="TalentHub ATS API")

    @portal.get("/jobs/ai-architect", response_class=HTMLResponse)
    async def job_page():
        return """
        <html><head><title>首席 AI 智能体架构师 - TalentHub</title></head>
        <body>
          <h1>岗位：首席 AI 智能体架构师</h1>
          <p>岗位职责：负责自主执行型多智能体内核、工具沙箱与记忆系统的架构设计。</p>
          <form action="/api/apply" method="post" enctype="multipart/form-data">
            <input type="text" name="candidate_name" placeholder="候选人姓名" required />
            <input type="email" name="candidate_email" placeholder="联系邮箱" required />
            <select name="years_exp"><option value="3-5">3-5年</option><option value="5+">5年以上</option></select>
            <textarea name="cover_letter" placeholder="针对本岗位的求职信"></textarea>
            <input type="file" name="resume_file" />
            <button type="submit">立即投递申请</button>
          </form>
        </body></html>
        """

    @portal.post("/api/apply", response_class=HTMLResponse)
    async def apply_job(
        candidate_name: str = Form(...),
        candidate_email: str = Form(...),
        years_exp: str = Form("3-5"),
        cover_letter: str = Form(""),
        resume_file: UploadFile = File(...),
    ):
        raw = await resume_file.read()
        submitted_records.append({
            "name": candidate_name,
            "email": candidate_email,
            "years_exp": years_exp,
            "cover_letter": cover_letter,
            "filename": resume_file.filename,
            "size": len(raw),
        })
        return f"<html><head><title>投递成功</title></head><body><h2>申请已受理：REF-2026-889</h2><p>候选人：{candidate_name}</p></body></html>"

    # 在本地空闲端口启动模拟招聘系统
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]
    cfg = uvicorn.Config(portal, host="127.0.0.1", port=port, log_level="error")
    srv = uvicorn.Server(cfg)
    th = threading.Thread(target=srv.run, daemon=True)
    th.start()
    base_url = f"http://127.0.0.1:{port}"
    for _ in range(40):
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.2):
                break
        except OSError:
            time.sleep(0.1)

    try:
        settings = load_settings(tmp_path)
        profile = settings.get_model("mock")
        # 预先写入用户的真实个人经历到长期记忆画像
        agent_seed = Agent(MockProvider(profile, script=[]), settings, tmp_path, approval="auto")
        agent_seed.memory_store.upsert_trait("identity", "resume_bg", "博士毕业于计算机系，主导过多智能体编排与分布式沙箱研发（6年经验）", source="explicit")
        await agent_seed.close()

        script = [
            LLMResponse(
                thinking="先自动探测外部招聘系统的 OpenAPI 接口规范，并打开目标岗位页面读取 JD 与表单控件。",
                content="",
                tool_calls=[
                    ToolCall("j1", "connector_manage", {"action": "discover", "url": base_url}),
                    ToolCall("j2", "browser_session", {"action": "open", "url": f"{base_url}/jobs/ai-architect"}),
                ],
            ),
            LLMResponse(
                thinking="结合长期记忆中的候选人博士与6年多智能体架构背景，生成定制 Cover Letter 与简历文档。",
                content="",
                tool_calls=[
                    ToolCall("j3", "create_document", {
                        "output_path": "outputs/tailored_resume_and_cl.docx",
                        "title": "求职申请：首席 AI 智能体架构师",
                        "markdown": "# 求职自荐信\n\n尊敬的招聘团队：结合贵司对多智能体内核与工具沙箱的岗位需求，本人拥有 6 年分布式智能体研发经验……",
                    }),
                ],
            ),
            LLMResponse(
                thinking="填写姓名、邮箱、年限与定制求职陈述，挂载简历附件并正式提交申请，随后登记求职追踪台账。",
                content="",
                tool_calls=[
                    ToolCall("j4", "browser_session", {
                        "action": "fill",
                        "fields": {
                            "candidate_name": "林致远",
                            "candidate_email": "zhiyuan@example.com",
                            "years_exp": "5+",
                            "cover_letter": "针对首席 AI 智能体架构师岗位定制：具备 6 年多智能体编排与安全沙箱架构实战经验。",
                        },
                    }),
                    ToolCall("j5", "browser_session", {
                        "action": "upload",
                        "target": "resume_file",
                        "file_path": "outputs/tailored_resume_and_cl.docx",
                    }),
                    ToolCall("j6", "browser_session", {"action": "submit"}),
                    ToolCall("j7", "tracker_manage", {
                        "action": "upsert",
                        "kind": "job_application",
                        "title": "TalentHub · 首席 AI 智能体架构师",
                        "target_ref": f"{base_url}/jobs/ai-architect",
                        "status": "submitted",
                        "meta": {"ref": "REF-2026-889", "cover_letter": "outputs/tailored_resume_and_cl.docx"},
                    }),
                ],
            ),
            LLMResponse(thinking="自检通过。", content="", tool_calls=[]),
            LLMResponse(thinking="汇报投递结果。", content="已完成岗位定制求职信生成并成功投递（受理号 REF-2026-889）。", tool_calls=[]),
        ]

        agent = Agent(MockProvider(profile, script=script), settings, tmp_path, approval="auto")
        try:
            res = await agent.run(f"帮我连接招聘系统 {base_url}/jobs/ai-architect ，根据我的个人经历撰写 cover letter 并完成投递")
            assert "REF-2026-889" in res
            assert len(submitted_records) == 1
            rec = submitted_records[0]
            assert rec["name"] == "林致远"
            assert rec["years_exp"] == "5+"
            assert "多智能体" in rec["cover_letter"]
            assert rec["filename"] == "tailored_resume_and_cl.docx"
            assert rec["size"] > 1000
        finally:
            await agent.close()
    finally:
        srv.should_exit = True


@pytest.mark.asyncio
async def test_pptx_edit_pdf_ops_and_live_verify_deliverable(tmp_path: Path):
    """验证 PPT 原地改写、PDF 合并与水印加盖，以及 verify_deliverable 对真实 Web 服务与文档的实测验收。"""
    reg = build_default_registry()
    ctx = _make_ctx(tmp_path)

    # 1. 创建初始 PPTX 并使用 edit_presentation 改写
    await reg.get("create_presentation").run({
        "output_path": "outputs/q3_deck.pptx",
        "title": "2026 Q3 经营复盘",
        "subtitle": "初稿版本",
        "slides": [
            {"title": "核心指标", "bullets": ["营收同比增长 18%", "毛利率保持稳定"]},
            {"title": "待删除草稿页", "bullets": ["临时占位"]},
        ],
    }, ctx)

    edited_ppt = await reg.get("edit_presentation").run({
        "input_path": "outputs/q3_deck.pptx",
        "output_path": "outputs/q3_deck_final.pptx",
        "replacements": [{"old": "18%", "new": "24.6%"}, {"old": "初稿版本", "new": "董事会定稿版"}],
        "delete_slides": [3],
        "add_slides": [{"title": "Q4 战略行动路线", "bullets": ["全面推进智能体自动化", "拓展海外独立站渠道"]}],
    }, ctx)
    assert not edited_ppt.is_error

    # 2. 创建两份 PDF 并用 pdf_ops 合并 + 加盖页眉水印
    from pypdf import PdfWriter

    for name in ("part1.pdf", "part2.pdf"):
        w = PdfWriter()
        w.add_blank_page(width=595, height=842)
        with open(tmp_path / name, "wb") as f:
            w.write(f)

    merged = await reg.get("pdf_ops").run({
        "action": "merge",
        "input_paths": ["part1.pdf", "part2.pdf"],
        "output_path": "outputs/combined.pdf",
    }, ctx)
    assert not merged.is_error

    stamped = await reg.get("pdf_ops").run({
        "action": "stamp_text",
        "input_path": "outputs/combined.pdf",
        "output_path": "outputs/combined_stamped.pdf",
        "stamp": "OMNIAGENT CONFIDENTIAL",
        "position": "watermark",
    }, ctx)
    assert not stamped.is_error

    # 3. 使用 verify_deliverable 实测验收 PPTX 与 PDF
    qa_doc = await reg.get("verify_deliverable").run({
        "kind": "office_file",
        "paths": ["outputs/q3_deck_final.pptx", "outputs/combined_stamped.pdf"],
    }, ctx)
    assert not qa_doc.is_error
    assert qa_doc.data["passed"] is True

    # 4. 编写一个真实的迷你 Python Web 服务并用 verify_deliverable(kind="web_service") 实测启动验收
    (tmp_path / "mini_app.py").write_text(
        "import sys, json\n"
        "from http.server import BaseHTTPRequestHandler, HTTPServer\n"
        "port = int(sys.argv[1])\n"
        "class H(BaseHTTPRequestHandler):\n"
        "    def do_GET(self):\n"
        "        self.send_response(200)\n"
        "        self.send_header('Content-Type', 'application/json')\n"
        "        self.end_headers()\n"
        "        self.wfile.write(json.dumps({'ok': True, 'service': 'mini_app'}).encode())\n"
        "    def log_message(self, *a): pass\n"
        "HTTPServer(('127.0.0.1', port), H).serve_forever()\n",
        encoding="utf-8",
    )

    qa_web = await reg.get("verify_deliverable").run({
        "kind": "web_service",
        "server_command": f'"{sys.executable}" mini_app.py {{port}}',
        "endpoints": [
            {"path": "/health", "method": "GET", "expect_status": 200, "expect_contains": "mini_app"},
        ],
    }, ctx)
    assert not qa_web.is_error
    assert qa_web.data["passed"] is True

    qa_py = await reg.get("verify_deliverable").run({
        "kind": "python_code",
        "paths": ["mini_app.py"],
    }, ctx)
    assert not qa_py.is_error


def test_websocket_multi_prompt_queue_execution(tmp_path: Path):
    """验证 WebSocket 多问题排队：连续入队 3 条问题、调整队列顺序、编辑内容并一次性依次自动执行完毕。"""
    settings = load_settings(tmp_path)
    app = create_app(tmp_path / "server_data", settings, default_model="mock")

    with TestClient(app) as client:
        r = client.post("/api/auth/register", json={"username": "queue_tester", "password": "password123"})
        assert r.status_code == 200

        with client.websocket_connect("/ws") as ws:
            ws.send_json({"type": "new", "model": "mock", "approval": "auto"})
            ready = ws.receive_json()
            assert ready["type"] == "ready"
            assert ready["queue"] == []
            cid = ready["conversation_id"]

            # 连续加入 3 个排队问题
            ws.send_json({"type": "queue_add", "content": "排队问题A：分析模块一"})
            ev_a = ws.receive_json()
            assert ev_a["type"] == "queue_updated"
            assert len(ev_a["queue"]) == 1

            ws.send_json({"type": "queue_add", "content": "排队问题B：分析模块二"})
            ev_b = ws.receive_json()
            assert len(ev_b["queue"]) == 2
            id_b = ev_b["enqueued"]["id"]

            ws.send_json({"type": "queue_add", "content": "排队问题C：将被移除"})
            ev_c = ws.receive_json()
            assert len(ev_c["queue"]) == 3
            id_c = ev_c["enqueued"]["id"]

            # 将 B 置顶到第一位，并删除 C
            ws.send_json({"type": "queue_move", "id": id_b, "direction": "top"})
            ev_mv = ws.receive_json()
            assert ev_mv["queue"][0]["id"] == id_b

            ws.send_json({"type": "queue_remove", "id": id_c})
            ev_rm = ws.receive_json()
            assert len(ev_rm["queue"]) == 2

            # 启动队列执行：验证 B 与 A 依次自动出队并连续执行直至最终 idle
            ws.send_json({"type": "queue_flush"})
            started_tasks: list[str] = []
            for _ in range(400):
                m = ws.receive_json()
                if m["type"] == "task_start" and (m.get("depth") or 0) == 0:
                    started_tasks.append(m["task"])
                if m["type"] == "idle":
                    assert m["queue"] == []
                    break

            assert started_tasks == ["排队问题B：分析模块二", "排队问题A：分析模块一"]

        # 确认两轮对话都已完整持久化在会话历史中
        conv = client.get(f"/api/conversations/{cid}").json()
        user_turns = [h["content"] for h in conv["history"] if h["role"] == "user"]
        assert user_turns == ["排队问题B：分析模块二", "排队问题A：分析模块一"]


def test_simultaneous_multi_conversation_switching_isolation(tmp_path: Path):
    """验证在一个对话执行期间切换到新对话同时运行：原对话在后台不受影响继续完成，两边产物与历史严格隔离。"""
    settings = load_settings(tmp_path)
    app = create_app(tmp_path / "server_data", settings, default_model="mock")

    with TestClient(app) as client:
        r = client.post("/api/auth/register", json={"username": "multi_runner", "password": "password123"})
        assert r.status_code == 200

        with client.websocket_connect("/ws") as ws:
            # 1. 创建对话 1 并立即发送任务
            ws.send_json({"type": "new", "model": "mock", "approval": "auto"})
            ready1 = ws.receive_json()
            while ready1["type"] != "ready":
                ready1 = ws.receive_json()
            cid1 = ready1["conversation_id"]

            ws.send_json({"type": "task", "content": "并发对话一：独立编写后台报告"})

            # 2. 不等待对话 1 完成，立即新建切换到对话 2 并同时启动第二个任务！
            ws.send_json({"type": "new", "model": "mock", "approval": "auto"})
            ready2 = None
            for _ in range(200):
                ev = ws.receive_json()
                if ev["type"] == "ready" and ev["conversation_id"] != cid1:
                    ready2 = ev
                    break
            assert ready2 is not None
            cid2 = ready2["conversation_id"]
            assert cid2 != cid1

            ws.send_json({"type": "task", "content": "并发对话二：同时执行另一项编程任务"})

            # 等待对话 2 完成
            for _ in range(300):
                ev = ws.receive_json()
                if ev.get("type") == "idle" and ev.get("conversation_id") == cid2:
                    break

            # 3. 切回对话 1，验证对话 1 在后台未受任何中断且已独立完成（或继续完成）
            ws.send_json({"type": "init", "conversation_id": cid1})
            ready1_back = None
            for _ in range(200):
                ev = ws.receive_json()
                if ev.get("type") == "ready" and ev.get("conversation_id") == cid1:
                    ready1_back = ev
                    break
            assert ready1_back is not None
            if ready1_back["running"]:
                for _ in range(200):
                    ev = ws.receive_json()
                    if ev.get("type") == "idle" and ev.get("conversation_id") == cid1:
                        break

        # 4. 核验两个对话在数据库中各自独立保存了完整对话，互不串台
        c1 = client.get(f"/api/conversations/{cid1}").json()
        c2 = client.get(f"/api/conversations/{cid2}").json()
        u1 = [h["content"] for h in c1["history"] if h["role"] == "user"]
        u2 = [h["content"] for h in c2["history"] if h["role"] == "user"]
        assert u1 == ["并发对话一：独立编写后台报告"]
        assert u2 == ["并发对话二：同时执行另一项编程任务"]
        assert any(h["role"] == "assistant" and h["content"] for h in c1["history"])
        assert any(h["role"] == "assistant" and h["content"] for h in c2["history"])

