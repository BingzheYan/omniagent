"""生成逼真的报销测试票据（电子发票 PDF、铁路电子客票、网约车行程单、酒店水单图片、出差审批单 Word）。"""
from __future__ import annotations

import shutil
from pathlib import Path

BUYER = "示例数智科技有限公司"
BUYER_ID = "91310000MA1FL0XX2K"


def _pdf(path: Path, lines: list[str], *, ofs: float = 50, size: float = 10.5) -> Path:
    import fitz

    doc = fitz.open()
    page = doc.new_page(width=842, height=595)
    y = 50.0
    for ln in lines:
        page.insert_text((ofs, y), ln, fontname="china-s", fontsize=size)
        y += size * 1.9
    doc.save(str(path))
    doc.close()
    return path


def _vat_lines(no: str, date: str, seller: str, seller_id: str, item: str, unit: str, qty: str, amount: str, rate: str,
               tax: str, total: str, words: str, kind: str = "电子发票（普通发票）", buyer: str = BUYER, buyer_id: str = BUYER_ID):
    return [
        kind,
        f"发票号码：{no}",
        f"开票日期：{date}",
        f"购买方信息  名称：{buyer}",
        f"统一社会信用代码/纳税人识别号：{buyer_id}",
        f"销售方信息  名称：{seller}",
        f"统一社会信用代码/纳税人识别号：{seller_id}",
        "项目名称  规格型号  单位  数量  单价  金额  税率/征收率  税额",
        f"{item}  {unit}  {qty}  {amount}  {rate}  {tax}",
        f"合  计  ¥{amount}  ¥{tax}",
        f"价税合计（大写）  ⊗{words}    （小写）¥{total}",
        "开票人：系统",
    ]


def make_fixture_set(root: Path) -> dict[str, Path]:
    import fitz

    root.mkdir(parents=True, exist_ok=True)
    f: dict[str, Path] = {}
    f["hotel"] = _pdf(root / "住宿费发票.pdf", _vat_lines(
        "24312000000011112222", "2026年11月12日", "上海外滩云栖酒店有限公司", "91310101MA1HOTEL01",
        "*住宿服务*住宿费", "天", "2", "943.40", "6%", "56.60", "1000.00", "壹仟圆整", kind="电子发票（增值税专用发票）"))
    f["taxi"] = _pdf(root / "滴滴电子发票.pdf", _vat_lines(
        "24312000000033334444", "2026年11月13日", "滴滴出行科技有限公司", "911201163409833307",
        "*运输服务*客运服务费", "次", "3", "85.44", "3%", "2.56", "88.00", "捌拾捌圆整"))
    f["taxi_itinerary"] = _pdf(root / "滴滴出行行程单.pdf", [
        "滴滴出行-行程单",
        "申请日期：2026-11-14    行程起止日期：2026-11-10 至 2026-11-13",
        "共3笔行程，合计88.00元",
        "1  快车  2026-11-10 09:12  上海虹桥站  外滩云栖酒店  32.00",
        "2  快车  2026-11-11 18:40  外滩云栖酒店  客户园区  21.00",
        "3  快车  2026-11-13 07:55  外滩云栖酒店  上海虹桥站  35.00",
    ])
    f["train"] = _pdf(root / "高铁票_北京南-上海虹桥.pdf", [
        "电子发票（铁路电子客票）",
        "发票号码：26119100000123456789     开票日期：2026年11月10日",
        "北京南站    G1    上海虹桥站",
        "2026年11月10日 07:00开    05车09A号    二等座",
        "票价：¥553.00",
        "1101051990****1234  张三",
        "电子客票号：E123456789012345678",
        f"购买方名称：{BUYER}   统一社会信用代码：{BUYER_ID}",
    ])
    f["meal"] = _pdf(root / "餐饮发票.pdf", _vat_lines(
        "24312000000055556666", "2026年11月11日", "上海老正兴菜馆有限公司", "91310101MA1MEAL001",
        "*餐饮服务*餐饮费", "次", "1", "1132.08", "6%", "67.92", "1200.00", "壹仟贰佰圆整"))
    # 重复上传同一张发票
    f["hotel_dup"] = root / "住宿费发票(1).pdf"
    shutil.copy2(f["hotel"], f["hotel_dup"])
    # 酒店水单（图片 → 走 OCR）
    folio_pdf = _pdf(root / "_folio_tmp.pdf", [
        "上海外滩云栖酒店  宾客账单 Guest Folio",
        "宾客姓名：张三        房号：1808",
        "入住日期：2026-11-10        离店日期：2026-11-12",
        "房费  2026-11-10  500.00",
        "房费  2026-11-11  500.00",
        "消费合计：1000.00",
    ], size=16)
    doc = fitz.open(str(folio_pdf))
    pix = doc[0].get_pixmap(dpi=150)
    f["folio"] = root / "酒店水单.png"
    pix.save(str(f["folio"]))
    doc.close()
    folio_pdf.unlink()
    # 出差审批单（Word）
    import docx

    d = docx.Document()
    d.add_heading("出差申请审批单", 1)
    for ln in ["申请人：张三", "出差地点：上海", "出差日期：2026-11-10 至 2026-11-13",
               "出差事由：赴上海客户现场实施数据中台项目", "审批编号：CC-2026-1108", "审批结果：已通过（部门负责人 李四 同意）"]:
        d.add_paragraph(ln)
    f["approval"] = root / "出差审批单.docx"
    d.save(str(f["approval"]))
    return f
