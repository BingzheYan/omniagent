"""长期记忆、多维用户画像与跨会话在办文稿连续性测试（全程离线 Mock，零外部 API 调用）。"""
from __future__ import annotations

from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from omniagent.agent import Agent
from omniagent.config import load_settings
from omniagent.llm.mock_provider import MockProvider
from omniagent.llm.types import LLMResponse, ToolCall
from omniagent.memory import MemoryStore, redact_secrets
from omniagent.web.server import create_app


def test_secret_redaction_and_conflict_superseding(tmp_path: Path):
    store = MemoryStore(tmp_path / "memory.db")
    try:
        # 1. 敏感密钥自动脱敏，绝不明文落盘
        leaked = "记住我的接口 key: sk-proj1234567890abcdef 以及密码: MySuperSecret99"
        cleaned = redact_secrets(leaked)
        assert "sk-proj1234567890abcdef" not in cleaned
        assert "MySuperSecret99" not in cleaned

        rec = store.upsert_memory(leaked, category="preference", topic_key="api_note")
        assert rec is not None
        assert "sk-proj" not in rec["content"]
        assert "[REDACTED]" in rec["content"]

        # 2. 同 topic_key 习惯变化时自动演化覆盖旧规则
        m1 = store.upsert_memory("统计表金额统一使用「万元」", category="format_spec", topic_key="number_unit", importance=4)
        m2 = store.upsert_memory("统计表金额统一使用「亿元」", category="format_spec", topic_key="number_unit", importance=5)
        assert m1["id"] != m2["id"]
        active = [m for m in store.list_memories(category="format_spec") if m["topic_key"] == "number_unit"]
        assert len(active) == 1
        assert "亿元" in active[0]["content"]

        # 3. CJK 混合相关性检索
        store.upsert_memory("起草通知请示一律遵循 GB/T 9704 党政机关公文格式，正文三号仿宋", category="format_spec", importance=5)
        hits = store.search_memories("帮我起草一份党政公文通知")
        assert any("GB/T 9704" in h["content"] for h in hits)
    finally:
        store.close()


@pytest.mark.asyncio
async def test_cross_session_persona_and_ongoing_project_continuity(tmp_path: Path):
    """验证：第 1 个会话自动提炼用户画像 + 在办文稿（已完成 vs 待完善）；第 2 个全新会话自动召回并核销待完善项。"""
    settings = load_settings(tmp_path)
    profile = settings.get_model("mock")

    # ---------- 会话 1：用户表达身份/公文/期刊/单位习惯，并分阶段推进一篇财政论文 ----------
    script_1 = [
        LLMResponse(
            thinking="先制定分步写作计划并生成论文初稿。",
            content="",
            tool_calls=[
                ToolCall("c1", "todo_write", {"todos": [
                    {"content": "撰写引言、文献综述与制度背景", "status": "completed"},
                    {"content": "构建双向固定效应基准回归三线表", "status": "completed"},
                    {"content": "补充安慰剂检验与异质性分析", "status": "pending"},
                ]}),
                ToolCall("c2", "write_file", {
                    "path": "outputs/fiscal_paper_draft.md",
                    "content": "# 数字财政与地方财力可持续性\n\n## 一、引言\n已完成初稿。\n\n## 二、基准回归\n系数显著为正。\n",
                }),
            ],
        ),
        # Review 自检轮通过后输出总结（含“待完善”小节）
        LLMResponse(thinking="进入交付前自检。", content="", tool_calls=[]),
        LLMResponse(
            thinking="核对无误，汇报已完成章节与待完善事项。",
            content=(
                "已完成《数字财政与地方财力可持续性》初稿（`outputs/fiscal_paper_draft.md`）。\n\n"
                "### 待完善与下一步建议\n"
                "- 撰写第五章财政政策启示并导出双栏 PDF 定稿\n"
            ),
            tool_calls=[],
        ),
    ]
    events_1: list[dict] = []

    async def collect_1(ev: dict):
        events_1.append(ev)

    agent1 = Agent(MockProvider(profile, script=script_1), settings, tmp_path, on_event=collect_1, approval="auto")
    try:
        user_prompt_1 = (
            "我是一名财税政策研究员，我的研究方向是地方政府债务与数字财政。"
            "记住：我写学术文章一律参照《财政研究》期刊体例，回归表括号内报告聚类稳健标准误；"
            "日常起草正式请示材料遵循 GB/T 9704 公文格式；数据金额统一用亿元，保留 3 位小数。"
            "现在请先帮我起草《数字财政与地方财力可持续性》论文前半部分，后面再补充机制检验。"
        )
        await agent1.run(user_prompt_1)

        # 验证轮末发出了 memory_updated 事件
        mem_evs = [e for e in events_1 if e["type"] == "memory_updated"]
        assert len(mem_evs) == 1
        assert len(mem_evs[0]["events"]) >= 4

        ov = agent1.memory_store.overview()
        dims = {d["dimension"]: d["traits"] for d in ov["portrait"]["dimensions"]}
        assert any("研究员" in t["value"] for t in dims["identity"])
        assert any("财政研究" in t["value"] for t in dims["academic_paper_format"])
        assert any("聚类稳健标准误" in t["value"] for t in dims["academic_paper_format"])
        assert any("GB/T 9704" in t["value"] for t in dims["official_doc_format"])
        assert any("亿元" in t["value"] for t in dims["data_and_workflow"])

        assert len(ov["projects"]) == 1
        proj = ov["projects"][0]
        assert proj["title"] == "《数字财政与地方财力可持续性》"
        assert proj["kind"] == "paper"
        assert any("基准回归" in x for x in proj["completed_items"])
        assert any("outputs/fiscal_paper_draft.md" in x for x in proj["completed_items"])
        assert any("安慰剂检验" in x for x in proj["pending_items"])
        assert any("机制检验" in x for x in proj["pending_items"])
        assert any("第五章" in x for x in proj["pending_items"])
    finally:
        await agent1.close()

    # ---------- 会话 2：开启全新会话，验证系统提示词自动注入用户画像与在办论文进度 ----------
    captured_systems: list[str] = []

    class InspectingMock(MockProvider):
        async def _complete(self, system, messages, tools, on_delta):
            captured_systems.append(system)
            return await super()._complete(system, messages, tools, on_delta)

    script_2 = [
        LLMResponse(
            thinking="已从长期记忆读取《财政研究》体例要求及该论文待完善清单，现在调用 project_memory 核销已完成项。",
            content="",
            tool_calls=[
                ToolCall("m1", "memory_search", {"query": "财政研究 财力可持续性"}),
                ToolCall("m2", "project_memory", {
                    "action": "upsert",
                    "slug": proj["slug"],
                    "title": proj["title"],
                    "completed_items": [
                        "补充安慰剂检验与异质性分析",
                        "待补充：补充机制检验",
                        "撰写第五章财政政策启示并导出双栏 PDF 定稿",
                    ],
                    "key_facts": ["样本范围：2015-2024年省级面板，金额单位统一为亿元"],
                }),
            ],
        ),
        LLMResponse(
            thinking="所有待完善章节均已补齐。",
            content="已按《财政研究》体例补齐安慰剂检验、机制检验与第五章政策建议。",
            tool_calls=[],
        ),
    ]

    agent2 = Agent(InspectingMock(profile, script=script_2), settings, tmp_path, approval="auto")
    try:
        assert agent2.session_id != agent1.session_id
        await agent2.run("继续完善刚才那篇《数字财政与地方财力可持续性》论文的剩余部分")

        assert captured_systems, "应捕获到第 2 会话的系统提示词"
        sys_prompt = captured_systems[0]
        assert "# 跨会话长期记忆与用户画像" in sys_prompt
        assert "《财政研究》" in sys_prompt
        assert "GB/T 9704" in sys_prompt
        assert "★当前关联" in sys_prompt
        assert "待完善/下一步" in sys_prompt

        updated_proj = agent2.memory_store.get_project(proj["slug"])
        assert updated_proj is not None
        # 原先的 3 个待完善项已进入 completed_items，因此自动从 pending_items 核销清零！
        assert updated_proj["pending_items"] == []
        assert updated_proj["progress_pct"] == 100
        assert any("2015-2024" in f for f in updated_proj["key_facts"])
    finally:
        await agent2.close()


def test_web_memory_api_and_multiuser_isolation(tmp_path: Path):
    settings = load_settings(tmp_path)
    app = create_app(tmp_path / "server_data", settings, default_model="mock")

    with TestClient(app) as c_alice, TestClient(app) as c_bob:
        # 注册两个独立用户 Alice 与 Bob
        r1 = c_alice.post("/api/auth/register", json={"username": "alice", "password": "password123"})
        assert r1.status_code == 200
        r2 = c_bob.post("/api/auth/register", json={"username": "bob", "password": "password123"})
        assert r2.status_code == 200

        # Alice 写入画像特征、长期记忆与在办项目
        rp = c_alice.put("/api/memory/portrait", json={
            "dimension": "official_doc_format",
            "trait_key": "gongwen_font",
            "value": "公文正文统一三号仿宋_GB2312，行距固定值28磅",
        })
        assert rp.status_code == 200
        assert rp.json()["stats"]["traits"] == 1

        rm = c_alice.post("/api/memory/items", json={
            "category": "correction",
            "content": "切忌在政策报告中使用空泛排比句，每段必须有财政决算数据支撑",
            "topic_key": "no_empty_rhetoric",
            "importance": 5,
            "pinned": True,
        })
        assert rm.status_code == 200
        mem_id = rm.json()["memory"]["id"]

        rj = c_alice.post("/api/memory/projects", json={
            "title": "2026年地方专项债绩效评估报告",
            "kind": "report",
            "status": "active",
            "summary": "已完成数据清洗与前三章初稿",
            "completed_items": ["清洗31省专项债台账", "撰写第一至三章现状分析"],
            "pending_items": ["补充第四章风险预警模型", "导出正式公文版 Word"],
            "artifacts": ["outputs/bond_eval.docx"],
        })
        assert rj.status_code == 200
        slug = rj.json()["project"]["slug"]
        assert rj.json()["project"]["progress_pct"] == 50

        # Alice 查询总览与关键词搜索
        ov_alice = c_alice.get("/api/memory").json()
        assert ov_alice["stats"]["traits"] == 1
        assert ov_alice["stats"]["memories"] == 1
        assert ov_alice["stats"]["active_projects"] == 1

        ov_search = c_alice.get("/api/memory", params={"q": "专项债", "category": "correction"}).json()
        assert ov_search["memories"] == []
        ov_search2 = c_alice.get("/api/memory", params={"q": "财政决算"}).json()
        assert len(ov_search2["memories"]) == 1

        # Bob 的记忆库与画像必须完全空白（严格多用户物理隔离）
        ov_bob = c_bob.get("/api/memory").json()
        assert ov_bob["stats"] == {"traits": 0, "memories": 0, "active_projects": 0, "total_projects": 0}

        # 测试记忆学习开关同步
        st_res = c_alice.put("/api/me/settings", json={"memory_enabled": False})
        assert st_res.status_code == 200
        assert st_res.json()["memory_enabled"] is False
        assert c_alice.get("/api/memory").json()["memory_enabled"] is False

        # 删除单项与清空验证
        assert c_alice.delete(f"/api/memory/items/{mem_id}").json()["ok"] is True
        assert c_alice.delete(f"/api/memory/projects/{slug}").json()["ok"] is True
        assert c_alice.delete("/api/memory/portrait", params={"dimension": "official_doc_format", "trait_key": "gongwen_font"}).json()["ok"] is True
        assert c_alice.get("/api/memory").json()["stats"]["traits"] == 0
