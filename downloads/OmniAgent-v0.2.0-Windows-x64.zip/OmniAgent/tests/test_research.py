"""Unit & integration tests for omniagent.research, check_document, new skills, and showcase paper."""
from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import pytest
import statsmodels.api as sm
import statsmodels.formula.api as smf
from linearmodels.panel import PanelOLS

from omniagent.config import Settings
from omniagent.research import (
    academic_style,
    coef_plot,
    corr_table,
    describe_table,
    event_study_plot,
    regtable,
    savefig,
    var_table,
    vif_table,
)
from omniagent.tools import ToolContext, ToolError, build_default_registry
from omniagent.tools.documents import extract_text, markdown_to_docx, tex_to_runs
from omniagent.tools.research import inspect_document
from omniagent.tools.skills import discover_skills

REPO_ROOT = Path(__file__).resolve().parent.parent


async def _noop(_event):
    return None


def _sample_panel_df() -> pd.DataFrame:
    rng = np.random.default_rng(42)
    provs = [f"P{i:02d}" for i in range(15)]
    years = list(range(2016, 2024))
    df = pd.DataFrame([(p, y) for p in provs for y in years], columns=["province", "year"])
    df["x1"] = rng.normal(0.5, 0.2, len(df))
    df["x2"] = rng.normal(1.0, 0.3, len(df))
    df["w"] = rng.uniform(0.5, 2.0, len(df))
    fe_p = df["province"].map({p: rng.normal(0, 0.3) for p in provs})
    df["y"] = 1.2 + 0.75 * df["x1"] - 0.35 * df["x2"] + fe_p + rng.normal(0, 0.08, len(df))
    return df


def test_new_builtin_skills_discovered():
    skills = discover_skills(None)
    for name, expected_ref in [
        ("official-document", "gongwen_template.py"),
        ("presentation", "pptx_template.py"),
        ("fiscal-paper", "templates.md"),
        ("data-analysis-report", "create_document"),
    ]:
        assert name in skills
        sk = skills[name]
        assert sk.source == "builtin"
        assert len(sk.description) > 20
        body = sk.body()
        assert len(body) > 500
        assert expected_ref in body


def test_describe_corr_vif_and_var_tables():
    df = _sample_panel_df()
    desc = describe_table(df, ["y", "x1", "x2"], labels={"y": "产出效率", "x1": "数字监督", "x2": "控制项"})
    for col_hdr in ("变量", "观测值", "均值", "标准差", "最小值", "中位数", "最大值"):
        assert col_hdr in desc
    assert "产出效率" in desc and "120" in desc

    corr = corr_table(df, ["y", "x1", "x2"], labels={"y": "Y", "x1": "X1", "x2": "X2"})
    assert "1.000" in corr
    assert "***" in corr  # strong correlation between y and x1

    df_col = df.copy()
    df_col["x1_dup"] = df_col["x1"] * 2.0 + np.random.default_rng(1).normal(0, 0.005, len(df_col))
    vif_low = vif_table(df, ["x1", "x2"])
    assert "1.0" in vif_low
    vif_high = vif_table(df_col, ["x1", "x1_dup", "x2"])
    assert "VIF" in vif_high and "1/VIF" in vif_high

    vt = var_table([("被解释变量", "效率", "Y", "综合指数")])
    assert "变量类型" in vt and "综合指数" in vt


def test_regtable_statsmodels_ols_wls_and_panelols():
    df = _sample_panel_df()
    ols = smf.ols("y ~ x1 + x2", data=df).fit()
    wls = sm.WLS(df["y"], sm.add_constant(df[["x1", "x2"]]), weights=df["w"]).fit()
    fe = PanelOLS.from_formula(
        "y ~ 1 + x1 + x2 + EntityEffects + TimeEffects",
        data=df.set_index(["province", "year"]),
    ).fit(cov_type="clustered", cluster_entity=True)

    md_se = regtable(
        [ols, wls, fe],
        model_names=["(1) OLS", "(2) WLS", "(3) 双向FE"],
        var_labels={"x1": "核心解释变量", "x2": "控制变量"},
        keep=["x1", "x2"],
        add_rows={"省份固定效应": ["否", "否", "是"], "年份固定效应": ["否", "否", "是"]},
        note="括号内为稳健标准误；*、**、*** 分别表示在 10%、5%、1% 水平上显著。",
    )
    assert "核心解释变量" in md_se
    assert "***" in md_se
    assert "(1) OLS" in md_se and "(2) WLS" in md_se and "(3) 双向FE" in md_se
    assert "观测值" in md_se and "120" in md_se
    assert "R² (Within)" in md_se
    assert "省份固定效应" in md_se
    assert "注：括号内为稳健标准误" in md_se

    md_t = regtable(ols, stat="t")
    assert "括号内为 t 统计量" in md_t


def test_academic_style_and_plots(tmp_path: Path):
    info = academic_style(dpi=300)
    assert info["dpi"] == 300
    assert plt.rcParams["axes.unicode_minus"] is False
    assert plt.rcParams["axes.spines.top"] is False
    assert plt.rcParams["axes.spines.right"] is False

    es_png = tmp_path / "es.png"
    fig1 = event_study_plot(
        coefs=[-0.01, 0.005, 0.08, 0.11],
        ses=[0.02, 0.018, 0.022, 0.025],
        periods=[-3, -2, 0, 1],
        zero_period=-1,
        title="事件研究检验",
        out_path=es_png,
    )
    assert es_png.exists() and es_png.stat().st_size > 5_000
    plt.close(fig1)

    cp_png = tmp_path / "coef.png"
    fig2 = coef_plot(
        {"变量A": 0.25, "变量B": -0.12, "变量C": 0.02},
        {"变量A": 0.05, "变量B": 0.04, "变量C": 0.06},
        out_path=cp_png,
    )
    assert cp_png.exists() and cp_png.stat().st_size > 5_000
    savefig(fig2, tmp_path / "coef2.png")
    assert (tmp_path / "coef2.png").exists()


def test_documents_inline_stars_and_math_fixes(tmp_path: Path):
    # Regression test for visual bug fixes in documents.py
    runs = tex_to_runs(r"i=1,\dots,30 + \hat{\beta}_1")
    joined = "".join(t for t, _ in runs)
    assert "…" in joined and "β" in joined

    md = (
        "# 测试标题\n\n"
        "表1报告了回归结果。\n\n"
        "表1 示例回归表\n\n"
        "| 变量 | (1) |\n|---|---|\n| X | 0.343*** |\n| | (0.039) |\n\n"
        "注：括号内为标准误；*、**、*** 分别表示在 10%、5%、1% 水平上显著。\n"
    )
    out_docx = tmp_path / "star_test.docx"
    markdown_to_docx(md, out_docx, tmp_path, style="academic")
    extracted = extract_text(out_docx)
    assert "*、**、***" in extracted


async def test_check_document_on_showcase_paper():
    docx_path = REPO_ROOT / "examples" / "sample_fiscal_paper.docx"
    pdf_path = REPO_ROOT / "examples" / "sample_fiscal_paper.pdf"
    csv_path = REPO_ROOT / "examples" / "fiscal_panel_2012_2023.csv"
    assert csv_path.exists() and docx_path.exists() and pdf_path.exists()
    panel = pd.read_csv(csv_path)
    assert panel.shape[0] == 360 and panel["province"].nunique() == 30 and panel["year"].nunique() == 12

    reg = build_default_registry(Settings(allow_outside_workspace=True))
    ctx = ToolContext(REPO_ROOT, Settings(allow_outside_workspace=True), _noop)
    tool_res = await reg.get("check_document").run(
        {"path": "examples/sample_fiscal_paper.docx", "doc_type": "fiscal_paper"},
        ctx,
    )
    assert not tool_res.is_error
    assert tool_res.data["score"] >= 95
    assert tool_res.data["metrics"]["valid_figures_count"] >= 4
    assert tool_res.data["metrics"]["tables_count"] >= 5
    assert tool_res.data["issues"] == []


def test_check_document_detects_structural_and_callout_defects(tmp_path: Path):
    # Create one valid image and reference one missing image
    fig_ok = tmp_path / "fig1.png"
    fig, ax = plt.subplots(figsize=(3, 2))
    ax.plot([1, 2, 3], [2, 3, 5])
    savefig(fig, fig_ok)

    bad_md = """# 不规范的论文草稿

摘要：太短的摘要。

关键词：财政

## 一、引言

这里有未清理的 TODO 与待补充字样，并且没有引用任何文献。

![图1 未在图前引用的趋势图](fig1.png)

![图3 跳号且缺失文件的图](missing_fig.png)

如图1所示，这句引用出现在图1之后（违反先见文后见图）。

## 二、空章节

## 三、实证结果分析

表1 未提前引用的回归表

| 变量 | (1) |
|---|---|
| X | 0.5*** |

上表1在出现之后才被首次提及，且缺少表注。
"""
    md_file = tmp_path / "bad_paper.md"
    md_file.write_text(bad_md, encoding="utf-8")

    res = inspect_document(md_file, doc_type="fiscal_paper", workspace=tmp_path)
    codes = {it["code"] for it in res["issues"]}
    assert res["score"] < 50
    assert res["passed"] is False
    assert "placeholder_leftover" in codes
    assert "empty_section" in codes
    assert "missing_sections" in codes
    assert "abstract_length" in codes
    assert "missing_citations" in codes
    assert "missing_or_broken_image" in codes
    assert "figure_numbering_nonsequential" in codes
    assert "figure_callout_after_figure" in codes
    assert "table_callout_after_table" in codes
    assert "table_notes_missing" in codes

    # Also verify unsupported extension raises ToolError
    bad_ext = tmp_path / "x.txt"
    bad_ext.write_text("hello", encoding="utf-8")
    with pytest.raises(ToolError):
        inspect_document(bad_ext, doc_type="generic")
