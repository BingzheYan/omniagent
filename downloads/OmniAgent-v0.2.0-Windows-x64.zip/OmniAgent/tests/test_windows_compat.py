"""Windows 跨平台兼容性专项测试。"""
from __future__ import annotations

import sqlite3
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from omniagent.config import Settings
from omniagent.connectors import ConnectorSpec, execute_sqlite, find_chrome_binary
from omniagent.desktop import build_desktop_app, build_windows_app_bundle
from omniagent.expense.ocr import _format_win_ocr_words
from omniagent.expense.reports import METHOD_LABEL
from omniagent.tools.base import ToolContext
from omniagent.tools.files import glob_files
from omniagent.tools.shell import BgProc, _decode_output, _kill_proc_tree, _terminate


def test_rel_returns_posix_forward_slashes(tmp_path: Path):
    sub = tmp_path / "outputs" / "figures"
    sub.mkdir(parents=True)
    img = sub / "chart_01.png"
    img.write_bytes(b"png")
    ctx = ToolContext(workspace=tmp_path, settings=Settings(), emit=AsyncMock())
    assert ctx.rel(img) == "outputs/figures/chart_01.png"
    assert ctx.rel(tmp_path) == "."


@pytest.mark.asyncio
async def test_glob_matches_nested_patterns_with_backslash_input(tmp_path: Path):
    src = tmp_path / "src" / "pkg"
    src.mkdir(parents=True)
    (src / "app.py").write_text("x = 1\n", encoding="utf-8")
    ctx = ToolContext(workspace=tmp_path, settings=Settings(), emit=AsyncMock())
    res_posix = await glob_files.run({"pattern": "src/**/*.py"}, ctx)
    res_win = await glob_files.run({"pattern": r"src\**\*.py"}, ctx)
    assert "src/pkg/app.py" in res_posix.content
    assert "src/pkg/app.py" in res_win.content


def test_shell_decode_output_supports_utf8_and_windows_gbk():
    utf8_bytes = "中文输出 UTF-8 ✅".encode("utf-8")
    gbk_bytes = "活动代码页: 936 文件夹列表".encode("gb18030")
    assert _decode_output(utf8_bytes) == "中文输出 UTF-8 ✅"
    with patch("omniagent.tools.shell.os.name", "nt"):
        assert _decode_output(gbk_bytes) == "活动代码页: 936 文件夹列表"
        assert _decode_output(utf8_bytes) == "中文输出 UTF-8 ✅"


@pytest.mark.asyncio
async def test_windows_process_tree_termination_without_sigkill(tmp_path: Path):
    fake_proc = MagicMock()
    fake_proc.pid = 43210
    fake_proc.returncode = None

    async def fake_wait():
        fake_proc.returncode = 0
        return 0

    fake_proc.wait = fake_wait
    log_file = tmp_path / "bg.log"
    fh = open(log_file, "wb")
    entry = BgProc(fake_proc, fh, "python -m http.server", log_file, 0.0)
    try:
        with patch("omniagent.tools.shell.os.name", "nt"), \
             patch("omniagent.tools.shell.subprocess.run") as mock_run:
            msg = await _terminate(entry, grace=1.0)
            assert "taskkill" in msg
            mock_run.assert_called_once()
            args = mock_run.call_args[0][0]
            assert args[:4] == ["taskkill", "/F", "/T", "/PID"]
            assert args[4] == "43210"
    finally:
        fh.close()


def test_kill_proc_tree_handles_missing_sigkill_attribute():
    fake_proc = MagicMock()
    fake_proc.pid = 99999
    with patch("omniagent.tools.shell.os.name", "nt"), \
         patch("omniagent.tools.shell.subprocess.run") as mock_run:
        _kill_proc_tree(fake_proc)
        assert mock_run.called


def test_windows_ocr_word_clustering_and_cjk_joining():
    raw = "\n".join([
        "10\t20\t18\t20\t增",
        "30\t21\t18\t20\t值",
        "50\t20\t18\t20\t税",
        "70\t20\t18\t20\t发",
        "90\t21\t18\t20\t票",
        "220\t20\t45\t20\tNo",
        "272\t20\t80\t20\t123456",
        "10\t65\t72\t20\t价税合计",
        "120\t66\t60\t20\t¥128.50",
    ])
    parsed = _format_win_ocr_words(raw)
    lines = parsed.splitlines()
    assert len(lines) == 2
    assert "增值税发票" in lines[0]
    assert "No 123456" in lines[0]
    assert "价税合计  ¥128.50" in lines[1]
    assert "ocr_windows" in METHOD_LABEL
    assert "pdf_ocr_windows" in METHOD_LABEL


def test_sqlite_readonly_uri_uses_as_uri(tmp_path: Path):
    db_file = tmp_path / "space dir" / "test.db"
    db_file.parent.mkdir(parents=True)
    conn = sqlite3.connect(str(db_file))
    conn.execute("CREATE TABLE items (id INTEGER PRIMARY KEY, name TEXT)")
    conn.execute("INSERT INTO items (name) VALUES ('win_ok')")
    conn.commit()
    conn.close()

    spec = ConnectorSpec(name="local_db", title="Local DB", kind="sqlite", config={"db_path": str(db_file)})
    res = execute_sqlite(spec, action="query", sql="SELECT name FROM items")
    assert res["rows"] == [["win_ok"]]


def test_build_windows_app_bundle_and_launchers(tmp_path: Path):
    vbs = build_windows_app_bundle(tmp_path)
    bat = tmp_path / "OmniAgent.bat"
    assert vbs.is_file() and vbs.name == "OmniAgent.vbs"
    assert bat.is_file()
    assert not bat.read_bytes().startswith(b"\xef\xbb\xbf")
    assert b"\r\n" in bat.read_bytes()

    with patch("omniagent.desktop.platform.system", return_value="Windows"):
        out = build_desktop_app(tmp_path / "dist2")
        assert out.name == "OmniAgent.vbs"

    repo_root = Path(__file__).resolve().parent.parent
    ps1 = repo_root / "scripts" / "win_bootstrap.ps1"
    assert ps1.is_file()
    ps1_bytes = ps1.read_bytes()
    assert ps1_bytes.startswith(b"\xef\xbb\xbf"), "PowerShell 5.1 中文脚本需带 UTF-8 BOM"
    assert b"\r\n" in ps1_bytes

    for bat_name in ("启动桌面端.bat", "启动Web工作台.bat", "启动命令行CLI.bat", "环境安装与自检.bat"):
        b_path = repo_root / bat_name
        assert b_path.is_file(), f"缺少 {bat_name}"
        raw = b_path.read_bytes()
        assert not raw.startswith(b"\xef\xbb\xbf"), f"{bat_name} 不能带 UTF-8 BOM"
        assert b"\r\n" in raw
        raw.decode("ascii")  # 纯 ASCII 包装器可兼容任意 Windows 代码页


def test_find_chrome_binary_checks_windows_paths(tmp_path: Path):
    fake_edge = tmp_path / "Microsoft" / "Edge" / "Application" / "msedge.exe"
    fake_edge.parent.mkdir(parents=True)
    fake_edge.write_bytes(b"MZ")
    with patch.dict("os.environ", {"ProgramFiles": str(tmp_path), "CHROME_BIN": ""}, clear=False), \
         patch("omniagent.connectors.shutil.which", return_value=None), \
         patch("pathlib.Path.exists", side_effect=lambda self=None: False) if False else patch("omniagent.connectors.os.environ.get", side_effect=lambda k, d="": str(tmp_path) if k == "ProgramFiles" else d):
        found = find_chrome_binary()
        assert found is not None
