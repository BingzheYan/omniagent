Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")
root = fso.GetParentFolderName(WScript.ScriptFullName)
ps1 = root & "\scripts\win_bootstrap.ps1"
ready = root & "\.venv\.omni_win_ready"
cmd = "powershell.exe -NoProfile -ExecutionPolicy Bypass -File """ & ps1 & """ desktop"
If fso.FileExists(ready) Then
    sh.Run cmd, 0, False
Else
    sh.Run cmd, 1, False
End If
