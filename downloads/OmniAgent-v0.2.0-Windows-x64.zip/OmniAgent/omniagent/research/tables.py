"""学术统计与计量回归表格生成：描述性统计、相关系数矩阵、VIF、发表级回归三线表（Markdown）。"""
from __future__ import annotations

from typing import Any, Mapping, Sequence

import numpy as np
import pandas as pd
from scipy import stats as sp_stats
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.tools.tools import add_constant


def _md_escape(val: Any) -> str:
    if val is None:
        return ""
    return str(val).replace("\n", " ").replace("|", "\\|").strip()


def _render_md_table(headers: Sequence[str], rows: Sequence[Sequence[Any]], aligns: Sequence[str] | None = None) -> str:
    cols = len(headers)
    if aligns is None:
        aligns = ["left"] + ["center"] * max(0, cols - 1)
    sep_map = {"left": ":---", "right": "---:", "center": ":---:"}
    sep = [sep_map.get(a, "---") for a in aligns]
    out = [
        "| " + " | ".join(_md_escape(h) for h in headers) + " |",
        "| " + " | ".join(sep) + " |",
    ]
    for r in rows:
        padded = list(r) + [""] * max(0, cols - len(r))
        out.append("| " + " | ".join(_md_escape(c) for c in padded[:cols]) + " |")
    return "\n".join(out)


def _resolve_cols(df: pd.DataFrame, cols: Sequence[str] | None) -> list[str]:
    if cols is not None:
        missing = [c for c in cols if c not in df.columns]
        if missing:
            raise KeyError(f"DataFrame 缺少列: {missing}")
        return list(cols)
    return list(df.select_dtypes(include=[np.number]).columns)


def _label(col: str, labels: Mapping[str, str] | None) -> str:
    if labels and col in labels:
        return str(labels[col])
    return str(col)


def var_table(
    rows: Sequence[Sequence[Any]],
    headers: Sequence[str] | None = None,
) -> str:
    """生成变量定义 Markdown 表。"""
    if not rows:
        return ""
    width = max(len(r) for r in rows)
    if headers is None:
        headers = (
            ("变量类型", "变量名称", "变量符号", "变量定义与度量")
            if width == 4
            else ("变量名称", "变量符号", "变量定义")
            if width == 3
            else tuple(f"列{i + 1}" for i in range(width))
        )
    aligns = ["center" if i < width - 1 else "left" for i in range(width)]
    return _render_md_table(headers, rows, aligns=aligns)


def df_to_markdown(df: pd.DataFrame, *, digits: int = 3, index: bool = False) -> str:
    """把任意 DataFrame 转为整洁的 Markdown 表格。"""
    work = df.reset_index() if index else df.copy()
    headers = [str(c) for c in work.columns]
    rows: list[list[str]] = []
    for _, sr in work.iterrows():
        row: list[str] = []
        for v in sr:
            if pd.isna(v):
                row.append("")
            elif isinstance(v, (bool, np.bool_)):
                row.append(str(bool(v)))
            elif isinstance(v, (int, np.integer)):
                row.append(f"{int(v)}")
            elif isinstance(v, (float, np.floating)):
                row.append(f"{float(v):.{digits}f}")
            else:
                row.append(str(v))
        rows.append(row)
    return _render_md_table(headers, rows)


def describe_table(
    df: pd.DataFrame,
    cols: Sequence[str] | None = None,
    labels: Mapping[str, str] | None = None,
    *,
    digits: int = 3,
) -> str:
    """生成学术论文标准描述性统计表（变量, 观测值, 均值, 标准差, 最小值, 中位数, 最大值）。"""
    use_cols = _resolve_cols(df, cols)
    headers = ["变量", "观测值", "均值", "标准差", "最小值", "中位数", "最大值"]
    rows: list[list[str]] = []
    fmt = f"{{:.{digits}f}}"
    for c in use_cols:
        s = pd.to_numeric(df[c], errors="coerce").dropna()
        n = int(len(s))
        if n == 0:
            rows.append([_label(c, labels), "0", "—", "—", "—", "—", "—"])
            continue
        std_val = float(s.std(ddof=1)) if n > 1 else 0.0
        rows.append([
            _label(c, labels),
            str(n),
            fmt.format(float(s.mean())),
            fmt.format(std_val),
            fmt.format(float(s.min())),
            fmt.format(float(s.median())),
            fmt.format(float(s.max())),
        ])
    return _render_md_table(headers, rows, aligns=["left"] + ["center"] * 6)


def _star_suffix(pval: float | None, stars: tuple[float, float, float] | None) -> str:
    if not stars or pval is None or np.isnan(pval):
        return ""
    t1, t2, t3 = sorted(float(x) for x in stars)
    if pval < t1:
        return "***"
    if pval < t2:
        return "**"
    if pval < t3:
        return "*"
    return ""


def corr_table(
    df: pd.DataFrame,
    cols: Sequence[str] | None = None,
    labels: Mapping[str, str] | None = None,
    *,
    digits: int = 3,
    stars: bool | tuple[float, float, float] = True,
    lower_only: bool = True,
) -> str:
    """生成带显著性星号的 Pearson 相关系数矩阵 Markdown 表。"""
    use_cols = _resolve_cols(df, cols)
    k = len(use_cols)
    star_levels = (0.1, 0.05, 0.01) if stars is True else (stars if isinstance(stars, tuple) else None)
    headers = ["变量"] + [f"({i + 1})" for i in range(k)]
    rows: list[list[str]] = []
    fmt = f"{{:.{digits}f}}"
    num_df = pd.DataFrame({c: pd.to_numeric(df[c], errors="coerce") for c in use_cols})
    for i, ci in enumerate(use_cols):
        row = [f"({i + 1}) {_label(ci, labels)}"]
        for j, cj in enumerate(use_cols):
            if i == j:
                row.append(fmt.format(1.0))
            elif lower_only and j > i:
                row.append("")
            else:
                pair = num_df[[ci, cj]].dropna()
                if len(pair) < 3 or pair[ci].nunique() < 2 or pair[cj].nunique() < 2:
                    row.append("—")
                else:
                    r_val, p_val = sp_stats.pearsonr(pair[ci].to_numpy(), pair[cj].to_numpy())
                    row.append(fmt.format(float(r_val)) + _star_suffix(float(p_val), star_levels))
        rows.append(row)
    return _render_md_table(headers, rows, aligns=["left"] + ["center"] * k)


def vif_table(
    df: pd.DataFrame,
    cols: Sequence[str],
    labels: Mapping[str, str] | None = None,
    *,
    digits: int = 3,
) -> str:
    """计算方差膨胀因子（VIF）并返回 Markdown 表。"""
    use_cols = _resolve_cols(df, cols)
    if not use_cols:
        raise ValueError("cols 不能为空")
    sub = pd.DataFrame({c: pd.to_numeric(df[c], errors="coerce") for c in use_cols}).dropna()
    if len(sub) <= len(use_cols):
        raise ValueError(f"有效样本量 ({len(sub)}) 不足以计算 {len(use_cols)} 个变量的 VIF")
    exog = add_constant(sub, has_constant="add")
    arr = exog.to_numpy(dtype=float)
    headers = ["变量", "VIF", "1/VIF"]
    rows: list[list[str]] = []
    fmt = f"{{:.{digits}f}}"
    for c in use_cols:
        idx = list(exog.columns).index(c)
        vif_val = float(variance_inflation_factor(arr, idx))
        tol = (1.0 / vif_val) if vif_val > 0 and np.isfinite(vif_val) else 0.0
        vif_str = fmt.format(vif_val) if np.isfinite(vif_val) else "∞"
        rows.append([_label(c, labels), vif_str, fmt.format(tol)])
    return _render_md_table(headers, rows, aligns=["left", "center", "center"])


def _extract_model_info(m: Any) -> dict[str, Any]:
    """统一提取 statsmodels 与 linearmodels 回归结果。"""
    raw_params = m.params
    if isinstance(raw_params, pd.Series):
        names = [str(k) for k in raw_params.index]
        params = {str(k): float(v) for k, v in raw_params.items()}
    else:
        exog_names = getattr(getattr(m, "model", None), "exog_names", None) or [f"x{i}" for i in range(len(raw_params))]
        names = [str(k) for k in exog_names]
        params = {str(k): float(v) for k, v in zip(names, raw_params)}

    def _to_map(attr_cands: tuple[str, ...]) -> dict[str, float]:
        for a in attr_cands:
            obj = getattr(m, a, None)
            if obj is not None:
                if isinstance(obj, pd.Series):
                    return {str(k): float(v) for k, v in obj.items()}
                return {str(k): float(v) for k, v in zip(names, obj)}
        return {}

    ses = _to_map(("std_errors", "bse"))
    tvals = _to_map(("tstats", "tvalues", "zvalues"))
    pvals = _to_map(("pvalues",))
    nobs = int(round(float(getattr(m, "nobs", 0))))
    effects = [str(e) for e in (getattr(m, "included_effects", None) or [])]
    is_panel = hasattr(m, "rsquared_within")
    r2 = getattr(m, "rsquared", None)
    r2_within = getattr(m, "rsquared_within", None)
    return {
        "names": names,
        "params": params,
        "ses": ses,
        "tvals": tvals,
        "pvals": pvals,
        "nobs": nobs,
        "r2": float(r2) if r2 is not None and not np.isnan(r2) else None,
        "r2_within": float(r2_within) if r2_within is not None and not np.isnan(r2_within) else None,
        "effects": effects,
        "is_panel": is_panel,
    }


_CONST_NAMES = ("Intercept", "const")


def regtable(
    models: Sequence[Any] | Any,
    model_names: Sequence[str] | None = None,
    var_labels: Mapping[str, str] | None = None,
    keep: Sequence[str] | None = None,
    stars: tuple[float, float, float] | None = (0.1, 0.05, 0.01),
    add_rows: Mapping[str, Sequence[Any]] | Sequence[tuple[str, Sequence[Any]]] | None = None,
    note: str | None = None,
    *,
    digits: int = 3,
    stat: str = "se",
    se: str | None = None,
    include_note: bool = True,
) -> str:
    """把 statsmodels OLS/WLS 与 linearmodels PanelOLS/IV2SLS 结果汇总为发表级 Markdown 表。"""
    model_list = list(models) if isinstance(models, (list, tuple)) else [models]
    if not model_list:
        raise ValueError("models 不能为空")
    infos = [_extract_model_info(m) for m in model_list]
    m_count = len(infos)
    col_names = list(model_names) if model_names is not None else [f"({i + 1})" for i in range(m_count)]
    if len(col_names) != m_count:
        raise ValueError(f"model_names 长度 ({len(col_names)}) 与模型数量 ({m_count}) 不一致")

    if keep is not None:
        ordered_vars = list(keep)
    else:
        seen: list[str] = []
        consts: list[str] = []
        for inf in infos:
            for nm in inf["names"]:
                if nm in _CONST_NAMES:
                    if nm not in consts:
                        consts.append(nm)
                elif nm not in seen:
                    seen.append(nm)
        ordered_vars = seen + consts

    default_labels = {"Intercept": "常数项", "const": "常数项"}
    merged_labels = {**default_labels, **(dict(var_labels) if var_labels else {})}

    use_t = stat.lower() in ("t", "tstat", "t_stat", "z")
    fmt = f"{{:.{digits}f}}"
    rows: list[list[str]] = []

    for v in ordered_vars:
        coef_row = [merged_labels.get(v, v)]
        sub_row = [""]
        for inf in infos:
            # 支持 "Intercept" 与 "const" 互通匹配（当用户未同时包含二者时）
            actual_v = v
            if actual_v not in inf["params"] and v in _CONST_NAMES:
                alt = next((c for c in _CONST_NAMES if c in inf["params"]), None)
                if alt is not None:
                    actual_v = alt
            if actual_v not in inf["params"]:
                coef_row.append("")
                sub_row.append("")
                continue
            b = inf["params"][actual_v]
            p = inf["pvals"].get(actual_v)
            coef_row.append(fmt.format(b) + _star_suffix(p, stars))
            s_map = inf["tvals"] if use_t else inf["ses"]
            sv = s_map.get(actual_v)
            sub_row.append(f"({fmt.format(sv)})" if sv is not None and np.isfinite(sv) else "")
        rows.append(coef_row)
        rows.append(sub_row)

    # 自定义行或自动识别 PanelOLS 固定效应行
    if add_rows is not None:
        items = list(add_rows.items()) if isinstance(add_rows, Mapping) else list(add_rows)
        for r_label, r_vals in items:
            vals = [str(x) for x in r_vals]
            if len(vals) != m_count:
                raise ValueError(f"add_rows[{r_label!r}] 长度 ({len(vals)}) 与模型数量 ({m_count}) 不一致")
            rows.append([str(r_label), *vals])
    elif any(inf["effects"] for inf in infos):
        rows.append(["个体固定效应", *[("是" if "Entity" in inf["effects"] else "否") for inf in infos]])
        rows.append(["时间固定效应", *[("是" if "Time" in inf["effects"] else "否") for inf in infos]])

    rows.append(["观测值", *[str(inf["nobs"]) for inf in infos]])

    has_panel_fe = any(inf["is_panel"] and inf["effects"] for inf in infos)
    if has_panel_fe:
        r2_vals = []
        for inf in infos:
            val = inf["r2_within"] if (inf["is_panel"] and inf["effects"] and inf["r2_within"] is not None) else inf["r2"]
            r2_vals.append(fmt.format(val) if val is not None else "—")
        rows.append(["R² (Within)", *r2_vals])
    else:
        rows.append(["R²", *[fmt.format(inf["r2"]) if inf["r2"] is not None else "—" for inf in infos]])

    md_table = _render_md_table(["变量", *col_names], rows, aligns=["left"] + ["center"] * m_count)
    if not include_note:
        return md_table

    if note is not None:
        note_str = note.strip()
        if note_str and not note_str.startswith(("注：", "注:", "说明：", "资料来源：")):
            note_str = "注：" + note_str
    else:
        paren_desc = se or ("括号内为 t 统计量" if use_t else "括号内为稳健标准误")
        if stars:
            t1, t2, t3 = sorted(float(x) for x in stars)
            pct = lambda x: f"{x * 100:g}%"
            star_desc = f"*、**、*** 分别表示在 {pct(t3)}、{pct(t2)}、{pct(t1)} 水平上显著"
            note_str = f"注：{paren_desc}；{star_desc}。"
        else:
            note_str = f"注：{paren_desc}。"
    return f"{md_table}\n\n{note_str}" if note_str else md_table
