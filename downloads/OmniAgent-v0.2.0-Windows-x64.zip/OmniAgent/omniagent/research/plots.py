"""中文学术期刊风格绘图（matplotlib）：中文字体自适应、300 dpi、事件研究平行趋势图、回归系数森林图。"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping, Sequence

import matplotlib
import numpy as np
import pandas as pd
from scipy import stats as sp_stats

# 无 GUI 环境安全使用 Agg 后端
try:
    if not matplotlib.get_backend() or "inline" not in matplotlib.get_backend().lower():
        matplotlib.use("Agg", force=False)
except Exception:  # noqa: BLE001
    pass

import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.figure import Figure

# 高对比度、灰度打印亦可通过明度与线型区分的学术配色
ACADEMIC_PALETTE: tuple[str, ...] = (
    "#1F4E79",  # 深海蓝（主序列）
    "#B22222",  # 砖红（对照/显著强调）
    "#0F766E",  # 墨青
    "#B45309",  # 琥珀棕
    "#5B21B6",  # 靛紫
    "#475569",  # 岩灰
)

_SANS_CANDIDATES = [
    "PingFang SC",
    "Heiti SC",
    "STHeiti",
    "Hiragino Sans GB",
    "Microsoft YaHei",
    "SimHei",
    "Noto Sans CJK SC",
    "Source Han Sans SC",
    "WenQuanYi Micro Hei",
    "Arial Unicode MS",
]
_SERIF_CANDIDATES = [
    "Songti SC",
    "STSong",
    "SimSun",
    "Noto Serif CJK SC",
    "Source Han Serif SC",
    "AR PL UMing CN",
]


def detect_cjk_font(*, serif: bool = False) -> str | None:
    """检测当前系统已安装的可用中文字体族名称。"""
    available = {f.name for f in font_manager.fontManager.ttflist}
    candidates = (_SERIF_CANDIDATES + _SANS_CANDIDATES) if serif else (_SANS_CANDIDATES + _SERIF_CANDIDATES)
    return next((c for c in candidates if c in available), None)


def academic_style(*, serif: bool = False, font_size: float = 10.5, dpi: int = 300) -> dict[str, Any]:
    """配置 matplotlib 为中文学术期刊出版级样式（自动中文字体、无上右边框、300 dpi、高对比配色）。"""
    from cycler import cycler

    chosen = detect_cjk_font(serif=serif)
    sans_list = ([chosen] if chosen else []) + [c for c in _SANS_CANDIDATES if c != chosen] + ["DejaVu Sans"]
    serif_list = ([chosen] if (chosen and serif) else []) + _SERIF_CANDIDATES + ["Times New Roman", "DejaVu Serif"]

    plt.rcParams.update({
        "font.family": "serif" if serif else "sans-serif",
        "font.sans-serif": sans_list,
        "font.serif": serif_list,
        "font.size": font_size,
        "axes.titlesize": font_size + 1.0,
        "axes.labelsize": font_size,
        "xtick.labelsize": font_size - 1.0,
        "ytick.labelsize": font_size - 1.0,
        "legend.fontsize": font_size - 1.0,
        "axes.unicode_minus": False,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.linewidth": 0.9,
        "axes.edgecolor": "#1F2937",
        "axes.prop_cycle": cycler(color=list(ACADEMIC_PALETTE)),
        "axes.grid": True,
        "grid.linestyle": ":",
        "grid.linewidth": 0.55,
        "grid.alpha": 0.45,
        "grid.color": "#94A3B8",
        "xtick.direction": "out",
        "ytick.direction": "out",
        "figure.dpi": 150,
        "savefig.dpi": dpi,
        "savefig.bbox": "tight",
        "savefig.facecolor": "white",
        "figure.facecolor": "white",
        "axes.facecolor": "white",
        "legend.frameon": False,
    })
    return {"font": chosen, "dpi": dpi, "palette": list(ACADEMIC_PALETTE)}


def savefig(fig: Figure, out_path: str | Path, *, dpi: int = 300, close: bool = True) -> Path:
    """以 300 dpi 紧凑边距保存图表到 PNG/PDF。"""
    p = Path(out_path)
    p.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(str(p), dpi=dpi, bbox_inches="tight", pad_inches=0.06, facecolor="white")
    if close:
        plt.close(fig)
    return p


def event_study_plot(
    coefs: Sequence[float],
    ses: Sequence[float],
    periods: Sequence[int | float],
    zero_period: int | float | None = -1,
    title: str | None = None,
    xlabel: str = "政策实施相对年份",
    ylabel: str = "动态处理效应估计值",
    out_path: str | Path | None = None,
    *,
    ref_period: int | float | None = None,
    ci: float = 0.95,
    figsize: tuple[float, float] = (6.6, 4.2),
    dpi: int = 300,
    ax: Any = None,
) -> Figure:
    """绘制事件研究法（平行趋势检验）动态效应图，返回 Figure（指定 out_path 时同步保存 PNG）。"""
    academic_style(dpi=dpi)
    if ref_period is not None:
        zero_period = ref_period

    c_arr = [float(x) for x in coefs]
    s_arr = [float(x) for x in ses]
    p_arr = [float(x) if not isinstance(x, (int, np.integer)) else int(x) for x in periods]
    if not (len(c_arr) == len(s_arr) == len(p_arr)):
        raise ValueError(f"coefs ({len(c_arr)})、ses ({len(s_arr)}) 与 periods ({len(p_arr)}) 长度必须一致")

    if zero_period is not None and zero_period not in p_arr:
        p_arr.append(zero_period)
        c_arr.append(0.0)
        s_arr.append(0.0)

    order = np.argsort(np.asarray(p_arr, dtype=float))
    xs = np.asarray([p_arr[i] for i in order], dtype=float)
    ys = np.asarray([c_arr[i] for i in order], dtype=float)
    es = np.asarray([s_arr[i] for i in order], dtype=float)

    z = float(sp_stats.norm.ppf(0.5 + ci / 2.0))
    lo = ys - z * es
    hi = ys + z * es

    if ax is None:
        fig, ax = plt.subplots(figsize=figsize)
    else:
        fig = ax.figure

    ax.axhline(0.0, color="#334155", linestyle="--", linewidth=0.9, zorder=1)
    if zero_period is not None:
        # 在基期与首期之间（通常 -0.5）或基期处绘制参考竖线
        vline_x = float(zero_period) + 0.5 if (float(zero_period) + 1.0) in set(xs) else float(zero_period)
        ax.axvline(vline_x, color="#94A3B8", linestyle="-.", linewidth=0.9, zorder=1)

    ax.fill_between(xs, lo, hi, color=ACADEMIC_PALETTE[0], alpha=0.14, zorder=2)
    ax.errorbar(
        xs,
        ys,
        yerr=z * es,
        fmt="o-",
        color=ACADEMIC_PALETTE[0],
        ecolor=ACADEMIC_PALETTE[0],
        elinewidth=1.15,
        capsize=3.5,
        capthick=1.0,
        markersize=5.5,
        markerfacecolor="white",
        markeredgewidth=1.4,
        linewidth=1.4,
        zorder=3,
        label=f"点估计及 {int(round(ci * 100))}% 置信区间",
    )
    if zero_period is not None and float(zero_period) in set(xs):
        idx0 = list(xs).index(float(zero_period))
        ax.plot([xs[idx0]], [ys[idx0]], marker="D", markersize=6.0, color=ACADEMIC_PALETTE[1], zorder=4, label=f"基期 ({zero_period})")

    if all(float(p).is_integer() for p in xs):
        ax.set_xticks(xs)
        ax.set_xticklabels([f"{int(p):+d}" if p > 0 else str(int(p)) for p in xs])
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    if title:
        ax.set_title(title, pad=8)
    ax.legend(loc="best", frameon=False)
    fig.tight_layout()

    if out_path is not None:
        savefig(fig, out_path, dpi=dpi, close=False)
    return fig


def coef_plot(
    coefs: Sequence[float] | Mapping[str, float] | Any,
    ses: Sequence[float] | Mapping[str, float] | None = None,
    labels: Sequence[str] | Mapping[str, str] | None = None,
    *,
    keep: Sequence[str] | None = None,
    ci: float = 0.95,
    title: str | None = None,
    xlabel: str = "估计系数及置信区间",
    ylabel: str | None = None,
    out_path: str | Path | None = None,
    figsize: tuple[float, float] | None = None,
    vertical: bool = False,
    dpi: int = 300,
    ax: Any = None,
) -> Figure:
    """绘制回归系数及置信区间森林图（支持传入数组、字典或已拟合回归模型），返回 Figure。"""
    academic_style(dpi=dpi)

    # 支持直接传入 statsmodels / linearmodels 结果对象
    if hasattr(coefs, "params") and ses is None:
        raw_p = coefs.params
        raw_s = getattr(coefs, "std_errors", None)
        if raw_s is None:
            raw_s = getattr(coefs, "bse", None)
        p_ser = raw_p if isinstance(raw_p, pd.Series) else pd.Series(raw_p)
        s_ser = raw_s if isinstance(raw_s, pd.Series) else pd.Series(raw_s, index=p_ser.index)
        keys = [str(k) for k in p_ser.index if str(k) not in ("Intercept", "const")]
        if keep is not None:
            keys = [k for k in keep if k in p_ser.index]
        c_vals = np.asarray([float(p_ser[k]) for k in keys], dtype=float)
        s_vals = np.asarray([float(s_ser[k]) for k in keys], dtype=float)
        if isinstance(labels, Mapping):
            disp_labels = [str(labels.get(k, k)) for k in keys]
        elif labels is not None:
            disp_labels = [str(x) for x in labels]
        else:
            disp_labels = keys
    elif isinstance(coefs, Mapping):
        keys = list(keep) if keep is not None else list(coefs.keys())
        c_vals = np.asarray([float(coefs[k]) for k in keys], dtype=float)
        if ses is None:
            s_vals = np.zeros_like(c_vals)
        elif isinstance(ses, Mapping):
            s_vals = np.asarray([float(ses[k]) for k in keys], dtype=float)
        else:
            s_vals = np.asarray([float(x) for x in ses], dtype=float)
        if isinstance(labels, Mapping):
            disp_labels = [str(labels.get(k, k)) for k in keys]
        elif labels is not None:
            disp_labels = [str(x) for x in labels]
        else:
            disp_labels = [str(k) for k in keys]
    else:
        c_vals = np.asarray([float(x) for x in coefs], dtype=float)
        s_vals = np.zeros_like(c_vals) if ses is None else np.asarray([float(x) for x in ses], dtype=float)
        if len(c_vals) != len(s_vals):
            raise ValueError(f"coefs ({len(c_vals)}) 与 ses ({len(s_vals)}) 长度不一致")
        if labels is None:
            disp_labels = [f"变量 {i + 1}" for i in range(len(c_vals))]
        elif isinstance(labels, Mapping):
            disp_labels = [str(v) for v in labels.values()]
        else:
            disp_labels = [str(x) for x in labels]

    if len(disp_labels) != len(c_vals):
        raise ValueError(f"labels ({len(disp_labels)}) 与 coefs ({len(c_vals)}) 长度不一致")

    z = float(sp_stats.norm.ppf(0.5 + ci / 2.0))
    err = z * s_vals
    n = len(c_vals)

    if figsize is None:
        figsize = (max(5.6, 1.1 * n), 4.0) if vertical else (6.4, max(3.2, 0.55 * n + 1.2))

    if ax is None:
        fig, ax = plt.subplots(figsize=figsize)
    else:
        fig = ax.figure

    pos = np.arange(n)
    sig = (c_vals - err > 0) | (c_vals + err < 0)
    colors = [ACADEMIC_PALETTE[0] if ok else "#64748B" for ok in sig]

    if vertical:
        ax.axhline(0.0, color="#334155", linestyle="--", linewidth=0.9, zorder=1)
        for idx in range(n):
            ax.errorbar(
                [pos[idx]],
                [c_vals[idx]],
                yerr=[[err[idx]], [err[idx]]],
                fmt="o",
                color=colors[idx],
                ecolor=colors[idx],
                elinewidth=1.3,
                capsize=4.0,
                markersize=6.0,
                zorder=3,
            )
        ax.set_xticks(pos)
        ax.set_xticklabels(disp_labels)
        if ylabel:
            ax.set_ylabel(ylabel)
        else:
            ax.set_ylabel(xlabel)
    else:
        # 自上而下按传入顺序展示
        y_pos = pos[::-1]
        ax.axvline(0.0, color="#334155", linestyle="--", linewidth=0.9, zorder=1)
        for idx in range(n):
            ax.errorbar(
                [c_vals[idx]],
                [y_pos[idx]],
                xerr=[[err[idx]], [err[idx]]],
                fmt="o",
                color=colors[idx],
                ecolor=colors[idx],
                elinewidth=1.3,
                capsize=4.0,
                markersize=6.0,
                zorder=3,
            )
        ax.set_yticks(y_pos)
        ax.set_yticklabels(disp_labels)
        ax.set_xlabel(xlabel)
        if ylabel:
            ax.set_ylabel(ylabel)

    if title:
        ax.set_title(title, pad=8)
    fig.tight_layout()

    if out_path is not None:
        savefig(fig, out_path, dpi=dpi, close=False)
    return fig
