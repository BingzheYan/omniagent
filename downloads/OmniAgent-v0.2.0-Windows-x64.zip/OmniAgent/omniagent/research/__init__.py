"""OmniAgent 学术研究与实证计量工具包（表格与期刊绘图）。"""
from __future__ import annotations

from .plots import ACADEMIC_PALETTE, academic_style, coef_plot, detect_cjk_font, event_study_plot, savefig
from .tables import corr_table, describe_table, df_to_markdown, regtable, var_table, vif_table

__all__ = [
    "ACADEMIC_PALETTE",
    "academic_style",
    "coef_plot",
    "corr_table",
    "describe_table",
    "detect_cjk_font",
    "df_to_markdown",
    "event_study_plot",
    "regtable",
    "savefig",
    "var_table",
    "vif_table",
]
