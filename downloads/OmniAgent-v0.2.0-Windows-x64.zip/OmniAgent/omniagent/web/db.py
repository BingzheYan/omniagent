"""Web 应用数据层（SQLite）：用户、登录令牌、对话索引与全文搜索、用量、个人密钥、系统设置、审计日志。"""
from __future__ import annotations

import base64
import datetime as dt
import hashlib
import hmac
import json
import secrets
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any

SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE COLLATE NOCASE,
    email TEXT DEFAULT '',
    display_name TEXT DEFAULT '',
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'user',
    status TEXT NOT NULL DEFAULT 'active',
    created REAL NOT NULL,
    last_login REAL,
    settings TEXT NOT NULL DEFAULT '{}',
    token_quota INTEGER
);
CREATE TABLE IF NOT EXISTS auth_tokens (
    token_hash TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created REAL NOT NULL,
    expires REAL NOT NULL,
    last_seen REAL,
    user_agent TEXT DEFAULT '',
    ip TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS conversations (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title TEXT DEFAULT '',
    created REAL NOT NULL,
    updated REAL NOT NULL,
    pinned INTEGER DEFAULT 0,
    archived INTEGER DEFAULT 0,
    model TEXT DEFAULT '',
    mode TEXT DEFAULT 'auto',
    message_count INTEGER DEFAULT 0,
    input_tokens INTEGER DEFAULT 0,
    output_tokens INTEGER DEFAULT 0,
    share_token TEXT UNIQUE,
    content TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_conv_user ON conversations(user_id, updated);
CREATE TABLE IF NOT EXISTS usage (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    conv_id TEXT,
    ts REAL NOT NULL,
    model TEXT,
    input_tokens INTEGER DEFAULT 0,
    output_tokens INTEGER DEFAULT 0,
    tasks INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_usage_user ON usage(user_id, ts);
CREATE TABLE IF NOT EXISTS api_keys (
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    model TEXT NOT NULL,
    key_enc TEXT NOT NULL,
    base_url TEXT,
    updated REAL,
    PRIMARY KEY (user_id, model)
);
CREATE TABLE IF NOT EXISTS system_settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts REAL NOT NULL,
    user_id INTEGER,
    username TEXT,
    action TEXT NOT NULL,
    detail TEXT DEFAULT '',
    ip TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS user_connectors (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    title TEXT NOT NULL,
    kind TEXT NOT NULL,
    description TEXT DEFAULT '',
    config_enc TEXT NOT NULL,
    enabled INTEGER DEFAULT 1,
    created REAL NOT NULL,
    updated REAL NOT NULL,
    UNIQUE(user_id, name)
);
CREATE TABLE IF NOT EXISTS custom_agents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    title TEXT NOT NULL,
    description TEXT DEFAULT '',
    icon TEXT DEFAULT '🤖',
    mode TEXT DEFAULT 'auto',
    system_prompt TEXT DEFAULT '',
    allowed_tools TEXT DEFAULT '[]',
    excluded_tools TEXT DEFAULT '[]',
    max_steps INTEGER DEFAULT 45,
    updated REAL NOT NULL,
    UNIQUE(user_id, name)
);
"""

DEFAULT_USER_SETTINGS = {
    "default_model": "",
    "default_mode": "auto",
    "default_approval": "smart",
    "theme": "system",
    "custom_instructions": "",
    "notify_on_done": True,
    "memory_enabled": True,
}

DEFAULT_SYSTEM_SETTINGS = {
    "allow_registration": True,
    "invite_code": "",
    "max_concurrent_tasks_per_user": 10,
    "storage_quota_mb": 2048,
    "default_model": "",
    "enabled_models": [],
}


# ----------------------------------------------------------------------------- 密码

def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    n, r, p = 2 ** 14, 8, 1
    h = hashlib.scrypt(password.encode(), salt=salt, n=n, r=r, p=p, dklen=32)
    return f"scrypt${n}${r}${p}${base64.b64encode(salt).decode()}${base64.b64encode(h).decode()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        algo, n, r, p, salt_b64, hash_b64 = stored.split("$")
        if algo != "scrypt":
            return False
        h = hashlib.scrypt(password.encode(), salt=base64.b64decode(salt_b64), n=int(n), r=int(r), p=int(p), dklen=32)
        return hmac.compare_digest(h, base64.b64decode(hash_b64))
    except Exception:  # noqa: BLE001
        return False


def _sha(s: str) -> str:
    return hashlib.sha256(s.encode()).hexdigest()


class Database:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(self.path), check_same_thread=False, isolation_level=None)
        self.conn.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        with self.lock:
            self.conn.executescript(SCHEMA)
            self.fts = self._init_fts()

    def _init_fts(self) -> bool:
        try:
            self.conn.execute(
                "CREATE VIRTUAL TABLE IF NOT EXISTS conv_fts USING fts5(conv_id UNINDEXED, user_id UNINDEXED, title, content,"
                " tokenize='trigram')")
            return True
        except sqlite3.OperationalError:
            return False

    def q(self, sql: str, args: tuple | list = ()) -> list[sqlite3.Row]:
        with self.lock:
            return self.conn.execute(sql, args).fetchall()

    def one(self, sql: str, args: tuple | list = ()) -> sqlite3.Row | None:
        with self.lock:
            return self.conn.execute(sql, args).fetchone()

    def x(self, sql: str, args: tuple | list = ()) -> sqlite3.Cursor:
        with self.lock:
            return self.conn.execute(sql, args)

    # ------------------------------------------------------------------ 用户
    @staticmethod
    def user_dict(row: sqlite3.Row | None) -> dict[str, Any] | None:
        if row is None:
            return None
        settings = {**DEFAULT_USER_SETTINGS, **json.loads(row["settings"] or "{}")}
        return {
            "id": row["id"], "username": row["username"], "email": row["email"] or "",
            "display_name": row["display_name"] or row["username"], "role": row["role"], "status": row["status"],
            "created": row["created"], "last_login": row["last_login"], "settings": settings,
            "token_quota": row["token_quota"],
        }

    def count_users(self) -> int:
        return self.one("SELECT COUNT(*) c FROM users")["c"]

    def create_user(self, username: str, password: str, role: str = "user", email: str = "",
                    display_name: str = "") -> dict[str, Any]:
        cur = self.x(
            "INSERT INTO users(username, email, display_name, password_hash, role, created) VALUES (?,?,?,?,?,?)",
            (username, email, display_name or username, hash_password(password), role, time.time()))
        return self.get_user(cur.lastrowid)

    def get_user(self, uid: int) -> dict[str, Any] | None:
        return self.user_dict(self.one("SELECT * FROM users WHERE id=?", (uid,)))

    def get_user_row_by_name(self, username: str) -> sqlite3.Row | None:
        return self.one("SELECT * FROM users WHERE username=?", (username,))

    def update_user(self, uid: int, **fields) -> dict[str, Any] | None:
        allowed = {"email", "display_name", "role", "status", "last_login", "token_quota"}
        sets, args = [], []
        for k, v in fields.items():
            if k == "password":
                sets.append("password_hash=?")
                args.append(hash_password(v))
            elif k == "settings":
                cur = self.get_user(uid)["settings"]
                cur.update({kk: vv for kk, vv in v.items() if kk in DEFAULT_USER_SETTINGS})
                sets.append("settings=?")
                args.append(json.dumps(cur, ensure_ascii=False))
            elif k in allowed:
                sets.append(f"{k}=?")
                args.append(v)
        if sets:
            self.x(f"UPDATE users SET {', '.join(sets)} WHERE id=?", (*args, uid))
        return self.get_user(uid)

    def list_users(self) -> list[dict[str, Any]]:
        rows = self.q("""
            SELECT u.*, (SELECT COUNT(*) FROM conversations c WHERE c.user_id=u.id) conv_count,
                   (SELECT COALESCE(SUM(input_tokens),0) FROM usage g WHERE g.user_id=u.id) in_tok,
                   (SELECT COALESCE(SUM(output_tokens),0) FROM usage g WHERE g.user_id=u.id) out_tok
            FROM users u ORDER BY u.id""")
        out = []
        for r in rows:
            d = self.user_dict(r)
            d.update(conversations=r["conv_count"], input_tokens=r["in_tok"], output_tokens=r["out_tok"])
            out.append(d)
        return out

    def delete_user(self, uid: int) -> None:
        with self.lock:
            if self.fts:
                self.conn.execute("DELETE FROM conv_fts WHERE user_id=?", (uid,))
            self.conn.execute("DELETE FROM usage WHERE user_id=?", (uid,))
            self.conn.execute("DELETE FROM users WHERE id=?", (uid,))

    # ------------------------------------------------------------------ 登录令牌
    def create_token(self, uid: int, ttl_days: float, user_agent: str = "", ip: str = "") -> str:
        raw = secrets.token_urlsafe(32)
        now = time.time()
        self.x("INSERT INTO auth_tokens(token_hash, user_id, created, expires, last_seen, user_agent, ip) VALUES (?,?,?,?,?,?,?)",
               (_sha(raw), uid, now, now + ttl_days * 86400, now, user_agent[:300], ip))
        return raw

    def user_by_token(self, raw: str | None) -> dict[str, Any] | None:
        if not raw:
            return None
        h = _sha(raw)
        row = self.one("SELECT t.expires, t.last_seen, u.* FROM auth_tokens t JOIN users u ON u.id=t.user_id WHERE t.token_hash=?",
                       (h,))
        if row is None:
            return None
        now = time.time()
        if row["expires"] < now:
            self.x("DELETE FROM auth_tokens WHERE token_hash=?", (h,))
            return None
        if not row["last_seen"] or now - row["last_seen"] > 300:
            self.x("UPDATE auth_tokens SET last_seen=? WHERE token_hash=?", (now, h))
        return self.user_dict(row)

    def delete_token(self, raw: str) -> None:
        self.x("DELETE FROM auth_tokens WHERE token_hash=?", (_sha(raw),))

    def list_tokens(self, uid: int, current_raw: str | None) -> list[dict[str, Any]]:
        cur = _sha(current_raw) if current_raw else None
        rows = self.q("SELECT * FROM auth_tokens WHERE user_id=? AND expires>? ORDER BY last_seen DESC", (uid, time.time()))
        return [{"id": r["token_hash"][:16], "created": r["created"], "last_seen": r["last_seen"],
                 "user_agent": r["user_agent"], "ip": r["ip"], "current": r["token_hash"] == cur} for r in rows]

    def delete_token_by_id(self, uid: int, token_id: str) -> None:
        self.x("DELETE FROM auth_tokens WHERE user_id=? AND substr(token_hash,1,16)=?", (uid, token_id))

    def delete_tokens_except(self, uid: int, keep_raw: str | None) -> None:
        if keep_raw:
            self.x("DELETE FROM auth_tokens WHERE user_id=? AND token_hash<>?", (uid, _sha(keep_raw)))
        else:
            self.x("DELETE FROM auth_tokens WHERE user_id=?", (uid,))

    # ------------------------------------------------------------------ 系统设置
    def get_settings(self) -> dict[str, Any]:
        out = dict(DEFAULT_SYSTEM_SETTINGS)
        for r in self.q("SELECT key, value FROM system_settings"):
            out[r["key"]] = json.loads(r["value"])
        return out

    def update_settings(self, **kv) -> dict[str, Any]:
        for k, v in kv.items():
            if k in DEFAULT_SYSTEM_SETTINGS:
                self.x("INSERT INTO system_settings(key, value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                       (k, json.dumps(v, ensure_ascii=False)))
        return self.get_settings()

    # ------------------------------------------------------------------ 对话
    @staticmethod
    def conv_dict(r: sqlite3.Row) -> dict[str, Any]:
        return {"id": r["id"], "title": r["title"] or "新对话", "created": r["created"], "updated": r["updated"],
                "pinned": bool(r["pinned"]), "archived": bool(r["archived"]), "model": r["model"], "mode": r["mode"],
                "message_count": r["message_count"], "input_tokens": r["input_tokens"],
                "output_tokens": r["output_tokens"], "shared": bool(r["share_token"])}

    def upsert_conversation(self, cid: str, uid: int, *, title: str, model: str, mode: str, message_count: int,
                            input_tokens: int, output_tokens: int, content: str, created: float | None = None) -> None:
        now = time.time()
        with self.lock:
            self.conn.execute("""
                INSERT INTO conversations(id, user_id, title, created, updated, model, mode, message_count, input_tokens,
                                          output_tokens, content)
                VALUES (?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(id) DO UPDATE SET title=CASE WHEN conversations.title='' THEN excluded.title
                    ELSE conversations.title END, updated=excluded.updated, model=excluded.model, mode=excluded.mode,
                    message_count=excluded.message_count, input_tokens=excluded.input_tokens,
                    output_tokens=excluded.output_tokens, content=excluded.content
                """, (cid, uid, title, created or now, now, model, mode, message_count, input_tokens, output_tokens,
                      content))
            if self.fts:
                row = self.conn.execute("SELECT title FROM conversations WHERE id=?", (cid,)).fetchone()
                self.conn.execute("DELETE FROM conv_fts WHERE conv_id=?", (cid,))
                self.conn.execute("INSERT INTO conv_fts(conv_id, user_id, title, content) VALUES (?,?,?,?)",
                                  (cid, uid, row["title"], content))

    def get_conversation(self, cid: str, uid: int | None = None) -> dict[str, Any] | None:
        if uid is None:
            r = self.one("SELECT * FROM conversations WHERE id=?", (cid,))
        else:
            r = self.one("SELECT * FROM conversations WHERE id=? AND user_id=?", (cid, uid))
        return self.conv_dict(r) if r else None

    def list_conversations(self, uid: int, q: str = "", archived: bool = False, limit: int = 200) -> list[dict[str, Any]]:
        q = (q or "").strip()
        if not q:
            rows = self.q("SELECT * FROM conversations WHERE user_id=? AND archived=? ORDER BY pinned DESC, updated DESC LIMIT ?",
                          (uid, int(archived), limit))
            return [self.conv_dict(r) for r in rows]
        out = []
        if self.fts and len(q) >= 3:
            try:
                phrase = '"' + q.replace('"', '""') + '"'
                rows = self.q("""
                    SELECT c.*, snippet(conv_fts, 3, '【', '】', '…', 12) snip FROM conv_fts f
                    JOIN conversations c ON c.id=f.conv_id
                    WHERE conv_fts MATCH ? AND f.user_id=? ORDER BY c.pinned DESC, c.updated DESC LIMIT ?""",
                              (phrase, uid, limit))
                for r in rows:
                    d = self.conv_dict(r)
                    d["snippet"] = r["snip"]
                    out.append(d)
                return out
            except sqlite3.OperationalError:
                pass
        like = f"%{q}%"
        rows = self.q("""SELECT * FROM conversations WHERE user_id=? AND (title LIKE ? OR content LIKE ?)
                         ORDER BY pinned DESC, updated DESC LIMIT ?""", (uid, like, like, limit))
        for r in rows:
            d = self.conv_dict(r)
            content = r["content"] or ""
            i = content.lower().find(q.lower())
            if i >= 0:
                d["snippet"] = "…" + content[max(0, i - 30): i + len(q) + 30].replace("\n", " ") + "…"
            out.append(d)
        return out

    def update_conversation(self, cid: str, uid: int, **fields) -> dict[str, Any] | None:
        sets, args = [], []
        for k in ("title", "pinned", "archived"):
            if k in fields and fields[k] is not None:
                sets.append(f"{k}=?")
                args.append(int(fields[k]) if k != "title" else str(fields[k])[:200])
        if sets:
            self.x(f"UPDATE conversations SET {', '.join(sets)} WHERE id=? AND user_id=?", (*args, cid, uid))
            if "title" in fields and self.fts:
                self.x("UPDATE conv_fts SET title=? WHERE conv_id=?", (fields["title"], cid))
        return self.get_conversation(cid, uid)

    def delete_conversation(self, cid: str, uid: int) -> None:
        self.x("DELETE FROM conversations WHERE id=? AND user_id=?", (cid, uid))
        if self.fts:
            self.x("DELETE FROM conv_fts WHERE conv_id=?", (cid,))

    def set_share(self, cid: str, uid: int, token: str | None) -> None:
        self.x("UPDATE conversations SET share_token=? WHERE id=? AND user_id=?", (token, cid, uid))

    def get_share_token(self, cid: str, uid: int) -> str | None:
        r = self.one("SELECT share_token FROM conversations WHERE id=? AND user_id=?", (cid, uid))
        return r["share_token"] if r else None

    def conversation_by_share(self, token: str) -> sqlite3.Row | None:
        return self.one("SELECT * FROM conversations WHERE share_token=?", (token,))

    # ------------------------------------------------------------------ 用量
    def add_usage(self, uid: int, cid: str | None, model: str, input_tokens: int, output_tokens: int, tasks: int = 1):
        self.x("INSERT INTO usage(user_id, conv_id, ts, model, input_tokens, output_tokens, tasks) VALUES (?,?,?,?,?,?,?)",
               (uid, cid, time.time(), model, input_tokens, output_tokens, tasks))

    def usage_daily(self, uid: int | None, days: int = 30) -> list[dict[str, Any]]:
        start = dt.date.today() - dt.timedelta(days=days - 1)
        start_ts = time.mktime(start.timetuple())
        where, args = "ts>=?", [start_ts]
        if uid is not None:
            where += " AND user_id=?"
            args.append(uid)
        rows = self.q(f"""SELECT date(ts, 'unixepoch', 'localtime') d, SUM(input_tokens) i, SUM(output_tokens) o,
                          SUM(tasks) t FROM usage WHERE {where} GROUP BY d""", args)
        by = {r["d"]: r for r in rows}
        out = []
        for k in range(days):
            day = (start + dt.timedelta(days=k)).isoformat()
            r = by.get(day)
            out.append({"date": day, "input_tokens": (r["i"] or 0) if r else 0, "output_tokens": (r["o"] or 0) if r else 0,
                        "tasks": (r["t"] or 0) if r else 0})
        return out

    def usage_totals(self, uid: int | None = None, since: float | None = None) -> dict[str, int]:
        where, args = "1=1", []
        if uid is not None:
            where += " AND user_id=?"
            args.append(uid)
        if since is not None:
            where += " AND ts>=?"
            args.append(since)
        r = self.one(f"SELECT COALESCE(SUM(input_tokens),0) i, COALESCE(SUM(output_tokens),0) o, COALESCE(SUM(tasks),0) t "
                     f"FROM usage WHERE {where}", args)
        return {"input_tokens": r["i"], "output_tokens": r["o"], "tasks": r["t"]}

    def usage_by_model(self, uid: int) -> list[dict[str, Any]]:
        rows = self.q("""SELECT model, SUM(input_tokens) i, SUM(output_tokens) o, SUM(tasks) t FROM usage WHERE user_id=?
                         GROUP BY model ORDER BY i DESC""", (uid,))
        return [{"model": r["model"], "input_tokens": r["i"], "output_tokens": r["o"], "tasks": r["t"]} for r in rows]

    # ------------------------------------------------------------------ 个人 API Key
    def set_api_key(self, uid: int, model: str, key_enc: str, base_url: str | None) -> None:
        self.x("""INSERT INTO api_keys(user_id, model, key_enc, base_url, updated) VALUES (?,?,?,?,?)
                  ON CONFLICT(user_id, model) DO UPDATE SET key_enc=excluded.key_enc, base_url=excluded.base_url,
                  updated=excluded.updated""", (uid, model, key_enc, base_url, time.time()))

    def get_api_keys(self, uid: int) -> dict[str, sqlite3.Row]:
        return {r["model"]: r for r in self.q("SELECT * FROM api_keys WHERE user_id=?", (uid,))}

    def delete_api_key(self, uid: int, model: str) -> None:
        self.x("DELETE FROM api_keys WHERE user_id=? AND model=?", (uid, model))

    # ------------------------------------------------------------------ 审计
    def audit(self, user: dict | None, action: str, detail: str = "", ip: str = "") -> None:
        self.x("INSERT INTO audit_log(ts, user_id, username, action, detail, ip) VALUES (?,?,?,?,?,?)",
               (time.time(), user["id"] if user else None, user["username"] if user else None, action, detail[:500], ip))

    def list_audit(self, limit: int = 200) -> list[dict[str, Any]]:
        rows = self.q("SELECT * FROM audit_log ORDER BY id DESC LIMIT ?", (limit,))
        return [{"ts": r["ts"], "username": r["username"], "action": r["action"], "detail": r["detail"], "ip": r["ip"]}
                for r in rows]

    def stats(self) -> dict[str, Any]:
        week = time.time() - 7 * 86400
        return {
            "users": self.count_users(),
            "active_users_7d": self.one("SELECT COUNT(*) c FROM users WHERE last_login>=?", (week,))["c"],
            "conversations": self.one("SELECT COUNT(*) c FROM conversations")["c"],
        }

    # ------------------------------------------------------------------ 外部连接器
    def upsert_connector(self, uid: int, name: str, title: str, kind: str, description: str,
                         config_enc: str, enabled: bool = True) -> dict[str, Any]:
        now = time.time()
        self.x("""
            INSERT INTO user_connectors(user_id, name, title, kind, description, config_enc, enabled, created, updated)
            VALUES (?,?,?,?,?,?,?,?,?)
            ON CONFLICT(user_id, name) DO UPDATE SET title=excluded.title, kind=excluded.kind,
                description=excluded.description, config_enc=excluded.config_enc,
                enabled=excluded.enabled, updated=excluded.updated
        """, (uid, name, title, kind, description, config_enc, int(enabled), now, now))
        r = self.one("SELECT * FROM user_connectors WHERE user_id=? AND name=?", (uid, name))
        return dict(r) if r else {}

    def list_connectors(self, uid: int) -> list[dict[str, Any]]:
        return [dict(r) for r in self.q("SELECT * FROM user_connectors WHERE user_id=? ORDER BY id", (uid,))]

    def get_connector(self, uid: int, name: str) -> dict[str, Any] | None:
        r = self.one("SELECT * FROM user_connectors WHERE user_id=? AND name=?", (uid, name))
        return dict(r) if r else None

    def delete_connector(self, uid: int, name: str) -> bool:
        cur = self.x("DELETE FROM user_connectors WHERE user_id=? AND name=?", (uid, name))
        return cur.rowcount > 0

    # ------------------------------------------------------------------ 自定义智能体
    def upsert_custom_agent(self, uid: int, spec: dict[str, Any]) -> dict[str, Any]:
        now = time.time()
        name = str(spec["name"]).strip().lower()
        allowed = json.dumps(spec.get("allowed_tools") or [], ensure_ascii=False)
        excluded = json.dumps(spec.get("excluded_tools") or [], ensure_ascii=False)
        self.x("""
            INSERT INTO custom_agents(user_id, name, title, description, icon, mode, system_prompt,
                                      allowed_tools, excluded_tools, max_steps, updated)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(user_id, name) DO UPDATE SET title=excluded.title, description=excluded.description,
                icon=excluded.icon, mode=excluded.mode, system_prompt=excluded.system_prompt,
                allowed_tools=excluded.allowed_tools, excluded_tools=excluded.excluded_tools,
                max_steps=excluded.max_steps, updated=excluded.updated
        """, (uid, name, spec.get("title") or name, spec.get("description") or "",
              spec.get("icon") or "🤖", spec.get("mode") or "auto", spec.get("system_prompt") or "",
              allowed, excluded, int(spec.get("max_steps") or 45), now))
        return self.get_custom_agent(uid, name) or {}

    def _agent_row(self, r: sqlite3.Row) -> dict[str, Any]:
        at = json.loads(r["allowed_tools"] or "[]")
        return {
            "name": r["name"], "title": r["title"], "description": r["description"], "icon": r["icon"],
            "mode": r["mode"], "system_prompt": r["system_prompt"],
            "allowed_tools": at if at else None,
            "excluded_tools": json.loads(r["excluded_tools"] or "[]"),
            "max_steps": r["max_steps"], "builtin": False, "source": "custom",
        }

    def list_custom_agents(self, uid: int) -> list[dict[str, Any]]:
        return [self._agent_row(r) for r in self.q("SELECT * FROM custom_agents WHERE user_id=? ORDER BY id", (uid,))]

    def get_custom_agent(self, uid: int, name: str) -> dict[str, Any] | None:
        r = self.one("SELECT * FROM custom_agents WHERE user_id=? AND name=?", (uid, name))
        return self._agent_row(r) if r else None

    def delete_custom_agent(self, uid: int, name: str) -> bool:
        cur = self.x("DELETE FROM custom_agents WHERE user_id=? AND name=?", (uid, name))
        return cur.rowcount > 0
