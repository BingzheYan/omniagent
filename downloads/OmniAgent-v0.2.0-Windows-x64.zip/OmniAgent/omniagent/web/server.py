"""OmniAgent Web 应用后端（多用户）：认证、对话管理、文件、用量、管理后台、WebSocket 实时事件流。

API 契约见 docs/API.md。
"""
from __future__ import annotations

import asyncio
import csv
import dataclasses
import datetime as dt
import io
import json
import logging
import mimetypes
import os
import re
import secrets
import shutil
import time
import uuid
import zipfile
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from fastapi import Depends, FastAPI, File, Form, HTTPException, Request, Response, UploadFile, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles

from omniagent import __version__
from omniagent.agent import Agent
from omniagent.agent.profiles import BUILTIN_AGENTS, discover_agents
from omniagent.agent.session import delete_session, load_session
from omniagent.config import ModelProfile, Settings
from omniagent.connectors import CONNECTOR_KINDS, ConnectorSpec, load_file_connectors, test_connector
from omniagent.llm import create_provider
from omniagent.llm.types import Message
from omniagent.memory import MEMORY_CATEGORIES, PORTRAIT_DIMENSIONS, PROJECT_KINDS, MemoryStore
from omniagent.tools import build_default_registry
from omniagent.tools.documents import DOC_EXTS, extract_text
from omniagent.tools.files import IGNORE_DIRS, IMAGE_EXTS

from .db import DEFAULT_SYSTEM_SETTINGS, DEFAULT_USER_SETTINGS, Database, verify_password

log = logging.getLogger(__name__)
STATIC = Path(__file__).parent / "static"
COOKIE = "omni_token"
TEXT_EXTS = {".txt", ".md", ".py", ".js", ".ts", ".tsx", ".jsx", ".json", ".yaml", ".yml", ".toml", ".ini", ".cfg",
             ".html", ".css", ".sh", ".sql", ".java", ".go", ".rs", ".c", ".cpp", ".h", ".hpp", ".rb", ".php", ".xml",
             ".log", ".env", ".vue", ".kt", ".swift", ".r", ".m", ".tex", ".csv", ".tsv", ".bib"}
USERNAME_RE = re.compile(r"^[\w.\-\u4e00-\u9fff]{3,32}$")


# ============================================================================ 工具函数

class SecretBox:
    """用服务器密钥加密用户的个人 API Key。"""

    def __init__(self, data_dir: Path):
        from cryptography.fernet import Fernet

        key_file = data_dir / "secret.key"
        if not key_file.exists():
            key_file.write_bytes(Fernet.generate_key())
            try:
                os.chmod(key_file, 0o600)
            except OSError:
                pass
        self.f = Fernet(key_file.read_bytes().strip())

    def enc(self, s: str) -> str:
        return self.f.encrypt(s.encode()).decode()

    def dec(self, s: str) -> str:
        return self.f.decrypt(s.encode()).decode()


def mask(key: str) -> str:
    return key[:4] + "…" + key[-4:] if len(key) > 10 else "****"


def dir_size(p: Path) -> int:
    total = 0
    for root, _dirs, files in os.walk(p):
        for f in files:
            try:
                total += (Path(root) / f).stat().st_size
            except OSError:
                pass
    return total


def client_ip(request: Request) -> str:
    fwd = request.headers.get("x-forwarded-for")
    if fwd:
        return fwd.split(",")[0].strip()
    return request.client.host if request.client else ""


def history_for_ui(messages: list[Message]) -> list[dict]:
    out: list[dict] = []
    calls: dict[str, dict] = {}
    for m in messages:
        if m.role == "user":
            if m.meta.get("compacted"):
                out.append({"role": "note", "content": "🗜 之前的对话已压缩为摘要"})
            elif not m.meta.get("system"):
                out.append({"role": "user", "content": m.content})
        elif m.role == "assistant":
            tcs = []
            for tc in m.tool_calls:
                item = {"id": tc.id, "name": tc.name, "arguments": tc.arguments, "result": None, "is_error": False,
                        "data": {}}
                calls[tc.id] = item
                tcs.append(item)
            entry: dict[str, Any] = {"role": "assistant", "content": m.content, "tool_calls": tcs}
            if m.meta.get("thinking"):
                entry["thinking"] = m.meta["thinking"]
            if m.meta.get("turn_changes"):
                entry["turn_changes"] = m.meta["turn_changes"]
            if m.meta.get("subagents"):
                entry["subagents"] = m.meta["subagents"]
            if m.meta.get("memories_learned"):
                entry["memories_learned"] = m.meta["memories_learned"]
            out.append(entry)
        elif m.role == "tool" and m.tool_call_id in calls:
            calls[m.tool_call_id]["result"] = m.content[:6000]
            calls[m.tool_call_id]["is_error"] = m.is_error
            if m.meta.get("data"):
                calls[m.tool_call_id]["data"] = m.meta["data"]
    return out


def history_to_markdown(title: str, messages: list[Message]) -> str:
    lines = [f"# {title or '对话'}", "", f"> 导出时间：{dt.datetime.now():%Y-%m-%d %H:%M}", ""]
    for item in history_for_ui(messages):
        if item["role"] == "user":
            lines += ["## 🧑 用户", "", item["content"], ""]
        elif item["role"] == "assistant":
            if item["content"]:
                lines += ["## 🤖 OmniAgent", "", item["content"], ""]
            for tc in item["tool_calls"]:
                arg = tc["arguments"].get("command") or tc["arguments"].get("path") or tc["arguments"].get("output_path") or ""
                lines.append(f"- 🔧 `{tc['name']}` {arg}{' ❌' if tc['is_error'] else ''}")
            if item["tool_calls"]:
                lines.append("")
        elif item["role"] == "note":
            lines += [f"*{item['content']}*", ""]
    return "\n".join(lines)


def search_text(messages: list[Message]) -> str:
    parts = [m.content for m in messages if m.role in ("user", "assistant") and m.content and not m.meta.get("system")]
    return "\n".join(parts)[:200_000]


# ============================================================================ 会话运行时

class WebSession:
    def __init__(self, agent: Agent, user_id: int):
        self.agent = agent
        self.user_id = user_id
        self.clients: set[WebSocket] = set()
        self.task: asyncio.Task | None = None
        self.pending: dict[str, asyncio.Future] = {}
        self.pending_interactions: dict[str, dict[str, Any]] = {}
        self.queue: list[dict[str, Any]] = []
        self.last_seen = time.time()

    @property
    def ws(self) -> WebSocket | None:
        return next(iter(self.clients), None)

    @property
    def running(self) -> bool:
        return self.task is not None and not self.task.done()

    def attach(self, ws: WebSocket) -> None:
        self.clients.add(ws)
        self.last_seen = time.time()

    def detach(self, ws: WebSocket) -> None:
        self.clients.discard(ws)
        self.last_seen = time.time()

    async def send(self, event: dict):
        payload = {**event, "conversation_id": self.agent.session_id}
        et = payload.get("type")
        if et == "approval_request" and payload.get("id"):
            self.pending_interactions[payload["id"]] = payload
        elif et == "approval_result" and payload.get("id"):
            self.pending_interactions.pop(payload["id"], None)
        elif et == "login_required" and payload.get("id"):
            self.pending_interactions[payload["id"]] = payload
        elif et == "login_resolved" and payload.get("id"):
            self.pending_interactions.pop(payload["id"], None)
        if not self.clients:
            return
        dead: list[WebSocket] = []
        for cli in list(self.clients):
            try:
                await cli.send_json(payload)
            except Exception:  # noqa: BLE001
                dead.append(cli)
        for d in dead:
            self.clients.discard(d)

    async def wait_reply(self, kind: str, payload: dict, timeout: float = 3600) -> Any:
        rid = payload.get("id") or uuid.uuid4().hex[:8]
        fut = asyncio.get_running_loop().create_future()
        self.pending[rid] = fut
        if kind == "ask_user":
            ev = {"type": "ask_user", "id": rid, **payload, "conversation_id": self.agent.session_id}
            self.pending_interactions[rid] = ev
            await self.send(ev)
        try:
            return await asyncio.wait_for(fut, timeout)
        except asyncio.TimeoutError:
            return None
        finally:
            self.pending.pop(rid, None)
            self.pending_interactions.pop(rid, None)


# ============================================================================ 应用

def create_app(data_dir: Path | str, settings: Settings, default_model: str | None = None,
               cookie_secure: bool = False, desktop_token: str | None = None) -> FastAPI:
    data_dir = Path(data_dir).expanduser().resolve()
    data_dir.mkdir(parents=True, exist_ok=True)
    db = Database(data_dir / "omniagent.db")
    box = SecretBox(data_dir)
    sessions: dict[str, WebSession] = {}
    user_sockets: dict[int, set[WebSocket]] = {}
    memory_stores: dict[int, MemoryStore] = {}
    login_failures: dict[str, list[float]] = {}

    @asynccontextmanager
    async def lifespan(_app):
        janitor = asyncio.create_task(_janitor())
        yield
        janitor.cancel()
        for s in list(sessions.values()):
            if s.running:
                s.task.cancel()
            await s.agent.close()
        for ms in list(memory_stores.values()):
            try:
                ms.close()
            except Exception:  # noqa: BLE001
                pass

    async def _janitor():
        """回收长时间空闲且未在运行的会话（释放 Python 内核等资源）。"""
        while True:
            await asyncio.sleep(300)
            now = time.time()
            for cid, s in list(sessions.items()):
                if not s.running and s.ws is None and now - s.last_seen > 1800:
                    sessions.pop(cid, None)
                    await s.agent.close()

    app = FastAPI(title="OmniAgent", version=__version__, lifespan=lifespan)
    app.state.db = db
    app.mount("/static", StaticFiles(directory=STATIC), name="static")

    # ------------------------------------------------------------------ 依赖
    def workspace_of(uid: int) -> Path:
        p = data_dir / "workspaces" / f"u{uid}"
        p.mkdir(parents=True, exist_ok=True)
        return p

    def memory_store_of(uid: int) -> MemoryStore:
        ms = memory_stores.get(uid)
        if ms is None:
            ms = MemoryStore(workspace_of(uid) / ".omniagent" / "memory.db")
            memory_stores[uid] = ms
        return ms

    async def current_user(request: Request) -> dict:
        user = db.user_by_token(request.cookies.get(COOKIE))
        if user is None:
            raise HTTPException(401, "未登录")
        if user["status"] != "active":
            raise HTTPException(403, "账号已被禁用")
        return user

    async def admin_user(user: dict = Depends(current_user)) -> dict:
        if user["role"] != "admin":
            raise HTTPException(403, "需要管理员权限")
        return user

    def safe_path(user: dict, rel: str | None) -> Path:
        ws = workspace_of(user["id"])
        p = (ws / (rel or ".")).resolve()
        try:
            p.relative_to(ws)
        except ValueError:
            raise HTTPException(403, "路径越界") from None
        return p

    def set_login_cookie(resp: Response, token: str, remember: bool):
        resp.set_cookie(COOKIE, token, httponly=True, samesite="lax", secure=cookie_secure,
                        max_age=30 * 86400 if remember else None, path="/")

    # ------------------------------------------------------------------ 模型解析
    def sys_settings() -> dict:
        return db.get_settings()

    def model_list(user: dict) -> list[dict]:
        keys = db.get_api_keys(user["id"])
        enabled = sys_settings().get("enabled_models") or []
        out = []
        for name, p in settings.models.items():
            if enabled and name not in enabled:
                continue
            if p.provider == "mock" and not (default_model == "mock" or name == default_model):
                continue
            out.append({"name": name, "model": p.model, "provider": p.provider,
                        "available": p.available or name in keys, "personal_key": name in keys,
                        "vision": bool(getattr(p, "vision", False))})
        return out

    def resolve_profile(user: dict, requested: str | None) -> ModelProfile:
        keys = db.get_api_keys(user["id"])
        avail = {m["name"] for m in model_list(user) if m["available"]}
        candidates = [requested, user["settings"].get("default_model"), sys_settings().get("default_model"), default_model]
        name = next((c for c in candidates if c and c in avail), None)
        if name is None:
            if not avail:
                raise HTTPException(400, "没有可用的模型：请在「设置 → 模型密钥」中配置 API Key，或联系管理员。")
            try:
                auto = settings.get_model("auto").name
                name = auto if auto in avail else sorted(avail)[0]
            except Exception:  # noqa: BLE001
                name = sorted(avail)[0]
        profile = settings.models[name]
        if name in keys:
            row = keys[name]
            profile = dataclasses.replace(profile, api_key=box.dec(row["key_enc"]), api_key_env=None,
                                          base_url=row["base_url"] or profile.base_url)
        return profile

    # ------------------------------------------------------------------ 会话管理
    def index_conversation(agent: Agent, uid: int):
        if not agent.messages:
            return
        db.upsert_conversation(
            agent.session_id, uid, title=agent.title, model=agent.llm.profile.name, mode=agent.mode,
            message_count=sum(1 for m in agent.messages if m.role in ("user", "assistant") and not m.meta.get("system")),
            input_tokens=agent.usage.input_tokens, output_tokens=agent.usage.output_tokens,
            content=search_text(agent.messages), created=agent.created)

    def user_connector_specs(uid: int) -> list[ConnectorSpec]:
        specs: list[ConnectorSpec] = []
        for r in db.list_connectors(uid):
            try:
                cfg = json.loads(box.dec(r["config_enc"]))
            except Exception:  # noqa: BLE001
                cfg = {}
            specs.append(ConnectorSpec(
                name=r["name"], title=r["title"], kind=r["kind"], description=r["description"],
                config=cfg, enabled=bool(r["enabled"]), source="user",
            ))
        return specs

    def sync_user_sessions(uid: int) -> None:
        conns = [c for c in user_connector_specs(uid) if c.enabled]
        custom_ag = db.list_custom_agents(uid)
        for s in sessions.values():
            if s.user_id == uid:
                s.agent.extra_connectors = conns
                s.agent.state["extra_connectors"] = conns
                s.agent.extra_agents = custom_ag

    def make_session(user: dict, conv_id: str | None, model: str | None = None, mode: str | None = None,
                     approval: str | None = None, agent_profile: str | None = None) -> WebSession:
        if conv_id and conv_id in sessions:
            s = sessions[conv_id]
            if s.user_id != user["id"]:
                raise HTTPException(404, "对话不存在")
            return s
        if conv_id and not db.get_conversation(conv_id, user["id"]):
            conv_id = None  # 不存在或不属于该用户 → 新建
        prefs = user["settings"]
        holder: dict[str, WebSession] = {}

        async def on_event(e):
            await holder["s"].send(e)

        async def approver(req):
            s = holder["s"]
            res = await s.wait_reply("approval", req)
            if isinstance(res, dict) and res.get("always"):
                s.agent.approval = "auto"
            return bool(res and res.get("approved"))

        async def ask_user(question):
            return await holder["s"].wait_reply("ask_user", {"question": question})

        profile = resolve_profile(user, model)
        uid = user["id"]
        conns = [c for c in user_connector_specs(uid) if c.enabled]
        custom_ag = db.list_custom_agents(uid)
        agent = Agent(create_provider(profile), settings, workspace_of(uid), mode=mode or prefs.get("default_mode", "auto"),
                      approval=approval or prefs.get("default_approval") or settings.approval, on_event=on_event,
                      approver=approver, ask_user=ask_user, session_id=conv_id,
                      custom_instructions=prefs.get("custom_instructions"),
                      on_saved=lambda a: index_conversation(a, uid),
                      agent_profile=agent_profile or "general",
                      extra_agents=custom_ag, extra_connectors=conns,
                      memory_enabled=bool(prefs.get("memory_enabled", True)),
                      memory_store=memory_store_of(uid))
        if conv_id:
            agent.load(conv_id)
        s = WebSession(agent, uid)
        holder["s"] = s
        sessions[agent.session_id] = s
        return s

    # ================================================================== 页面
    @app.get("/", response_class=HTMLResponse)
    async def index():
        return HTMLResponse((STATIC / "index.html").read_text(encoding="utf-8"), headers={"Cache-Control": "no-cache"})

    @app.get("/share/{token}", response_class=HTMLResponse)
    async def share_page(token: str):
        page = STATIC / "share.html"
        if not page.exists():
            page = STATIC / "index.html"
        return HTMLResponse(page.read_text(encoding="utf-8"))

    @app.get("/api/health")
    async def health():
        return {"ok": True, "version": __version__, "sessions": len(sessions)}

    # ================================================================== 认证
    @app.get("/api/auth/status")
    async def auth_status():
        st = sys_settings()
        has_users = db.count_users() > 0
        return {"has_users": has_users, "registration_open": (not has_users) or bool(st["allow_registration"]),
                "invite_required": has_users and bool(st["invite_code"]), "version": __version__,
                "desktop_mode": bool(desktop_token)}

    @app.get("/api/auth/desktop-login")
    async def desktop_login(token: str, request: Request):
        if not desktop_token or not secrets.compare_digest(token, desktop_token):
            raise HTTPException(403, "桌面令牌无效")
        if db.count_users() == 0:
            user = db.create_user("desktop", secrets.token_urlsafe(16), role="admin", display_name="本机桌面用户")
        else:
            rows = db.list_users()
            admin_u = next((u for u in rows if u["role"] == "admin" and u["status"] == "active"), rows[0])
            user = db.get_user(admin_u["id"])
        raw = db.create_token(user["id"], 30, request.headers.get("user-agent", "OmniAgent Desktop"), client_ip(request))
        db.update_user(user["id"], last_login=time.time())
        resp = RedirectResponse(url="/", status_code=302)
        set_login_cookie(resp, raw, True)
        return resp

    @app.post("/api/auth/register")
    async def register(request: Request, response: Response):
        body = await request.json()
        username = (body.get("username") or "").strip()
        password = body.get("password") or ""
        st = sys_settings()
        first = db.count_users() == 0
        if not first:
            if not st["allow_registration"]:
                raise HTTPException(403, "管理员已关闭注册")
            if st["invite_code"] and body.get("invite_code") != st["invite_code"]:
                raise HTTPException(403, "邀请码错误")
        if not USERNAME_RE.match(username):
            raise HTTPException(400, "用户名需为 3-32 位字母、数字、中文或 _ . -")
        if len(password) < 8:
            raise HTTPException(400, "密码至少 8 位")
        if db.get_user_row_by_name(username):
            raise HTTPException(409, "用户名已存在")
        user = db.create_user(username, password, role="admin" if first else "user",
                              email=(body.get("email") or "").strip(), display_name=(body.get("display_name") or "").strip())
        token = db.create_token(user["id"], 30, request.headers.get("user-agent", ""), client_ip(request))
        set_login_cookie(response, token, True)
        db.update_user(user["id"], last_login=time.time())
        db.audit(user, "register", "首位用户（管理员）" if first else "", client_ip(request))
        return {"user": db.get_user(user["id"])}

    @app.post("/api/auth/login")
    async def login(request: Request, response: Response):
        body = await request.json()
        username = (body.get("username") or "").strip()
        ip = client_ip(request)
        key = f"{ip}|{username.lower()}"
        now = time.time()
        fails = [t for t in login_failures.get(key, []) if now - t < 600]
        if len(fails) >= 5:
            raise HTTPException(429, "失败次数过多，请 10 分钟后再试")
        row = db.get_user_row_by_name(username)
        if row is None or not verify_password(body.get("password") or "", row["password_hash"]):
            fails.append(now)
            login_failures[key] = fails
            db.audit({"id": row["id"], "username": row["username"]} if row else None, "login_failed", username, ip)
            raise HTTPException(401, "用户名或密码错误")
        if row["status"] != "active":
            raise HTTPException(403, "账号已被禁用，请联系管理员")
        login_failures.pop(key, None)
        remember = bool(body.get("remember", True))
        token = db.create_token(row["id"], 30 if remember else 1, request.headers.get("user-agent", ""), ip)
        set_login_cookie(response, token, remember)
        user = db.update_user(row["id"], last_login=now)
        db.audit(user, "login", "", ip)
        return {"user": user}

    @app.post("/api/auth/logout")
    async def logout(request: Request, response: Response):
        raw = request.cookies.get(COOKIE)
        if raw:
            user = db.user_by_token(raw)
            db.delete_token(raw)
            if user:
                db.audit(user, "logout", "", client_ip(request))
        response.delete_cookie(COOKIE, path="/")
        return {"ok": True}

    @app.get("/api/auth/me")
    async def me(user: dict = Depends(current_user)):
        return {"user": user}

    # ================================================================== 个人中心
    @app.patch("/api/me")
    async def update_me(request: Request, user: dict = Depends(current_user)):
        body = await request.json()
        fields = {k: str(body[k]).strip()[:100] for k in ("display_name", "email") if k in body}
        return {"user": db.update_user(user["id"], **fields)}

    @app.post("/api/me/password")
    async def change_password(request: Request, user: dict = Depends(current_user)):
        body = await request.json()
        row = db.get_user_row_by_name(user["username"])
        if not verify_password(body.get("old_password") or "", row["password_hash"]):
            raise HTTPException(400, "原密码错误")
        if len(body.get("new_password") or "") < 8:
            raise HTTPException(400, "新密码至少 8 位")
        db.update_user(user["id"], password=body["new_password"])
        db.delete_tokens_except(user["id"], request.cookies.get(COOKIE))
        db.audit(user, "password_change", "", client_ip(request))
        return {"ok": True}

    @app.get("/api/me/settings")
    async def get_my_settings(user: dict = Depends(current_user)):
        return user["settings"]

    @app.put("/api/me/settings")
    async def put_my_settings(request: Request, user: dict = Depends(current_user)):
        body = await request.json()
        clean = {k: v for k, v in body.items() if k in DEFAULT_USER_SETTINGS}
        if "default_mode" in clean and clean["default_mode"] not in ("auto", "code", "office"):
            raise HTTPException(400, "无效的模式")
        if "default_approval" in clean and clean["default_approval"] not in ("auto", "smart", "always"):
            raise HTTPException(400, "无效的审批策略")
        if "custom_instructions" in clean:
            clean["custom_instructions"] = str(clean["custom_instructions"])[:8000]
        if "memory_enabled" in clean:
            clean["memory_enabled"] = bool(clean["memory_enabled"])
        updated = db.update_user(user["id"], settings=clean)
        for s in sessions.values():  # 自定义指令与记忆开关对已打开的会话即时生效
            if s.user_id == user["id"]:
                s.agent.custom_instructions = updated["settings"].get("custom_instructions")
                s.agent.memory_enabled = bool(updated["settings"].get("memory_enabled", True))
        return updated["settings"]

    @app.get("/api/me/keys")
    async def my_keys(user: dict = Depends(current_user)):
        keys = db.get_api_keys(user["id"])
        out = []
        for name, p in settings.models.items():
            if p.provider == "mock":
                continue
            row = keys.get(name)
            out.append({"model": name, "provider": p.provider, "model_id": p.model, "has_key": row is not None,
                        "masked": mask(box.dec(row["key_enc"])) if row else "", "base_url": (row["base_url"] if row else None),
                        "default_base_url": p.base_url, "system_available": p.available})
        return out

    @app.put("/api/me/keys/{model}")
    async def put_key(model: str, request: Request, user: dict = Depends(current_user)):
        if model not in settings.models:
            raise HTTPException(404, "未知模型")
        body = await request.json()
        key = (body.get("api_key") or "").strip()
        if len(key) < 8:
            raise HTTPException(400, "API Key 格式不正确")
        db.set_api_key(user["id"], model, box.enc(key), (body.get("base_url") or "").strip() or None)
        db.audit(user, "api_key_set", model, client_ip(request))
        return {"ok": True}

    @app.delete("/api/me/keys/{model}")
    async def del_key(model: str, user: dict = Depends(current_user)):
        db.delete_api_key(user["id"], model)
        return {"ok": True}

    @app.get("/api/me/usage")
    async def my_usage(days: int = 30, user: dict = Depends(current_user)):
        days = max(1, min(days, 365))
        totals = db.usage_totals(user["id"])
        totals["conversations"] = len(db.list_conversations(user["id"], limit=100000)) + \
            len(db.list_conversations(user["id"], archived=True, limit=100000))
        month_start = time.mktime(dt.date.today().replace(day=1).timetuple())
        month = db.usage_totals(user["id"], since=month_start)
        return {"daily": db.usage_daily(user["id"], days), "total": totals, "month": month,
                "quota": user.get("token_quota"), "by_model": db.usage_by_model(user["id"])}

    @app.get("/api/me/devices")
    async def my_devices(request: Request, user: dict = Depends(current_user)):
        return db.list_tokens(user["id"], request.cookies.get(COOKIE))

    @app.delete("/api/me/devices/{token_id}")
    async def kick_device(token_id: str, request: Request, user: dict = Depends(current_user)):
        if token_id == "all_others":
            db.delete_tokens_except(user["id"], request.cookies.get(COOKIE))
        else:
            db.delete_token_by_id(user["id"], token_id)
        return {"ok": True}

    # ================================================================== 配置、智能体与连接器
    @app.get("/api/config")
    async def config(user: dict = Depends(current_user)):
        models = model_list(user)
        try:
            dm = resolve_profile(user, None).name
        except HTTPException:
            dm = None
        agents = [a.to_dict() for a in discover_agents(workspace_of(user["id"]), db.list_custom_agents(user["id"])).values()]
        conns = [c.public_dict() for c in user_connector_specs(user["id"])]
        for fc in load_file_connectors(workspace_of(user["id"])).values():
            if not any(x["name"] == fc.name for x in conns):
                conns.append(fc.public_dict())
        return {
            "models": models, "default_model": dm, "user": user, "version": __version__,
            "agents": agents, "connectors": conns,
            "memory_stats": memory_store_of(user["id"]).overview()["stats"],
            "memory_enabled": bool(user["settings"].get("memory_enabled", True)),
            "features": {"web_search": bool(settings.tavily_api_key), "desktop": bool(desktop_token)},
        }

    @app.get("/api/agents")
    async def get_agents(user: dict = Depends(current_user)):
        ws = workspace_of(user["id"])
        agents = [a.to_dict() for a in discover_agents(ws, db.list_custom_agents(user["id"])).values()]
        tool_names = build_default_registry(settings).names()
        return {"agents": agents, "tools": tool_names}

    @app.post("/api/agents")
    async def save_agent(request: Request, user: dict = Depends(current_user)):
        body = await request.json()
        name = re.sub(r"[^a-z0-9_\-]", "", str(body.get("name") or "").strip().lower())[:32]
        if not name or name in BUILTIN_AGENTS:
            raise HTTPException(400, "智能体标识需为字母/数字/下划线，且不能覆盖内置智能体")
        spec = {
            "name": name, "title": str(body.get("title") or name)[:60],
            "description": str(body.get("description") or "")[:300],
            "icon": str(body.get("icon") or "🤖")[:4],
            "mode": body.get("mode") if body.get("mode") in ("auto", "code", "office") else "auto",
            "system_prompt": str(body.get("system_prompt") or "")[:12000],
            "allowed_tools": body.get("allowed_tools") or [],
            "excluded_tools": body.get("excluded_tools") or [],
            "max_steps": max(5, min(int(body.get("max_steps") or 45), 120)),
        }
        saved = db.upsert_custom_agent(user["id"], spec)
        sync_user_sessions(user["id"])
        return {"agent": saved}

    @app.delete("/api/agents/{name}")
    async def remove_agent(name: str, user: dict = Depends(current_user)):
        ok = db.delete_custom_agent(user["id"], name)
        sync_user_sessions(user["id"])
        return {"ok": ok}

    @app.get("/api/connectors")
    async def get_connectors(user: dict = Depends(current_user)):
        items = [c.public_dict() for c in user_connector_specs(user["id"])]
        for fc in load_file_connectors(workspace_of(user["id"])).values():
            if not any(x["name"] == fc.name for x in items):
                items.append(fc.public_dict())
        return {"connectors": items, "kinds": list(CONNECTOR_KINDS)}

    @app.post("/api/connectors")
    async def save_connector(request: Request, user: dict = Depends(current_user)):
        body = await request.json()
        name = re.sub(r"[^\w.\-]", "", str(body.get("name") or "").strip())[:40]
        kind = str(body.get("kind") or "http_api")
        if not name or kind not in CONNECTOR_KINDS:
            raise HTTPException(400, "请提供合法的连接器标识与类型")
        cfg = dict(body.get("config") or {})
        existing = db.get_connector(user["id"], name)
        if existing:
            try:
                old_cfg = json.loads(box.dec(existing["config_enc"]))
            except Exception:  # noqa: BLE001
                old_cfg = {}
            for k, v in list(cfg.items()):
                if isinstance(v, str) and ("…" in v or v == "****") and k in old_cfg:
                    cfg[k] = old_cfg[k]
        db.upsert_connector(
            user["id"], name, str(body.get("title") or name)[:80], kind,
            str(body.get("description") or "")[:300], box.enc(json.dumps(cfg, ensure_ascii=False)),
            enabled=bool(body.get("enabled", True)),
        )
        sync_user_sessions(user["id"])
        spec = next((c for c in user_connector_specs(user["id"]) if c.name == name), None)
        return {"connector": spec.public_dict() if spec else None}

    @app.delete("/api/connectors/{name}")
    async def remove_connector(name: str, user: dict = Depends(current_user)):
        ok = db.delete_connector(user["id"], name)
        sync_user_sessions(user["id"])
        return {"ok": ok}

    @app.post("/api/connectors/{name}/test")
    async def check_connector(name: str, user: dict = Depends(current_user)):
        all_specs = {c.name: c for c in user_connector_specs(user["id"])}
        all_specs.update({k: v for k, v in load_file_connectors(workspace_of(user["id"])).items() if k not in all_specs})
        spec = all_specs.get(name)
        if not spec:
            raise HTTPException(404, "连接器不存在")
        try:
            res = await test_connector(spec)
            return res
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "summary": f"连接测试失败：{e}"}

    # ================================================================== 长期记忆与用户画像
    @app.get("/api/memory")
    async def get_memory_overview(q: str = "", category: str = "", user: dict = Depends(current_user)):
        ms = memory_store_of(user["id"])
        ov = ms.overview()
        if q.strip() or category.strip():
            ov["memories"] = ms.list_memories(category=category.strip(), q=q.strip(), limit=200)
        ov["memory_enabled"] = bool(user["settings"].get("memory_enabled", True))
        return ov

    @app.put("/api/memory/portrait")
    async def save_portrait_trait(request: Request, user: dict = Depends(current_user)):
        body = await request.json()
        dim = str(body.get("dimension") or "").strip()
        tkey = str(body.get("trait_key") or "").strip()
        val = str(body.get("value") or "").strip()
        if dim not in PORTRAIT_DIMENSIONS or not val:
            raise HTTPException(400, "请提供有效的画像维度与特征内容")
        if not tkey:
            tkey = f"manual_{int(time.time() * 1000) % 1000000}"
        ms = memory_store_of(user["id"])
        tr = ms.upsert_trait(dim, tkey, val, confidence=0.98, source="explicit")
        return {"trait": tr, "stats": ms.overview()["stats"]}

    @app.delete("/api/memory/portrait")
    async def remove_portrait_trait(dimension: str, trait_key: str, user: dict = Depends(current_user)):
        ms = memory_store_of(user["id"])
        ok = ms.delete_trait(dimension, trait_key)
        return {"ok": ok, "stats": ms.overview()["stats"]}

    @app.post("/api/memory/items")
    async def save_memory_item(request: Request, user: dict = Depends(current_user)):
        body = await request.json()
        content = str(body.get("content") or "").strip()
        if len(content) < 3:
            raise HTTPException(400, "记忆内容至少 3 个字符")
        cat = str(body.get("category") or "preference")
        if cat not in MEMORY_CATEGORIES:
            cat = "preference"
        tags = body.get("tags") or []
        if isinstance(tags, str):
            tags = [t.strip() for t in re.split(r"[,，\s]+", tags) if t.strip()]
        ms = memory_store_of(user["id"])
        rec = ms.upsert_memory(
            content,
            category=cat,
            topic_key=str(body.get("topic_key") or ""),
            tags=list(tags),
            importance=int(body.get("importance") or 4),
            pinned=bool(body.get("pinned", False)),
            source=str(body.get("source") or "manual"),
            mem_id=body.get("id") or None,
        )
        return {"memory": rec, "stats": ms.overview()["stats"]}

    @app.delete("/api/memory/items/{mem_id}")
    async def remove_memory_item(mem_id: str, user: dict = Depends(current_user)):
        ms = memory_store_of(user["id"])
        ok = ms.delete_memory(mem_id)
        return {"ok": ok, "stats": ms.overview()["stats"]}

    @app.post("/api/memory/projects")
    async def save_memory_project(request: Request, user: dict = Depends(current_user)):
        body = await request.json()
        title = str(body.get("title") or "").strip()
        if not title:
            raise HTTPException(400, "请提供项目或文稿标题")
        kind = str(body.get("kind") or "general")
        if kind not in PROJECT_KINDS:
            kind = "general"

        def _as_lines(val: Any) -> list[str] | None:
            if val is None:
                return None
            if isinstance(val, list):
                return [str(x).strip() for x in val if str(x).strip()]
            return [x.strip() for x in str(val).splitlines() if x.strip()]

        ms = memory_store_of(user["id"])
        proj = ms.upsert_project(
            title,
            slug=str(body.get("slug") or ""),
            kind=kind,
            status=str(body.get("status") or "active"),
            summary=str(body.get("summary") or ""),
            completed_items=_as_lines(body.get("completed_items")),
            pending_items=_as_lines(body.get("pending_items")),
            key_facts=_as_lines(body.get("key_facts")),
            artifacts=_as_lines(body.get("artifacts")),
            merge=bool(body.get("merge", False)),
        )
        return {"project": proj, "stats": ms.overview()["stats"]}

    @app.delete("/api/memory/projects/{slug}")
    async def remove_memory_project(slug: str, user: dict = Depends(current_user)):
        ms = memory_store_of(user["id"])
        ok = ms.delete_project(slug)
        return {"ok": ok, "stats": ms.overview()["stats"]}

    @app.delete("/api/memory/clear")
    async def clear_all_memory(user: dict = Depends(current_user)):
        ms = memory_store_of(user["id"])
        ms.clear_all()
        return {"ok": True, "stats": ms.overview()["stats"]}

    # ================================================================== 外部事项追踪器（邮件/日历/投递/监控）
    @app.get("/api/trackers")
    async def get_trackers(kind: str = "", status: str = "", user: dict = Depends(current_user)):
        from omniagent.connectors.protocols import TrackerStore

        ts = TrackerStore(workspace_of(user["id"]) / ".omniagent" / "trackers.db")
        try:
            return {"trackers": ts.list_trackers(kind=kind, status=status)}
        finally:
            ts.close()

    @app.post("/api/trackers/poll")
    async def poll_trackers_api(user: dict = Depends(current_user)):
        from omniagent.connectors.protocols import TrackerStore

        ws = workspace_of(user["id"])
        ts = TrackerStore(ws / ".omniagent" / "trackers.db")
        try:
            alerts = await ts.poll_updates(ws)
            return {"alerts": alerts, "trackers": ts.list_trackers()}
        finally:
            ts.close()

    @app.delete("/api/trackers/{tid}")
    async def remove_tracker_api(tid: str, user: dict = Depends(current_user)):
        from omniagent.connectors.protocols import TrackerStore

        ts = TrackerStore(workspace_of(user["id"]) / ".omniagent" / "trackers.db")
        try:
            return {"ok": ts.delete(tid)}
        finally:
            ts.close()

    # ================================================================== 对话
    @app.get("/api/conversations")
    async def list_convs(q: str = "", archived: int = 0, limit: int = 200, user: dict = Depends(current_user)):
        items = db.list_conversations(user["id"], q, bool(archived), min(limit, 1000))
        for it in items:
            s = sessions.get(it["id"])
            it["running"] = bool(s and s.running)
        return items

    def load_conv(user: dict, cid: str) -> tuple[dict, dict]:
        conv = db.get_conversation(cid, user["id"])
        if not conv:
            raise HTTPException(404, "对话不存在")
        data = load_session(workspace_of(user["id"]), cid)
        if not data:
            raise HTTPException(404, "对话内容不存在")
        s = sessions.get(cid)
        if s:  # 运行中的会话以内存为准
            data["messages"] = s.agent.messages
            data["todos"] = s.agent.state.get("todos", [])
            data["file_changes"] = list((s.agent.state.get("file_changes") or {}).values())
            data["external_ops"] = list(s.agent.state.get("external_ops") or [])
        return conv, data

    @app.get("/api/conversations/{cid}")
    async def get_conv(cid: str, user: dict = Depends(current_user)):
        conv, data = load_conv(user, cid)
        s = sessions.get(cid)
        return {**conv, "todos": data.get("todos", []), "history": history_for_ui(data["messages"]),
                "file_changes": data.get("file_changes", []),
                "external_ops": data.get("external_ops", []),
                "agent_profile": data.get("agent_profile", "general"),
                "running": bool(s and s.running), "usage": data.get("usage", {})}

    @app.patch("/api/conversations/{cid}")
    async def patch_conv(cid: str, request: Request, user: dict = Depends(current_user)):
        body = await request.json()
        if not db.get_conversation(cid, user["id"]):
            raise HTTPException(404, "对话不存在")
        conv = db.update_conversation(cid, user["id"], title=body.get("title"), pinned=body.get("pinned"),
                                      archived=body.get("archived"))
        if body.get("title") and cid in sessions:
            sessions[cid].agent.title = str(body["title"])[:200]
        return {"conversation": conv}

    @app.delete("/api/conversations/{cid}")
    async def delete_conv(cid: str, request: Request, user: dict = Depends(current_user)):
        if not db.get_conversation(cid, user["id"]):
            raise HTTPException(404, "对话不存在")
        s = sessions.pop(cid, None)
        if s:
            if s.running:
                s.task.cancel()
            await s.agent.close()
        db.delete_conversation(cid, user["id"])
        delete_session(workspace_of(user["id"]), cid)
        db.audit(user, "conversation_delete", cid, client_ip(request))
        return {"ok": True}

    @app.get("/api/conversations/{cid}/export")
    async def export_conv(cid: str, format: str = "md", user: dict = Depends(current_user)):
        conv, data = load_conv(user, cid)
        safe_title = re.sub(r"[\\/:*?\"<>|\s]+", "_", conv["title"])[:50] or cid
        if format == "json":
            payload = {"id": cid, "title": conv["title"], "created": conv["created"],
                       "messages": [m.to_dict() for m in data["messages"]]}
            content = json.dumps(payload, ensure_ascii=False, indent=2).encode()
            return _download(content, f"{safe_title}.json", "application/json")
        md = history_to_markdown(conv["title"], data["messages"])
        if format == "docx":
            from omniagent.tools.documents import markdown_to_docx

            tmp = data_dir / "tmp" / f"{uuid.uuid4().hex}.docx"
            tmp.parent.mkdir(parents=True, exist_ok=True)
            await asyncio.to_thread(markdown_to_docx, md, tmp, workspace_of(user["id"]), None)
            content = tmp.read_bytes()
            tmp.unlink(missing_ok=True)
            return _download(content, f"{safe_title}.docx",
                             "application/vnd.openxmlformats-officedocument.wordprocessingml.document")
        return _download(md.encode(), f"{safe_title}.md", "text/markdown; charset=utf-8")

    def _download(content: bytes, filename: str, media: str) -> Response:
        from urllib.parse import quote

        return Response(content, media_type=media,
                        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(filename)}"})

    @app.post("/api/conversations/{cid}/share")
    async def share_conv(cid: str, request: Request, user: dict = Depends(current_user)):
        if not db.get_conversation(cid, user["id"]):
            raise HTTPException(404, "对话不存在")
        token = db.get_share_token(cid, user["id"]) or secrets.token_urlsafe(16)
        db.set_share(cid, user["id"], token)
        db.audit(user, "share_create", cid, client_ip(request))
        return {"token": token, "share_url": f"{str(request.base_url).rstrip('/')}/share/{token}"}

    @app.delete("/api/conversations/{cid}/share")
    async def unshare_conv(cid: str, user: dict = Depends(current_user)):
        db.set_share(cid, user["id"], None)
        return {"ok": True}

    @app.get("/api/share/{token}")
    async def get_share(token: str):
        row = db.conversation_by_share(token)
        if not row:
            raise HTTPException(404, "分享链接不存在或已关闭")
        data = load_session(workspace_of(row["user_id"]), row["id"])
        if not data:
            raise HTTPException(404, "对话内容不存在")
        owner = db.get_user(row["user_id"])
        return {"title": row["title"], "created": row["created"], "updated": row["updated"],
                "author": owner["display_name"] if owner else "", "history": history_for_ui(data["messages"])}

    # ================================================================== 文件
    @app.get("/api/files")
    async def files(path: str = ".", user: dict = Depends(current_user)):
        d = safe_path(user, path)
        if not d.is_dir():
            raise HTTPException(400, "不是目录")
        ws = workspace_of(user["id"])
        items = []
        for e in sorted(d.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower())):
            if e.name in IGNORE_DIRS or e.name == ".DS_Store":
                continue
            st = e.stat()
            items.append({"name": e.name, "path": str(e.relative_to(ws)), "is_dir": e.is_dir(), "size": st.st_size,
                          "mtime": st.st_mtime})
        return {"path": str(d.relative_to(ws)) if d != ws else ".", "items": items}

    @app.get("/api/file")
    async def raw_file(path: str, download: int = 0, user: dict = Depends(current_user)):
        p = safe_path(user, path)
        if not p.is_file():
            raise HTTPException(404, "文件不存在")
        return FileResponse(p, filename=p.name if download else None,
                            media_type=mimetypes.guess_type(p.name)[0] or "application/octet-stream",
                            content_disposition_type="attachment" if download else "inline")

    @app.put("/api/file")
    async def save_text_file(request: Request, user: dict = Depends(current_user)):
        body = await request.json()
        rel_path = str(body.get("path") or "").strip()
        if not rel_path:
            raise HTTPException(400, "缺少文件路径")
        p = safe_path(user, rel_path)
        if p.exists() and p.is_dir():
            raise HTTPException(400, "不能覆盖目录")
        content = str(body.get("content") or "")
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        st = p.stat()
        ws = workspace_of(user["id"])
        return {"ok": True, "path": str(p.relative_to(ws)), "size": st.st_size, "mtime": st.st_mtime}

    @app.get("/api/preview")
    async def preview(path: str, user: dict = Depends(current_user)):
        p = safe_path(user, path)
        if not p.is_file():
            raise HTTPException(404, "文件不存在")
        ext = p.suffix.lower()
        info = {"path": path, "name": p.name, "size": p.stat().st_size, "ext": ext, "mtime": p.stat().st_mtime}
        if ext in IMAGE_EXTS:
            return {**info, "kind": "image"}
        if ext in (".html", ".htm"):
            return {**info, "kind": "html"}
        if ext == ".pdf":
            return {**info, "kind": "pdf"}
        if ext in (".csv", ".tsv"):
            text = p.read_text(encoding="utf-8-sig", errors="replace")
            rows = list(csv.reader(io.StringIO(text), delimiter="\t" if ext == ".tsv" else ","))
            return {**info, "kind": "table", "rows": rows[:500], "total": len(rows)}
        if ext in DOC_EXTS:
            try:
                text = await asyncio.to_thread(extract_text, p)
            except Exception as e:  # noqa: BLE001
                raise HTTPException(400, f"无法解析文档：{e}") from None
            return {**info, "kind": "markdown", "content": text[:200_000]}
        if ext == ".md":
            return {**info, "kind": "markdown", "content": p.read_text(encoding="utf-8", errors="replace")[:200_000]}
        if ext in TEXT_EXTS or p.stat().st_size < 512_000:
            raw = p.read_bytes()[:400_000]
            if b"\x00" in raw[:8192]:
                return {**info, "kind": "binary"}
            return {**info, "kind": "code", "content": raw.decode("utf-8", "replace")}
        return {**info, "kind": "binary"}

    def storage_quota_bytes() -> int:
        return int(sys_settings().get("storage_quota_mb") or 0) * 1024 * 1024

    @app.get("/api/files/storage")
    async def storage(user: dict = Depends(current_user)):
        used = await asyncio.to_thread(dir_size, workspace_of(user["id"]))
        return {"used_bytes": used, "quota_bytes": storage_quota_bytes()}

    @app.post("/api/upload")
    async def upload(files: list[UploadFile] = File(...), dir: str = Form("uploads"), user: dict = Depends(current_user)):
        target = safe_path(user, dir)
        target.mkdir(parents=True, exist_ok=True)
        quota = storage_quota_bytes()
        used = await asyncio.to_thread(dir_size, workspace_of(user["id"])) if quota else 0
        ws = workspace_of(user["id"])
        saved = []
        for f in files:
            name = Path(f.filename or "file").name
            if not name or name.startswith("."):
                name = f"file_{int(time.time())}{name}"
            dest = target / name
            if dest.exists():
                dest = target / f"{dest.stem}_{int(time.time())}{dest.suffix}"
            with open(dest, "wb") as out:
                shutil.copyfileobj(f.file, out)
            used += dest.stat().st_size
            if quota and used > quota:
                dest.unlink(missing_ok=True)
                raise HTTPException(413, "存储空间不足，请清理文件或联系管理员提高配额")
            saved.append(str(dest.relative_to(ws)))
        return {"saved": saved}

    @app.delete("/api/files")
    async def delete_file(path: str, request: Request, user: dict = Depends(current_user)):
        p = safe_path(user, path)
        if p == workspace_of(user["id"]):
            raise HTTPException(400, "不能删除工作区根目录")
        if not p.exists():
            raise HTTPException(404, "文件不存在")
        shutil.rmtree(p) if p.is_dir() else p.unlink()
        db.audit(user, "file_delete", path, client_ip(request))
        return {"ok": True}

    @app.post("/api/files/rename")
    async def rename_file(request: Request, user: dict = Depends(current_user)):
        body = await request.json()
        p = safe_path(user, body.get("path"))
        new_name = Path(body.get("new_name") or "").name
        if not p.exists() or not new_name:
            raise HTTPException(400, "参数错误")
        dest = p.with_name(new_name)
        safe_path(user, str(dest.relative_to(workspace_of(user["id"]))))
        if dest.exists():
            raise HTTPException(409, "同名文件已存在")
        p.rename(dest)
        return {"path": str(dest.relative_to(workspace_of(user["id"])))}

    @app.post("/api/files/mkdir")
    async def mkdir(request: Request, user: dict = Depends(current_user)):
        body = await request.json()
        p = safe_path(user, body.get("path"))
        p.mkdir(parents=True, exist_ok=True)
        return {"path": str(p.relative_to(workspace_of(user["id"])))}

    @app.get("/api/files/zip")
    async def zip_dir(path: str = ".", user: dict = Depends(current_user)):
        d = safe_path(user, path)
        if not d.is_dir():
            raise HTTPException(400, "不是目录")

        def build() -> bytes:
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
                for root, dirs, fs in os.walk(d):
                    dirs[:] = [x for x in dirs if x not in IGNORE_DIRS]
                    for f in fs:
                        fp = Path(root) / f
                        z.write(fp, fp.relative_to(d))
            return buf.getvalue()

        content = await asyncio.to_thread(build)
        return _download(content, f"{d.name or 'workspace'}.zip", "application/zip")

    # ================================================================== 管理后台
    @app.get("/api/admin/stats")
    async def admin_stats(admin: dict = Depends(admin_user)):
        st = db.stats()
        tot = db.usage_totals()
        return {**st, "tasks_running": sum(1 for s in sessions.values() if s.running),
                "tokens": {"input": tot["input_tokens"], "output": tot["output_tokens"]}, "tasks_total": tot["tasks"],
                "daily": db.usage_daily(None, 30)}

    @app.get("/api/admin/users")
    async def admin_users(admin: dict = Depends(admin_user)):
        users = db.list_users()
        for u in users:
            p = data_dir / "workspaces" / f"u{u['id']}"
            u["storage_bytes"] = await asyncio.to_thread(dir_size, p) if p.exists() else 0
        return users

    @app.post("/api/admin/users")
    async def admin_create_user(request: Request, admin: dict = Depends(admin_user)):
        body = await request.json()
        username = (body.get("username") or "").strip()
        if not USERNAME_RE.match(username):
            raise HTTPException(400, "用户名需为 3-32 位字母、数字、中文或 _ . -")
        if len(body.get("password") or "") < 8:
            raise HTTPException(400, "密码至少 8 位")
        if db.get_user_row_by_name(username):
            raise HTTPException(409, "用户名已存在")
        role = body.get("role") if body.get("role") in ("admin", "user") else "user"
        user = db.create_user(username, body["password"], role, body.get("email", ""), body.get("display_name", ""))
        db.audit(admin, "user_create", username, client_ip(request))
        return {"user": user}

    @app.patch("/api/admin/users/{uid}")
    async def admin_update_user(uid: int, request: Request, admin: dict = Depends(admin_user)):
        body = await request.json()
        target = db.get_user(uid)
        if not target:
            raise HTTPException(404, "用户不存在")
        fields: dict[str, Any] = {}
        if "role" in body:
            if body["role"] not in ("admin", "user"):
                raise HTTPException(400, "无效角色")
            if uid == admin["id"] and body["role"] != "admin":
                raise HTTPException(400, "不能取消自己的管理员权限")
            fields["role"] = body["role"]
        if "status" in body:
            if body["status"] not in ("active", "disabled"):
                raise HTTPException(400, "无效状态")
            if uid == admin["id"] and body["status"] != "active":
                raise HTTPException(400, "不能禁用自己")
            fields["status"] = body["status"]
            if body["status"] == "disabled":
                db.delete_tokens_except(uid, None)
        if body.get("password"):
            if len(body["password"]) < 8:
                raise HTTPException(400, "密码至少 8 位")
            fields["password"] = body["password"]
            db.delete_tokens_except(uid, None)
        if "token_quota" in body:
            q = body["token_quota"]
            fields["token_quota"] = int(q) if q not in (None, "", 0) else None
        for k in ("display_name", "email"):
            if k in body:
                fields[k] = str(body[k])[:100]
        user = db.update_user(uid, **fields)
        db.audit(admin, "user_update", f"{target['username']}: {', '.join(fields)}", client_ip(request))
        return {"user": user}

    @app.delete("/api/admin/users/{uid}")
    async def admin_delete_user(uid: int, request: Request, admin: dict = Depends(admin_user)):
        if uid == admin["id"]:
            raise HTTPException(400, "不能删除自己")
        target = db.get_user(uid)
        if not target:
            raise HTTPException(404, "用户不存在")
        for cid, s in list(sessions.items()):
            if s.user_id == uid:
                if s.running:
                    s.task.cancel()
                await s.agent.close()
                sessions.pop(cid, None)
        db.delete_user(uid)
        shutil.rmtree(data_dir / "workspaces" / f"u{uid}", ignore_errors=True)
        db.audit(admin, "user_delete", target["username"], client_ip(request))
        return {"ok": True}

    @app.get("/api/admin/settings")
    async def admin_get_settings(admin: dict = Depends(admin_user)):
        return {**sys_settings(), "all_models": [{"name": n, "model": p.model, "available": p.available}
                                                 for n, p in settings.models.items()]}

    @app.put("/api/admin/settings")
    async def admin_put_settings(request: Request, admin: dict = Depends(admin_user)):
        body = await request.json()
        clean = {k: v for k, v in body.items() if k in DEFAULT_SYSTEM_SETTINGS}
        for k in ("max_concurrent_tasks_per_user", "storage_quota_mb"):
            if k in clean:
                clean[k] = max(0, int(clean[k] or 0))
        if "enabled_models" in clean:
            clean["enabled_models"] = [m for m in clean["enabled_models"] if m in settings.models]
        st = db.update_settings(**clean)
        db.audit(admin, "settings_update", ", ".join(clean), client_ip(request))
        return st

    @app.get("/api/admin/audit")
    async def admin_audit(limit: int = 200, admin: dict = Depends(admin_user)):
        return db.list_audit(min(limit, 2000))

    # ================================================================== WebSocket
    async def broadcast_conv_state(s: WebSession, *, finished: bool = False):
        conns = user_sockets.get(s.user_id)
        if not conns:
            return
        ev = {
            "type": "sidebar_conv_state",
            "id": s.agent.session_id,
            "title": s.agent.title or "新对话",
            "running": s.running,
            "finished": finished,
            "queue_len": len(s.queue),
            "model": s.agent.llm.profile.name,
            "updated": time.time(),
        }
        dead: list[WebSocket] = []
        for sock in list(conns):
            # 当前已直接挂载在该会话上的前端连接会收到原生 task_start / idle，仅向切换到其他对话的连接推送后台状态
            if sock in s.clients:
                continue
            try:
                await sock.send_json(ev)
            except Exception:  # noqa: BLE001
                dead.append(sock)
        for d in dead:
            conns.discard(d)

    def ready_payload(s: WebSession) -> dict:
        a = s.agent
        return {"type": "ready", "conversation_id": a.session_id, "session_id": a.session_id, "title": a.title,
                "model": a.llm.profile.name, "mode": a.mode, "approval": a.approval,
                "agent_profile": a.agent_profile_name, "running": s.running,
                "queue": list(s.queue),
                "live_state": a.get_live_state() if s.running else None,
                "pending_interactions": list(s.pending_interactions.values()),
                "file_changes": list((a.state.get("file_changes") or {}).values()),
                "external_ops": list(a.state.get("external_ops") or [])[-200:],
                "history": history_for_ui(a.messages), "todos": a.state.get("todos", [])}

    def check_can_run(user: dict):
        st = sys_settings()
        limit = int(st.get("max_concurrent_tasks_per_user") or 0)
        running = sum(1 for s in sessions.values() if s.user_id == user["id"] and s.running)
        if limit and running >= limit:
            raise HTTPException(429, f"同时运行的任务已达上限（{limit} 个），请等待其他任务完成")
        quota = user.get("token_quota")
        if quota:
            month_start = time.mktime(dt.date.today().replace(day=1).timetuple())
            used = db.usage_totals(user["id"], since=month_start)
            if used["input_tokens"] + used["output_tokens"] >= quota:
                raise HTTPException(429, "本月 token 额度已用完，请联系管理员")

    def build_task_content(raw_text: str, attachments: list[str] | None = None) -> str:
        text = (raw_text or "").strip()
        if attachments:
            text += "\n\n[用户上传/附带的文件]\n" + "\n".join(f"- {p}" for p in attachments)
        return text

    def apply_run_options(s: WebSession, u: dict, spec: dict[str, Any]) -> None:
        a = s.agent
        if spec.get("model") and spec["model"] != a.llm.profile.name:
            a.llm = create_provider(resolve_profile(u, spec["model"]))
        elif spec.get("model") is None and not a.llm.profile.available and a.llm.profile.provider != "mock":
            a.llm = create_provider(resolve_profile(u, a.llm.profile.name))
        if spec.get("mode") in ("auto", "code", "office"):
            a.mode = spec["mode"]
        if spec.get("approval") in ("auto", "smart", "always"):
            a.approval = spec["approval"]
        if spec.get("agent_profile"):
            a.set_agent_profile(str(spec["agent_profile"]), db.list_custom_agents(u["id"]))
        a.extra_connectors = [c for c in user_connector_specs(u["id"]) if c.enabled]
        a.state["extra_connectors"] = a.extra_connectors

    async def start_task(s: WebSession, user: dict, content: str):
        async def runner():
            cur_content = content
            cancelled = False
            try:
                while True:
                    before_in, before_out = s.agent.usage.input_tokens, s.agent.usage.output_tokens
                    first = not s.agent.title
                    try:
                        if first:
                            s.agent.title = cur_content.strip().splitlines()[0][:60] if cur_content.strip() else "新对话"
                        # 立即在任务启动瞬间持久化并写入会话索引，确保用户立刻切换到其他对话时左侧栏能实时显示并随时切回！
                        s.agent.save()
                        db.upsert_conversation(
                            s.agent.session_id, s.user_id, title=s.agent.title,
                            model=s.agent.llm.profile.name, mode=s.agent.mode,
                            message_count=max(1, len(s.agent.messages) + 1),
                            input_tokens=s.agent.usage.input_tokens, output_tokens=s.agent.usage.output_tokens,
                            content=search_text(s.agent.messages) or cur_content[:2000], created=s.agent.created,
                        )
                        await s.send({"type": "conversation_updated", "id": s.agent.session_id, "title": s.agent.title})
                        await broadcast_conv_state(s)
                        await s.agent.run(cur_content)
                    except asyncio.CancelledError:
                        cancelled = True
                        break
                    except Exception as e:  # noqa: BLE001
                        log.exception("agent failed")
                        await s.send({"type": "error", "message": f"{type(e).__name__}: {e}"})
                    finally:
                        di = s.agent.usage.input_tokens - before_in
                        do = s.agent.usage.output_tokens - before_out
                        db.add_usage(s.user_id, s.agent.session_id, s.agent.llm.profile.name, di, do, 1)
                        try:
                            index_conversation(s.agent, s.user_id)
                        except Exception:  # noqa: BLE001
                            pass
                        s.last_seen = time.time()
                        await s.send({"type": "conversation_updated", "id": s.agent.session_id, "title": s.agent.title})

                    if cancelled or not s.queue:
                        break
                    # 自动出队并执行下一条排队问题
                    nxt = s.queue.pop(0)
                    latest_u = db.get_user(s.user_id) or user
                    try:
                        apply_run_options(s, latest_u, nxt)
                    except Exception as e:  # noqa: BLE001
                        log.warning("apply queued options warning: %s", e)
                    await s.send({"type": "queue_updated", "queue": list(s.queue), "dequeued": nxt})
                    await broadcast_conv_state(s)
                    cur_content = build_task_content(nxt.get("raw_text", ""), nxt.get("attachments"))
            finally:
                await s.send({"type": "idle", "conversation_id": s.agent.session_id, "queue": list(s.queue)})
                await broadcast_conv_state(s, finished=not cancelled)

        s.task = asyncio.create_task(runner())
        await asyncio.sleep(0)

    def truncate_last_turn(agent: Agent) -> str | None:
        idx = None
        for i in range(len(agent.messages) - 1, -1, -1):
            m = agent.messages[i]
            if m.role == "user" and not m.meta.get("system"):
                idx = i
                break
        if idx is None:
            return None
        content = agent.messages[idx].content
        agent.messages = agent.messages[:idx]
        return content

    @app.websocket("/ws")
    async def ws_endpoint(ws: WebSocket):
        user = db.user_by_token(ws.cookies.get(COOKIE))
        if user is None or user["status"] != "active":
            await ws.accept()
            await ws.close(code=4401)
            return
        await ws.accept()
        user_sockets.setdefault(user["id"], set()).add(ws)
        current: WebSession | None = None

        async def err(message: str):
            await ws.send_json({"type": "error", "message": message})

        try:
            while True:
                msg = await ws.receive_json()
                t = msg.get("type")
                user = db.get_user(user["id"]) or user  # 设置可能已更新
                try:
                    if t in ("init", "new"):
                        if current is not None:
                            # 仅解绑当前前端视图订阅，原后台会话任务继续独立运行不受任何影响！
                            current.detach(ws)
                        cid = (msg.get("conversation_id") or msg.get("session_id")) if t == "init" else None
                        current = make_session(user, cid, msg.get("model"), msg.get("mode"), msg.get("approval"),
                                               msg.get("agent_profile"))
                        current.attach(ws)
                        await ws.send_json(ready_payload(current))
                    elif t == "ping":
                        await ws.send_json({"type": "pong"})
                    elif current is None:
                        await err("请先发送 init")
                    elif t in ("task", "queue_add", "regenerate", "edit_last"):
                        a = current.agent
                        # 若当前正在执行且收到新问题（task 或 queue_add），自动加入会话排队队列！
                        if (t == "task" and current.running) or t == "queue_add":
                            raw_text = (msg.get("content") or "").strip()
                            if not raw_text:
                                await err("排队问题内容不能为空")
                                continue
                            if len(current.queue) >= 30:
                                await err("排队队列已满（最多 30 条）")
                                continue
                            q_item = {
                                "id": f"q_{uuid.uuid4().hex[:8]}",
                                "raw_text": raw_text,
                                "attachments": list(msg.get("attachments") or []),
                                "model": msg.get("model"),
                                "mode": msg.get("mode"),
                                "approval": msg.get("approval"),
                                "agent_profile": msg.get("agent_profile"),
                                "created": time.time(),
                            }
                            current.queue.append(q_item)
                            await current.send({"type": "queue_updated", "queue": list(current.queue), "enqueued": q_item})
                            # 若原本处于空闲态但收到 queue_add 且要求自动运行，可由 queue_flush 触发
                            continue

                        if current.running:
                            await err("当前任务仍在执行中")
                            continue
                        check_can_run(user)
                        apply_run_options(current, user, msg)
                        if t == "task":
                            raw_text = (msg.get("content") or "").strip()
                            if not raw_text:
                                await err("任务内容不能为空")
                                continue
                            content = build_task_content(raw_text, msg.get("attachments"))
                        else:
                            last = truncate_last_turn(a)
                            if last is None:
                                await err("没有可以重新生成的消息")
                                continue
                            content = (msg.get("content") or "").strip() if t == "edit_last" else last
                            if not content:
                                await err("内容不能为空")
                                continue
                            await ws.send_json(ready_payload(current))
                        await start_task(current, user, content)
                    elif t == "queue_remove":
                        qid = str(msg.get("id") or "")
                        current.queue = [x for x in current.queue if x["id"] != qid]
                        await current.send({"type": "queue_updated", "queue": list(current.queue)})
                    elif t == "queue_edit":
                        qid = str(msg.get("id") or "")
                        new_txt = str(msg.get("content") or "").strip()
                        if new_txt:
                            for x in current.queue:
                                if x["id"] == qid:
                                    x["raw_text"] = new_txt
                                    break
                        await current.send({"type": "queue_updated", "queue": list(current.queue)})
                    elif t == "queue_move":
                        qid = str(msg.get("id") or "")
                        direction = str(msg.get("direction") or "up")
                        idx = next((i for i, x in enumerate(current.queue) if x["id"] == qid), -1)
                        if idx >= 0:
                            item = current.queue.pop(idx)
                            if direction == "top":
                                current.queue.insert(0, item)
                            elif direction == "up":
                                current.queue.insert(max(0, idx - 1), item)
                            elif direction == "down":
                                current.queue.insert(min(len(current.queue), idx + 1), item)
                            else:
                                current.queue.insert(idx, item)
                        await current.send({"type": "queue_updated", "queue": list(current.queue)})
                    elif t == "queue_clear":
                        current.queue.clear()
                        await current.send({"type": "queue_updated", "queue": []})
                    elif t == "queue_flush":
                        if not current.running and current.queue:
                            check_can_run(user)
                            nxt = current.queue.pop(0)
                            apply_run_options(current, user, nxt)
                            await current.send({"type": "queue_updated", "queue": list(current.queue), "dequeued": nxt})
                            await start_task(current, user, build_task_content(nxt.get("raw_text", ""), nxt.get("attachments")))
                    elif t in ("approval", "answer"):
                        fut = current.pending.get(msg.get("id"))
                        if fut and not fut.done():
                            fut.set_result(msg if t == "approval" else msg.get("text", ""))
                    elif t == "login_done":
                        # 用户在界面上确认“我已完成登录”，通知正在 wait_login 的浏览器自动化继续执行
                        current.agent.state.setdefault("_login_confirmed", set()).add(str(msg.get("id") or ""))
                    elif t == "stop":
                        if current.running:
                            current.task.cancel()
                    else:
                        await err(f"未知消息类型 {t}")
                except HTTPException as e:
                    await err(str(e.detail))
        except WebSocketDisconnect:
            pass
        except Exception as e:  # noqa: BLE001
            log.exception("ws error: %s", e)
        finally:
            if current is not None:
                current.detach(ws)
            if user and user.get("id") in user_sockets:
                user_sockets[user["id"]].discard(ws)

    @app.exception_handler(KeyError)
    async def key_error(_, exc):
        return JSONResponse({"detail": str(exc)}, status_code=400)

    return app


def default_data_dir() -> Path:
    return Path(os.environ.get("OMNI_DATA_DIR") or (Path.home() / ".omniagent" / "server")).expanduser()


def serve(workspace: Path | None, settings: Settings, host: str = "127.0.0.1", port: int = 8765,
          default_model: str | None = None, data_dir: Path | None = None):
    import uvicorn
    from rich.console import Console

    data_dir = Path(data_dir) if data_dir else default_data_dir()
    Console().print(f"[bold cyan]OmniAgent 工作台[/bold cyan] 已启动 → [link]http://{host}:{port}[/link]   数据目录: {data_dir}")
    uvicorn.run(create_app(data_dir, settings, default_model, cookie_secure=os.environ.get("OMNI_SECURE_COOKIE") == "1"),
                host=host, port=port, log_level="warning")
