/* 右侧工作面板：审阅(Diff/预览/在线编辑) / 计划 / 产出 / 预览 / 文件管理 */
import { S, bus } from "./state.js";
import {
  $, $$, esc, div, h, fileUrl, FILE_ICON, fileTypeBadge, isBinaryPath,
  basename, joinPath, fmtBytes, fmtRelative, download, renderUnifiedDiffHtml,
} from "./util.js";
import { api, upload, post, put, del } from "./api.js";
import { toast, confirmDialog, promptDialog, openMenu, lightbox, spinner, emptyState } from "./ui.js";
import { setMarkdown } from "./markdown.js";
import { SVG } from "./icons.js";

const P = {
  outputs: new Map(),
  changes: new Map(), // path -> {path, status, added, removed, diff, binary, updated}
  tab: "plan",
  cwd: ".",
  previewPath: null,
  reviewPath: null,
  reviewMode: "diff", // diff | preview | edit
  editorDirty: false,
  reviewSeq: 0,
  filesLoaded: false,
  loadSeq: 0,
};
let addAttachmentFn = () => {};
const IS_MAC = /Mac|iPhone|iPad/.test(navigator.platform || navigator.userAgent);

const CODE_LANG = {
  py: "python", js: "javascript", jsx: "javascript", ts: "typescript", tsx: "typescript",
  json: "json", sh: "bash", zsh: "bash", yaml: "yaml", yml: "yaml", html: "xml",
  xml: "xml", css: "css", scss: "scss", sql: "sql", java: "java", go: "go", rs: "rust",
  c: "c", cpp: "cpp", h: "c", r: "r", tex: "latex", toml: "ini", ini: "ini", md: "markdown",
};

export function init({ onAttach }) {
  addAttachmentFn = onAttach;
  $$(".ptab").forEach((t) => (t.onclick = () => switchTab(t.dataset.tab)));
  $("#fm-upload").onclick = () => $("#fm-file-input").click();
  $("#fm-file-input").onchange = (e) => { uploadHere(e.target.files); e.target.value = ""; };
  $("#fm-mkdir").onclick = mkdir;
  $("#fm-zip").onclick = () => download(`/api/files/zip?path=${encodeURIComponent(P.cwd)}`);
  $("#fm-refresh").onclick = () => loadFiles();
  const tab = $("#tab-files");
  tab.addEventListener("dragover", (e) => { if ([...e.dataTransfer.types].includes("Files")) { e.preventDefault(); tab.classList.add("drag"); } });
  tab.addEventListener("dragleave", (e) => { if (!tab.contains(e.relatedTarget)) tab.classList.remove("drag"); });
  tab.addEventListener("drop", (e) => {
    if (![...e.dataTransfer.types].includes("Files")) return;
    e.preventDefault();
    e.stopPropagation();
    tab.classList.remove("drag");
    uploadHere(e.dataTransfer.files);
  });
  bus.on("files:changed", () => { if (P.tab === "files" || P.filesLoaded) loadFiles(); });
  bus.on("conv:idle", () => { if (P.filesLoaded) loadFiles(); });
  renderPlan([], { quiet: true });
  renderOutputs();
  renderReviewEmpty();
  $("#preview-body").innerHTML = emptyState("👁", "点击文件进行预览", "支持表格、文档、图片、PDF、HTML、代码等");
}

export function switchTab(name) {
  const changed = P.tab !== name;
  P.tab = name;
  $$(".ptab").forEach((t) => {
    const on = t.dataset.tab === name;
    t.classList.toggle("active", on);
    t.setAttribute("aria-selected", on ? "true" : "false");
  });
  ["review", "ops", "plan", "outputs", "preview", "files"].forEach((n) => {
    const el = $("#tab-" + n);
    if (!el) return;
    const show = n === name;
    el.hidden = !show;
    if (show && changed) {
      el.classList.remove("pane-enter");
      void el.offsetWidth;
      el.classList.add("pane-enter");
    }
  });
  if (name === "files" && !P.filesLoaded) loadFiles();
  if (name === "review") renderReviewTab();
  if (name === "ops") renderOps();
}

/* ==========================================================================
   🖥 操作（接入外部系统 / 应用时的实时操作步骤 + 页面截图直播）
   ========================================================================== */
const OPS = { list: [], map: new Map(), selected: null, follow: true };
const OP_STATUS = { running: "执行中", done: "完成", error: "失败" };
const OP_ACTION = {
  open: "打开", snapshot: "读取页面", click: "点击", fill: "填写", select: "选择", check: "勾选", upload: "上传附件",
  press: "按键", scroll: "滚动", wait: "等待", wait_login: "等待登录", read_tables: "读取表格", screenshot: "截图",
  back: "返回", submit: "提交", close: "关闭", analyze: "票据核对", list: "列表", read: "读取", send_email: "发送",
  send_reply: "回复", draft_reply: "草稿", add: "新增", update: "更新", discover: "探测", register: "注册",
};

export function setOps(list = []) {
  OPS.list = [];
  OPS.map.clear();
  OPS.selected = null;
  OPS.follow = true;
  (list || []).forEach((o) => upsertOp(o, { silent: true }));
  updateOpsBadge();
  if (P.tab === "ops") renderOps();
}

export function upsertOp(op, { silent = false } = {}) {
  if (!op || !op.id) return;
  let cur = OPS.map.get(op.id);
  const isNew = !cur;
  if (isNew) {
    cur = { ...op };
    OPS.list.push(cur);
    OPS.map.set(op.id, cur);
    if (OPS.list.length > 300) OPS.map.delete(OPS.list.shift().id);
  } else {
    for (const [k, v] of Object.entries(op)) if (v !== undefined && v !== null && v !== "") cur[k] = v;
  }
  if (OPS.follow) OPS.selected = cur.id;
  updateOpsBadge();
  if (silent) return;
  if (isNew && !P.editorDirty) {
    bus.emit("panel:show");
    if (P.tab !== "ops") switchTab("ops");
  }
  if (P.tab === "ops") renderOps();
}

function updateOpsBadge() {
  const badge = $("#ops-count");
  const dot = $("#ops-live-dot");
  if (badge) {
    badge.hidden = !OPS.list.length;
    badge.textContent = OPS.list.length;
  }
  if (dot) dot.hidden = !OPS.list.some((o) => o.status === "running");
}

function opShot(o) {
  return o && o.screenshot ? fileUrl(o.screenshot) : "";
}

function renderOps() {
  const stage = $("#ops-stage"), tb = $("#ops-toolbar"), tl = $("#ops-timeline");
  if (!stage || !tl) return;
  if (!OPS.list.length) {
    stage.innerHTML = "";
    tb.innerHTML = "";
    tl.innerHTML = emptyState("🖥", "暂无外部系统操作", "智能体接入网页业务系统、邮箱、日历、数据库或执行智能报销时，每一步操作与页面截图都会在这里实时展示");
    return;
  }
  const sel = OPS.map.get(OPS.selected) || OPS.list[OPS.list.length - 1];
  // 直播舞台：优先展示所选步骤截图；该步无截图时回溯同一系统最近一张截图
  let shotOp = sel && sel.screenshot ? sel : null;
  if (!shotOp) {
    const idx = OPS.list.indexOf(sel);
    for (let i = idx; i >= 0; i--) if (OPS.list[i].screenshot) { shotOp = OPS.list[i]; break; }
  }
  const stepNo = OPS.list.indexOf(sel) + 1;
  stage.innerHTML = "";
  const head = h("div", { class: "ops-stage-head" },
    h("span", { class: "ops-sys-ic", text: sel.icon || "🔌" }),
    h("div", { class: "ops-stage-meta" },
      h("div", { class: "ops-stage-title" },
        h("b", { text: sel.system || sel.tool }),
        sel.session ? h("span", { class: "ops-chip", text: sel.session }) : null,
        h("span", { class: `ops-status ${sel.status}`, text: OP_STATUS[sel.status] || sel.status })),
      (sel.url || shotOp?.url) ? h("a", { class: "ops-url", href: sel.url || shotOp.url, target: "_blank", rel: "noopener noreferrer", title: sel.url || shotOp.url, text: sel.page_title ? `${sel.page_title} · ${sel.url || shotOp.url}` : (sel.url || shotOp.url) }) : null));
  stage.appendChild(head);
  const screen = h("div", { class: "ops-screen" + (sel.status === "running" ? " live" : "") });
  if (shotOp) {
    const img = h("img", { src: opShot(shotOp), alt: `步骤 ${stepNo} 截图`, loading: "lazy" });
    img.onclick = () => lightbox(img.src);
    screen.appendChild(img);
    if (sel.status === "running") screen.appendChild(h("span", { class: "ops-rec", text: "● LIVE" }));
  } else {
    screen.appendChild(h("div", { class: "ops-screen-empty" }, h("span", { text: sel.icon || "🔌" }), h("small", { text: sel.status === "running" ? "正在执行…" : "该步骤没有页面截图" })));
  }
  stage.appendChild(screen);
  stage.appendChild(h("div", { class: "ops-caption" },
    h("span", { class: "ops-step-no", text: `Step ${stepNo}/${OPS.list.length}` }),
    h("span", { class: "ops-caption-text", text: sel.title || "" }),
    sel.detail ? h("small", { text: sel.detail }) : null));

  tb.innerHTML = "";
  const running = OPS.list.filter((o) => o.status === "running").length;
  const errs = OPS.list.filter((o) => o.status === "error").length;
  tb.append(
    h("span", { class: "muted small", text: `共 ${OPS.list.length} 步` + (running ? ` · ${running} 步执行中` : "") + (errs ? ` · ${errs} 步失败` : "") }),
    h("span", { class: "spacer" }),
    h("button", {
      type: "button", class: "btn small ghost" + (OPS.follow ? " on" : ""), text: OPS.follow ? "● 跟随最新" : "○ 跟随最新",
      title: "开启后自动展示最新一步", onclick: () => { OPS.follow = !OPS.follow; if (OPS.follow) OPS.selected = OPS.list[OPS.list.length - 1]?.id; renderOps(); },
    }));

  tl.innerHTML = "";
  OPS.list.forEach((o, i) => {
    const ic = o.status === "running" ? h("span", { class: "spinner sm" }) : h("span", { class: "ops-st-ic " + o.status, text: o.status === "error" ? "✕" : "✓" });
    const row = h("div", { class: `ops-row ${o.status}` + (o.id === sel.id ? " active" : ""), role: "listitem", tabindex: "0", title: o.detail || o.title },
      h("span", { class: "ops-idx", text: String(i + 1) }),
      ic,
      h("div", { class: "ops-row-main" },
        h("div", { class: "ops-row-title" },
          h("span", { class: "ops-row-ic", text: o.icon || "🔌" }),
          o.action ? h("span", { class: "ops-act", text: OP_ACTION[o.action] || o.action }) : null,
          h("span", { class: "ops-row-text", text: o.title || o.system })),
        o.detail ? h("small", { class: "ops-row-detail", text: o.detail }) : null,
        o.fields && o.fields.length ? h("small", { class: "ops-row-fields", text: "字段：" + o.fields.join("、") }) : null),
      o.screenshot ? h("img", { class: "ops-thumb", src: opShot(o), alt: "", loading: "lazy" }) : null,
      o.duration != null ? h("span", { class: "ops-dur", text: `${o.duration}s` }) : null);
    const pick = () => { OPS.selected = o.id; OPS.follow = i === OPS.list.length - 1; renderOps(); };
    row.onclick = pick;
    row.onkeydown = (e) => { if (e.key === "Enter") pick(); };
    tl.appendChild(row);
  });
  if (OPS.follow) requestAnimationFrame(() => { tl.scrollTop = tl.scrollHeight; });
}

/* ==========================================================================
   🔍 审阅（Review / Diff / 全文预览 / 在线编辑保存）
   ========================================================================== */
export function setChanges(files = []) {
  P.changes.clear();
  P.reviewPath = null;
  P.editorDirty = false;
  upsertChanges(files, { silent: true });
  if (P.tab === "review") renderReviewTab();
}

export function upsertChanges(files = [], { silent = false } = {}) {
  for (const f of files || []) {
    if (!f || !f.path) continue;
    const prev = P.changes.get(f.path) || {};
    P.changes.set(f.path, {
      path: f.path,
      status: f.status || prev.status || "modified",
      added: f.added ?? prev.added ?? 0,
      removed: f.removed ?? prev.removed ?? 0,
      diff: f.diff || prev.diff || "",
      binary: f.binary ?? prev.binary ?? isBinaryPath(f.path),
      updated: f.updated || Date.now() / 1000,
    });
    addOutput(f.path);
  }
  updateReviewBadge();
  if (!P.reviewPath && P.changes.size) {
    P.reviewPath = [...P.changes.keys()][0];
  }
  if (!silent && P.tab === "review" && !P.editorDirty) {
    renderReviewTab();
  }
}

function updateReviewBadge() {
  const badge = $("#review-count");
  if (!badge) return;
  badge.hidden = !P.changes.size;
  badge.textContent = P.changes.size;
}

export function openReview(path, mode = "diff", extraFiles = null) {
  if (extraFiles && extraFiles.length) upsertChanges(extraFiles, { silent: true });
  if (path && !P.changes.has(path)) {
    P.changes.set(path, {
      path,
      status: "modified",
      added: 0,
      removed: 0,
      diff: "",
      binary: isBinaryPath(path),
      updated: Date.now() / 1000,
    });
    updateReviewBadge();
  }
  P.reviewPath = path || P.reviewPath || [...P.changes.keys()][0] || null;
  if (mode === "edit" && P.reviewPath && isBinaryPath(P.reviewPath)) mode = "preview";
  P.reviewMode = mode;
  P.editorDirty = false;
  bus.emit("panel:show");
  switchTab("review");
}

function renderReviewEmpty() {
  const bar = $("#review-files-bar"), tb = $("#review-toolbar"), body = $("#review-body");
  if (!bar || !body) return;
  bar.innerHTML = `<span class="muted small">会话变更文件（0）</span>`;
  tb.hidden = true;
  body.innerHTML = emptyState("🔍", "暂无文件变更", "智能体编写或修改文件后，点击对话中的「Review」或文件行即可在此对照 Diff 与在线编辑");
}

function renderReviewTab() {
  if (!P.changes.size && !P.reviewPath) {
    renderReviewEmpty();
    return;
  }
  if (!P.reviewPath || (!P.changes.has(P.reviewPath) && P.changes.size)) {
    P.reviewPath = [...P.changes.keys()][0];
  }
  renderReviewFilesBar();
  renderReviewToolbar();
  renderReviewBody();
}

function renderReviewFilesBar() {
  const bar = $("#review-files-bar");
  bar.innerHTML = "";
  const items = [...P.changes.values()];
  if (items.length > 5) {
    const sel = h("select", { class: "rf-pill", "aria-label": "快速切换变更文件" });
    items.forEach((f) => {
      const stat = f.binary ? " [BIN]" : ` (+${f.added || 0} -${f.removed || 0})`;
      const opt = h("option", { value: f.path, text: `${basename(f.path)}${stat}` });
      if (f.path === P.reviewPath) opt.selected = true;
      sel.appendChild(opt);
    });
    sel.onchange = () => selectReviewFile(sel.value);
    bar.appendChild(sel);
  }
  items.forEach((f) => {
    const ft = fileTypeBadge(f.path);
    const pill = h("button", {
      type: "button",
      class: "rf-pill" + (f.path === P.reviewPath ? " active" : ""),
      title: f.path,
      onclick: () => selectReviewFile(f.path),
    },
    h("span", { class: `ft-badge ${ft.cls}`, text: ft.text }),
    h("span", { text: basename(f.path) }),
    f.binary
      ? h("span", { class: "fc-stat-badge bin", text: "BIN" })
      : h("span", { class: "fc-stats" },
        h("span", { class: "diff-add", text: `+${f.added || 0}` }),
        h("span", { class: "diff-del", text: `-${f.removed || 0}` })));
    bar.appendChild(pill);
  });
}

async function selectReviewFile(path) {
  if (path === P.reviewPath) return;
  if (P.editorDirty) {
    const ok = await confirmDialog("当前文件有未保存的编辑内容，确定放弃并切换文件吗？", { okText: "放弃更改", danger: true });
    if (!ok) return;
    P.editorDirty = false;
  }
  P.reviewPath = path;
  if (P.reviewMode === "edit" && isBinaryPath(path)) P.reviewMode = "diff";
  renderReviewTab();
}

function renderReviewToolbar() {
  const tb = $("#review-toolbar");
  const path = P.reviewPath;
  if (!path) { tb.hidden = true; return; }
  tb.hidden = false;
  tb.innerHTML = "";
  const fc = P.changes.get(path);
  const binary = fc?.binary || isBinaryPath(path);
  const ft = fileTypeBadge(path);

  const left = h("div", { class: "rv-path", title: path },
    h("span", { class: `ft-badge ${ft.cls}`, text: ft.text }),
    h("span", { class: "p", text: path }));

  const modes = h("div", { class: "rv-modes", role: "tablist" });
  [
    ["diff", "Diff 对比", false],
    ["preview", "全文 / 预览", false],
    ["edit", "在线编辑", binary],
  ].forEach(([m, label, disabled]) => {
    const b = h("button", {
      type: "button",
      class: "rv-mode" + (P.reviewMode === m ? " active" : ""),
      text: label,
      disabled,
      title: disabled ? "二进制文件不支持纯文本编辑" : label,
      onclick: async () => {
        if (P.reviewMode === m) return;
        if (P.editorDirty && P.reviewMode === "edit") {
          const ok = await confirmDialog("放弃未保存的编辑内容？", { okText: "放弃", danger: true });
          if (!ok) return;
          P.editorDirty = false;
        }
        P.reviewMode = m;
        renderReviewToolbar();
        renderReviewBody();
      },
    });
    modes.appendChild(b);
  });

  const acts = h("div", { class: "ph-acts" },
    modes,
    h("button", {
      class: "icon-btn", type: "button", title: "附加到对话输入框", html: SVG.paperclip,
      onclick: () => { addAttachmentFn(path); toast("已附加到输入框", "success"); },
    }),
    h("a", { class: "icon-btn", href: fileUrl(path, 1), download: "", title: "下载文件", html: SVG.download }));

  tb.append(left, acts);
}

async function renderReviewBody() {
  const body = $("#review-body");
  const path = P.reviewPath;
  if (!path) return;
  const seq = ++P.reviewSeq;
  const fc = P.changes.get(path);
  const binary = fc?.binary || isBinaryPath(path);

  if (P.reviewMode === "diff") {
    if (fc?.diff) {
      body.innerHTML = renderUnifiedDiffHtml(fc.diff);
      return;
    }
    if (binary) {
      body.innerHTML = "";
      const banner = div("diff-banner", "📦 富格式 / 二进制文件 · 已自动切换渲染预览");
      const pvWrap = div("preview-body");
      body.append(banner, pvWrap);
      await renderPreviewInto(pvWrap, path, () => seq === P.reviewSeq);
      return;
    }
    body.innerHTML = spinner("正在加载文件对比…");
    try {
      const text = await fetchEditableText(path);
      if (seq !== P.reviewSeq) return;
      const lines = String(text).replace(/\r\n/g, "\n").split("\n");
      const synth = [`@@ -0,0 +1,${lines.length} @@`, ...lines.map((l) => "+" + l)].join("\n");
      body.innerHTML = renderUnifiedDiffHtml(synth);
    } catch (e) {
      if (seq === P.reviewSeq) body.innerHTML = emptyState("⚠️", "无法加载文件内容", e.message);
    }
    return;
  }

  if (P.reviewMode === "preview") {
    body.innerHTML = "";
    const pvWrap = div("preview-body");
    body.appendChild(pvWrap);
    await renderPreviewInto(pvWrap, path, () => seq === P.reviewSeq);
    return;
  }

  if (P.reviewMode === "edit") {
    body.innerHTML = spinner("正在读取源码…");
    try {
      const text = await fetchEditableText(path);
      if (seq !== P.reviewSeq) return;
      mountEditor(body, path, text);
    } catch (e) {
      if (seq === P.reviewSeq) body.innerHTML = emptyState("⚠️", "读取文件失败", e.message);
    }
  }
}

async function fetchEditableText(path) {
  const r = await api(`/api/preview?path=${encodeURIComponent(path)}`);
  const lower = path.toLowerCase();
  if (r.kind === "code" || (r.kind === "markdown" && (lower.endsWith(".md") || lower.endsWith(".mdx")))) {
    return r.content ?? "";
  }
  if (r.kind === "html" || r.kind === "table") {
    const raw = await api(`/api/file?path=${encodeURIComponent(path)}`);
    return typeof raw === "string" ? raw : JSON.stringify(raw, null, 2);
  }
  if (r.content != null && !isBinaryPath(path)) return r.content;
  throw new Error("该文件为二进制格式，不支持直接文本编辑");
}

function mountEditor(container, path, initialText) {
  container.innerHTML = "";
  let savedText = String(initialText ?? "");
  P.editorDirty = false;
  const modKey = IS_MAC ? "⌘S" : "Ctrl+S";

  const statusEl = h("span", { class: "editor-status", text: `UTF-8 · ${savedText.split("\n").length} 行 · 已同步` });
  const saveBtn = h("button", { class: "btn small primary", type: "button", text: `💾 保存 (${modKey})`, disabled: true });
  const bar = h("div", { class: "editor-bar" }, statusEl, saveBtn);

  const gutter = h("div", { class: "editor-gutter", "aria-hidden": "true" });
  const ta = h("textarea", { class: "code-editor-ta", spellcheck: "false", "aria-label": `编辑 ${path}` });
  ta.value = savedText;

  const updateGutter = () => {
    const n = ta.value.split("\n").length;
    let out = "";
    for (let i = 1; i <= n; i++) out += i + "\n";
    gutter.textContent = out;
    const dirty = ta.value !== savedText;
    P.editorDirty = dirty;
    saveBtn.disabled = !dirty;
    statusEl.className = "editor-status" + (dirty ? " dirty" : "");
    statusEl.textContent = dirty ? `● 未保存修改 · ${n} 行` : `✓ 已同步 · ${n} 行`;
  };
  updateGutter();

  ta.addEventListener("input", updateGutter);
  ta.addEventListener("scroll", () => { gutter.scrollTop = ta.scrollTop; });
  ta.addEventListener("keydown", (e) => {
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "s") {
      e.preventDefault();
      doSave();
      return;
    }
    if (e.key === "Tab") {
      e.preventDefault();
      const s = ta.selectionStart, end = ta.selectionEnd;
      ta.setRangeText("  ", s, end, "end");
      updateGutter();
    }
  });

  async function doSave() {
    if (saveBtn.disabled) return;
    saveBtn.disabled = true;
    statusEl.textContent = "正在保存…";
    try {
      await put("/api/file", { path, content: ta.value });
      savedText = ta.value;
      updateGutter();
      toast(`已保存 ${basename(path)}`, "success");
      bus.emit("files:changed");
    } catch (e) {
      saveBtn.disabled = false;
      toast("保存失败：" + e.message, "error");
      updateGutter();
    }
  }
  saveBtn.onclick = doSave;

  const wrap = h("div", { class: "editor-wrap" }, gutter, ta);
  container.append(bar, wrap);
  setTimeout(() => ta.focus(), 30);
}

/* ==========================================================================
   📋 计划
   ========================================================================== */
export function renderPlan(todos, { quiet = false } = {}) {
  const list = $("#plan-list");
  const bar = $("#plan-progress .bar");
  if (!todos || !todos.length) {
    list.innerHTML = emptyState("📋", "暂无计划", "智能体开始执行后，任务计划会实时显示在这里");
    bar.style.width = "0";
    $("#plan-stat").textContent = "任务计划";
    return;
  }
  const ic = { completed: "✓", in_progress: "", cancelled: "✕", pending: "" };
  list.innerHTML = todos.map((t, i) => `<div class="plan-item ${esc(t.status)}"><span class="ic">${t.status === "in_progress" ? '<span class="spinner sm"></span>' : ic[t.status] ?? ""}</span><span class="pi-num">${i + 1}.</span><span class="pi-text">${esc(t.content)}</span></div>`).join("");
  const done = todos.filter((t) => t.status === "completed").length;
  bar.style.width = `${(done / todos.length) * 100}%`;
  $("#plan-stat").textContent = `任务计划 · 已完成 ${done}/${todos.length}`;
  if (!quiet && (P.tab === "outputs" || P.tab === "plan")) {
    bus.emit("panel:show");
    switchTab("plan");
  }
}

/* ==========================================================================
   📦 产出
   ========================================================================== */
export function addOutput(p) {
  if (!p || P.outputs.has(p)) return;
  P.outputs.set(p, Date.now());
  renderOutputs();
}
export function resetOutputs() {
  P.outputs.clear();
  renderOutputs();
}
function renderOutputs() {
  const el = $("#outputs-list");
  const badge = $("#outputs-count");
  badge.hidden = !P.outputs.size;
  badge.textContent = P.outputs.size;
  if (!P.outputs.size) {
    el.innerHTML = emptyState("📦", "暂无产出", "本次对话生成或修改的文件会显示在这里");
    return;
  }
  el.innerHTML = "";
  [...P.outputs.keys()].reverse().forEach((p) => {
    const name = basename(p);
    const row = h("div", { class: "out", role: "button", tabindex: "0", title: p },
      h("span", { class: "out-ic", text: FILE_ICON(name) }),
      h("span", { class: "out-text" }, h("b", { text: name }), h("small", { text: p })),
      !isBinaryPath(p) ? h("button", {
        class: "icon-btn", type: "button", title: "在审阅器中编辑", text: "✏️",
        onclick: (e) => { e.stopPropagation(); openReview(p, "edit"); },
      }) : null,
      h("a", { class: "icon-btn", href: fileUrl(p, 1), download: "", title: "下载", "aria-label": `下载 ${name}`, text: "⬇", onclick: (e) => e.stopPropagation() }));
    row.onclick = () => preview(p);
    row.onkeydown = (e) => { if (e.key === "Enter") preview(p); };
    el.appendChild(row);
  });
}

/* ==========================================================================
   👁 预览
   ========================================================================== */
export async function preview(path) {
  P.previewPath = path;
  bus.emit("panel:show");
  switchTab("preview");
  const head = $("#preview-head"), body = $("#preview-body");
  const name = basename(path);
  head.innerHTML = "";
  head.append(
    h("div", { class: "ph-title", title: path }, h("span", { text: FILE_ICON(name) }), h("span", { class: "ph-name", text: path })),
    h("div", { class: "ph-acts" },
      !isBinaryPath(path) ? h("button", {
        class: "btn small ghost", type: "button", text: "✏️ 编辑", title: "打开在线代码编辑器",
        onclick: () => openReview(path, "edit"),
      }) : null,
      h("button", { class: "btn small ghost", type: "button", text: "📎 附加", title: "附加到任务", onclick: () => { addAttachmentFn(path); toast("已附加到输入框", "success"); } }),
      h("a", { class: "btn small ghost", href: fileUrl(path), target: "_blank", rel: "noopener", text: "↗ 新窗口" }),
      h("a", { class: "btn small", href: fileUrl(path, 1), download: "", text: "⬇ 下载" })));
  await renderPreviewInto(body, path, () => P.previewPath === path);
}

async function renderPreviewInto(body, path, isCurrent) {
  const name = basename(path);
  body.innerHTML = spinner("加载预览…");
  try {
    const r = await api(`/api/preview?path=${encodeURIComponent(path)}`);
    if (isCurrent && !isCurrent()) return;
    const ts = r.mtime ? `&t=${Math.floor(r.mtime)}` : `&t=${Date.now()}`;
    if (r.kind === "image") {
      body.innerHTML = "";
      const img = h("img", { src: fileUrl(path) + ts, alt: name, class: "pv-img" });
      img.onclick = () => lightbox(img.src);
      body.appendChild(img);
    } else if (r.kind === "html") {
      body.innerHTML = `<iframe class="pv-frame" sandbox="allow-scripts allow-popups allow-forms" src="${fileUrl(path)}${ts}" title="${esc(name)}"></iframe>`;
    } else if (r.kind === "pdf") {
      body.innerHTML = `<iframe class="pv-frame" src="${fileUrl(path)}${ts}" title="${esc(name)}"></iframe>`;
    } else if (r.kind === "markdown") {
      body.innerHTML = `<div class="md pv-md"></div>`;
      setMarkdown(body.firstChild, r.content || "");
    } else if (r.kind === "code") {
      const ext = name.split(".").pop().toLowerCase();
      body.innerHTML = `<pre class="pv-code"><code></code></pre>`;
      const code = body.querySelector("code");
      code.textContent = r.content || "";
      const lang = CODE_LANG[ext];
      if (lang && window.hljs && window.hljs.getLanguage(lang) && (r.content || "").length < 200000) {
        code.className = `language-${lang}`;
        try { window.hljs.highlightElement(code); } catch { /* ignore */ }
      }
    } else if (r.kind === "table") {
      const [hd, ...rows] = r.rows || [];
      body.innerHTML = `<div class="pv-meta">共 ${Math.max(0, (r.total || 0) - 1)} 行数据${r.total > 500 ? "（仅显示前 500 行）" : ""}</div>
        <div class="pv-table"><table><thead><tr>${(hd || []).map((c) => `<th>${esc(c)}</th>`).join("")}</tr></thead>
        <tbody>${rows.map((rw) => `<tr>${rw.map((c) => `<td>${esc(c)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;
    } else {
      body.innerHTML = emptyState("📦", "该文件类型暂不支持预览", `${fmtBytes(r.size)} · 可下载后用本地软件打开`);
      body.querySelector(".empty").appendChild(h("a", { class: "btn small primary", href: fileUrl(path, 1), download: "", text: "下载文件" }));
    }
  } catch (e) {
    if (!isCurrent || isCurrent()) body.innerHTML = emptyState("⚠️", "预览失败", e.message);
  }
}

/* ==========================================================================
   🗂 文件管理
   ========================================================================== */
export async function loadFiles(path = P.cwd) {
  const seq = ++P.loadSeq;
  const list = $("#fm-list");
  if (!P.filesLoaded) list.innerHTML = spinner("加载中…");
  try {
    const r = await api(`/api/files?path=${encodeURIComponent(path)}`);
    if (seq !== P.loadSeq) return;
    P.filesLoaded = true;
    P.cwd = r.path || ".";
    renderCrumbs();
    renderFileList(r.items || []);
  } catch (e) {
    if (seq !== P.loadSeq) return;
    if (path !== "." && (e.status === 400 || e.status === 404)) { P.cwd = "."; return loadFiles("."); }
    list.innerHTML = emptyState("⚠️", "加载失败", e.message);
  }
  loadStorage();
}

function renderCrumbs() {
  const nav = $("#fm-crumbs");
  nav.innerHTML = "";
  const parts = P.cwd === "." ? [] : P.cwd.split("/").filter(Boolean);
  const mk = (label, p, last) => {
    const b = h("button", { type: "button", class: "crumb" + (last ? " current" : ""), text: label });
    if (last) b.setAttribute("aria-current", "page"); else b.onclick = () => loadFiles(p);
    return b;
  };
  nav.appendChild(mk("🏠 工作区", ".", !parts.length));
  parts.forEach((name, i) => {
    nav.appendChild(h("span", { class: "crumb-sep", text: "/" }));
    nav.appendChild(mk(name, parts.slice(0, i + 1).join("/"), i === parts.length - 1));
  });
}

function renderFileList(items) {
  const list = $("#fm-list");
  list.innerHTML = "";
  if (P.cwd !== ".") {
    const up = h("div", { class: "fm-row up", role: "listitem", tabindex: "0" }, h("span", { class: "fm-ic", text: "↩" }), h("span", { class: "fm-name", text: "返回上一级" }));
    const parent = P.cwd.split("/").slice(0, -1).join("/") || ".";
    up.onclick = () => loadFiles(parent);
    up.onkeydown = (e) => { if (e.key === "Enter") loadFiles(parent); };
    list.appendChild(up);
  }
  if (!items.length) {
    list.appendChild(div("", emptyState("🗂", P.cwd === "." ? "工作区还是空的" : "空文件夹", "点击「上传」或把文件拖到这里")));
    return;
  }
  for (const it of items) {
    const more = h("button", { class: "icon-btn fm-more", type: "button", "aria-label": `${it.name} 的更多操作`, "aria-haspopup": "menu", text: "⋯" });
    const row = h("div", { class: "fm-row" + (it.is_dir ? " dir" : ""), role: "listitem", tabindex: "0", title: it.path },
      h("span", { class: "fm-ic", text: FILE_ICON(it.name, it.is_dir) }),
      h("span", { class: "fm-main" }, h("span", { class: "fm-name", text: it.name }),
        h("small", { class: "fm-meta", text: (it.is_dir ? "文件夹" : fmtBytes(it.size)) + " · " + fmtRelative(it.mtime) })),
      more);
    const open = () => (it.is_dir ? loadFiles(it.path) : preview(it.path));
    row.onclick = (e) => { if (!more.contains(e.target)) open(); };
    row.onkeydown = (e) => { if (e.key === "Enter" && e.target === row) open(); };
    more.onclick = (e) => { e.stopPropagation(); openMenu(more, fileMenu(it)); };
    row.oncontextmenu = (e) => { e.preventDefault(); openMenu(more, fileMenu(it)); };
    list.appendChild(row);
  }
}

function fileMenu(it) {
  return it.is_dir ? [
    { icon: "📂", label: "打开", onClick: () => loadFiles(it.path) },
    { icon: "🗜", label: "打包下载", onClick: () => download(`/api/files/zip?path=${encodeURIComponent(it.path)}`) },
    { icon: "✎", label: "重命名", onClick: () => rename(it) },
    { divider: true },
    { icon: "🗑", label: "删除", danger: true, onClick: () => remove(it) },
  ] : [
    { icon: "👁", label: "预览", onClick: () => preview(it.path) },
    { icon: "✏️", label: "在线编辑", hidden: isBinaryPath(it.path), onClick: () => openReview(it.path, "edit") },
    { icon: "🔍", label: "审阅对比", onClick: () => openReview(it.path, "diff") },
    { icon: "📎", label: "附加到任务", onClick: () => { addAttachmentFn(it.path); toast("已附加到输入框", "success"); } },
    { icon: "⬇", label: "下载", onClick: () => download(fileUrl(it.path, 1)) },
    { icon: "✎", label: "重命名", onClick: () => rename(it) },
    { divider: true },
    { icon: "🗑", label: "删除", danger: true, onClick: () => remove(it) },
  ];
}

async function rename(it) {
  const name = await promptDialog({ title: "重命名", label: "新名称", value: it.name });
  if (!name || name === it.name) return;
  try {
    await post("/api/files/rename", { path: it.path, new_name: name });
    toast("已重命名", "success");
    loadFiles();
  } catch (e) { toast(e.message, "error"); }
}
async function remove(it) {
  const ok = await confirmDialog(`确定删除${it.is_dir ? "文件夹" : "文件"}「${it.name}」吗？${it.is_dir ? "文件夹内的所有内容都会被删除，" : ""}此操作不可恢复。`, { title: "删除确认", okText: "删除", danger: true });
  if (!ok) return;
  try {
    await del(`/api/files?path=${encodeURIComponent(it.path)}`);
    toast("已删除", "success");
    S.attachments = S.attachments.filter((p) => p !== it.path && !p.startsWith(it.path + "/"));
    loadFiles();
  } catch (e) { toast(e.message, "error"); }
}
async function mkdir() {
  const name = await promptDialog({ title: "新建文件夹", label: "文件夹名称", placeholder: "例如：data" });
  if (!name) return;
  if (/[\\/]/.test(name)) { toast("名称不能包含 / 或 \\", "error"); return; }
  try {
    await post("/api/files/mkdir", { path: joinPath(P.cwd, name) });
    toast("文件夹已创建", "success");
    loadFiles();
  } catch (e) { toast(e.message, "error"); }
}
async function uploadHere(files) {
  files = [...(files || [])];
  if (!files.length) return;
  const st = $("#fm-storage");
  const prev = st.innerHTML;
  st.innerHTML = `<div class="loading"><span class="spinner sm"></span><span>上传中 <b>0%</b></span></div>`;
  try {
    const r = await upload(files, P.cwd, (p) => { const b = st.querySelector("b"); if (b) b.textContent = Math.round(p * 100) + "%"; });
    toast(`已上传 ${r.saved?.length || 0} 个文件`, "success");
  } catch (e) {
    toast(e.message, "error");
    st.innerHTML = prev;
  }
  loadFiles();
}
async function loadStorage() {
  try {
    const r = await api("/api/files/storage");
    const used = r.used_bytes || 0, quota = r.quota_bytes || 0;
    const pct = quota ? Math.min(100, (used / quota) * 100) : 0;
    $("#fm-storage").innerHTML = `<div class="storage-row"><span>存储空间</span><span>${fmtBytes(used)}${quota ? " / " + fmtBytes(quota) : "（不限）"}</span></div>
      ${quota ? `<div class="progress sm"><div class="bar${pct > 90 ? " danger" : pct > 75 ? " warn" : ""}" style="width:${pct}%"></div></div>` : ""}`;
  } catch { /* ignore */ }
}
