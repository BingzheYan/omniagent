/* 管理后台：概览 / 用户管理 / 系统设置 / 审计日志 */
import { S, bus } from "./state.js";
import { $, $$, esc, h, div, fmtK, fmtNum, fmtBytes, fmtDateTime, fmtRelative, initials, avatarColor, debounce } from "./util.js";
import { api, post, patch, put, del } from "./api.js";
import { toast, openMenu, formDialog, confirmDialog, promptDialog, spinner, emptyState } from "./ui.js";
import { barChart, fillDays } from "./charts.js";

const TABS = [
  { id: "dashboard", label: "概览", icon: "📊" },
  { id: "users", label: "用户管理", icon: "👥" },
  { id: "settings", label: "系统设置", icon: "⚙️" },
  { id: "audit", label: "审计日志", icon: "📜" },
];
let view, content, current = null;

function build() {
  view = $("#admin-view");
  view.innerHTML = "";
  const nav = h("nav", { class: "admin-nav", "aria-label": "管理后台导航" });
  TABS.forEach((t) => nav.appendChild(h("a", { class: "admin-tab", href: `#/admin/${t.id}`, "data-tab": t.id }, h("span", { text: t.icon }), h("span", { text: t.label }))));
  const head = h("header", { class: "admin-head" },
    h("a", { class: "btn ghost small", href: S.convId && S.convPersisted ? `#/c/${S.convId}` : "#/", id: "admin-back", text: "← 返回对话" }),
    h("div", { class: "admin-title" }, h("span", { class: "logo", text: "◆" }), h("span", { text: "管理后台" })),
    nav);
  content = h("div", { class: "admin-content", tabindex: "-1" });
  view.append(head, content);
}

export function show(tab = "dashboard") {
  if (!TABS.some((t) => t.id === tab)) tab = "dashboard";
  if (!view || !view.firstChild) build();
  $("#admin-back").href = S.convId && S.convPersisted ? `#/c/${S.convId}` : "#/";
  view.hidden = false;
  $("#app").hidden = true;
  document.title = "管理后台 · OmniAgent";
  $$(".admin-tab", view).forEach((a) => { const on = a.dataset.tab === tab; a.classList.toggle("active", on); if (on) a.setAttribute("aria-current", "page"); else a.removeAttribute("aria-current"); });
  current = tab;
  content.innerHTML = "";
  ({ dashboard, users, settings, audit })[tab](content);
}
export function hide() {
  if (!view || view.hidden) return false;
  view.hidden = true;
  $("#app").hidden = false;
  current = null;
  bus.emit("admin:hidden");
  return true;
}

const card = (label, value, sub, icon) => div("stat-card", `<div class="sc-label">${icon ? `<span>${icon}</span> ` : ""}${esc(label)}</div><div class="sc-value">${esc(value)}</div>${sub ? `<div class="sc-sub">${esc(sub)}</div>` : ""}`);
const panelBox = (title, extra) => {
  const p = div("admin-panel");
  const hd = h("div", { class: "ap-head" }, h("h3", { text: title }));
  if (extra) hd.appendChild(extra);
  p.appendChild(hd);
  return p;
};

/* ---------------- 概览 ---------------- */
async function dashboard(el) {
  el.innerHTML = spinner("加载中…");
  let s;
  try { s = await api("/api/admin/stats"); } catch (e) { el.innerHTML = emptyState("⚠️", "加载失败", e.message); return; }
  if (current !== "dashboard") return;
  el.innerHTML = "";
  const tk = s.tokens || {};
  const cards = div("stat-cards");
  cards.append(
    card("用户总数", fmtNum(s.users), `近 7 天活跃 ${fmtNum(s.active_users_7d)}`, "👥"),
    card("对话总数", fmtNum(s.conversations), s.tasks_total != null ? `累计任务 ${fmtNum(s.tasks_total)}` : "", "💬"),
    card("运行中任务", fmtNum(s.tasks_running), "", "⚡"),
    card("Token 消耗", fmtK((tk.input || 0) + (tk.output || 0)), `输入 ${fmtK(tk.input)} · 输出 ${fmtK(tk.output)}`, "🔢"));
  el.appendChild(cards);
  const daily = fillDays(s.daily, 30);
  const p1 = panelBox("每日 Token 用量（近 30 天）");
  p1.appendChild(div("", barChart(daily, {
    series: [{ key: "input_tokens", label: "输入", color: "var(--accent)" }, { key: "output_tokens", label: "输出", color: "var(--green)" }],
    extraTip: (d) => `任务：${d.tasks || 0}`,
  })));
  const p2 = panelBox("每日任务数（近 30 天）");
  p2.appendChild(div("", barChart(daily, { series: [{ key: "tasks", label: "任务数", color: "var(--yellow)" }], height: 160 })));
  el.append(p1, p2);
}

/* ---------------- 用户管理 ---------------- */
async function users(el) {
  const search = h("input", { type: "search", class: "input", placeholder: "搜索用户名 / 名称 / 邮箱", "aria-label": "搜索用户" });
  const add = h("button", { class: "btn primary small", type: "button", text: "＋ 新建用户", onclick: createUser });
  const tools = div("ap-tools");
  tools.append(search, add);
  const p = panelBox("用户管理", tools);
  const body = div("", spinner("加载中…"));
  p.appendChild(body);
  el.appendChild(p);
  let list = [];
  const render = () => {
    const q = search.value.trim().toLowerCase();
    const rows = list.filter((u) => !q || [u.username, u.display_name, u.email].some((x) => String(x || "").toLowerCase().includes(q)));
    if (!rows.length) { body.innerHTML = emptyState("👥", q ? "没有匹配的用户" : "暂无用户"); return; }
    const table = h("table", { class: "table users-table" });
    table.innerHTML = `<thead><tr><th>用户</th><th>角色</th><th>状态</th><th class="right">对话</th><th class="right">Token（入/出）</th><th class="right">存储</th><th class="right">月额度</th><th>最近登录</th><th></th></tr></thead>`;
    const tb = h("tbody");
    rows.forEach((u) => {
      const me = u.id === S.user.id;
      const tr = h("tr", { class: u.status !== "active" ? "disabled" : "" });
      tr.innerHTML = `<td><div class="user-cell"><span class="avatar sm" style="background:${avatarColor(u.username)}">${esc(initials(u.display_name || u.username))}</span>
          <div><b>${esc(u.display_name || u.username)}</b>${me ? ' <span class="badge-s info">我</span>' : ""}<div class="muted small">@${esc(u.username)}${u.email ? " · " + esc(u.email) : ""}</div></div></div></td>
        <td>${u.role === "admin" ? '<span class="badge-s accent">管理员</span>' : '<span class="badge-s muted">用户</span>'}</td>
        <td>${u.status === "active" ? '<span class="badge-s ok">正常</span>' : '<span class="badge-s danger">已禁用</span>'}</td>
        <td class="right mono">${fmtNum(u.conversations)}</td>
        <td class="right mono">${fmtK(u.input_tokens)} / ${fmtK(u.output_tokens)}</td>
        <td class="right mono">${fmtBytes(u.storage_bytes)}</td>
        <td class="right mono">${u.token_quota ? fmtK(u.token_quota) : "不限"}</td>
        <td class="nowrap" title="${esc(fmtDateTime(u.last_login))}">${u.last_login ? fmtRelative(u.last_login) : "从未"}</td>`;
      const td = h("td", { class: "right" });
      const more = h("button", { class: "icon-btn", type: "button", text: "⋯", "aria-label": `管理 ${u.username}`, "aria-haspopup": "menu" });
      more.onclick = () => openMenu(more, userMenu(u, me));
      td.appendChild(more);
      tr.appendChild(td);
      tb.appendChild(tr);
    });
    table.appendChild(tb);
    body.innerHTML = "";
    body.appendChild(div("table-wrap"));
    body.firstChild.appendChild(table);
  };
  search.addEventListener("input", debounce(render, 150));
  async function load() {
    try { list = await api("/api/admin/users"); if (current === "users") render(); } catch (e) { body.innerHTML = emptyState("⚠️", "加载失败", e.message); }
  }
  async function act(u, body, msg) {
    try { await patch(`/api/admin/users/${u.id}`, body); toast(msg, "success"); load(); } catch (e) { toast(e.message, "error"); }
  }
  function userMenu(u, me) {
    return [
      { header: `@${u.username}` },
      { icon: "🛡", label: u.role === "admin" ? "设为普通用户" : "设为管理员", disabled: me, onClick: async () => {
        if (await confirmDialog(`确定将「${u.username}」${u.role === "admin" ? "降为普通用户" : "设为管理员"}吗？`)) act(u, { role: u.role === "admin" ? "user" : "admin" }, "角色已更新");
      } },
      { icon: u.status === "active" ? "⛔" : "✅", label: u.status === "active" ? "禁用账号" : "启用账号", disabled: me, onClick: async () => {
        if (u.status === "active" && !(await confirmDialog(`禁用后「${u.username}」将立即被踢下线且无法登录，确定吗？`, { danger: true, okText: "禁用" }))) return;
        act(u, { status: u.status === "active" ? "disabled" : "active" }, u.status === "active" ? "账号已禁用" : "账号已启用");
      } },
      { icon: "🔑", label: "重置密码", onClick: async () => {
        const pw = await promptDialog({ title: `重置「${u.username}」的密码`, label: "新密码", type: "text", value: randomPassword(), hint: "至少 8 位。重置后该用户的所有登录将失效，请把新密码安全地告知对方。" });
        if (pw) act(u, { password: pw }, "密码已重置");
      } },
      { icon: "🔢", label: "设置 Token 额度", onClick: async () => {
        const r = await formDialog({ title: `设置「${u.username}」的每月 Token 额度`, okText: "保存", fields: [{ name: "q", label: "每月 Token 额度", type: "number", min: 0, value: u.token_quota || "", placeholder: "留空或 0 表示不限", hint: "按自然月统计输入 + 输出 Token，超出后无法发起新任务" }] });
        if (r) act(u, { token_quota: r.q ? Math.floor(r.q) : null }, "额度已更新");
      } },
      { divider: true },
      { icon: "🗑", label: "删除用户", danger: true, disabled: me, onClick: async () => {
        const v = await promptDialog({ title: "删除用户", label: `此操作会永久删除「${u.username}」及其所有对话和文件。请输入用户名确认：`, placeholder: u.username });
        if (v == null) return;
        if (v !== u.username) { toast("用户名不匹配，已取消", "warn"); return; }
        try { await del(`/api/admin/users/${u.id}`); toast("用户已删除", "success"); load(); } catch (e) { toast(e.message, "error"); }
      } },
    ];
  }
  async function createUser() {
    const r = await formDialog({
      title: "新建用户", okText: "创建",
      fields: [
        { name: "username", label: "用户名", required: true, placeholder: "3-32 位字母、数字、中文或 _ . -" },
        { name: "display_name", label: "显示名称", placeholder: "可选" },
        { name: "email", label: "邮箱", type: "email", placeholder: "可选" },
        { name: "password", label: "初始密码", required: true, value: randomPassword(), hint: "至少 8 位，请告知用户登录后自行修改" },
        { name: "role", label: "角色", type: "select", value: "user", options: [{ value: "user", label: "普通用户" }, { value: "admin", label: "管理员" }] },
      ],
      onSubmit: (v) => post("/api/admin/users", v),
    });
    if (r) { toast(`用户「${r.username}」已创建`, "success"); load(); }
  }
  load();
}
function randomPassword() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789";
  const a = new Uint32Array(12);
  crypto.getRandomValues(a);
  return [...a].map((x) => chars[x % chars.length]).join("");
}

/* ---------------- 系统设置 ---------------- */
async function settings(el) {
  el.innerHTML = spinner("加载中…");
  let st;
  try { st = await api("/api/admin/settings"); } catch (e) { el.innerHTML = emptyState("⚠️", "加载失败", e.message); return; }
  if (current !== "settings") return;
  el.innerHTML = "";
  const p = panelBox("系统设置");
  const form = h("form", { class: "form admin-form" });
  const reg = h("input", { type: "checkbox", id: "as-reg" });
  reg.checked = !!st.allow_registration;
  const invite = h("input", { id: "as-invite", value: st.invite_code || "", placeholder: "留空表示无需邀请码" });
  const gen = h("button", { type: "button", class: "btn small ghost", text: "随机生成", onclick: () => { invite.value = randomPassword().slice(0, 8); } });
  const conc = h("input", { id: "as-conc", type: "number", min: "0", value: st.max_concurrent_tasks_per_user ?? 2 });
  const quota = h("input", { id: "as-quota", type: "number", min: "0", value: st.storage_quota_mb ?? 0 });
  const all = st.all_models || [];
  const dm = h("select", { id: "as-dm" }, h("option", { value: "", text: "自动选择" }), ...all.map((m) => h("option", { value: m.name, text: `${m.name} · ${m.model}${m.available ? "" : "（未配置 Key）"}` })));
  dm.value = st.default_model || "";
  const enabled = new Set(st.enabled_models || []);
  const allOn = !enabled.size;
  const modelsBox = div("model-checks");
  all.forEach((m) => {
    const cb = h("input", { type: "checkbox", value: m.name, id: `as-m-${m.name}` });
    cb.checked = allOn || enabled.has(m.name);
    modelsBox.appendChild(h("label", { class: "model-check", for: cb.id }, cb, h("span", {}, h("b", { text: m.name }), h("small", { class: "muted", text: ` ${m.model}` })),
      m.available ? h("span", { class: "badge-s ok", text: "可用" }) : h("span", { class: "badge-s muted", text: "无系统 Key" })));
  });
  const row = (label, input, hint, extra) => h("div", { class: "field" }, h("label", { for: input.id, text: label }), extra ? h("div", { class: "input-row" }, input, extra) : input, hint ? h("div", { class: "hint", text: hint }) : null);
  const s1 = div("set-section");
  s1.append(h("h4", { text: "注册与访问" }),
    h("label", { class: "field check", for: "as-reg" }, reg, h("span", { text: "允许新用户公开注册" })),
    row("邀请码", invite, "设置后，注册时必须填写该邀请码", gen));
  const s2 = div("set-section");
  s2.append(h("h4", { text: "资源限制" }), div("grid-2"));
  s2.lastChild.append(row("每用户最大并发任务数", conc, "0 表示不限制"), row("每用户存储配额（MB）", quota, "0 表示不限制"));
  const s3 = div("set-section");
  s3.append(h("h4", { text: "模型" }), row("系统默认模型", dm, "用户未设置默认模型时使用"),
    h("div", { class: "field" }, h("label", { text: "启用的模型" }), modelsBox, h("div", { class: "hint", text: "取消勾选可对所有用户隐藏该模型；全部勾选等同于不限制" })));
  const save = h("button", { class: "btn primary", type: "submit", text: "保存设置" });
  const act = div("set-actions sticky");
  act.appendChild(save);
  form.append(s1, s2, s3, act);
  form.onsubmit = async (e) => {
    e.preventDefault();
    const checked = $$("input[type=checkbox]", modelsBox).filter((c) => c.checked).map((c) => c.value);
    if (all.length && !checked.length) { toast("至少需要启用一个模型", "warn"); return; }
    save.disabled = true;
    try {
      await put("/api/admin/settings", {
        allow_registration: reg.checked, invite_code: invite.value.trim(),
        max_concurrent_tasks_per_user: Number(conc.value) || 0, storage_quota_mb: Number(quota.value) || 0,
        default_model: dm.value, enabled_models: checked.length === all.length ? [] : checked,
      });
      toast("系统设置已保存", "success");
      bus.emit("config:reload");
    } catch (err) { toast(err.message, "error"); }
    save.disabled = false;
  };
  p.appendChild(form);
  el.appendChild(p);
}

/* ---------------- 审计日志 ---------------- */
const ACTION_LABEL = {
  login: "登录", login_failed: "登录失败", logout: "退出登录", register: "注册", password_change: "修改密码",
  api_key_set: "设置密钥", user_create: "创建用户", user_update: "修改用户", user_delete: "删除用户", settings_update: "修改系统设置",
  share: "分享对话", conversation_delete: "删除对话",
};
async function audit(el) {
  const search = h("input", { type: "search", class: "input", placeholder: "筛选用户 / 操作 / 详情 / IP", "aria-label": "筛选日志" });
  const refresh = h("button", { class: "btn small ghost", type: "button", text: "⟳ 刷新" });
  const tools = div("ap-tools");
  tools.append(search, refresh);
  const p = panelBox("审计日志", tools);
  const body = div("", spinner("加载中…"));
  p.appendChild(body);
  el.appendChild(p);
  let list = [];
  const render = () => {
    const q = search.value.trim().toLowerCase();
    const rows = list.filter((r) => !q || [r.username, r.action, ACTION_LABEL[r.action], r.detail, r.ip].some((x) => String(x || "").toLowerCase().includes(q)));
    if (!rows.length) { body.innerHTML = emptyState("📜", "没有日志记录"); return; }
    body.innerHTML = `<div class="table-wrap"><table class="table"><thead><tr><th>时间</th><th>用户</th><th>操作</th><th>详情</th><th>IP</th></tr></thead><tbody>
      ${rows.map((r) => `<tr class="${r.action === "login_failed" ? "warn-row" : ""}"><td class="nowrap mono small">${fmtDateTime(r.ts)}</td><td>${esc(r.username || "—")}</td>
      <td><span class="badge-s ${/fail|delete/.test(r.action) ? "danger" : /create|register/.test(r.action) ? "ok" : "muted"}">${esc(ACTION_LABEL[r.action] || r.action)}</span></td>
      <td class="detail">${esc(r.detail || "")}</td><td class="mono small">${esc(r.ip || "")}</td></tr>`).join("")}</tbody></table></div>`;
  };
  async function load() {
    try { list = await api("/api/admin/audit?limit=500"); if (current === "audit") render(); } catch (e) { body.innerHTML = emptyState("⚠️", "加载失败", e.message); }
  }
  search.addEventListener("input", debounce(render, 150));
  refresh.onclick = load;
  load();
}
