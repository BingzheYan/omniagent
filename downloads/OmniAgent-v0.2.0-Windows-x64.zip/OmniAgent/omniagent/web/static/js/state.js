/* 全局状态与事件总线 */
export const S = {
  user: null,          // 当前用户
  config: null,        // /api/config (含 models, agents, connectors)
  settings: {},        // 用户偏好
  convId: null,        // 当前对话 ID
  convTitle: "",
  convPersisted: false,
  routed: false,
  running: false,
  attachments: [],
  booted: false,
};

const handlers = {};
export const bus = {
  on(ev, fn) { (handlers[ev] ||= []).push(fn); },
  emit(ev, ...args) {
    for (const fn of handlers[ev] || []) {
      try { fn(...args); } catch (e) { console.error(`[bus:${ev}]`, e); }
    }
  },
};

export const isMobile = () => window.matchMedia("(max-width: 900px)").matches;

/* ---------------- 主题（默认深色 Claude Code / Codex 风格） ---------------- */
const mq = window.matchMedia("(prefers-color-scheme: dark)");
let themePref = localStorage.getItem("omni_theme") || "dark";

export const hasSavedTheme = () => {
  try { return !!localStorage.getItem("omni_theme"); } catch { return false; }
};

export function isDarkTheme(pref = themePref) {
  return pref === "dark" || (pref === "system" && mq.matches);
}

export function applyTheme(pref, { persist = true } = {}) {
  if (pref) themePref = pref;
  if (persist) {
    try { localStorage.setItem("omni_theme", themePref); } catch { /* ignore */ }
  }
  const dark = isDarkTheme(themePref);
  document.documentElement.dataset.theme = dark ? "dark" : "light";
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.content = dark ? "#0d1117" : "#ffffff";
  bus.emit("theme:changed", dark ? "dark" : "light", themePref);
}

export function toggleTheme() {
  const next = isDarkTheme() ? "light" : "dark";
  applyTheme(next, { persist: true });
  return next;
}

export const getThemePref = () => themePref;
mq.addEventListener?.("change", () => { if (themePref === "system") applyTheme("system", { persist: false }); });
