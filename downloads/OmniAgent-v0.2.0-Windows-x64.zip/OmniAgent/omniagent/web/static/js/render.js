/* 对话渲染（主工作台与分享页共用）：思维链轨迹、子智能体点阵行、工具卡片、文件变更摘要卡、历史回放 */
import {
  esc, div, h, fileUrl, ICONS, TOOL_LABELS, FILE_ICON, fileTypeBadge,
  isBinaryPath, basename, shortDir, copyText, renderUnifiedDiffHtml,
} from "./util.js";
import { renderMarkdown, enhance, setMarkdown } from "./markdown.js";
import { SVG } from "./icons.js";

const TOOL_SVG = {
  read_file: SVG.fileText, write_file: SVG.fileText, edit_file: SVG.edit,
  list_dir: SVG.folder, glob: SVG.search, grep: SVG.search,
  run_shell: SVG.terminal, process: SVG.cpu, python: SVG.code,
  create_document: SVG.fileText, create_presentation: SVG.slides, edit_presentation: SVG.slides,
  create_spreadsheet: SVG.chart, pdf_ops: SVG.fileText,
  web_fetch: SVG.globe, web_search: SVG.globe, browser_inspect: SVG.globe, browser_session: SVG.globe,
  desktop_inspect: SVG.cpu, desktop_action: SVG.cpu,
  load_skill: SVG.sparkles, view_image: SVG.eye, check_document: SVG.shield, verify_deliverable: SVG.shield,
  list_connectors: SVG.plug, connector_query: SVG.plug, connector_manage: SVG.plug,
  email_ops: SVG.mail, calendar_ops: SVG.calendar, tracker_manage: SVG.radar,
  memory_upsert: SVG.brain, memory_search: SVG.brain, memory_delete: SVG.brain,
  portrait_update: SVG.userCard, project_memory: SVG.brain,
  todo_write: SVG.plan, ask_user: SVG.thought, delegate_task: SVG.agents, delegate_parallel: SVG.agents,
};

export const ATTACH_MARK = "[用户上传/附带的文件]";
const DOC_GEN_TOOLS = new Set(["create_document", "create_presentation", "create_spreadsheet"]);

/** 拆出服务器拼接在用户消息后面的附件列表 */
export function splitAttachments(content) {
  content = String(content ?? "");
  const i = content.indexOf(ATTACH_MARK);
  if (i < 0) return { text: content, files: [] };
  const files = content.slice(i + ATTACH_MARK.length).split("\n").map((s) => s.replace(/^\s*-\s*/, "").trim()).filter(Boolean);
  return { text: content.slice(0, i).trimEnd(), files };
}

export function actionBtn(icon, label, onClick) {
  const b = h("button", { class: "act", type: "button", title: label, "aria-label": label }, h("span", { text: icon }));
  b.onclick = onClick;
  return b;
}

export function copyAction(getText) {
  const b = actionBtn("⧉", "复制", async () => {
    const ok = await copyText(getText());
    b.firstChild.textContent = ok ? "✓" : "✕";
    b.classList.add("done");
    setTimeout(() => { b.firstChild.textContent = "⧉"; b.classList.remove("done"); }, 1400);
  });
  return b;
}

/** 用户消息 */
export function userMsgEl(text, files = [], opts = {}) {
  const m = div("msg user");
  m._raw = text;
  const bubble = div("bubble");
  bubble.textContent = text;
  m.appendChild(bubble);
  if (files.length) {
    const fl = div("msg-files");
    files.forEach((p) => {
      const c = h("button", { class: "file-chip", type: "button", title: p }, h("span", { text: FILE_ICON(p) }), h("span", { text: basename(p) }));
      if (opts.onPreview) c.onclick = () => opts.onPreview(p);
      else if (opts.onFile) c.onclick = () => opts.onFile(p);
      else c.disabled = true;
      fl.appendChild(c);
    });
    m.appendChild(fl);
  }
  const acts = div("msg-actions");
  acts.appendChild(copyAction(() => m._raw));
  m.appendChild(acts);
  return m;
}

/** 助手消息（md 容器 + 操作栏） */
export function assistantMsgEl(content = "", { streaming = false } = {}) {
  const m = div("msg assistant");
  const body = div("md" + (streaming ? " cursor" : ""));
  m._raw = content;
  if (content) setMarkdown(body, content);
  m.appendChild(body);
  const acts = div("msg-actions");
  acts.appendChild(copyAction(() => m._raw));
  m.appendChild(acts);
  m._md = body;
  return m;
}

export function summarizeArgs(name, a = {}) {
  if (!a || typeof a !== "object") return "";
  if (name === "connector_query") {
    return [a.connector, a.action || a.method, a.endpoint || a.sql || a.subpath || a.tool_name].filter(Boolean).join(" · ");
  }
  if (name === "delegate_parallel" && Array.isArray(a.tasks)) {
    return `${a.tasks.length} 个并行子智能体 (${a.tasks.map((t) => t.role || t.agent_type || "子任务").join(", ")})`;
  }
  if (name === "delegate_task") {
    return [a.agent_type, a.role, a.task ? String(a.task).slice(0, 60) : ""].filter(Boolean).join(" · ");
  }
  if (name === "load_skill") return a.name || a.skill || "";
  if (name === "desktop_inspect") return a.action || "";
  return a.path || a.command || a.output_path || a.pattern || a.url || a.query || a.role || (a.code ? String(a.code).split("\n")[0] : "");
}

/** 工具卡片 */
export function toolCardEl(id, name, args = {}, summary = "") {
  const el = document.createElement("details");
  el.className = "tool";
  el.dataset.id = id || "";
  el.dataset.name = name;
  el.innerHTML = `<summary><span class="tool-ic">${TOOL_SVG[name] || SVG.cpu}</span><span class="name">${esc(TOOL_LABELS[name] || name)}</span>`
    + `<span class="sum">${esc(summary || summarizeArgs(name, args))}</span><span class="dur"></span>`
    + `<span class="st"><span class="spinner sm"></span></span><span class="chev">›</span></summary><div class="body"></div>`;
  const body = el.querySelector(".body");
  const code = args.code || args.command;
  if (code) body.appendChild(div("", `<div class="label">${name === "python" ? "Python 代码" : "Shell 命令"}</div><pre class="code">${esc(code)}</pre>`));
  else if (Object.keys(args).length) {
    const shown = { ...args };
    for (const k of ["content", "markdown", "new_string", "old_string"]) {
      if (typeof shown[k] === "string" && shown[k].length > 1500) shown[k] = shown[k].slice(0, 1500) + "…";
    }
    body.appendChild(div("", `<div class="label">调用参数</div><pre>${esc(JSON.stringify(shown, null, 2))}</pre>`));
  }
  return el;
}

/** 文件产物卡片（生成文档等） */
export function fileCardEl(path, { onPreview, onReview, shareMode } = {}) {
  const name = basename(path);
  const card = div("file-card");
  card.innerHTML = `<span class="fc-ic">${FILE_ICON(name)}</span><span class="fc-text"><b>${esc(name)}</b><small>${esc(path)}</small></span>`;
  if (!shareMode) {
    const acts = div("fc-acts");
    if (onReview) acts.appendChild(h("button", { class: "btn small ghost", type: "button", text: "审阅", onclick: () => onReview(path, "preview") }));
    else if (onPreview) acts.appendChild(h("button", { class: "btn small ghost", type: "button", text: "预览", onclick: () => onPreview(path) }));
    acts.appendChild(h("a", { class: "btn small", href: fileUrl(path, 1), download: "", text: "下载" }));
    card.appendChild(acts);
  }
  return card;
}

/** 填充工具执行结果 */
export function fillToolResult(el, name, content, isError, data, duration, opts = {}) {
  const st = el.querySelector(".st");
  st.className = "st " + (isError ? "err" : "ok");
  st.textContent = isError ? "✗" : "✓";
  el.classList.toggle("is-error", !!isError);
  if (duration != null) el.querySelector(".dur").textContent = duration + "s";
  const body = el.querySelector(".body");
  data = data || {};
  if (data.diff) {
    const lines = String(data.diff).split("\n").map((l) => {
      const c = l.startsWith("@@") ? "hunk" : l.startsWith("+") && !l.startsWith("+++") ? "add" : l.startsWith("-") && !l.startsWith("---") ? "del" : "";
      return `<span class="${c}">${esc(l) || " "}</span>`;
    }).join("");
    body.appendChild(div("", `<div class="label">变更 Diff</div><pre class="diff">${lines}</pre>`));
  } else if (content != null && content !== "") {
    body.appendChild(div("", `<div class="label">${isError ? "错误输出" : "执行结果"}</div><pre class="out">${esc(content)}</pre>`));
  }
  const imgs = [...(data.images || []), ...(data.image ? [data.image] : [])];
  imgs.forEach((p) => {
    if (!opts.shareMode) {
      const img = h("img", { src: fileUrl(p), alt: basename(p), loading: "lazy" });
      img.onerror = () => img.remove();
      if (opts.onImage) img.onclick = () => opts.onImage(img.src);
      body.appendChild(img);
    }
    if (opts.onFile) opts.onFile(p);
  });
  if (imgs.length && !opts.collapse && !opts.shareMode) el.open = true;
  if (isError) el.open = false;
  if (data.path && !isError) {
    if (opts.onFile) opts.onFile(data.path);
    if (DOC_GEN_TOOLS.has(name) && !el.nextElementSibling?.classList?.contains("file-card")) {
      el.after(fileCardEl(data.path, opts));
    }
  }
}

/* ==========================================================================
   Subagent 点阵行（Image 2 风格：Started ∷ <role> / Completed ∷ <role> · 1.2s ›）
   ========================================================================== */
export function subagentRowEl({ subagent_id, agent_type, icon, role, task, elapsed, report, running = true } = {}) {
  const el = document.createElement("details");
  el.className = `subagent-row ${running ? "running" : "done"}`;
  if (subagent_id) el.dataset.subId = subagent_id;
  const dots = `<span class="dot-matrix" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i><i></i></span>`;
  el.innerHTML = `<summary>${dots}`
    + `<span class="sub-verb">${running ? "Started" : "Completed"}</span>`
    + `<span class="sub-sep">∷</span>`
    + `<span class="sub-role">${esc(role || "专业子智能体")}</span>`
    + `<span class="sub-type-pill">${esc(agent_type || "subagent")}</span>`
    + `<span class="sub-elapsed">${elapsed != null ? `· ${elapsed}s` : ""}</span>`
    + `<span class="chev">›</span></summary>`
    + `<div class="sub-detail">`
    + (task ? `<div><div class="sub-sec-label">委派任务</div><div class="sub-task-box">${esc(task)}</div></div>` : "")
    + `<div class="sub-steps"></div>`
    + `<div class="sub-report-slot"></div>`
    + `</div>`;
  if (!running && report) {
    fillSubagentReport(el, report);
  }
  return el;
}

function fillSubagentReport(el, report) {
  const slot = el.querySelector(".sub-report-slot");
  if (!slot || !report) return;
  slot.innerHTML = `<div class="sub-sec-label">子智能体结论报告</div><div class="sub-report-box md"></div>`;
  setMarkdown(slot.querySelector(".md"), report);
}

export function completeSubagentRow(el, { elapsed, report } = {}) {
  if (!el) return;
  el.classList.remove("running");
  el.classList.add("done");
  const verb = el.querySelector(".sub-verb");
  if (verb) verb.textContent = "Completed";
  const elp = el.querySelector(".sub-elapsed");
  if (elp && elapsed != null) elp.textContent = `· ${elapsed}s`;
  if (report) fillSubagentReport(el, report);
}

/* ==========================================================================
   Activity & Chain-of-Thought Trace（思维链 + 可折叠步骤轨迹）
   ========================================================================== */
export function summarizeTraceActions(toolNames = [], subCount = 0, changeCount = 0, thinkCount = 0) {
  const counts = {};
  for (const n of toolNames) counts[n] = (counts[n] || 0) + 1;
  const parts = [];
  if (counts.list_dir || counts.glob) parts.push("浏览目录");
  if (counts.grep) parts.push("搜索代码");
  if (counts.read_file) parts.push(`读取 ${counts.read_file} 次文件`);
  if (counts.list_connectors || counts.connector_query || counts.connector_manage) parts.push("连接外部系统");
  if (counts.email_ops) parts.push("处理邮件");
  if (counts.calendar_ops) parts.push("排定日程");
  if (counts.browser_session) parts.push("交互填表投递");
  if (counts.tracker_manage) parts.push("追踪外部动态");
  if (counts.web_fetch || counts.web_search || counts.browser_inspect) parts.push("检索网页");
  if (counts.desktop_inspect || counts.desktop_action) parts.push("协同桌面应用");
  if (counts.load_skill) parts.push("加载专业技能");
  if (counts.memory_search) parts.push("检索长期记忆");
  if (counts.memory_upsert || counts.portrait_update || counts.project_memory) parts.push("更新记忆与画像");
  if (counts.python) parts.push("运行 Python 分析");
  if (counts.run_shell || counts.process) parts.push("执行终端命令");
  const writeOps = (counts.write_file || 0) + (counts.edit_file || 0) + (counts.create_document || 0)
    + (counts.create_spreadsheet || 0) + (counts.create_presentation || 0) + (counts.edit_presentation || 0) + (counts.pdf_ops || 0);
  if (changeCount > 0) parts.push(`编写与修改 ${changeCount} 个文件`);
  else if (writeOps > 0) parts.push(`编辑文件 ${writeOps} 次`);
  if (subCount > 0 || counts.delegate_task || counts.delegate_parallel) {
    parts.push(`协同 ${subCount || (counts.delegate_task || 0) + (counts.delegate_parallel || 0)} 个子智能体`);
  }
  if (counts.check_document || counts.view_image || counts.verify_deliverable) parts.push("实测与质量验收");
  if (!parts.length) return thinkCount > 0 ? "深度推理与规划" : "分析任务";
  return parts.slice(0, 4).join("、");
}

export function createTurnTrace({ running = true, open = true } = {}) {
  const wrap = div(`turn-trace${running ? " running" : ""}${open ? " open" : ""}`);
  wrap._state = {
    running,
    steps: 0,
    toolNames: [],
    subCount: 0,
    changeCount: 0,
    cotList: [], // [{step, text}]
  };
  const head = h("button", { type: "button", class: "trace-head", "aria-expanded": String(open) },
    h("span", { class: "trace-ic", html: running ? `<span class="spinner sm"></span>` : "✓" }),
    h("span", { class: "trace-title", text: running ? "正在思考与执行…" : "思考与执行轨迹" }),
    h("span", { class: "trace-meta" }),
    h("span", { class: "trace-chev", text: "›" }));

  const cotDrawer = document.createElement("details");
  cotDrawer.className = "cot-drawer";
  cotDrawer.hidden = true;
  cotDrawer.innerHTML = `<summary><span class="cot-label">💭 思维链</span><span class="chev">›</span></summary><div class="cot-steps"></div>`;

  const body = div("trace-body");
  const collapseInner = div("trace-collapse-inner");
  collapseInner.append(cotDrawer, body);
  const collapseShell = h("div", { class: "trace-collapse-shell" }, collapseInner);
  head.onclick = () => {
    const isOpen = wrap.classList.toggle("open");
    wrap._userToggled = true;
    head.setAttribute("aria-expanded", String(isOpen));
  };
  wrap.append(head, collapseShell);
  wrap._head = head;
  wrap._cot = cotDrawer;
  wrap._body = body;
  return wrap;
}

export function addTraceThinking(traceEl, text, stepNum) {
  const clean = String(text || "").trim();
  if (!traceEl || !clean) return;
  const st = traceEl._state;
  const step = stepNum || st.cotList.length + 1;
  st.cotList.push({ step, text: clean });
  renderCotDrawer(traceEl);
  refreshTraceHeader(traceEl);
}

function renderCotDrawer(traceEl) {
  const st = traceEl._state;
  const drawer = traceEl._cot;
  if (!st.cotList.length) {
    drawer.hidden = true;
    return;
  }
  drawer.hidden = false;
  const totalChars = st.cotList.reduce((s, x) => s + x.text.length, 0);
  drawer.querySelector(".cot-label").textContent = `💭 思维链（${st.cotList.length} 步推理 · ${totalChars} 字）`;
  const box = drawer.querySelector(".cot-steps");
  box.innerHTML = "";
  st.cotList.forEach((item) => {
    box.appendChild(div("cot-step-item", `<span class="cot-step-tag">Step ${item.step}</span>${esc(item.text)}`));
  });
}

export function refreshTraceHeader(traceEl) {
  if (!traceEl) return;
  const st = traceEl._state;
  const ic = traceEl.querySelector(".trace-ic");
  const title = traceEl.querySelector(".trace-title");
  const meta = traceEl.querySelector(".trace-meta");
  const actionSum = summarizeTraceActions(st.toolNames, st.subCount, st.changeCount, st.cotList.length);
  const stepCount = Math.max(st.steps, st.cotList.length, st.toolNames.length ? 1 : 0);

  if (st.running) {
    ic.innerHTML = `<span class="spinner sm"></span>`;
    title.textContent = `正在思考与执行…（${actionSum}）`;
  } else {
    ic.textContent = "✓";
    title.textContent = `${actionSum} · 思考与执行轨迹${stepCount ? `（${stepCount} 步）` : ""}`;
  }
  const metaParts = [];
  if (st.toolNames.length) metaParts.push(`${st.toolNames.length} 次工具`);
  if (st.cotList.length) metaParts.push(`💭 ${st.cotList.length} 步推理`);
  meta.textContent = metaParts.join(" · ");
}

export function finalizeTurnTrace(traceEl, { collapse = false, steps } = {}) {
  if (!traceEl) return;
  traceEl._state.running = false;
  if (steps != null) traceEl._state.steps = Math.max(traceEl._state.steps, steps);
  traceEl.classList.remove("running");
  if (collapse && !traceEl._userToggled) {
    traceEl.classList.remove("open");
    traceEl._head.setAttribute("aria-expanded", "false");
  }
  refreshTraceHeader(traceEl);
}

/* ==========================================================================
   In-Chat File Changes Summary Card（Image 1 风格）
   ========================================================================== */
export function normalizeTurnChanges(files = []) {
  const map = new Map();
  for (const f of files || []) {
    if (!f || !f.path) continue;
    const prev = map.get(f.path) || {};
    map.set(f.path, {
      path: f.path,
      status: f.status || prev.status || "modified",
      added: f.added ?? prev.added ?? 0,
      removed: f.removed ?? prev.removed ?? 0,
      diff: f.diff || prev.diff || "",
      binary: f.binary ?? prev.binary ?? (!f.diff && !f.added && !f.removed && isBinaryPath(f.path)),
    });
  }
  return [...map.values()];
}

export function fileChangesCardEl(rawFiles = [], opts = {}) {
  const files = normalizeTurnChanges(rawFiles);
  const card = div("fc-summary-card spotlight-card" + (files.length > 12 ? " collapsed" : ""));
  updateFileChangesCard(card, files, opts);
  return card;
}

export function updateFileChangesCard(card, rawFiles = [], opts = {}) {
  const files = normalizeTurnChanges(rawFiles);
  card._files = files;
  const wasCollapsed = card.classList.contains("collapsed") && card._userToggled;
  if (!card._userToggled) card.classList.toggle("collapsed", files.length > 12);
  else card.classList.toggle("collapsed", wasCollapsed);

  const totalAdded = files.reduce((s, f) => s + (Number(f.added) || 0), 0);
  const totalRemoved = files.reduce((s, f) => s + (Number(f.removed) || 0), 0);

  card.innerHTML = "";
  const toggleBtn = h("button", {
    type: "button",
    class: "fc-sum-toggle",
    onclick: () => {
      card._userToggled = true;
      card.classList.toggle("collapsed");
    },
  },
  h("span", { class: "fc-chev", text: "⌄" }),
  h("span", { text: `${files.length} ${files.length === 1 ? "file" : "files"} changed` }),
  h("span", { class: "diff-add", text: `+${totalAdded}` }),
  h("span", { class: "diff-del", text: `-${totalRemoved}` }));

  const head = h("div", { class: "fc-sum-head" }, toggleBtn);
  if (!opts.shareMode && opts.onReview && files.length) {
    head.appendChild(h("button", {
      type: "button",
      class: "fc-review-btn",
      title: "打开右侧审阅面板对比 Diff 与在线编辑",
      html: `${SVG.diff}<span>Review</span>`,
      onclick: () => opts.onReview(files[0].path, "diff", files),
    }));
  }

  const list = div("fc-sum-list");
  files.forEach((f) => {
    const wrap = div("fc-row-wrap");
    const ft = fileTypeBadge(f.path);
    const stats = h("span", { class: "fc-stats" });
    if (f.binary) {
      if (f.status === "added") stats.appendChild(h("span", { class: "fc-stat-badge new", text: "NEW" }));
      stats.appendChild(h("span", { class: "fc-stat-badge bin", text: "BIN" }));
    } else if (f.status === "added" && !f.added && !f.removed) {
      stats.appendChild(h("span", { class: "fc-stat-badge new", text: "NEW" }));
    } else {
      stats.append(
        h("span", { class: "diff-add", text: `+${f.added || 0}` }),
        h("span", { class: "diff-del", text: `-${f.removed || 0}` }));
    }

    const row = h("button", {
      type: "button",
      class: "fc-row",
      title: opts.shareMode ? (f.diff ? "点击展开/收起变更 Diff" : f.path) : `审阅 ${f.path}`,
    },
    h("span", { class: `ft-badge ${ft.cls}`, text: ft.text }),
    h("span", { class: "fc-fname", text: basename(f.path) }),
    h("span", { class: "fc-dir", text: shortDir(f.path) }),
    stats);

    if (!opts.shareMode && opts.onReview) {
      row.onclick = () => opts.onReview(f.path, "diff", files);
    } else if (opts.shareMode && f.diff) {
      let diffBox = null;
      row.onclick = () => {
        if (diffBox) { diffBox.remove(); diffBox = null; return; }
        diffBox = div("fc-inline-diff", renderUnifiedDiffHtml(f.diff));
        wrap.appendChild(diffBox);
      };
    } else if (opts.onPreview) {
      row.onclick = () => opts.onPreview(f.path);
    }
    wrap.appendChild(row);
    list.appendChild(wrap);
  });

  const fcShell = h("div", { class: "fc-collapse-shell" }, h("div", { class: "fc-collapse-inner" }, list));
  card.append(head, fcShell);
}

/** 对话内记忆与画像沉淀提示胶囊 */
export function memoryLearnedBarEl(events = [], opts = {}) {
  const list = Array.isArray(events) ? events : [];
  const hasProj = list.some((x) => x.kind === "project");
  const hasTrait = list.some((x) => x.kind === "portrait" || x.kind === "memory");
  const defaultTab = hasProj && !hasTrait ? "projects" : "portrait";
  const summaries = list.map((x) => String(x.summary || "").trim()).filter(Boolean);
  const preview = summaries.slice(0, 2).map((s) => (s.length > 44 ? s.slice(0, 43) + "…" : s)).join(" · ");

  const bar = h("div", { class: "mem-learned-bar" },
    h("span", { class: "mlb-ic", html: SVG.brain }),
    h("span", { class: "mlb-title", text: `已沉淀长期记忆（${list.length} 项）` }),
    preview ? h("span", { class: "mlb-preview", text: preview, title: summaries.join("\n") }) : null,
    !opts.shareMode && opts.onOpenMemory ? h("button", {
      type: "button",
      class: "mlb-btn",
      text: "查看画像与进度 ›",
      onclick: () => opts.onOpenMemory(defaultTab),
    }) : null,
  );
  return bar;
}

/* ==========================================================================
   历史回放渲染（按轮聚合思维链轨迹、子智能体、最终回复与文件变更卡）
   ========================================================================== */
export function renderHistory(container, items, opts = {}) {
  let lastAsst = null, lastUser = null;
  const frag = document.createDocumentFragment();
  const allSessionChanges = [];
  const arr = items || [];

  let i = 0;
  while (i < arr.length) {
    const it = arr[i];
    if (it.role === "user") {
      const { text, files } = splitAttachments(it.content);
      lastUser = userMsgEl(text, files, opts);
      frag.appendChild(lastUser);
      lastAsst = null;
      i++;
      continue;
    }
    if (it.role === "note") {
      frag.appendChild(div("msg note", `<span>${esc(it.content)}</span>`));
      i++;
      continue;
    }
    if (it.role === "assistant") {
      // 收集同一轮中连续的所有 assistant 步骤
      const group = [];
      while (i < arr.length && arr[i].role === "assistant") {
        group.push(arr[i]);
        i++;
      }
      const isLastGroupAndRunning = i === arr.length && !!opts.running;
      const lastStep = group[group.length - 1];
      const hasFinalAnswer = !isLastGroupAndRunning
        && !(lastStep.tool_calls && lastStep.tool_calls.length)
        && String(lastStep.content || "").trim().length > 0;
      const traceSteps = hasFinalAnswer ? group.slice(0, -1) : group;
      const finalStep = hasFinalAnswer ? lastStep : null;

      // 统计本轮是否有轨迹内容（思维链 / 工具调用 / 子智能体 / 中间分析说明）
      const turnSubs = [];
      const turnChangesRaw = [];
      const turnMemories = [];
      let hasTraceItems = false;

      for (const g of group) {
        if (g.thinking && String(g.thinking).trim()) hasTraceItems = true;
        if ((g.tool_calls || []).some((tc) => tc.name !== "todo_write")) hasTraceItems = true;
        if (g.subagents && g.subagents.length) {
          hasTraceItems = true;
          turnSubs.push(...g.subagents);
        }
        if (g.turn_changes && g.turn_changes.length) {
          turnChangesRaw.push(...g.turn_changes);
        }
        if (g.memories_learned && g.memories_learned.length) {
          turnMemories.push(...g.memories_learned);
        }
      }
      for (const g of traceSteps) {
        if (g.content && String(g.content).trim()) hasTraceItems = true;
      }

      // 若旧会话没有存 turn_changes，则从工具调用的 data 中回溯提取
      if (!turnChangesRaw.length) {
        for (const g of group) {
          for (const tc of g.tool_calls || []) {
            if (tc.is_error) continue;
            const d = tc.data || {};
            const p = d.path || tc.arguments?.output_path
              || ((tc.name === "write_file" || tc.name === "edit_file") ? tc.arguments?.path : null);
            if (p) {
              turnChangesRaw.push({
                path: p,
                status: d.status || (tc.name === "edit_file" ? "modified" : "added"),
                added: d.added || 0,
                removed: d.removed || 0,
                diff: d.diff || "",
                binary: !d.diff && !d.added && !d.removed && isBinaryPath(p),
              });
            }
          }
        }
      }

      const turnChanges = normalizeTurnChanges(turnChangesRaw);
      if (turnChanges.length) allSessionChanges.push(...turnChanges);

      if (hasTraceItems) {
        const trace = createTurnTrace({ running: isLastGroupAndRunning, open: isLastGroupAndRunning });
        trace._state.steps = group.length;
        trace._state.changeCount = turnChanges.length;
        trace._state.subCount = turnSubs.length;

        let stepIdx = 0;
        for (const g of group) {
          stepIdx++;
          const thinkText = String(g.thinking || "").trim();
          const isIntermediateNote = g !== finalStep && String(g.content || "").trim();
          if (thinkText) {
            addTraceThinking(trace, thinkText, stepIdx);
            const thBox = document.createElement("details");
            thBox.className = "thinking";
            thBox.innerHTML = `<summary><span>💭 Step ${stepIdx} 推理思考（${thinkText.length} 字）</span><span class="chev">›</span></summary><div class="think-text">${esc(thinkText)}</div>`;
            trace._body.appendChild(thBox);
          } else if (isIntermediateNote) {
            addTraceThinking(trace, String(g.content).trim(), stepIdx);
          }
          if (isIntermediateNote) {
            const note = div("step-note md");
            setMarkdown(note, g.content);
            trace._body.appendChild(note);
          }
          for (const tc of g.tool_calls || []) {
            if (tc.name === "todo_write") continue;
            trace._state.toolNames.push(tc.name);
            const args = tc.arguments || {};
            const el = toolCardEl(tc.id, tc.name, args, summarizeArgs(tc.name, args));
            trace._body.appendChild(el);
            const data = { ...(tc.data || {}) };
            const p = data.path || args.output_path || ((tc.name === "write_file" || tc.name === "edit_file") ? args.path : null);
            if (p && !tc.is_error) data.path = p;
            const mm = /已保存图像[:：]\s*(.+)/.exec(tc.result || "");
            if (mm && !data.images) data.images = mm[1].split(/[,，]\s*/).map((s) => s.trim()).filter(Boolean);
            if (tc.result != null) fillToolResult(el, tc.name, tc.result, tc.is_error, data, null, { ...opts, collapse: true });
            else { const st = el.querySelector(".st"); st.className = "st"; st.textContent = "—"; }
          }
        }

        for (const sub of turnSubs) {
          trace._body.appendChild(subagentRowEl({ ...sub, running: false }));
        }

        if (!isLastGroupAndRunning) {
          finalizeTurnTrace(trace, { collapse: true, steps: group.length });
        } else {
          refreshTraceHeader(trace);
        }
        frag.appendChild(trace);
      }

      if (finalStep && String(finalStep.content || "").trim()) {
        lastAsst = assistantMsgEl(finalStep.content);
        frag.appendChild(lastAsst);
      }

      if (turnChanges.length) {
        frag.appendChild(fileChangesCardEl(turnChanges, opts));
      }
      if (turnMemories.length) {
        frag.appendChild(memoryLearnedBarEl(turnMemories, opts));
      }
      continue;
    }
    i++;
  }

  if (allSessionChanges.length && opts.onChanges) {
    opts.onChanges(allSessionChanges);
  }
  container.appendChild(frag);
  markFinals(container, { skipLast: !!opts.running });
  return { lastAssistant: lastAsst, lastUser };
}

/** 每一轮（两个用户消息之间）最后一条助手消息标记为最终答复 */
export function markFinals(container, { skipLast = false } = {}) {
  let lastA = null;
  for (const el of container.children) {
    if (el.classList.contains("user")) { if (lastA) lastA.classList.add("final"); lastA = null; }
    else if (el.classList.contains("assistant")) lastA = el;
  }
  if (lastA && !skipLast) lastA.classList.add("final");
}

export { renderMarkdown, enhance, setMarkdown };
