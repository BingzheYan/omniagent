/* 轻量 SVG 图表 */
import { esc, fmtK } from "./util.js";

/**
 * 堆叠柱状图
 * data: [{date, ...}]  series: [{key, label, color}]
 */
export function barChart(data, { series, height = 200, extraTip } = {}) {
  data = data || [];
  if (!data.length) return `<div class="chart-empty">暂无数据</div>`;
  const W = 720, H = height, padL = 44, padR = 8, padT = 12, padB = 26;
  const iw = W - padL - padR, ih = H - padT - padB;
  const sums = data.map((d) => series.reduce((s, x) => s + (Number(d[x.key]) || 0), 0));
  const rawMax = Math.max(1, ...sums);
  const mag = 10 ** Math.floor(Math.log10(rawMax));
  const max = [1, 2, 2.5, 5, 10].map((s) => s * mag).find((v) => v >= rawMax) || rawMax;
  const bw = iw / data.length;
  const barW = Math.max(2, Math.min(28, bw * 0.68));
  let svg = `<svg class="chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="用量柱状图">`;
  for (let i = 0; i <= 4; i++) {
    const y = padT + ih - (ih * i) / 4;
    svg += `<line x1="${padL}" x2="${W - padR}" y1="${y}" y2="${y}" class="grid"/>`;
    svg += `<text x="${padL - 6}" y="${y + 4}" text-anchor="end" class="axis">${fmtK((max * i) / 4)}</text>`;
  }
  const labelEvery = Math.ceil(data.length / 10);
  data.forEach((d, i) => {
    const x = padL + i * bw + (bw - barW) / 2;
    let y = padT + ih;
    const tipLines = [String(d.date || d.label || "")];
    series.forEach((s) => {
      const v = Number(d[s.key]) || 0;
      const bh = (v / max) * ih;
      y -= bh;
      if (bh > 0) svg += `<rect x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${barW.toFixed(1)}" height="${bh.toFixed(1)}" style="fill:${s.color}" rx="2"/>`;
      tipLines.push(`${s.label}：${v.toLocaleString("zh-CN")}`);
    });
    if (extraTip) tipLines.push(extraTip(d));
    svg += `<rect x="${(padL + i * bw).toFixed(1)}" y="${padT}" width="${bw.toFixed(1)}" height="${ih}" class="hit"><title>${esc(tipLines.filter(Boolean).join("\n"))}</title></rect>`;
    if (i % labelEvery === 0 || i === data.length - 1) {
      const lbl = String(d.date || d.label || "").slice(5);
      svg += `<text x="${(padL + i * bw + bw / 2).toFixed(1)}" y="${H - 8}" text-anchor="middle" class="axis">${esc(lbl)}</text>`;
    }
  });
  svg += `</svg>`;
  const legend = `<div class="chart-legend">${series.map((s) => `<span><i style="background:${s.color}"></i>${esc(s.label)}</span>`).join("")}</div>`;
  return `<div class="chart-wrap">${svg}${legend}</div>`;
}

/** 补齐最近 N 天的日期（缺失的日期填 0） */
export function fillDays(daily, days = 30) {
  const map = new Map((daily || []).map((d) => [d.date, d]));
  const out = [];
  const now = new Date();
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() - i);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    out.push(map.get(key) || { date: key, input_tokens: 0, output_tokens: 0, tasks: 0 });
  }
  return out;
}
