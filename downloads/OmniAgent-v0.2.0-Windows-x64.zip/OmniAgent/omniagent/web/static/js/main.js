/* 入口：启动、登录态、路由、三栏可拖拽布局、智能体与连接器入口、快捷键、用户菜单 */
import { S, bus, isMobile, applyTheme, getThemePref, hasSavedTheme, toggleTheme, isDarkTheme } from "./state.js";
import { $, esc, initials, avatarColor } from "./util.js";
import { api, put, post, setUnauthorizedHandler } from "./api.js";
import { toast, openMenu, closeMenu, isMenuOpen, closeTopModal, hasModal } from "./ui.js";
import * as auth from "./auth.js";
import * as chat from "./chat.js";
import * as sidebar from "./sidebar.js";
import * as panel from "./panel.js";
import * as hub from "./hub.js";
import { openMemoryModal } from "./memory.js";
import { initSmoothAccordions, circularThemeTransition, smoothViewSwitch } from "./motion.js";
import { SVG } from "./icons.js";

let appInited = false;
const IS_MAC = /Mac|iPhone|iPad/.test(navigator.platform || navigator.userAgent);

/* ================= 启动 ================= */
async function boot() {
  initSpotlight();
  initSmoothAccordions();
  applyTheme(getThemePref(), { persist: false });
  setUnauthorizedHandler(onUnauthorized);
  bus.on("unauthorized", onUnauthorized);
  try {
    const r = await api("/api/auth/me");
    await enterApp(r.user || r);
  } catch (e) {
    if (e.status === 401 || e.status === 403) {
      auth.showAuth({ onLogin: enterApp, message: e.status === 403 ? e.message : "" });
    } else {
      showBootError(e);
    }
  }
}

function showBootError(e) {
  const b = $("#boot");
  b.innerHTML = `<div class="boot-logo">◆</div><div class="boot-err">无法连接到服务器<br><small>${esc(e.message || "")}</small></div><button class="btn primary" type="button" id="boot-retry">重试</button>`;
  $("#boot-retry").onclick = () => location.reload();
}

async function enterApp(user) {
  if (appInited) { location.reload(); return; }
  S.user = user;
  S.settings = user.settings || {};
  // 若本地尚未显式保存主题，仅在用户服务器偏好明确指定为 light / dark 时同步（忽略默认 "system"，保持首次打开为深色工作台）
  if (!hasSavedTheme() && (S.settings.theme === "light" || S.settings.theme === "dark")) {
    applyTheme(S.settings.theme, { persist: true });
  }
  await loadConfig();
  smoothViewSwitch(() => {
    $("#boot").hidden = true;
    auth.hideAuth();
    $("#app").hidden = false;
  });
  appInited = true;

  panel.init({ onAttach: chat.addAttachment });
  chat.init();
  sidebar.init();
  chat.applyConfig();
  initLayout();
  initResizers();
  renderUser();
  bindShortcuts();
  bindBus();
  window.addEventListener("hashchange", route);
  route();
  sidebar.refresh();
  if (!(S.config?.models || []).some((m) => m.available)) {
    toast("欢迎使用 OmniAgent！请先配置模型 API Key（如 DeepSeek）即可开始对话", "warn", 6500);
    openSettings("keys");
  }
}

async function loadConfig() {
  try {
    S.config = await api("/api/config");
    if (S.config.user) { S.user = { ...S.user, ...S.config.user }; S.settings = S.user.settings || S.settings; }
  } catch (e) {
    S.config = S.config || { models: [], agents: [], connectors: [], default_model: null };
    if (e.status !== 401) toast("加载配置失败：" + e.message, "error");
  }
}

function onUnauthorized() {
  if (!appInited) return;
  if (auth.isAuthVisible()) return;
  chat.disconnect();
  closeMenu();
  while (closeTopModal()) { /* 关闭全部模态框 */ }
  auth.showAuth({ onLogin: enterApp, message: "登录已过期或已在其他设备退出，请重新登录。" });
}

/* ================= 路由 ================= */
let adminMod = null;
async function route() {
  const hash = location.hash.replace(/^#/, "");
  if (hash.startsWith("/admin")) {
    if (S.user.role !== "admin") { toast("需要管理员权限", "error"); history.replaceState(null, "", "#/"); return route(); }
    adminMod = adminMod || (await import("./admin.js"));
    closeDrawers();
    adminMod.show(hash.split("/")[2] || "dashboard");
    return;
  }
  if (adminMod) {
    adminMod.hide();
    const t = $("#conv-title")?.textContent?.trim();
    document.title = t && t !== "新对话" ? `${t} · OmniAgent` : "OmniAgent";
  }
  const m = hash.match(/^\/c\/([\w.-]+)/);
  if (m) chat.openConversation(m[1]);
  else if (!S.routed || S.convPersisted) chat.openConversation(null);
  S.routed = true;
}

export function newChat() {
  if (adminMod) {
    adminMod.hide();
    const t = $("#conv-title")?.textContent?.trim();
    document.title = t && t !== "新对话" ? `${t} · OmniAgent` : "OmniAgent";
  }
  if (location.hash.startsWith("#/c/") || location.hash.startsWith("#/admin")) location.hash = "#/";
  else if (S.convPersisted || S.running) chat.openConversation(null);
  else chat.focusInput();
  closeDrawers();
}

function initSpotlight() {
  document.addEventListener("pointermove", (e) => {
    const card = e.target?.closest?.(".spotlight-card");
    if (!card) return;
    const rect = card.getBoundingClientRect();
    card.style.setProperty("--mx", `${Math.round(e.clientX - rect.left)}px`);
    card.style.setProperty("--my", `${Math.round(e.clientY - rect.top)}px`);
  }, { passive: true });
}

/* ================= 布局、抽屉与智能体/连接器中心 ================= */
function initLayout() {
  const app = $("#app");
  if (localStorage.getItem("omni_sb_collapsed") === "1") app.classList.add("sb-collapsed");
  const savedPanel = localStorage.getItem("omni_panel_collapsed");
  if (savedPanel === "0") app.classList.remove("panel-collapsed");
  else app.classList.add("panel-collapsed");
  syncPanelBtnState();
  syncThemeBtnIcon();

  $("#btn-new").onclick = newChat;
  $("#btn-collapse-sidebar").onclick = () => {
    if (isMobile()) { closeDrawers(); return; }
    app.classList.add("sb-collapsed");
    localStorage.setItem("omni_sb_collapsed", "1");
  };
  $("#btn-open-sidebar").onclick = () => {
    if (isMobile()) { app.classList.add("sb-open"); app.classList.remove("panel-open"); showBackdrop(); }
    else { app.classList.remove("sb-collapsed"); localStorage.setItem("omni_sb_collapsed", "0"); }
  };
  $("#btn-toggle-panel").onclick = () => togglePanel();
  $("#btn-close-panel").onclick = () => togglePanel(false);
  $("#backdrop").onclick = closeDrawers;

  // 主题快速切换（带圆形光波扩散 View Transition）
  $("#btn-theme-toggle").onclick = (ev) => {
    circularThemeTransition(ev, () => {
      const next = toggleTheme();
      S.settings.theme = next;
      put("/api/me/settings", { theme: next }).catch(() => {});
    });
  };
  bus.on("theme:changed", syncThemeBtnIcon);

  // 智能体中心与外部连接器中心
  const openAgents = () => {
    closeDrawers();
    hub.openAgentsModal({
      currentAgent: chat.getAgent(),
      onSelectAgent: chat.selectAgent,
      onInsertPrompt: chat.insertIntoInput,
    });
  };
  const openConnectors = () => {
    closeDrawers();
    hub.openConnectorsModal({
      onInsertConnector: (c) => chat.insertIntoInput(`@connector:${c.name} `),
    });
  };
  const openMemory = (tab = "portrait") => {
    closeDrawers();
    openMemoryModal({
      initialTab: tab,
      onContinueProject: (prompt) => {
        newChat();
        setTimeout(() => chat.setInputValue(prompt), 60);
      },
      onPreviewFile: (path) => panel.preview(path),
    });
  };
  $("#btn-agents").onclick = openAgents;
  $("#sb-btn-agents").onclick = openAgents;
  $("#btn-connectors").onclick = openConnectors;
  $("#sb-btn-connectors").onclick = openConnectors;
  const sbMemBtn = $("#sb-btn-memory");
  if (sbMemBtn) sbMemBtn.onclick = () => openMemory("portrait");
  bus.on("memory:open", (tab) => openMemory(tab || "portrait"));

  $("#btn-conv-menu").onclick = () => {
    const c = sidebar.findConv(S.convId) || { id: S.convId, title: S.convTitle, pinned: false, archived: false };
    openMenu($("#btn-conv-menu"), sidebar.convMenuItems(c, null));
  };
  $("#user-btn").onclick = () => openMenu($("#user-btn"), userMenuItems(), { align: "left", placement: "above" });
  $(".kbd-new").textContent = IS_MAC ? "⌘⇧O" : "Ctrl+Shift+O";
  $(".kbd-search").textContent = IS_MAC ? "⌘K" : "Ctrl+K";
  window.matchMedia("(max-width: 900px)").addEventListener?.("change", closeDrawers);
}

function syncThemeBtnIcon() {
  const btn = $("#btn-theme-toggle");
  if (!btn) return;
  const dark = isDarkTheme();
  btn.innerHTML = dark ? SVG.sun : SVG.moon;
  btn.title = dark ? "切换为温润浅色主题" : "切换为深邃暗色主题";
}

function syncPanelBtnState() {
  const app = $("#app"), btn = $("#btn-toggle-panel");
  if (!app || !btn) return;
  const open = isMobile() ? app.classList.contains("panel-open") : !app.classList.contains("panel-collapsed");
  btn.classList.toggle("active", open);
}

function togglePanel(force) {
  const app = $("#app");
  if (isMobile()) {
    const open = force ?? !app.classList.contains("panel-open");
    app.classList.toggle("panel-open", open);
    app.classList.remove("sb-open");
    if (open) showBackdrop(); else closeDrawers();
  } else {
    const collapsed = force === undefined ? !app.classList.contains("panel-collapsed") : !force;
    app.classList.toggle("panel-collapsed", collapsed);
    localStorage.setItem("omni_panel_collapsed", collapsed ? "1" : "0");
    localStorage.setItem("omni_panel_pinned", collapsed ? "0" : "1");
  }
  syncPanelBtnState();
}
function showBackdrop() { $("#backdrop").hidden = false; }
function closeDrawers() {
  const app = $("#app");
  app.classList.remove("sb-open", "panel-open");
  $("#backdrop").hidden = true;
  syncPanelBtnState();
}

/* ================= 左右双侧栏可拖拽分栏器 ================= */
function initResizers() {
  const app = $("#app");
  const leftHandle = $("#resizer-left");
  const rightHandle = $("#resizer-right");

  const clampLeft = (w) => Math.max(180, Math.min(420, Math.min(w, window.innerWidth - 420)));
  const clampRight = (w) => Math.max(320, Math.min(Math.floor(window.innerWidth * 0.65), window.innerWidth - 340, w));

  const savedSb = Number(localStorage.getItem("omni_sb_width"));
  if (savedSb >= 180) app.style.setProperty("--sb-w", clampLeft(savedSb) + "px");

  const savedPn = Number(localStorage.getItem("omni_panel_width"));
  if (savedPn >= 320) app.style.setProperty("--panel-w", clampRight(savedPn) + "px");

  function bindDrag(handle, onMove, onDone) {
    if (!handle) return;
    handle.addEventListener("pointerdown", (e) => {
      if (isMobile() || e.button !== 0) return;
      e.preventDefault();
      handle.setPointerCapture?.(e.pointerId);
      handle.classList.add("dragging");
      app.classList.add("is-resizing");

      const move = (ev) => onMove(ev.clientX);
      const stop = (ev) => {
        handle.releasePointerCapture?.(ev.pointerId);
        handle.classList.remove("dragging");
        app.classList.remove("is-resizing");
        handle.removeEventListener("pointermove", move);
        handle.removeEventListener("pointerup", stop);
        handle.removeEventListener("pointercancel", stop);
        onDone?.();
      };
      handle.addEventListener("pointermove", move);
      handle.addEventListener("pointerup", stop);
      handle.addEventListener("pointercancel", stop);
    });
  }

  let curSbW = savedSb || 260;
  bindDrag(leftHandle, (clientX) => {
    curSbW = clampLeft(clientX);
    app.style.setProperty("--sb-w", curSbW + "px");
  }, () => {
    try { localStorage.setItem("omni_sb_width", String(Math.round(curSbW))); } catch { /* ignore */ }
  });
  leftHandle?.addEventListener("dblclick", () => {
    curSbW = 260;
    app.style.setProperty("--sb-w", "260px");
    try { localStorage.setItem("omni_sb_width", "260"); } catch { /* ignore */ }
  });

  let curPnW = savedPn || 440;
  bindDrag(rightHandle, (clientX) => {
    curPnW = clampRight(window.innerWidth - clientX);
    app.style.setProperty("--panel-w", curPnW + "px");
  }, () => {
    try { localStorage.setItem("omni_panel_width", String(Math.round(curPnW))); } catch { /* ignore */ }
  });
  rightHandle?.addEventListener("dblclick", () => {
    const wide = Math.floor(window.innerWidth * 0.54);
    const current = $("#panel").getBoundingClientRect().width;
    curPnW = Math.abs(current - wide) < 40 ? 440 : clampRight(wide);
    app.style.setProperty("--panel-w", curPnW + "px");
    try { localStorage.setItem("omni_panel_width", String(Math.round(curPnW))); } catch { /* ignore */ }
  });

  window.addEventListener("resize", () => {
    if (isMobile()) return;
    const pRect = $("#panel")?.getBoundingClientRect();
    if (pRect && pRect.width > window.innerWidth * 0.65) {
      app.style.setProperty("--panel-w", clampRight(pRect.width) + "px");
    }
  });
}

/* ================= 用户 ================= */
function renderUser() {
  const u = S.user;
  const name = u.display_name || u.username;
  const av = $("#user-avatar");
  av.textContent = initials(name);
  av.style.background = avatarColor(u.username);
  $("#user-name").textContent = name;
  $("#user-role").textContent = u.role === "admin" ? "管理员" : "@" + u.username;
  $("#welcome-title").textContent = `${greeting()}，${name}`;
}
function greeting() {
  const hr = new Date().getHours();
  return hr < 6 ? "夜深了" : hr < 11 ? "早上好" : hr < 13 ? "中午好" : hr < 18 ? "下午好" : "晚上好";
}

function userMenuItems() {
  const pref = getThemePref();
  const setTheme = (t) => {
    applyTheme(t, { persist: true });
    S.settings.theme = t;
    put("/api/me/settings", { theme: t }).catch(() => {});
  };
  return [
    { header: `${S.user.display_name || S.user.username} · @${S.user.username}` },
    { icon: SVG.agents, label: "智能体矩阵", onClick: () => $("#sb-btn-agents").click() },
    { icon: SVG.plug, label: "外部系统接入", onClick: () => $("#sb-btn-connectors").click() },
    { icon: SVG.brain, label: "记忆与用户画像", onClick: () => $("#sb-btn-memory")?.click() },
    { icon: SVG.settings, label: "偏好与模型密钥", onClick: () => openSettings() },
    { icon: SVG.chart, label: "用量与账单统计", onClick: () => openSettings("usage") },
    { icon: SVG.shield, label: "系统管理后台", hidden: S.user.role !== "admin", onClick: () => { location.hash = "#/admin"; } },
    { divider: true },
    { header: "界面外观" },
    { icon: SVG.moon, label: "深邃暗色（Obsidian）", checked: pref === "dark", onClick: () => setTheme("dark") },
    { icon: SVG.sun, label: "温润纸白（Editorial）", checked: pref === "light", onClick: () => setTheme("light") },
    { icon: SVG.cpu, label: "跟随系统设置", checked: pref === "system", onClick: () => setTheme("system") },
    { divider: true },
    { icon: SVG.terminal, label: "键盘快捷键", onClick: showShortcuts },
    { icon: SVG.logout, label: "退出当前账号", danger: true, onClick: logout },
  ];
}

async function openSettings(tab) {
  const m = await import("./settings.js");
  m.openSettings(tab);
}

async function showShortcuts() {
  const { openModal } = await import("./ui.js");
  const mod = IS_MAC ? "⌘" : "Ctrl";
  const rows = [
    [`${mod} K`, "搜索历史对话"],
    [`${mod} Shift O`, "新建对话"],
    ["Enter", "发送消息"],
    ["Shift Enter", "输入框换行"],
    [`${mod} S`, "在右侧审阅编辑器中保存文件"],
    [`${mod} Enter`, "保存编辑的用户消息"],
    ["Esc", "关闭弹窗 / 菜单 / 移动端抽屉"],
  ];
  openModal({
    title: "键盘快捷键", size: "sm",
    content: `<table class="table shortcuts">${rows.map(([k, v]) => `<tr><td>${k.split(" ").map((x) => `<kbd>${esc(x)}</kbd>`).join(" ")}</td><td>${esc(v)}</td></tr>`).join("")}</table>`,
  });
}

async function logout() {
  chat.disconnect();
  try { await post("/api/auth/logout", {}); } catch { /* ignore */ }
  history.replaceState(null, "", "/");
  location.reload();
}

/* ================= 事件总线 ================= */
function bindBus() {
  bus.on("drawer:close", closeDrawers);
  bus.on("panel:show", () => {
    const app = $("#app");
    if (isMobile()) { app.classList.add("panel-open"); app.classList.remove("sb-open"); showBackdrop(); }
    else if (app.classList.contains("panel-collapsed")) { app.classList.remove("panel-collapsed"); localStorage.setItem("omni_panel_collapsed", "0"); }
    syncPanelBtnState();
  });
  bus.on("settings:open", (tab) => openSettings(tab));
  bus.on("user:updated", renderUser);
  bus.on("settings:updated", () => { if (!S.convPersisted && !S.running) chat.applyDefaults(); });
  bus.on("config:reload", async () => {
    const keepModel = $("#sel-model").value;
    const keepAgent = $("#sel-agent").value;
    await loadConfig();
    chat.applyConfig();
    if (S.convPersisted && keepModel) {
      const o = [...$("#sel-model").options].find((x) => x.value === keepModel && !x.disabled);
      if (o) $("#sel-model").value = keepModel;
    }
    if (keepAgent && [...$("#sel-agent").options].some((x) => x.value === keepAgent)) {
      $("#sel-agent").value = keepAgent;
    }
  });
  bus.on("conv:renamed", (t) => { $("#conv-title").textContent = t; });
  bus.on("conv:deleted-current", () => { if (location.hash.startsWith("#/c/")) location.hash = "#/"; else chat.openConversation(null); });
  bus.on("admin:hidden", () => { /* 返回对话视图 */ });
}

/* ================= 快捷键 ================= */
function bindShortcuts() {
  document.addEventListener("keydown", (e) => {
    const mod = e.metaKey || e.ctrlKey;
    const k = (e.key || "").toLowerCase();
    if (mod && !e.shiftKey && !e.altKey && k === "k") {
      e.preventDefault();
      if (!$("#admin-view").hidden) location.hash = S.convPersisted && S.convId ? `#/c/${S.convId}` : "#/";
      const app = $("#app");
      if (isMobile()) { app.classList.add("sb-open"); showBackdrop(); }
      else app.classList.remove("sb-collapsed");
      sidebar.focusSearch();
      return;
    }
    if (mod && e.shiftKey && k === "o") { e.preventDefault(); newChat(); return; }
    if (e.key === "Escape") {
      if (isMenuOpen()) { closeMenu(); e.preventDefault(); return; }
      if (hasModal()) { if (closeTopModal()) e.preventDefault(); return; }
      const app = $("#app");
      if (app.classList.contains("sb-open") || app.classList.contains("panel-open")) { closeDrawers(); e.preventDefault(); }
    }
  });
}

boot();
