/* REST 客户端：统一错误处理与 401 跳转登录 */
let unauthorizedHandler = () => {};
export function setUnauthorizedHandler(fn) { unauthorizedHandler = fn; }

export class ApiError extends Error {
  constructor(message, status) { super(message); this.status = status; }
}

/**
 * api(path, {method, body, form, noAuthRedirect})
 * - body: JSON 对象；form: FormData
 */
export async function api(path, { method, body, form, noAuthRedirect, signal } = {}) {
  const opts = { method: method || (body !== undefined || form ? "POST" : "GET"), headers: {}, credentials: "same-origin", signal };
  if (form) opts.body = form;
  else if (body !== undefined) {
    opts.headers["Content-Type"] = "application/json";
    opts.body = JSON.stringify(body);
  }
  let r;
  try {
    r = await fetch(path, opts);
  } catch (e) {
    if (e.name === "AbortError") throw e;
    throw new ApiError("网络错误，无法连接服务器", 0);
  }
  if (r.status === 401 && !noAuthRedirect && !path.startsWith("/api/auth/")) unauthorizedHandler();
  if (!r.ok) {
    let detail;
    try {
      const j = await r.json();
      detail = j.detail;
      if (Array.isArray(detail)) detail = detail.map((x) => x.msg || JSON.stringify(x)).join("；");
      else if (detail && typeof detail === "object") detail = JSON.stringify(detail);
    } catch { /* not json */ }
    if (!detail) {
      detail = { 401: "未登录或登录已过期", 403: "权限不足", 404: "资源不存在", 413: "文件过大", 429: "请求过于频繁，请稍后再试" }[r.status]
        || `请求失败（${r.status}）`;
    }
    throw new ApiError(detail, r.status);
  }
  if (r.status === 204) return {};
  const ct = r.headers.get("content-type") || "";
  return ct.includes("json") ? r.json() : r.text();
}

export const get = (p, o) => api(p, o);
export const post = (p, body, o) => api(p, { ...o, method: "POST", body: body ?? {} });
export const put = (p, body, o) => api(p, { ...o, method: "PUT", body: body ?? {} });
export const patch = (p, body, o) => api(p, { ...o, method: "PATCH", body: body ?? {} });
export const del = (p, o) => api(p, { ...o, method: "DELETE" });

/** 带进度的上传（XHR） */
export function upload(files, dir = "uploads", onProgress) {
  return new Promise((resolve, reject) => {
    const fd = new FormData();
    [...files].forEach((f) => fd.append("files", f, f.name));
    fd.append("dir", dir || "uploads");
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "/api/upload");
    xhr.withCredentials = true;
    if (onProgress) xhr.upload.onprogress = (e) => e.lengthComputable && onProgress(e.loaded / e.total);
    xhr.onload = () => {
      let j = {};
      try { j = JSON.parse(xhr.responseText); } catch { /* ignore */ }
      if (xhr.status === 401) unauthorizedHandler();
      if (xhr.status >= 200 && xhr.status < 300) resolve(j);
      else reject(new ApiError((typeof j.detail === "string" && j.detail) || `上传失败（${xhr.status}）`, xhr.status));
    };
    xhr.onerror = () => reject(new ApiError("网络错误，上传失败", 0));
    xhr.send(fd);
  });
}
