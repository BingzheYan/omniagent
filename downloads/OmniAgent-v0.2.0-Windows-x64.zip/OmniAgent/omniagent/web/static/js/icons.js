/* 精密矢量图标系统（1.5px 线性 SVG + 多层棱镜品牌徽标）—— 替代粗糙的系统彩色 Emoji */

const svg = (paths, viewBox = "0 0 24 24", cls = "ui-ic") =>
  `<svg class="${cls}" viewBox="${viewBox}" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths}</svg>`;

/** 多面棱镜品牌徽标（带高光切面与柔和渐变） */
export const BRAND_LOGO_SVG = `<svg class="brand-prism" viewBox="0 0 32 32" fill="none" aria-hidden="true">
  <defs>
    <linearGradient id="omni-g1" x1="4" y1="3" x2="28" y2="29" gradientUnits="userSpaceOnUse">
      <stop offset="0%" stop-color="#939aff"/>
      <stop offset="52%" stop-color="#5e6ad2"/>
      <stop offset="100%" stop-color="#38bdf8"/>
    </linearGradient>
    <linearGradient id="omni-g2" x1="16" y1="5" x2="16" y2="27" gradientUnits="userSpaceOnUse">
      <stop offset="0%" stop-color="#ffffff" stop-opacity="0.95"/>
      <stop offset="100%" stop-color="#c7d2fe" stop-opacity="0.72"/>
    </linearGradient>
  </defs>
  <rect x="2" y="2" width="28" height="28" rx="9" fill="url(#omni-g1)"/>
  <rect x="2.5" y="2.5" width="27" height="27" rx="8.5" stroke="white" stroke-opacity="0.24"/>
  <path d="M16 6.8L23.6 16L16 25.2L8.4 16L16 6.8Z" fill="url(#omni-g2)"/>
  <path d="M16 6.8L23.6 16L16 18.4V6.8Z" fill="white" fill-opacity="0.38"/>
  <circle cx="16" cy="16" r="2.1" fill="#312e81"/>
</svg>`;

export const SVG = {
  plus: svg(`<path d="M12 5v14M5 12h14"/>`),
  search: svg(`<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>`),
  sidebarLeft: svg(`<rect x="3" y="4" width="18" height="16" rx="3"/><path d="M9 4v16"/>`),
  sidebarClose: svg(`<rect x="3" y="4" width="18" height="16" rx="3"/><path d="M9 4v16M15 10l-2 2 2 2"/>`),
  panelRight: svg(`<rect x="3" y="4" width="18" height="16" rx="3"/><path d="M15 4v16"/>`),
  agents: svg(`<rect x="4" y="6" width="16" height="12" rx="4"/><path d="M9 11v2M15 11v2M12 3v3M8 21h8"/>`),
  plug: svg(`<path d="M12 22v-5"/><path d="M9 8V3M15 8V3"/><path d="M6 8h12v4a6 6 0 0 1-12 0V8Z"/>`),
  archive: svg(`<rect x="3" y="4" width="18" height="4" rx="1.5"/><path d="M5 8v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8"/><path d="M10 12h4"/>`),
  sun: svg(`<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/>`),
  moon: svg(`<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79Z"/>`),
  dots: svg(`<circle cx="5" cy="12" r="1.4" fill="currentColor"/><circle cx="12" cy="12" r="1.4" fill="currentColor"/><circle cx="19" cy="12" r="1.4" fill="currentColor"/>`),
  paperclip: svg(`<path d="m21.44 11.05-8.49 8.49a5.5 5.5 0 0 1-7.78-7.78l9.19-9.19a3.5 3.5 0 0 1 4.95 4.95l-9.2 9.19a1.5 1.5 0 0 1-2.12-2.12l8.49-8.48"/>`),
  sendUp: svg(`<path d="M12 19V5M6 11l6-6 6 6"/>`),
  stop: `<svg class="ui-ic" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><rect x="6.5" y="6.5" width="11" height="11" rx="2.5"/></svg>`,
  diff: svg(`<path d="M14 3v4a1 1 0 0 0 1 1h4"/><path d="M17 21H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7l5 5v11a2 2 0 0 1-2 2Z"/><path d="M9 12h6M12 9v6M9 17h6"/>`),
  plan: svg(`<path d="M9 6h11M9 12h11M9 18h11"/><path d="m3.5 6 1.5 1.5L7.5 5"/><path d="m3.5 12 1.5 1.5L7.5 11"/><circle cx="5" cy="18" r="1.5"/>`),
  box: svg(`<path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><path d="m3.3 7 8.7 5 8.7-5M12 22V12"/>`),
  eye: svg(`<path d="M2.5 12s3.5-7 9.5-7 9.5 7 9.5 7-3.5 7-9.5 7-9.5-7-9.5-7Z"/><circle cx="12" cy="12" r="3"/>`),
  eyeOff: svg(`<path d="M17.94 17.94A10.07 10.07 0 0 1 12 19c-6 0-9.5-7-9.5-7a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c6 0 9.5 7 9.5 7a18.5 18.5 0 0 1-2.16 3.19M1 1l22 22"/>`),
  folder: svg(`<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Z"/>`),
  folderPlus: svg(`<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Z"/><path d="M12 11v6M9 14h6"/>`),
  upload: svg(`<path d="M12 16V4m0 0-4 4m4-4 4 4"/><path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"/>`),
  download: svg(`<path d="M12 4v12m0 0-4-4m4 4 4-4"/><path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"/>`),
  refresh: svg(`<path d="M21 12a9 9 0 1 1-2.64-6.36"/><path d="M21 3v6h-6"/>`),
  close: svg(`<path d="M18 6 6 18M6 6l12 12"/>`),
  arrowDown: svg(`<path d="M12 5v14m0 0-5-5m5 5 5-5"/>`),
  arrowUpRight: svg(`<path d="M7 17 17 7M9 7h8v8"/>`),
  sparkles: svg(`<path d="m12 3 1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9L12 3Z"/><path d="m19 16 .9 2.1L22 19l-2.1.9L19 22l-.9-2.1L16 19l2.1-.9L19 16Z"/>`),
  code: svg(`<polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/>`),
  rocket: svg(`<path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09Z"/><path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2Z"/>`),
  chart: svg(`<path d="M3 3v18h18"/><path d="M7 16v-5M12 16V8M17 16v-3"/>`),
  academic: svg(`<path d="M22 10 12 5 2 10l10 5 10-5Z"/><path d="M6 12.5V17c0 1.7 2.7 3 6 3s6-1.3 6-3v-4.5"/>`),
  slides: svg(`<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4M9 10l2 2 4-4"/>`),
  terminal: svg(`<rect x="3" y="4" width="18" height="16" rx="2.5"/><path d="m7 9 3 3-3 3M13 15h4"/>`),
  fileText: svg(`<path d="M14 3v4a1 1 0 0 0 1 1h4"/><path d="M17 21H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7l5 5v11a2 2 0 0 1-2 2Z"/><path d="M9 13h6M9 17h4"/>`),
  edit: svg(`<path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/>`),
  globe: svg(`<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14.5 14.5 0 0 0 0 18 14.5 14.5 0 0 0 0-18"/>`),
  shield: svg(`<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/><path d="m9 12 2 2 4-4"/>`),
  cpu: svg(`<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4"/>`),
  thought: svg(`<path d="M9.5 3A5.5 5.5 0 0 0 4 8.5c0 1.6.7 3 1.8 4L5 17l4.3-1.3c.8.2 1.7.3 2.7.3a6.5 6.5 0 0 0 6.5-6.5C18.5 5.9 15.1 3 11 3H9.5Z"/>`),
  settings: svg(`<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9c.26.6.77 1.02 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1Z"/>`),
  logout: svg(`<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>`),
  copy: svg(`<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>`),
  check: svg(`<polyline points="20 6 9 17 4 12"/>`),
  pin: svg(`<path d="m15 4 5 5-4 4 1 5-5-5-5 5-2-2 5-5-4-4 5 1 4-4Z"/>`),
  share: svg(`<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="m8.59 13.51 6.83 3.98M15.41 6.51l-6.82 3.98"/>`),
  trash: svg(`<path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/>`),
  chatEmpty: svg(`<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v10Z"/><path d="M8 9h8M8 13h5"/>`),
  brain: svg(`<path d="M12 4.5a3.5 3.5 0 0 0-5.9 2.5A3.5 3.5 0 0 0 4.5 13a3.5 3.5 0 0 0 1.8 6.5A3.5 3.5 0 0 0 12 20V4.5Z"/><path d="M12 4.5a3.5 3.5 0 0 1 5.9 2.5A3.5 3.5 0 0 1 19.5 13a3.5 3.5 0 0 1-1.8 6.5A3.5 3.5 0 0 1 12 20V4.5Z"/><path d="M9 10h.01M15 10h.01M9.5 14.5c.7.7 1.6 1 2.5 1s1.8-.3 2.5-1"/>`),
  userCard: svg(`<rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="2"/><path d="M6 16c.6-1.5 1.7-2.2 3-2.2s2.4.7 3 2.2M14 9h4M14 13h4"/>`),
  mail: svg(`<rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="m3 7 9 6 9-6"/>`),
  calendar: svg(`<rect x="3" y="5" width="18" height="16" rx="2.5"/><path d="M16 3v4M8 3v4M3 10h18"/>`),
  queue: svg(`<path d="M4 7h11M4 12h11M4 17h7"/><path d="m17 13 3 3-3 3M20 16h-5"/>`),
  radar: svg(`<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.5" fill="currentColor"/><path d="m12 12 6-6"/>`),
};
