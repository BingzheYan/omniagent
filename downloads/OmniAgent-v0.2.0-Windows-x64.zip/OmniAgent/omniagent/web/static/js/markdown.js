/* Markdown 渲染：marked + DOMPurify + highlight.js + KaTeX（CDN 不可用时优雅降级） */
import { esc, copyText } from "./util.js";

let configured = false;
function setup() {
  if (configured) return;
  configured = true;
  if (window.marked && window.marked.use) window.marked.use({ breaks: true, gfm: true });
  if (window.hljs && window.hljs.configure) window.hljs.configure({ ignoreUnescapedHTML: true });
}

const CODE_SPLIT = /(```[\s\S]*?(?:```|$)|~~~[\s\S]*?(?:~~~|$)|`[^`\n]+`)/g;
const MATH_RE = /(\$\$[\s\S]+?\$\$|\\\[[\s\S]+?\\\]|\\\([\s\S]+?\\\)|(?<![\\$\w])\$(?![\s$])(?:[^$\n\\]|\\.){1,400}?(?<!\s)\$(?![\w$]))/g;

/** 把数学公式替换为占位符，避免被 markdown 解析破坏 */
function protectMath(src) {
  const store = [];
  if (!/[$\\]/.test(src)) return { src, store };
  const out = src.split(CODE_SPLIT).map((part, i) => {
    if (i % 2 === 1) return part; // 代码片段
    return part.replace(MATH_RE, (m) => { store.push(m); return `MATHPH${store.length - 1}END`; });
  });
  return { src: out.join(""), store };
}

export function renderMarkdown(text) {
  setup();
  text = String(text ?? "");
  if (!(window.marked && window.DOMPurify)) return `<p>${esc(text).replace(/\n/g, "<br>")}</p>`;
  const { src, store } = protectMath(text);
  let html;
  try {
    html = window.DOMPurify.sanitize(window.marked.parse(src));
  } catch {
    return `<p>${esc(text).replace(/\n/g, "<br>")}</p>`;
  }
  if (store.length) html = html.replace(/MATHPH(\d+)END/g, (_, i) => esc(store[+i] ?? ""));
  return html;
}

const KATEX_OPTS = {
  delimiters: [
    { left: "$$", right: "$$", display: true },
    { left: "\\[", right: "\\]", display: true },
    { left: "\\(", right: "\\)", display: false },
    { left: "$", right: "$", display: false },
  ],
  throwOnError: false,
  ignoredTags: ["script", "noscript", "style", "textarea", "pre", "code", "option"],
};

/** 渲染完成后的增强：代码高亮 + 复制按钮、外链、表格滚动、数学公式 */
export function enhance(root) {
  if (!root) return;
  setup();
  root.querySelectorAll("pre > code").forEach((code) => {
    const pre = code.parentElement;
    if (pre.dataset.enh) return;
    pre.dataset.enh = "1";
    const lang = (code.className.match(/language-([\w+#.-]+)/) || [])[1] || "";
    if (window.hljs && code.textContent.length < 60000) {
      try {
        if (lang && window.hljs.getLanguage(lang)) window.hljs.highlightElement(code);
        else if (!lang && code.textContent.length < 8000) {
          const r = window.hljs.highlightAuto(code.textContent);
          if (r.relevance > 5) { code.innerHTML = r.value; code.classList.add("hljs"); }
        }
      } catch { /* ignore */ }
    }
    const wrap = document.createElement("div");
    wrap.className = "codeblock";
    const head = document.createElement("div");
    head.className = "code-head";
    head.innerHTML = `<span class="code-lang">${esc(lang || "code")}</span><button type="button" class="code-copy" aria-label="复制代码">复制</button>`;
    pre.replaceWith(wrap);
    wrap.append(head, pre);
    const btn = head.querySelector("button");
    btn.onclick = async () => {
      const ok = await copyText(code.textContent);
      btn.textContent = ok ? "已复制 ✓" : "复制失败";
      setTimeout(() => (btn.textContent = "复制"), 1500);
    };
  });
  root.querySelectorAll("a[href]").forEach((a) => {
    const href = a.getAttribute("href") || "";
    if (!href.startsWith("#")) { a.target = "_blank"; a.rel = "noopener noreferrer"; }
  });
  root.querySelectorAll("table").forEach((t) => {
    if (t.parentElement.classList.contains("table-wrap")) return;
    const w = document.createElement("div");
    w.className = "table-wrap";
    t.replaceWith(w);
    w.appendChild(t);
  });
  if (window.renderMathInElement && /\$|\\\(|\\\[/.test(root.textContent)) {
    try { window.renderMathInElement(root, KATEX_OPTS); } catch { /* ignore */ }
  }
}

/** 一步到位：设置 innerHTML 并增强 */
export function setMarkdown(el, text) {
  el.innerHTML = renderMarkdown(text);
  enhance(el);
}
