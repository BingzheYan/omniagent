/* 智能体与子智能体中心（Agents & Subagents）+ 外部系统接入中心（Connectors Hub） */
import { S, bus } from "./state.js";
import { $, $$, esc, h, div, TOOL_LABELS, ICONS } from "./util.js";
import { api, post, del } from "./api.js";
import { toast, openModal, confirmDialog, spinner, emptyState } from "./ui.js";

const SHORT_TITLES = {
  general: "全能主控",
  coder: "软件开发",
  researcher: "资料调研",
  analyst: "数据计量",
  writer: "学术公文",
  connector: "应用连接",
  reviewer: "质量审查",
};

export function shortAgentLabel(a) {
  return SHORT_TITLES[a.name] || a.title || a.name;
}

const MODE_LABEL = { auto: "自动模式", code: "编程模式", office: "办公模式" };

/* ==========================================================================
   🤖 智能体与子智能体管理弹窗（Agents & Subagents Modal）
   ========================================================================== */
export async function openAgentsModal({ currentAgent = "general", onSelectAgent, onInsertPrompt } = {}) {
  const root = div("hub-layout");
  const leftCol = div("hub-col");
  const rightCol = div("hub-col");
  root.append(leftCol, rightCol);

  const modal = openModal({
    title: "🤖 智能体与专业子智能体中心（Agents & Subagents）",
    size: "xl",
    content: root,
    actions: [{ label: "关闭", kind: "ghost" }],
  });

  leftCol.innerHTML = spinner("正在加载智能体列表…");
  let agents = S.config?.agents || [];
  let allTools = Object.keys(TOOL_LABELS);

  async function reloadData() {
    try {
      const r = await api("/api/agents");
      agents = r.agents || [];
      if (r.tools && r.tools.length) allTools = r.tools;
    } catch (e) {
      toast("加载智能体失败：" + e.message, "error");
    }
    renderList();
  }

  function renderList() {
    leftCol.innerHTML = "";
    leftCol.appendChild(div("hub-col-head", `<h4>可用主控与子智能体（${agents.length}）</h4><span class="muted small">主控可通过 delegate_task / delegate_parallel 自动协同子智能体</span>`));
    const list = div("hub-list");
    agents.forEach((a) => {
      const isSel = a.name === currentAgent;
      const card = div("hub-card spotlight-card" + (isSel ? " selected" : ""));
      const srcBadge = a.builtin
        ? `<span class="badge-s info">${a.name === "general" ? "默认主控" : "内置专业智能体"}</span>`
        : `<span class="badge-s accent">${a.source === "workspace" ? "工作区定义" : "自定义"}</span>`;

      card.appendChild(div("hc-top",
        `<span class="hc-ic">${esc(a.icon || "🤖")}</span>`
        + `<span class="hc-title">${esc(a.title || a.name)}</span>`
        + `<span class="hc-code">${esc(a.name)}</span>`
        + srcBadge
        + `<span class="badge-s muted">${esc(MODE_LABEL[a.mode] || a.mode)} · ≤${a.max_steps || 50}步</span>`));

      if (a.description) card.appendChild(div("hc-desc", esc(a.description)));

      const toolsWrap = div("hc-tools");
      if (Array.isArray(a.allowed_tools) && a.allowed_tools.length) {
        toolsWrap.appendChild(h("span", { class: "hc-tool-tag", text: `限定 ${a.allowed_tools.length} 项工具：` }));
        a.allowed_tools.slice(0, 8).forEach((t) => {
          toolsWrap.appendChild(h("span", { class: "hc-tool-tag", text: `${ICONS[t] || ""} ${TOOL_LABELS[t] || t}`.trim() }));
        });
        if (a.allowed_tools.length > 8) toolsWrap.appendChild(h("span", { class: "hc-tool-tag", text: `+${a.allowed_tools.length - 8}` }));
      } else if (Array.isArray(a.excluded_tools) && a.excluded_tools.length) {
        toolsWrap.appendChild(h("span", { class: "hc-tool-tag", text: `全套工具（排除：${a.excluded_tools.map((t) => TOOL_LABELS[t] || t).join("、")}）` }));
      } else {
        toolsWrap.appendChild(h("span", { class: "hc-tool-tag", text: "全套编程、科研办公与连接器工具" }));
      }
      card.appendChild(toolsWrap);

      const acts = div("hc-acts");
      acts.appendChild(h("button", {
        type: "button",
        class: "btn small " + (isSel ? "ghost" : "primary"),
        text: isSel ? "✓ 当前使用中" : "选用为主智能体",
        onclick: () => {
          onSelectAgent?.(a.name, a);
          toast(`已切换智能体：${a.icon || "🤖"} ${a.title}`, "success");
          modal.close();
        },
      }));
      if (a.name !== "general" && onInsertPrompt) {
        acts.appendChild(h("button", {
          type: "button",
          class: "btn small ghost",
          text: "↘ 委派子任务",
          onclick: () => {
            onInsertPrompt(`请委派子智能体 ${a.name}（${a.title}）执行：`);
            modal.close();
          },
        }));
      }
      if (!a.builtin && a.source === "custom") {
        acts.appendChild(h("button", {
          type: "button",
          class: "btn small ghost",
          text: "✎ 编辑",
          onclick: () => renderForm(a),
        }));
        acts.appendChild(h("button", {
          type: "button",
          class: "btn small ghost danger-text",
          text: "删除",
          onclick: async () => {
            if (!(await confirmDialog(`确定删除自定义智能体「${a.title} (${a.name})」吗？`, { danger: true, okText: "删除" }))) return;
            try {
              await del(`/api/agents/${encodeURIComponent(a.name)}`);
              toast("已删除自定义智能体", "success");
              bus.emit("config:reload");
              await reloadData();
            } catch (e) { toast(e.message, "error"); }
          },
        }));
      }
      card.appendChild(acts);
      list.appendChild(card);
    });
    leftCol.appendChild(list);
  }

  function renderForm(editing = null) {
    rightCol.innerHTML = "";
    const head = div("hub-col-head");
    head.appendChild(h("h4", { text: editing ? `编辑智能体：${editing.name}` : "＋ 创建自定义智能体" }));
    if (editing) {
      head.appendChild(h("button", { type: "button", class: "btn small ghost", text: "切换为新建", onclick: () => renderForm(null) }));
    }
    rightCol.appendChild(head);

    const box = div("hub-form-box");
    const form = h("form", { class: "form", autocomplete: "off" });

    const nameIn = h("input", {
      placeholder: "英文标识，如 quant_auditor",
      value: editing?.name || "",
      disabled: !!editing,
      required: true,
    });
    const titleIn = h("input", { placeholder: "例如：量化风控审计专家", value: editing?.title || "", required: true });
    const iconIn = h("input", { placeholder: "🤖", value: editing?.icon || "🤖", maxlength: "4" });
    const modeIn = h("select", {},
      h("option", { value: "auto", text: "自动模式 (auto)" }),
      h("option", { value: "code", text: "编程模式 (code)" }),
      h("option", { value: "office", text: "办公模式 (office)" }));
    modeIn.value = editing?.mode || "auto";
    const stepsIn = h("input", { type: "number", min: "5", max: "120", value: editing?.max_steps || 45 });
    const descIn = h("input", { placeholder: "一句话说明该智能体擅长的领域与边界", value: editing?.description || "" });
    const promptIn = h("textarea", {
      rows: "5",
      placeholder: "系统提示词（定义角色规范、分析方法、输出标准等）…",
    });
    promptIn.value = editing?.system_prompt || "";

    const restrictChk = h("input", { type: "checkbox" });
    restrictChk.checked = Array.isArray(editing?.allowed_tools) && editing.allowed_tools.length > 0;
    const allowedSet = new Set(editing?.allowed_tools || allTools);

    const toolsGrid = div("tool-checks");
    toolsGrid.hidden = !restrictChk.checked;
    allTools.forEach((t) => {
      const cb = h("input", { type: "checkbox", value: t });
      cb.checked = allowedSet.has(t);
      toolsGrid.appendChild(h("label", { class: "tool-chk" }, cb, h("span", { text: `${ICONS[t] || "🔧"} ${TOOL_LABELS[t] || t}` })));
    });
    restrictChk.onchange = () => { toolsGrid.hidden = !restrictChk.checked; };

    const g1 = div("grid-2");
    g1.append(
      h("div", { class: "field" }, h("label", { text: "唯一标识 (name) *" }), nameIn),
      h("div", { class: "field" }, h("label", { text: "显示名称 *" }), titleIn),
    );
    const g2 = div("grid-3");
    g2.append(
      h("div", { class: "field" }, h("label", { text: "图标" }), iconIn),
      h("div", { class: "field" }, h("label", { text: "默认模式" }), modeIn),
      h("div", { class: "field" }, h("label", { text: "最大步数" }), stepsIn),
    );

    const saveBtn = h("button", { type: "submit", class: "btn primary block", text: editing ? "保存智能体修改" : "创建智能体" });
    form.append(
      g1,
      g2,
      h("div", { class: "field" }, h("label", { text: "职责简介" }), descIn),
      h("div", { class: "field" }, h("label", { text: "系统提示词 (System Prompt)" }), promptIn),
      h("label", { class: "field check" }, restrictChk, h("span", { text: "限定可用工具白名单（不勾选则可使用全部工具）" })),
      toolsGrid,
      saveBtn,
    );

    form.onsubmit = async (e) => {
      e.preventDefault();
      const name = nameIn.value.trim().toLowerCase().replace(/[^a-z0-9_-]/g, "");
      const title = titleIn.value.trim();
      if (!name || !title) { toast("请填写合法的英文标识和显示名称", "warn"); return; }
      const allowed = restrictChk.checked
        ? $$("input[type=checkbox]", toolsGrid).filter((x) => x.checked).map((x) => x.value)
        : [];
      saveBtn.disabled = true;
      try {
        await post("/api/agents", {
          name,
          title,
          icon: iconIn.value.trim() || "🤖",
          mode: modeIn.value,
          max_steps: Number(stepsIn.value) || 45,
          description: descIn.value.trim(),
          system_prompt: promptIn.value.trim(),
          allowed_tools: allowed,
          excluded_tools: [],
        });
        toast(`智能体「${title}」已保存`, "success");
        bus.emit("config:reload");
        await reloadData();
        renderForm(null);
      } catch (err) {
        toast(err.message, "error");
      }
      saveBtn.disabled = false;
    };

    box.appendChild(form);
    rightCol.appendChild(box);
  }

  renderForm(null);
  await reloadData();
}

/* ==========================================================================
   🔌 外部系统与数据源接入中心（Connectors Hub Modal）
   ========================================================================== */
const KIND_META = {
  email: { icon: "📧", short: "邮箱收发", title: "双向邮箱（IMAP/SMTP 读取邮件、线程回复、动态追踪）" },
  calendar: { icon: "📅", short: "日历排期", title: "日历与活动提醒（CalDAV / .ics）" },
  http_api: { icon: "🌐", short: "REST API", title: "REST / SaaS 双向业务接口" },
  web_app: { icon: "🧭", short: "交互网页", title: "招聘 / OA / CRM 交互式网页系统" },
  sqlite: { icon: "🗄", short: "SQLite 库", title: "外部软件 SQLite 数据库" },
  local_folder: { icon: "📂", short: "本地目录", title: "外部软件数据 / 导出目录" },
  webhook: { icon: "🔔", short: "Webhook", title: "飞书 / 钉钉 / 企微 / Slack 机器人" },
  graphql: { icon: "◈", short: "GraphQL", title: "GraphQL 查询与变更端点" },
  mcp: { icon: "🧩", short: "MCP 服务", title: "标准 MCP Stdio 工具服务" },
};

export async function openConnectorsModal({ onInsertConnector } = {}) {
  const root = div("hub-layout");
  const leftCol = div("hub-col");
  const rightCol = div("hub-col");
  root.append(leftCol, rightCol);

  const modal = openModal({
    title: "🔌 外部应用与数据源接入中心（Connectors Hub）",
    size: "xl",
    content: root,
    actions: [{ label: "关闭", kind: "ghost" }],
  });

  leftCol.innerHTML = spinner("正在加载连接器…");
  let connectors = S.config?.connectors || [];

  async function reloadConnectors() {
    try {
      const r = await api("/api/connectors");
      connectors = r.connectors || [];
    } catch (e) {
      toast("加载连接器失败：" + e.message, "error");
    }
    renderConnectorList();
  }

  function targetSummary(c) {
    const cfg = c.config || {};
    return cfg.imap_host || cfg.caldav_url || cfg.webhook_url || cfg.db_path || cfg.base_url || cfg.folder_path || cfg.url
      || (cfg.command ? `${cfg.command} ${(cfg.args || []).join?.(" ") || cfg.args || ""}` : (c.kind === "email" ? "本地沙箱邮箱" : c.kind === "calendar" ? "本地日历引擎" : ""));
  }

  function renderConnectorList() {
    leftCol.innerHTML = "";
    leftCol.appendChild(div("hub-col-head", `<h4>已配置连接器（${connectors.length}）</h4><span class="muted small">点击「插入指令」可在对话框引用 @connector</span>`));
    const list = div("hub-list");
    if (!connectors.length) {
      list.innerHTML = emptyState("🔌", "暂未接入外部数据源", "在右侧选择数据库、REST 接口、本地软件目录、业务网页或 MCP 服务即可一键接入");
      leftCol.appendChild(list);
      return;
    }

    connectors.forEach((c) => {
      const km = KIND_META[c.kind] || { icon: "🔌", short: c.kind, title: c.kind };
      const card = div("hub-card");
      card.appendChild(div("hc-top",
        `<span class="hc-ic">${km.icon}</span>`
        + `<span class="hc-title">${esc(c.title || c.name)}</span>`
        + `<span class="hc-code">@connector:${esc(c.name)}</span>`
        + `<span class="badge-s info">${esc(km.short)}</span>`
        + (c.enabled !== false ? `<span class="badge-s ok">已启用</span>` : `<span class="badge-s muted">已停用</span>`)));

      const sum = targetSummary(c);
      if (sum) card.appendChild(div("muted small mono", esc(sum)));
      if (c.description) card.appendChild(div("hc-desc", esc(c.description)));

      const testSlot = div("");
      testSlot.hidden = true;
      card.appendChild(testSlot);

      const testBtn = h("button", {
        type: "button",
        class: "btn small",
        text: "⚡ 测试连接",
        onclick: async () => {
          testBtn.disabled = true;
          testBtn.textContent = "测试中…";
          testSlot.hidden = false;
          testSlot.className = "conn-test-res";
          testSlot.textContent = "正在连接验证…";
          try {
            const res = await post(`/api/connectors/${encodeURIComponent(c.name)}/test`, {});
            testSlot.className = "conn-test-res " + (res.ok ? "ok" : "err");
            testSlot.textContent = (res.ok ? "✓ " : "✕ ") + (res.summary || (res.ok ? "连接成功" : "连接失败"));
          } catch (e) {
            testSlot.className = "conn-test-res err";
            testSlot.textContent = "✕ " + e.message;
          }
          testBtn.disabled = false;
          testBtn.textContent = "⚡ 测试连接";
        },
      });

      const acts = h("div", { class: "hc-acts" }, testBtn);
      acts.appendChild(h("button", {
        type: "button",
        class: "btn small primary",
        text: "↘ 插入指令",
        onclick: () => {
          onInsertConnector?.(c);
          modal.close();
        },
      }));

      if (c.source === "user" || !c.source) {
        acts.appendChild(h("button", {
          type: "button",
          class: "btn small ghost",
          text: "✎ 编辑",
          onclick: () => renderConnectorForm(c),
        }));
        acts.appendChild(h("button", {
          type: "button",
          class: "btn small ghost danger-text",
          text: "删除",
          onclick: async () => {
            if (!(await confirmDialog(`确定移除连接器「${c.title || c.name}」吗？`, { danger: true, okText: "删除" }))) return;
            try {
              await del(`/api/connectors/${encodeURIComponent(c.name)}`);
              toast("已删除连接器", "success");
              bus.emit("config:reload");
              await reloadConnectors();
            } catch (e) { toast(e.message, "error"); }
          },
        }));
      }
      card.appendChild(acts);
      list.appendChild(card);
    });
    leftCol.appendChild(list);
  }

  function renderConnectorForm(editing = null) {
    rightCol.innerHTML = "";
    let kind = editing?.kind || "sqlite";
    const head = div("hub-col-head");
    head.appendChild(h("h4", { text: editing ? `编辑连接器：${editing.name}` : "＋ 新增外部连接器" }));
    if (editing) {
      head.appendChild(h("button", { type: "button", class: "btn small ghost", text: "切换为新建", onclick: () => renderConnectorForm(null) }));
    }
    rightCol.appendChild(head);

    const box = div("hub-form-box");
    const kindGrid = div("kind-grid");
    const dynBox = div("form");

    const nameIn = h("input", {
      placeholder: "英文标识，如 erp_sqlite / github_api",
      value: editing?.name || "",
      disabled: !!editing,
      required: true,
    });
    const titleIn = h("input", { placeholder: "显示名称，如：财务系统数据库", value: editing?.title || "", required: true });
    const descIn = h("input", { placeholder: "可选：说明包含哪些表、接口或数据用途", value: editing?.description || "" });
    const enabledIn = h("input", { type: "checkbox" });
    enabledIn.checked = editing ? editing.enabled !== false : true;

    let collectConfig = () => ({});

    function buildKindFields(k, cfg = {}) {
      kind = k;
      $$(".kind-btn", kindGrid).forEach((b) => b.classList.toggle("active", b.dataset.kind === k));
      dynBox.innerHTML = "";

      if (k === "sqlite") {
        const dbPath = h("input", { placeholder: "/path/to/database.sqlite 或 ~/Documents/app.db", value: cfg.db_path || "", required: true });
        dynBox.appendChild(h("div", { class: "field" },
          h("label", { text: "SQLite 数据库文件路径 (db_path) *" }),
          dbPath,
          h("div", { class: "hint", text: "采用只读模式 (mode=ro) 安全连接，自动探查表结构并支持 SQL 查询分析" })));
        collectConfig = () => {
          if (!dbPath.value.trim()) throw new Error("请填写 SQLite 数据库文件路径");
          return { db_path: dbPath.value.trim() };
        };
      } else if (k === "http_api") {
        const baseUrl = h("input", { placeholder: "https://api.example.com/v1", value: cfg.base_url || "", required: true });
        const defEp = h("input", { placeholder: "可选，如 /status 或 /projects（用于测试连接）", value: cfg.default_endpoint || "" });
        const authType = h("select", {},
          h("option", { value: "none", text: "无认证 (None)" }),
          h("option", { value: "bearer", text: "Bearer Token (Authorization: Bearer …)" }),
          h("option", { value: "header", text: "自定义请求头 (Header API Key)" }),
          h("option", { value: "query", text: "URL 查询参数 (Query Key)" }),
          h("option", { value: "basic", text: "Basic Auth (username:password)" }));
        authType.value = cfg.auth_type || "none";
        const authKey = h("input", { placeholder: "Header 或参数名，如 X-API-Key", value: cfg.auth_key || "X-API-Key" });
        const authVal = h("input", { type: "password", placeholder: "Token / API Key / user:pass", value: cfg.auth_value || "", autocomplete: "new-password" });
        const authKeyWrap = h("div", { class: "field" }, h("label", { text: "认证键名 (auth_key)" }), authKey);
        const authValWrap = h("div", { class: "field" }, h("label", { text: "认证凭证 (auth_value)" }), authVal);
        const syncAuthVis = () => {
          authKeyWrap.hidden = !["header", "query"].includes(authType.value);
          authValWrap.hidden = authType.value === "none";
        };
        authType.onchange = syncAuthVis;
        syncAuthVis();

        dynBox.append(
          h("div", { class: "field" }, h("label", { text: "接口根地址 (base_url) *" }), baseUrl),
          h("div", { class: "field" }, h("label", { text: "默认测试端点 (default_endpoint)" }), defEp),
          h("div", { class: "field" }, h("label", { text: "认证方式 (auth_type)" }), authType),
          authKeyWrap,
          authValWrap,
        );
        collectConfig = () => {
          if (!baseUrl.value.trim()) throw new Error("请填写 Base URL");
          return {
            base_url: baseUrl.value.trim(),
            default_endpoint: defEp.value.trim(),
            auth_type: authType.value,
            auth_key: authKey.value.trim(),
            auth_value: authVal.value.trim(),
          };
        };
      } else if (k === "local_folder") {
        const folderPath = h("input", { placeholder: "/Users/.../Exports 或外部软件数据目录", value: cfg.folder_path || "", required: true });
        dynBox.appendChild(h("div", { class: "field" },
          h("label", { text: "外部软件数据目录路径 (folder_path) *" }),
          folderPath,
          h("div", { class: "hint", text: "受控只读访问指定目录下的 Excel / Word / PDF / CSV / JSON 文件" })));
        collectConfig = () => {
          if (!folderPath.value.trim()) throw new Error("请填写本地目录路径");
          return { folder_path: folderPath.value.trim() };
        };
      } else if (k === "web_app") {
        const urlIn = h("input", { placeholder: "https://dashboard.example.com/reports", value: cfg.url || "", required: true });
        const cookiesIn = h("input", { type: "password", placeholder: "可选：session=...; token=...", value: cfg.cookies || "", autocomplete: "new-password" });
        const headersIn = h("textarea", { rows: "2", placeholder: '可选 JSON 请求头，如 {"X-Org": "hq"}' });
        headersIn.value = cfg.headers ? JSON.stringify(cfg.headers) : "";
        const jsChk = h("input", { type: "checkbox" });
        jsChk.checked = cfg.render_js !== false;
        dynBox.append(
          h("div", { class: "field" }, h("label", { text: "业务网页地址 (url) *" }), urlIn),
          h("div", { class: "field" }, h("label", { text: "登录态 Cookie（加密存储）" }), cookiesIn),
          h("div", { class: "field" }, h("label", { text: "自定义请求头 JSON" }), headersIn),
          h("label", { class: "field check" }, jsChk, h("span", { text: "启用无头浏览器渲染动态 JS 与自动提取表格" })),
        );
        collectConfig = () => {
          if (!urlIn.value.trim()) throw new Error("请填写网页 URL");
          let headers;
          if (headersIn.value.trim()) {
            try { headers = JSON.parse(headersIn.value.trim()); } catch { throw new Error("自定义请求头需为合法 JSON 对象"); }
          }
          return { url: urlIn.value.trim(), cookies: cookiesIn.value.trim(), headers, render_js: jsChk.checked };
        };
      } else if (k === "mcp") {
        const cmdIn = h("input", { placeholder: "例如：npx 或 uvx 或 python3", value: cfg.command || "", required: true });
        const argsStr = Array.isArray(cfg.args) ? cfg.args.join(" ") : (cfg.args || "");
        const argsIn = h("input", { placeholder: "-y @modelcontextprotocol/server-filesystem /path", value: argsStr });
        const cwdIn = h("input", { placeholder: "可选工作目录", value: cfg.cwd || "" });
        const envIn = h("textarea", { rows: "2", placeholder: '可选环境变量 JSON，如 {"GITHUB_TOKEN": "..."}' });
        envIn.value = cfg.env ? JSON.stringify(cfg.env) : "";
        dynBox.append(
          h("div", { class: "field" }, h("label", { text: "启动命令 (command) *" }), cmdIn),
          h("div", { class: "field" }, h("label", { text: "命令参数 (args)" }), argsIn),
          h("div", { class: "field" }, h("label", { text: "工作目录 (cwd)" }), cwdIn),
          h("div", { class: "field" }, h("label", { text: "环境变量 JSON (env)" }), envIn),
        );
        collectConfig = () => {
          if (!cmdIn.value.trim()) throw new Error("请填写 MCP 启动命令");
          let env;
          if (envIn.value.trim()) {
            try { env = JSON.parse(envIn.value.trim()); } catch { throw new Error("环境变量需为合法 JSON 对象"); }
          }
          const args = argsIn.value.trim() ? argsIn.value.trim().split(/\s+/) : [];
          return { command: cmdIn.value.trim(), args, cwd: cwdIn.value.trim() || undefined, env };
        };
      } else if (k === "email") {
        const imapHost = h("input", { placeholder: "如 imap.qq.com / imap.gmail.com（留空则启用本地沙箱邮箱）", value: cfg.imap_host || "" });
        const smtpHost = h("input", { placeholder: "如 smtp.qq.com / smtp.gmail.com", value: cfg.smtp_host || "" });
        const userIn = h("input", { placeholder: "邮箱账号，如 user@company.com", value: cfg.username || "" });
        const passIn = h("input", { type: "password", placeholder: "IMAP/SMTP 授权码或应用专用密码（加密存储）", value: cfg.password || "", autocomplete: "new-password" });
        dynBox.append(
          h("div", { class: "grid-2" },
            h("div", { class: "field" }, h("label", { text: "IMAP 服务器" }), imapHost),
            h("div", { class: "field" }, h("label", { text: "SMTP 服务器" }), smtpHost)),
          h("div", { class: "grid-2" },
            h("div", { class: "field" }, h("label", { text: "邮箱账号 (username)" }), userIn),
            h("div", { class: "field" }, h("label", { text: "授权码 / 密码" }), passIn)),
          h("div", { class: "hint", text: "支持读取未读邮件、提取附件、保持线程发送回复及持续追踪对方回信；留空服务器地址可使用本地沙箱邮箱测试" }),
        );
        collectConfig = () => ({
          imap_host: imapHost.value.trim(),
          smtp_host: smtpHost.value.trim(),
          username: userIn.value.trim(),
          password: passIn.value.trim(),
          mode: imapHost.value.trim() ? "imap_smtp" : "sandbox",
        });
      } else if (k === "calendar") {
        const calUrl = h("input", { placeholder: "可选 CalDAV 地址（留空则使用本地持久化日历与 .ics 引擎）", value: cfg.caldav_url || "" });
        const cUser = h("input", { placeholder: "可选 CalDAV 用户名", value: cfg.username || "" });
        const cPass = h("input", { type: "password", placeholder: "可选 CalDAV 密码", value: cfg.password || "", autocomplete: "new-password" });
        dynBox.append(
          h("div", { class: "field" }, h("label", { text: "CalDAV 同步地址 (caldav_url)" }), calUrl),
          h("div", { class: "grid-2" },
            h("div", { class: "field" }, h("label", { text: "账号" }), cUser),
            h("div", { class: "field" }, h("label", { text: "密码" }), cPass)),
          h("div", { class: "hint", text: "支持读取日程、检测会议冲突、创建/改期活动、提前提醒及生成标准 .ics 邀请函" }),
        );
        collectConfig = () => ({ caldav_url: calUrl.value.trim(), username: cUser.value.trim(), password: cPass.value.trim() });
      } else if (k === "webhook") {
        const whUrl = h("input", { placeholder: "https://open.feishu.cn/open-apis/bot/v2/hook/... 或钉钉/企微/Slack 地址", value: cfg.webhook_url || "", required: true });
        dynBox.appendChild(h("div", { class: "field" }, h("label", { text: "Webhook URL *" }), whUrl));
        collectConfig = () => {
          if (!whUrl.value.trim()) throw new Error("请填写 Webhook URL");
          return { webhook_url: whUrl.value.trim() };
        };
      } else if (k === "graphql") {
        const gUrl = h("input", { placeholder: "https://api.example.com/graphql", value: cfg.base_url || "", required: true });
        const gTok = h("input", { type: "password", placeholder: "可选 Bearer Token", value: cfg.auth_value || "", autocomplete: "new-password" });
        dynBox.append(
          h("div", { class: "field" }, h("label", { text: "GraphQL 端点 *" }), gUrl),
          h("div", { class: "field" }, h("label", { text: "Bearer Token" }), gTok),
        );
        collectConfig = () => {
          if (!gUrl.value.trim()) throw new Error("请填写 GraphQL 端点 URL");
          return { base_url: gUrl.value.trim(), auth_type: gTok.value.trim() ? "bearer" : "none", auth_value: gTok.value.trim() };
        };
      }
    }

    Object.entries(KIND_META).forEach(([k, meta]) => {
      const b = h("button", {
        type: "button",
        class: "kind-btn" + (k === kind ? " active" : ""),
        dataset: { kind: k },
        title: meta.title,
        onclick: () => buildKindFields(k, editing?.kind === k ? editing.config : {}),
      }, h("span", { text: meta.icon }), h("span", { text: meta.short }));
      kindGrid.appendChild(b);
    });

    buildKindFields(kind, editing?.config || {});

    const form = h("form", { class: "form", autocomplete: "off" });
    const g1 = div("grid-2");
    g1.append(
      h("div", { class: "field" }, h("label", { text: "连接器标识 (name) *" }), nameIn),
      h("div", { class: "field" }, h("label", { text: "显示名称 *" }), titleIn),
    );

    const formTestBanner = div("");
    formTestBanner.hidden = true;

    const saveBtn = h("button", { type: "submit", class: "btn primary", text: "保存连接器" });
    const saveTestBtn = h("button", { type: "button", class: "btn", text: "⚡ 保存并测试" });

    async function submitConnector(andTest = false) {
      const name = nameIn.value.trim().replace(/[^\w.-]/g, "");
      const title = titleIn.value.trim();
      if (!name || !title) { toast("请填写连接器标识和显示名称", "warn"); return; }
      let cfg;
      try { cfg = collectConfig(); } catch (err) { toast(err.message, "warn"); return; }

      saveBtn.disabled = saveTestBtn.disabled = true;
      try {
        await post("/api/connectors", {
          name,
          title,
          kind,
          description: descIn.value.trim(),
          config: cfg,
          enabled: enabledIn.checked,
        });
        bus.emit("config:reload");
        await reloadConnectors();
        if (andTest) {
          formTestBanner.hidden = false;
          formTestBanner.className = "conn-test-res";
          formTestBanner.textContent = "已保存，正在执行连接测试…";
          const res = await post(`/api/connectors/${encodeURIComponent(name)}/test`, {});
          formTestBanner.className = "conn-test-res " + (res.ok ? "ok" : "err");
          formTestBanner.textContent = (res.ok ? "✓ " : "✕ ") + (res.summary || "");
        } else {
          toast(`连接器「${title}」已保存`, "success");
          renderConnectorForm(null);
        }
      } catch (err) {
        toast(err.message, "error");
      }
      saveBtn.disabled = saveTestBtn.disabled = false;
    }

    form.onsubmit = (e) => { e.preventDefault(); submitConnector(false); };
    saveTestBtn.onclick = () => submitConnector(true);

    form.append(
      g1,
      dynBox,
      h("div", { class: "field" }, h("label", { text: "备注说明" }), descIn),
      h("label", { class: "field check" }, enabledIn, h("span", { text: "启用该连接器（智能体可通过 list_connectors / connector_query 调用）" })),
      formTestBanner,
      h("div", { class: "hc-acts" }, saveBtn, saveTestBtn),
    );

    box.append(kindGrid, form);
    rightCol.appendChild(box);
  }

  renderConnectorForm(null);
  await reloadConnectors();
}
