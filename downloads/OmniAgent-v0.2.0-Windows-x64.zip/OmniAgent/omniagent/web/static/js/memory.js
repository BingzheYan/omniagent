/* 长期记忆、多维用户画像与在办文稿连续性工作台（Memory & Persona Studio） */
import { S } from "./state.js";
import { $, $$, esc, h, div, fmtRelative, debounce } from "./util.js";
import { api, post, put, del } from "./api.js";
import { toast, openModal, confirmDialog, spinner, emptyState } from "./ui.js";
import { SVG } from "./icons.js";

const DIM_ICONS = {
  identity: SVG.userCard,
  official_doc_format: SVG.fileText,
  academic_paper_format: SVG.academic,
  writing_style: SVG.edit,
  coding_prefs: SVG.code,
  data_and_workflow: SVG.chart,
};

const PRESET_TRAITS = [
  { dimension: "official_doc_format", trait_key: "gongwen_standard", label: "GB/T 9704 党政公文规范",
    value: "起草公文严格遵循 GB/T 9704 标准：标题二号小标宋、正文三号仿宋_GB2312、四级标题序号「一、（一）1.（1）」，庄重严谨。" },
  { dimension: "academic_paper_format", trait_key: "target_journal", label: "《财政研究》期刊体例",
    value: "学术论文参照《财政研究》《经济研究》体例：标准学术三线表、括号内报告聚类稳健标准误、先文字引出图表再做机制解读。" },
  { dimension: "writing_style", trait_key: "conclusion_first", label: "结论先行·拒绝空洞套话",
    value: "报告采用「核心结论先行 + 数据证据支撑」结构，严禁使用空泛过渡词与 AI 套话，关键判断均附具体数值与变动幅度。" },
  { dimension: "data_and_workflow", trait_key: "number_unit", label: "金额万元·保留两位小数",
    value: "统计报表金额统一折算为「万元」，描述性统计与增长率保留 2 位小数，回归系数保留 3 位小数；修改文稿默认保留原件另存修订版。" },
  { dimension: "coding_prefs", trait_key: "python_modern", label: "Python 类型注解与 pytest",
    value: "Python 工程统一使用完整类型注解（Type Hints）、最小侵入式 Diff 修改，并在交付前运行 pytest 验证无回归。" },
];

const STATUS_META = {
  active: { label: "进行中", cls: "info" },
  blocked: { label: "待决策/阻塞", cls: "warn" },
  completed: { label: "已定稿/完结", cls: "ok" },
  archived: { label: "已归档", cls: "muted" },
};

export function syncMemoryBadge(stats) {
  if (!stats) return;
  if (S.config) S.config.memory_stats = stats;
  const badge = $("#sb-mem-badge");
  if (!badge) return;
  const total = (Number(stats.traits) || 0) + (Number(stats.memories) || 0) + (Number(stats.active_projects) || 0);
  badge.hidden = total === 0;
  badge.textContent = String(total);
}

export async function openMemoryModal({ initialTab = "portrait", onContinueProject, onPreviewFile } = {}) {
  const wrap = div("mem-studio");
  const topBar = div("mem-topbar");
  const bodyWrap = div("mem-body-wrap");
  wrap.append(topBar, bodyWrap);

  const modal = openModal({
    title: "记忆与用户画像中心（Long-Term Memory & Persona）",
    size: "xl",
    content: wrap,
    actions: [{ label: "完成", kind: "ghost" }],
  });

  let activeTab = initialTab || "portrait";
  let data = null;
  let searchQ = "";
  let filterCat = "";
  let editingProject = null;
  let editingMemory = null;

  bodyWrap.innerHTML = spinner("正在读取用户画像与长期记忆库…");

  async function loadOverview() {
    try {
      const qs = new URLSearchParams();
      if (searchQ) qs.set("q", searchQ);
      if (filterCat) qs.set("category", filterCat);
      data = await api("/api/memory" + (qs.toString() ? `?${qs}` : ""));
      syncMemoryBadge(data.stats);
      renderAll();
    } catch (e) {
      bodyWrap.innerHTML = `<div class="empty">加载记忆库失败：${esc(e.message)}</div>`;
    }
  }

  function renderTopBar() {
    const st = data?.stats || { traits: 0, memories: 0, active_projects: 0 };
    const enabled = data?.memory_enabled !== false;
    topBar.innerHTML = "";

    const tabs = h("div", { class: "segmented mem-tabs", role: "tablist" },
      tabBtn("portrait", "用户画像", st.traits),
      tabBtn("projects", "在办工作与文稿", st.active_projects),
      tabBtn("memories", "长期记忆库", st.memories),
    );

    const controls = div("mem-top-controls");
    const toggleLabel = h("label", { class: "mem-switch", title: "开启后，系统会从日常对话、纠错与工具使用习惯中自动提炼画像并追踪在办文稿进度" },
      h("input", {
        type: "checkbox",
        checked: enabled,
        onchange: async (ev) => {
          const val = ev.target.checked;
          try {
            await put("/api/me/settings", { memory_enabled: val });
            if (S.settings) S.settings.memory_enabled = val;
            if (data) data.memory_enabled = val;
            toast(val ? "已开启自动记忆与画像学习" : "已暂停自动记忆提炼", "info");
          } catch (err) {
            ev.target.checked = !val;
            toast("更新设置失败：" + err.message, "error");
          }
        },
      }),
      h("span", { text: "自动学习习惯与进度" }),
    );

    const clearBtn = h("button", {
      type: "button",
      class: "btn small ghost danger-text",
      html: `${SVG.trash}<span>清空记忆</span>`,
      onclick: async () => {
        const ok = await confirmDialog({
          title: "清空全部长期记忆与用户画像",
          message: "确定清空当前账号下的所有用户画像特征、在办文稿进度与长期记忆条目吗？此操作不可撤销（不影响已有对话记录与工作区文件）。",
          confirmText: "确认清空",
          danger: true,
        });
        if (!ok) return;
        const r = await del("/api/memory/clear");
        syncMemoryBadge(r.stats);
        toast("已清空全部长期记忆", "info");
        await loadOverview();
      },
    });

    controls.append(toggleLabel, clearBtn);
    topBar.append(tabs, controls);
  }

  function tabBtn(id, label, count) {
    return h("button", {
      type: "button",
      class: "seg" + (activeTab === id ? " active" : ""),
      onclick: () => {
        activeTab = id;
        renderAll();
      },
    },
    h("span", { text: label }),
    count > 0 ? h("span", { class: "mem-tab-cnt", text: String(count) }) : null);
  }

  function renderAll() {
    renderTopBar();
    bodyWrap.innerHTML = "";
    if (activeTab === "portrait") renderPortraitTab();
    else if (activeTab === "projects") renderProjectsTab();
    else renderMemoriesTab();
  }

  /* ========================================================================
     Tab 1: 用户画像（6 大维度结构化画像 + 一键预设 + 手动补充）
     ======================================================================== */
  function renderPortraitTab() {
    const dims = data?.portrait?.dimensions || [];
    const intro = div("mem-banner",
      `<div class="mem-banner-ic">${SVG.sparkles}</div>`
      + `<div class="mem-banner-text"><b>动态演化用户画像</b><span>OmniAgent 会从你的公文/论文格式指令、审改偏好与高频工具习惯中描绘专属画像，并在每次新对话中自动贴合，无需重复交代。</span></div>`);
    bodyWrap.appendChild(intro);

    // 快捷习惯模板条
    const presetRow = div("mem-presets");
    presetRow.appendChild(h("span", { class: "mem-preset-label", text: "一键注入常用体例：" }));
    PRESET_TRAITS.forEach((p) => {
      presetRow.appendChild(h("button", {
        type: "button",
        class: "mem-preset-chip",
        title: p.value,
        html: `${SVG.plus}<span>${esc(p.label)}</span>`,
        onclick: async () => {
          await put("/api/memory/portrait", { dimension: p.dimension, trait_key: p.trait_key, value: p.value });
          await post("/api/memory/items", {
            content: p.value,
            category: p.dimension.includes("format") ? "format_spec" : "preference",
            topic_key: p.trait_key,
            importance: 4,
          });
          toast(`已写入画像规范：${p.label}`, "success");
          await loadOverview();
        },
      }));
    });
    bodyWrap.appendChild(presetRow);

    // 6 大画像维度网格
    const grid = div("mem-dim-grid");
    dims.forEach((d) => {
      const card = div("mem-dim-card spotlight-card");
      const head = div("mem-dim-head");
      head.innerHTML = `<span class="mem-dim-ic">${DIM_ICONS[d.dimension] || SVG.brain}</span>`
        + `<div class="mem-dim-meta"><h4>${esc(d.title)}</h4><p>${esc(d.desc)}</p></div>`
        + `<span class="badge-s ${d.traits.length ? "info" : ""}">${d.traits.length} 项</span>`;
      card.appendChild(head);

      const list = div("mem-trait-list");
      if (!d.traits.length) {
        list.appendChild(div("mem-trait-empty", "暂未捕获该维度习惯，可在日常对话中自然表达或在下方手动添加"));
      } else {
        d.traits.forEach((tr) => {
          const pct = Math.round((Number(tr.confidence) || 0.8) * 100);
          const row = div("mem-trait-row");
          const srcTag = tr.source === "explicit"
            ? `<span class="mem-src explicit">明确要求</span>`
            : `<span class="mem-src inferred">习惯归纳 · ${tr.evidence_count || 1}次</span>`;
          row.append(
            div("mem-trait-main",
              `<span class="mem-trait-val">${esc(tr.value)}</span>`
              + `<div class="mem-trait-sub">${srcTag}<span class="mem-conf" title="画像置信度">置信度 ${pct}%</span></div>`),
            h("button", {
              type: "button",
              class: "icon-btn xs mem-del-btn",
              title: "移除该画像特征",
              html: SVG.close,
              onclick: async () => {
                await del(`/api/memory/portrait?dimension=${encodeURIComponent(d.dimension)}&trait_key=${encodeURIComponent(tr.trait_key)}`);
                await loadOverview();
              },
            }),
          );
          list.appendChild(row);
        });
      }
      card.appendChild(list);
      grid.appendChild(card);
    });
    bodyWrap.appendChild(grid);

    // 手动添加画像特征栏
    const addBox = h("form", { class: "mem-quick-form" });
    const selDim = h("select", { "aria-label": "画像维度" },
      dims.map((d) => h("option", { value: d.dimension, text: d.title })));
    const inpVal = h("input", {
      type: "text",
      placeholder: "补充你的个人习惯或格式标准（如：汇报材料一律用「一、（一）1.」序号，图表使用蓝灰学术配色）…",
      required: true,
    });
    const btnAdd = h("button", { type: "submit", class: "btn primary small", text: "添加至画像" });
    addBox.append(selDim, inpVal, btnAdd);
    addBox.onsubmit = async (ev) => {
      ev.preventDefault();
      const val = inpVal.value.trim();
      if (!val) return;
      btnAdd.disabled = true;
      try {
        await put("/api/memory/portrait", { dimension: selDim.value, value: val });
        await post("/api/memory/items", {
          content: val,
          category: selDim.value.includes("format") ? "format_spec" : "preference",
          importance: 4,
        });
        inpVal.value = "";
        toast("已添加至用户画像与长期记忆", "success");
        await loadOverview();
      } catch (e) {
        toast("保存失败：" + e.message, "error");
      } finally {
        btnAdd.disabled = false;
      }
    };
    bodyWrap.appendChild(addBox);
  }

  /* ========================================================================
     Tab 2: 在办工作与文稿连续性（Ongoing Projects — 已完成 vs 待完善）
     ======================================================================== */
  function renderProjectsTab() {
    const projects = data?.projects || [];
    const kinds = data?.project_kinds || { paper: "学术论文", official_doc: "公文方案", report: "数据分析报告", code_project: "软件工程", general: "综合事项" };

    const layout = div("hub-layout");
    const leftCol = div("hub-col");
    const rightCol = div("hub-col");
    layout.append(leftCol, rightCol);
    bodyWrap.appendChild(layout);

    leftCol.appendChild(div("hub-col-head",
      `<h4>在办文稿、报告与工程（${projects.length}）</h4>`
      + `<span class="muted small">自动记录同一篇报告/论文「已做哪些内容、还有哪些待完善」</span>`));

    if (!projects.length) {
      leftCol.appendChild(emptyState(SVG.fileText, "暂无在办工作记录", "当你在对话中撰写论文报告、推进多步研发或提及「后面再补充…」时，系统会自动在此建立连续性台账。"));
    } else {
      const list = div("hub-list");
      projects.forEach((p) => {
        const st = STATUS_META[p.status] || STATUS_META.active;
        const card = div("mem-proj-card spotlight-card");
        card.appendChild(div("mp-head",
          `<div class="mp-title-row">`
          + `<span class="badge-s info">${esc(p.kind_label || kinds[p.kind] || p.kind)}</span>`
          + `<strong class="mp-title">${esc(p.title)}</strong>`
          + `<span class="badge-s ${st.cls}">${esc(st.label)}</span>`
          + `</div>`
          + `<div class="mp-prog-row"><div class="progress sm"><div class="bar" style="width:${p.progress_pct || 0}%"></div></div>`
          + `<span class="mp-pct">${p.progress_pct || 0}% · 更新于 ${fmtRelative(p.updated)}</span></div>`));

        if (p.summary) card.appendChild(div("mp-summary", esc(p.summary)));

        const cols = div("mp-columns");
        const doneBox = div("mp-col done");
        doneBox.appendChild(div("mp-col-title", `已完成内容（${(p.completed_items || []).length}）`));
        if ((p.completed_items || []).length) {
          const ul = h("ul", { class: "mp-list" });
          p.completed_items.forEach((it) => ul.appendChild(h("li", { text: it })));
          doneBox.appendChild(ul);
        } else {
          doneBox.appendChild(div("mp-empty", "尚无已完成记录"));
        }

        const pendBox = div("mp-col pending");
        pendBox.appendChild(div("mp-col-title", `待完善 / 下一步（${(p.pending_items || []).length}）`));
        if ((p.pending_items || []).length) {
          const ul = h("ul", { class: "mp-list" });
          p.pending_items.forEach((it) => ul.appendChild(h("li", { text: it })));
          pendBox.appendChild(ul);
        } else {
          pendBox.appendChild(div("mp-empty", "当前无遗留待办事项"));
        }
        cols.append(doneBox, pendBox);
        card.appendChild(cols);

        if ((p.key_facts || []).length) {
          card.appendChild(div("mp-facts", `<b>锁定口径：</b>${p.key_facts.map(esc).join(" ； ")}`));
        }

        if ((p.artifacts || []).length) {
          const arts = div("mp-arts");
          p.artifacts.forEach((path) => {
            arts.appendChild(h("button", {
              type: "button",
              class: "hc-tool-tag mp-art-chip",
              text: path,
              title: "在右侧工作台预览该文件",
              onclick: () => {
                if (onPreviewFile) { modal.close(); onPreviewFile(path); }
              },
            }));
          });
          card.appendChild(arts);
        }

        const acts = div("hc-acts");
        if (onContinueProject) {
          acts.appendChild(h("button", {
            type: "button",
            class: "btn small primary",
            html: `<span>继续推进待完善项</span>${SVG.arrowUpRight}`,
            onclick: () => {
              const pend = (p.pending_items || []).length
                ? `重点完成以下待完善事项：\n${p.pending_items.map((x, idx) => `${idx + 1}. ${x}`).join("\n")}`
                : "对已有初稿做进一步深化润色与质量核验";
              const artHint = (p.artifacts || []).length ? `（关联文件：${p.artifacts.join(", ")}）` : "";
              const prompt = `继续推进在办项目「${p.title}」${artHint}。\n请基于长期记忆中已完成的进度衔接工作，${pend}`;
              modal.close();
              onContinueProject(prompt, p);
            },
          }));
        }
        acts.appendChild(h("button", {
          type: "button",
          class: "btn small ghost",
          text: "编辑台账",
          onclick: () => { editingProject = p; renderProjectForm(rightCol, kinds); },
        }));
        acts.appendChild(h("button", {
          type: "button",
          class: "btn small ghost danger-text",
          text: "删除",
          onclick: async () => {
            const r = await del(`/api/memory/projects/${encodeURIComponent(p.slug)}`);
            syncMemoryBadge(r.stats);
            if (editingProject?.slug === p.slug) editingProject = null;
            await loadOverview();
          },
        }));
        card.appendChild(acts);
        list.appendChild(card);
      });
      leftCol.appendChild(list);
    }

    renderProjectForm(rightCol, kinds);
  }

  function renderProjectForm(container, kinds) {
    container.innerHTML = "";
    const p = editingProject || {};
    container.appendChild(div("hub-col-head",
      `<h4>${editingProject ? `编辑项目：${esc(p.title)}` : "登记在办文稿 / 项目台账"}</h4>`));

    const box = h("form", { class: "form hub-form-box" });
    box.innerHTML = `
      <div class="field"><label>文稿 / 报告 / 项目标题 *</label>
        <input name="title" required placeholder="如：数字财政与地方产业升级实证论文" value="${esc(p.title || "")}"></div>
      <div class="grid-2">
        <div class="field"><label>成果类型</label>
          <select name="kind">${Object.entries(kinds).map(([k, v]) => `<option value="${esc(k)}"${(p.kind || "report") === k ? " selected" : ""}>${esc(v)}</option>`).join("")}</select></div>
        <div class="field"><label>当前状态</label>
          <select name="status">
            <option value="active"${(p.status || "active") === "active" ? " selected" : ""}>进行中</option>
            <option value="blocked"${p.status === "blocked" ? " selected" : ""}>待补充数据/阻塞</option>
            <option value="completed"${p.status === "completed" ? " selected" : ""}>已定稿完结</option>
            <option value="archived"${p.status === "archived" ? " selected" : ""}>已归档</option>
          </select></div>
      </div>
      <div class="field"><label>整体进展摘要</label>
        <input name="summary" placeholder="一句话概括当前版本进展与核心目标" value="${esc(p.summary || "")}"></div>
      <div class="field"><label>已完成内容（每行一项）</label>
        <textarea name="completed_items" rows="3" placeholder="已完成引言与文献综述&#10;已完成双向固定效应基准回归表">${esc((p.completed_items || []).join("\n"))}</textarea></div>
      <div class="field"><label>待完善事项 / 下一步计划（每行一项）</label>
        <textarea name="pending_items" rows="3" placeholder="补充安慰剂检验与工具变量稳健性检验&#10;撰写第五章政策建议并导出双栏 PDF">${esc((p.pending_items || []).join("\n"))}</textarea></div>
      <div class="field"><label>跨会话锁定的核心口径 / 结论（每行一项）</label>
        <textarea name="key_facts" rows="2" placeholder="样本区间：2015-2024年31省面板；金额单位：亿元">${esc((p.key_facts || []).join("\n"))}</textarea></div>
      <div class="field"><label>关联工作区文件路径（每行一个）</label>
        <input name="artifacts" placeholder="outputs/fiscal_report.docx" value="${esc((p.artifacts || []).join(", "))}"></div>
      <div class="row" style="justify-content:flex-end;gap:8px">
        ${editingProject ? `<button type="button" class="btn small ghost" id="mp-cancel">新建模式</button>` : ""}
        <button type="submit" class="btn small primary">${editingProject ? "保存项目更新" : "创建项目台账"}</button>
      </div>
    `;
    const cancelBtn = box.querySelector("#mp-cancel");
    if (cancelBtn) cancelBtn.onclick = () => { editingProject = null; renderProjectForm(container, kinds); };
    box.onsubmit = async (ev) => {
      ev.preventDefault();
      const fd = new FormData(box);
      const arts = String(fd.get("artifacts") || "").split(/[,，\n]+/).map((s) => s.trim()).filter(Boolean);
      try {
        const r = await post("/api/memory/projects", {
          slug: editingProject?.slug || "",
          title: fd.get("title"),
          kind: fd.get("kind"),
          status: fd.get("status"),
          summary: fd.get("summary"),
          completed_items: fd.get("completed_items"),
          pending_items: fd.get("pending_items"),
          key_facts: fd.get("key_facts"),
          artifacts: arts,
          merge: false,
        });
        syncMemoryBadge(r.stats);
        editingProject = null;
        toast("已保存在办项目进度", "success");
        await loadOverview();
      } catch (e) {
        toast("保存失败：" + e.message, "error");
      }
    };
    container.appendChild(box);
  }

  /* ========================================================================
     Tab 3: 长期记忆库（检索、分类筛选、置顶常驻、冲突覆盖与增删改）
     ======================================================================== */
  function renderMemoriesTab() {
    const memories = data?.memories || [];
    const cats = data?.categories || {
      format_spec: "格式与体例规范",
      correction: "纠错与避坑教训",
      preference: "个人习惯与偏好",
      domain_fact: "业务口径与背景事实",
      episodic: "历史任务纪要",
    };

    const layout = div("hub-layout");
    const leftCol = div("hub-col");
    const rightCol = div("hub-col");
    layout.append(leftCol, rightCol);
    bodyWrap.appendChild(layout);

    // 搜索与分类筛选条
    const filterWrap = div("mem-filter-bar");
    const searchInput = h("input", {
      type: "search",
      class: "mem-search-inp",
      placeholder: "搜索长期记忆（如：公文、三线表、万元、不要用）…",
      value: searchQ,
    });
    const runSearch = debounce(() => { searchQ = searchInput.value.trim(); loadOverview(); }, 220);
    searchInput.oninput = runSearch;

    const chips = div("mem-cat-chips");
    chips.appendChild(catChip("", "全部", filterCat === ""));
    Object.entries(cats).forEach(([k, label]) => {
      chips.appendChild(catChip(k, label, filterCat === k));
    });
    filterWrap.append(searchInput, chips);
    leftCol.appendChild(filterWrap);

    if (!memories.length) {
      leftCol.appendChild(emptyState(SVG.brain, "暂无匹配的长期记忆", "在对话中说「记住以后公文统一用 GB/T 9704 格式」或纠正智能体的偏差，系统会自动提炼并沉淀到这里。"));
    } else {
      const list = div("hub-list");
      memories.forEach((m) => {
        const card = div("hub-card mem-item-card spotlight-card" + (m.pinned ? " pinned" : ""));
        const catTone = m.category === "correction" ? "warn" : m.category === "format_spec" ? "info" : "accent";
        card.appendChild(div("hc-top",
          `<span class="badge-s ${catTone}">${esc(m.category_label || cats[m.category] || m.category)}</span>`
          + (m.pinned ? `<span class="badge-s info">置顶铁律</span>` : "")
          + `<span class="badge-s">重要度 P${6 - Math.min(5, Math.max(1, m.importance || 3))}</span>`
          + (m.topic_key ? `<span class="hc-code">#${esc(m.topic_key)}</span>` : "")
          + `<span class="mem-hit-meta">${m.hit_count ? `已召回 ${m.hit_count} 次 · ` : ""}${fmtRelative(m.updated)}</span>`));

        card.appendChild(div("mem-item-content", esc(m.content)));

        const acts = div("hc-acts");
        acts.appendChild(h("button", {
          type: "button",
          class: "btn small ghost",
          text: m.pinned ? "取消置顶" : "置顶常驻",
          onclick: async () => {
            await post("/api/memory/items", {
              id: m.id, content: m.content, category: m.category, topic_key: m.topic_key,
              tags: m.tags, importance: m.importance, pinned: !m.pinned,
            });
            await loadOverview();
          },
        }));
        acts.appendChild(h("button", {
          type: "button",
          class: "btn small ghost",
          text: "编辑",
          onclick: () => { editingMemory = m; renderMemoryForm(rightCol, cats); },
        }));
        acts.appendChild(h("button", {
          type: "button",
          class: "btn small ghost danger-text",
          text: "删除",
          onclick: async () => {
            const r = await del(`/api/memory/items/${encodeURIComponent(m.id)}`);
            syncMemoryBadge(r.stats);
            if (editingMemory?.id === m.id) editingMemory = null;
            await loadOverview();
          },
        }));
        card.appendChild(acts);
        list.appendChild(card);
      });
      leftCol.appendChild(list);
    }

    renderMemoryForm(rightCol, cats);
  }

  function catChip(cat, label, active) {
    return h("button", {
      type: "button",
      class: "tpl-chip" + (active ? " active" : ""),
      text: label,
      onclick: () => { filterCat = cat; loadOverview(); },
    });
  }

  function renderMemoryForm(container, cats) {
    container.innerHTML = "";
    const m = editingMemory || {};
    container.appendChild(div("hub-col-head",
      `<h4>${editingMemory ? "编辑长期记忆条目" : "新增长期记忆 / 规范铁律"}</h4>`));
    const box = h("form", { class: "form hub-form-box" });
    box.innerHTML = `
      <div class="field"><label>记忆类别</label>
        <select name="category">${Object.entries(cats).map(([k, v]) => `<option value="${esc(k)}"${(m.category || "format_spec") === k ? " selected" : ""}>${esc(v)}</option>`).join("")}</select></div>
      <div class="field"><label>记忆规则 / 偏好 / 事实内容 *</label>
        <textarea name="content" rows="4" required placeholder="例如：撰写财政研究类论文时，基准回归表需同时汇报不控制与控制双向固定效应的结果，括号内统一展示省级聚类稳健标准误。">${esc(m.content || "")}</textarea></div>
      <div class="grid-2">
        <div class="field"><label>主题演化键（可选）</label>
          <input name="topic_key" placeholder="如 reg_table_rule" value="${esc(m.topic_key || "")}"></div>
        <div class="field"><label>重要度（1~5）</label>
          <select name="importance">
            <option value="5"${(m.importance || 4) === 5 ? " selected" : ""}>P1 · 核心铁律（常驻）</option>
            <option value="4"${(m.importance || 4) === 4 ? " selected" : ""}>P2 · 高优规范（常驻）</option>
            <option value="3"${m.importance === 3 ? " selected" : ""}>P3 · 常规偏好（召回）</option>
            <option value="2"${m.importance === 2 ? " selected" : ""}>P4 · 辅助参考</option>
          </select></div>
      </div>
      <label class="field check"><input type="checkbox" name="pinned"${m.pinned ? " checked" : ""}><span>置顶为每次任务必须遵循的常驻记忆</span></label>
      <div class="row" style="justify-content:flex-end;gap:8px">
        ${editingMemory ? `<button type="button" class="btn small ghost" id="mem-cancel">取消编辑</button>` : ""}
        <button type="submit" class="btn small primary">${editingMemory ? "保存修改" : "写入长期记忆"}</button>
      </div>
    `;
    const cancelBtn = box.querySelector("#mem-cancel");
    if (cancelBtn) cancelBtn.onclick = () => { editingMemory = null; renderMemoryForm(container, cats); };
    box.onsubmit = async (ev) => {
      ev.preventDefault();
      const fd = new FormData(box);
      try {
        const r = await post("/api/memory/items", {
          id: editingMemory?.id || null,
          category: fd.get("category"),
          content: fd.get("content"),
          topic_key: fd.get("topic_key"),
          importance: Number(fd.get("importance") || 4),
          pinned: fd.get("pinned") === "on",
          source: "manual",
        });
        syncMemoryBadge(r.stats);
        editingMemory = null;
        toast("已写入长期记忆库", "success");
        await loadOverview();
      } catch (e) {
        toast("保存失败：" + e.message, "error");
      }
    };
    container.appendChild(box);
  }

  await loadOverview();
}
