/* 左侧栏：对话列表、搜索、分组、操作菜单 */
import { S, bus } from "./state.js";
import { $, esc, h, div, debounce, download, copyText, fmtRelative } from "./util.js";
import { api, patch, post, del } from "./api.js";
import { toast, openMenu, confirmDialog, openModal, emptyState } from "./ui.js";
import { SVG } from "./icons.js";

const SB = { convs: [], archived: false, q: "", seq: 0, loaded: false };
let listEl, headEl;

export function init() {
  listEl = $("#conv-list");
  headEl = $("#conv-list-head");
  const search = $("#search");
  const doSearch = debounce(() => { SB.q = search.value.trim(); refresh(); }, 280);
  search.addEventListener("input", doSearch);
  search.addEventListener("keydown", (e) => {
    if (e.key === "Escape") { search.value = ""; SB.q = ""; refresh(); search.blur(); }
    if (e.key === "ArrowDown") { e.preventDefault(); listEl.querySelector(".conv-item")?.focus(); }
  });
  $("#btn-archived").onclick = () => {
    SB.archived = !SB.archived;
    $("#btn-archived").setAttribute("aria-pressed", String(SB.archived));
    $("#btn-archived").classList.toggle("active", SB.archived);
    $("#btn-archived span").textContent = SB.archived ? "返回对话列表" : "已归档对话";
    refresh();
  };
  listEl.addEventListener("keydown", (e) => {
    if (!["ArrowDown", "ArrowUp"].includes(e.key)) return;
    const items = [...listEl.querySelectorAll(".conv-item")];
    const i = items.indexOf(document.activeElement);
    if (i < 0) return;
    e.preventDefault();
    items[e.key === "ArrowDown" ? Math.min(i + 1, items.length - 1) : Math.max(i - 1, 0)].focus();
  });
  const soon = debounce(refresh, 400);
  bus.on("conv:changed", highlight);
  bus.on("conv:updated", soon);
  bus.on("conv:idle", soon);
  bus.on("conv:touched", soon);
  bus.on("conv:live-state", onLiveConvState);
  // 有任务运行时定期刷新运行状态兜底
  setInterval(() => { if (!document.hidden && SB.convs.some((c) => c.running)) refresh(); }, 6000);
}

function onLiveConvState(ev) {
  if (!ev || !ev.id) return;
  let existing = SB.convs.find((c) => c.id === ev.id);
  const wasRunning = existing ? !!existing.running : false;
  if (existing) {
    existing.running = !!ev.running;
    if (ev.title) existing.title = ev.title;
    existing.updated = ev.updated || Date.now() / 1000;
    existing.queue_len = ev.queue_len || 0;
  } else if (!SB.archived && !SB.q) {
    existing = {
      id: ev.id,
      title: ev.title || "新对话",
      running: !!ev.running,
      queue_len: ev.queue_len || 0,
      model: ev.model || "",
      created: ev.updated || Date.now() / 1000,
      updated: ev.updated || Date.now() / 1000,
      pinned: false,
      archived: false,
    };
    SB.convs.unshift(existing);
  }
  render();
  if (wasRunning && !ev.running && ev.finished && ev.id !== S.convId) {
    toast(`后台对话「${(ev.title || "任务").slice(0, 26)}」已执行完成`, "success", 4200);
  }
}

export async function refresh() {
  const seq = ++SB.seq;
  const params = new URLSearchParams({ archived: SB.archived ? "1" : "0", limit: "200" });
  if (SB.q) params.set("q", SB.q);
  if (!SB.loaded) listEl.innerHTML = `<div class="loading"><span class="spinner sm"></span><span>加载中…</span></div>`;
  try {
    const list = await api(`/api/conversations?${params}`);
    if (seq !== SB.seq) return;
    SB.convs = Array.isArray(list) ? list : list.items || [];
    SB.loaded = true;
    render();
  } catch (e) {
    if (seq !== SB.seq || e.status === 401) return;
    listEl.innerHTML = "";
    listEl.appendChild(div("", emptyState("⚠️", "加载失败", e.message)));
    listEl.appendChild(h("button", { class: "btn small block", type: "button", text: "重试", onclick: refresh }));
  }
}

function groupOf(c) {
  if (c.pinned) return "置顶";
  const ts = (c.updated || c.created || 0) * 1000;
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const t0 = today.getTime();
  if (ts >= t0) return "今天";
  if (ts >= t0 - 86400000) return "昨天";
  if (ts >= t0 - 6 * 86400000) return "7 天内";
  if (ts >= t0 - 29 * 86400000) return "30 天内";
  return "更早";
}

function syncRunningBadge() {
  const badge = $("#sb-running-badge");
  if (!badge) return;
  const runCount = SB.convs.filter((c) => c.running).length;
  badge.hidden = runCount === 0;
  badge.textContent = `${runCount} 运行中`;
}

function render() {
  syncRunningBadge();
  listEl.innerHTML = "";
  headEl.hidden = !(SB.q || SB.archived);
  if (SB.q) headEl.textContent = `搜索「${SB.q}」· ${SB.convs.length} 个结果`;
  else if (SB.archived) headEl.textContent = `已归档 · ${SB.convs.length} 个对话`;
  if (!SB.convs.length) {
    listEl.innerHTML = SB.q ? emptyState("🔍", "没有找到相关对话", "换个关键词试试")
      : SB.archived ? emptyState("🗄", "没有已归档的对话") : emptyState("💬", "还没有对话", "点击「新对话」开始你的第一个任务");
    return;
  }
  const flat = SB.q || SB.archived;
  const groups = new Map();
  for (const c of SB.convs) {
    const g = flat ? "" : groupOf(c);
    if (!groups.has(g)) groups.set(g, []);
    groups.get(g).push(c);
  }
  const order = ["置顶", "今天", "昨天", "7 天内", "30 天内", "更早", ""];
  for (const g of order) {
    const items = groups.get(g);
    if (!items) continue;
    const sec = div("conv-group");
    if (g) sec.appendChild(h("div", { class: "conv-group-title", text: g }));
    items.forEach((c) => sec.appendChild(itemEl(c)));
    listEl.appendChild(sec);
  }
  highlight();
}

function itemEl(c) {
  const a = h("a", { class: "conv-item" + (c.running ? " is-running" : ""), href: `#/c/${c.id}`, "data-id": c.id, title: c.title || "未命名对话" });
  const title = h("span", { class: "ci-title", text: c.title || "未命名对话" });
  const line = h("span", { class: "ci-line" }, title);
  if (c.running) {
    line.prepend(h("span", { class: "run-dot", title: "后台执行中", "aria-label": "执行中" }));
    line.appendChild(h("span", { class: "ci-run-tag", text: c.queue_len ? `运行·排${c.queue_len}` : "运行中" }));
  } else if (c.pinned && (SB.q || SB.archived)) {
    line.prepend(h("span", { class: "pin-ic", text: "📌" }));
  }
  a.appendChild(line);
  if (SB.q && c.snippet) {
    const snip = h("span", { class: "ci-snippet" });
    snip.innerHTML = highlightQuery(c.snippet, SB.q);
    a.appendChild(snip);
  }
  const more = h("button", { class: "ci-more", type: "button", "aria-label": `“${c.title || "未命名"}”的更多操作`, "aria-haspopup": "menu", text: "⋯" });
  more.onclick = (e) => { e.preventDefault(); e.stopPropagation(); openMenu(more, convMenuItems(c, a)); };
  a.appendChild(more);
  a.addEventListener("contextmenu", (e) => { e.preventDefault(); openMenu(more, convMenuItems(c, a)); });
  a.addEventListener("click", () => bus.emit("drawer:close"));
  a.addEventListener("dblclick", (e) => { e.preventDefault(); startRename(c, a); });
  return a;
}

function highlightQuery(text, q) {
  const safe = esc(text);
  const words = q.split(/\s+/).filter(Boolean).map((w) => esc(w).replace(/[.*+?^${}()|[\]\\]/g, "\\$&"));
  if (!words.length) return safe;
  return safe.replace(new RegExp(`(${words.join("|")})`, "gi"), "<mark>$1</mark>");
}

function highlight() {
  if (!listEl) return;
  listEl.querySelectorAll(".conv-item").forEach((a) => {
    const on = a.dataset.id === S.convId;
    a.classList.toggle("active", on);
    if (on) a.setAttribute("aria-current", "page"); else a.removeAttribute("aria-current");
  });
}

export function findConv(id) { return SB.convs.find((c) => c.id === id); }

/** 对话操作菜单（侧栏与顶栏共用） */
export function convMenuItems(c, itemEl) {
  return [
    { icon: SVG.edit, label: "重命名", onClick: () => (itemEl ? startRename(c, itemEl) : renameDialog(c)) },
    { icon: SVG.pin, label: c.pinned ? "取消置顶" : "置顶对话", onClick: () => update(c, { pinned: !c.pinned }, c.pinned ? "已取消置顶" : "已置顶") },
    { icon: SVG.share, label: "创建分享链接", onClick: () => share(c) },
    { divider: true },
    { icon: SVG.download, label: "导出 Markdown", onClick: () => exportConv(c, "md") },
    { icon: SVG.download, label: "导出 Word (.docx)", onClick: () => exportConv(c, "docx") },
    { icon: SVG.download, label: "导出 JSON", onClick: () => exportConv(c, "json") },
    { divider: true },
    { icon: SVG.archive, label: c.archived ? "移出归档" : "归档对话", onClick: () => update(c, { archived: !c.archived }, c.archived ? "已移出归档" : "已归档") },
    { icon: SVG.trash, label: "删除对话", danger: true, onClick: () => remove(c) },
  ];
}

async function update(c, body, msg) {
  try {
    const r = await patch(`/api/conversations/${c.id}`, body);
    Object.assign(c, r.conversation || r || body);
    if (msg) toast(msg, "success");
    if (body.title && c.id === S.convId) bus.emit("conv:renamed", body.title);
    refresh();
  } catch (e) { toast(e.message, "error"); }
}

function startRename(c, el) {
  const titleEl = el.querySelector(".ci-title");
  if (!titleEl || el.querySelector("input")) return;
  const input = h("input", { class: "ci-rename", value: c.title || "", "aria-label": "对话标题", maxlength: "120" });
  titleEl.replaceWith(input);
  el.classList.add("renaming");
  input.focus();
  input.select();
  let done = false;
  const finish = (save) => {
    if (done) return;
    done = true;
    const v = input.value.trim();
    el.classList.remove("renaming");
    input.replaceWith(titleEl);
    if (save && v && v !== c.title) { titleEl.textContent = v; update(c, { title: v }, "已重命名"); }
  };
  input.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); });
  input.addEventListener("keydown", (e) => {
    e.stopPropagation();
    if (e.key === "Enter" && !e.isComposing) { e.preventDefault(); finish(true); }
    if (e.key === "Escape") { e.preventDefault(); finish(false); }
  });
  input.addEventListener("blur", () => finish(true));
}

async function renameDialog(c) {
  const { promptDialog } = await import("./ui.js");
  const v = await promptDialog({ title: "重命名对话", label: "标题", value: c.title || "" });
  if (v && v !== c.title) update(c, { title: v }, "已重命名");
}

function exportConv(c, fmt) {
  download(`/api/conversations/${c.id}/export?format=${fmt}`);
  toast("正在导出…", "info", 1500);
}

async function share(c) {
  let r;
  try { r = await post(`/api/conversations/${c.id}/share`, {}); } catch (e) { toast(e.message, "error"); return; }
  const url = new URL(r.share_url || `/share/${r.token}`, location.origin).href;
  const copied = await copyText(url);
  const input = h("input", { class: "share-input", value: url, readonly: true, "aria-label": "分享链接" });
  input.onfocus = () => input.select();
  const content = div("share-box");
  content.append(
    h("p", { class: "muted", text: "任何拥有此链接的人都可以查看该对话的只读版本（不包含你的文件）。" }),
    input,
    copied ? h("p", { class: "ok-text", text: "✓ 链接已复制到剪贴板" }) : null);
  openModal({
    title: "分享对话", size: "sm", content,
    actions: [
      { label: "停止分享", kind: "ghost danger-text", onClick: async () => {
        await del(`/api/conversations/${c.id}/share`);
        toast("已停止分享，原链接已失效", "success");
      } },
      { label: "打开", kind: "ghost", onClick: () => { window.open(url, "_blank", "noopener"); return false; } },
      { label: "复制链接", kind: "primary", onClick: async () => {
        const ok = await copyText(url);
        toast(ok ? "链接已复制" : "复制失败，请手动复制", ok ? "success" : "error");
      } },
    ],
  });
}

async function remove(c) {
  const ok = await confirmDialog(`确定删除对话「${c.title || "未命名对话"}」吗？删除后无法恢复。`, { title: "删除对话", okText: "删除", danger: true });
  if (!ok) return;
  try {
    await del(`/api/conversations/${c.id}`);
    toast("对话已删除", "success");
    SB.convs = SB.convs.filter((x) => x.id !== c.id);
    render();
    if (c.id === S.convId) bus.emit("conv:deleted-current");
  } catch (e) { toast(e.message, "error"); }
}

export function focusSearch() {
  const s = $("#search");
  s.focus();
  s.select();
}
export { fmtRelative };
