/* 设置中心：个人资料 / 偏好设置 / 模型密钥 / 用量统计 / 账号安全 */
import { S, bus, applyTheme, getThemePref } from "./state.js";
import { $, $$, esc, h, div, fmtK, fmtNum, fmtDateTime, fmtRelative, initials, avatarColor } from "./util.js";
import { api, patch, put, post, del } from "./api.js";
import { toast, openModal, formDialog, confirmDialog, spinner, emptyState } from "./ui.js";
import { barChart, fillDays } from "./charts.js";

const TABS = [
  { id: "profile", label: "个人资料", icon: "👤" },
  { id: "prefs", label: "偏好设置", icon: "⚙️" },
  { id: "keys", label: "模型密钥", icon: "🔑" },
  { id: "usage", label: "用量统计", icon: "📈" },
  { id: "security", label: "账号安全", icon: "🛡" },
];

let modal = null;

export function openSettings(tab = "profile") {
  if (modal) { switchTab(tab); return; }
  const nav = h("nav", { class: "set-nav", role: "tablist", "aria-label": "设置分类" });
  const pane = h("div", { class: "set-pane", role: "tabpanel" });
  TABS.forEach((t) => nav.appendChild(h("button", { type: "button", class: "set-tab", role: "tab", "data-tab": t.id, onclick: () => switchTab(t.id) },
    h("span", { text: t.icon }), h("span", { text: t.label }))));
  const wrap = div("settings");
  wrap.append(nav, pane);
  modal = openModal({ title: "设置", size: "xl", content: wrap, className: "settings-modal", onClose: () => { modal = null; } });
  switchTab(tab);
}

function switchTab(id) {
  if (!modal) return;
  $$(".set-tab", modal.el).forEach((b) => { const on = b.dataset.tab === id; b.classList.toggle("active", on); b.setAttribute("aria-selected", String(on)); });
  const pane = $(".set-pane", modal.el);
  pane.innerHTML = "";
  ({ profile, prefs, keys, usage, security })[id]?.(pane);
}

const section = (title, desc) => {
  const s = div("set-section");
  s.appendChild(h("h4", { text: title }));
  if (desc) s.appendChild(h("p", { class: "muted small", text: desc }));
  return s;
};
const field = (label, input, hint) => h("div", { class: "field" }, h("label", { text: label, for: input.id || null }), input, hint ? h("div", { class: "hint", text: hint }) : null);

/* ---------------- 个人资料 ---------------- */
function profile(pane) {
  const u = S.user;
  const head = div("profile-head", `<span class="avatar lg" style="background:${avatarColor(u.username)}">${esc(initials(u.display_name || u.username))}</span>
    <div><div class="ph-name">${esc(u.display_name || u.username)}</div><div class="muted small">@${esc(u.username)} · ${u.role === "admin" ? "管理员" : "普通用户"} · 注册于 ${fmtDateTime(u.created).slice(0, 10)}</div></div>`);
  const name = h("input", { id: "set-display", value: u.display_name || "", placeholder: u.username, maxlength: "60" });
  const email = h("input", { id: "set-email", type: "email", value: u.email || "", placeholder: "name@example.com" });
  const uname = h("input", { id: "set-username", value: u.username, disabled: true });
  const save = h("button", { class: "btn primary", type: "button", text: "保存修改" });
  save.onclick = async () => {
    save.disabled = true;
    try {
      const r = await patch("/api/me", { display_name: name.value.trim(), email: email.value.trim() });
      S.user = { ...S.user, ...(r.user || {}) };
      bus.emit("user:updated");
      toast("个人资料已保存", "success");
      switchTab("profile");
    } catch (e) { toast(e.message, "error"); }
    save.disabled = false;
  };
  const s = section("基本信息");
  s.append(field("用户名", uname, "用户名不可修改"), field("显示名称", name), field("邮箱", email), div("set-actions"));
  s.lastChild.appendChild(save);
  pane.append(head, s);
}

/* ---------------- 偏好设置 ---------------- */
function prefs(pane) {
  const st = S.settings || {};
  const models = S.config?.models || [];
  const model = h("select", { id: "set-model" }, h("option", { value: "", text: "跟随系统默认" }),
    ...models.map((m) => h("option", { value: m.name, text: m.name + (m.available ? "" : "（未配置）"), disabled: !m.available })));
  model.value = st.default_model || "";
  const mode = h("select", { id: "set-mode" }, ...[["auto", "自动"], ["code", "编程"], ["office", "办公"]].map(([v, l]) => h("option", { value: v, text: l })));
  mode.value = st.default_mode || "auto";
  const approval = h("select", { id: "set-approval" }, ...[["smart", "智能（高风险操作需确认）"], ["auto", "全自动"], ["always", "每步确认"]].map(([v, l]) => h("option", { value: v, text: l })));
  approval.value = st.default_approval || "smart";
  const themeBox = div("segmented");
  let theme = getThemePref();
  [["light", "☀️ 浅色"], ["dark", "🌙 深色"], ["system", "🖥 跟随系统"]].forEach(([v, l]) => {
    const b = h("button", { type: "button", class: "seg" + (theme === v ? " active" : ""), text: l, "aria-pressed": String(theme === v) });
    b.onclick = () => { theme = v; $$(".seg", themeBox).forEach((x) => { x.classList.toggle("active", x === b); x.setAttribute("aria-pressed", String(x === b)); }); applyTheme(v); };
    themeBox.appendChild(b);
  });
  const ci = h("textarea", { id: "set-ci", rows: "6", maxlength: "8000", placeholder: "例如：我是财政学研究者，请使用规范的学术中文写作；图表使用宋体/Times New Roman；回归结果保留三位小数。" });
  ci.value = st.custom_instructions || "";
  const notify = h("input", { type: "checkbox", id: "set-notify" });
  notify.checked = !!st.notify_on_done;
  notify.onchange = async () => {
    if (notify.checked && "Notification" in window && Notification.permission !== "granted") {
      const p = await Notification.requestPermission().catch(() => "denied");
      if (p !== "granted") toast("浏览器未授予通知权限，请在浏览器设置中允许通知", "warn");
    }
  };
  const save = h("button", { class: "btn primary", type: "button", text: "保存偏好" });
  save.onclick = async () => {
    save.disabled = true;
    try {
      const r = await put("/api/me/settings", {
        default_model: model.value, default_mode: mode.value, default_approval: approval.value, theme,
        custom_instructions: ci.value, notify_on_done: notify.checked,
      });
      S.settings = r || S.settings;
      S.user.settings = S.settings;
      applyTheme(S.settings.theme || theme);
      bus.emit("settings:updated");
      toast("偏好设置已保存", "success");
    } catch (e) { toast(e.message, "error"); }
    save.disabled = false;
  };
  const s1 = section("新对话默认值", "新建对话时，输入框下方的模型、模式与审批策略会使用这些默认值。");
  s1.append(div("grid-3"));
  s1.lastChild.append(field("默认模型", model), field("默认模式", mode), field("默认审批策略", approval));
  const s2 = section("外观");
  s2.append(themeBox);
  const s3 = section("自定义指令", "这些说明会附加到每个对话的系统提示词中，让智能体了解你的身份、偏好与写作风格。");
  s3.append(ci, h("div", { class: "hint", text: `${ci.value.length}/8000` }));
  ci.addEventListener("input", () => { s3.querySelector(".hint").textContent = `${ci.value.length}/8000`; });
  const s4 = section("通知");
  s4.append(h("label", { class: "field check", for: "set-notify" }, notify, h("span", { text: "任务完成或需要确认时，若页面在后台则发送浏览器通知" })));
  const act = div("set-actions sticky");
  act.appendChild(save);
  pane.append(s1, s2, s3, s4, act);
}

/* ---------------- 模型密钥 ---------------- */
async function keys(pane) {
  pane.appendChild(section("个人模型 API Key", "你的密钥将加密存储，仅用于你自己的任务。设置后即可使用对应模型（即使系统未配置该模型）。"));
  const box = div("", spinner("加载中…"));
  pane.appendChild(box);
  let list;
  try { list = await api("/api/me/keys"); } catch (e) { box.innerHTML = emptyState("⚠️", "加载失败", e.message); return; }
  if (!list.length) { box.innerHTML = emptyState("🔑", "没有可配置的模型"); return; }
  const table = h("table", { class: "table" });
  table.innerHTML = `<thead><tr><th>模型</th><th>服务商</th><th>状态</th><th class="right">操作</th></tr></thead>`;
  const tb = h("tbody");
  list.forEach((k) => {
    const status = k.has_key ? `<span class="badge-s ok">个人密钥 ${esc(k.masked || "")}</span>`
      : k.system_available ? `<span class="badge-s info">系统已配置</span>` : `<span class="badge-s muted">未配置</span>`;
    const tr = h("tr", {});
    tr.innerHTML = `<td><b>${esc(k.model)}</b><div class="muted small mono">${esc(k.model_id || "")}</div></td><td>${esc(k.provider || "")}</td><td>${status}${k.base_url ? `<div class="muted small mono">${esc(k.base_url)}</div>` : ""}</td>`;
    const td = h("td", { class: "right nowrap" });
    td.appendChild(h("button", { class: "btn small", type: "button", text: k.has_key ? "更换" : "设置", onclick: () => setKey(k) }));
    if (k.has_key) td.appendChild(h("button", { class: "btn small ghost danger-text", type: "button", text: "移除", onclick: () => removeKey(k) }));
    tr.appendChild(td);
    tb.appendChild(tr);
  });
  table.appendChild(tb);
  box.innerHTML = "";
  box.appendChild(h("div", { class: "table-wrap" }, table));
}
async function setKey(k) {
  const r = await formDialog({
    title: `设置 ${k.model} 的 API Key`,
    intro: `服务商：${k.provider || "—"}　模型：${k.model_id || k.model}`,
    fields: [
      { name: "api_key", label: "API Key", type: "password", required: true, placeholder: "sk-…", autocomplete: "new-password" },
      { name: "base_url", label: "Base URL（可选）", value: k.base_url || "", placeholder: k.default_base_url || "使用默认地址", hint: "使用代理或私有部署时填写，留空则使用默认地址" },
    ],
    okText: "保存",
    onSubmit: (v) => put(`/api/me/keys/${encodeURIComponent(k.model)}`, { api_key: v.api_key.trim(), base_url: v.base_url.trim() || undefined }),
  });
  if (r) { toast("API Key 已保存", "success"); bus.emit("config:reload"); switchTab("keys"); }
}
async function removeKey(k) {
  if (!(await confirmDialog(`确定移除 ${k.model} 的个人 API Key 吗？`, { danger: true, okText: "移除" }))) return;
  try {
    await del(`/api/me/keys/${encodeURIComponent(k.model)}`);
    toast("已移除", "success");
    bus.emit("config:reload");
    switchTab("keys");
  } catch (e) { toast(e.message, "error"); }
}

/* ---------------- 用量统计 ---------------- */
async function usage(pane) {
  pane.innerHTML = spinner("加载中…");
  let r;
  try { r = await api("/api/me/usage?days=30"); } catch (e) { pane.innerHTML = emptyState("⚠️", "加载失败", e.message); return; }
  pane.innerHTML = "";
  const daily = fillDays(r.daily, 30);
  const sum = daily.reduce((a, d) => ({ i: a.i + (d.input_tokens || 0), o: a.o + (d.output_tokens || 0), t: a.t + (d.tasks || 0) }), { i: 0, o: 0, t: 0 });
  const t = r.total || {};
  const cards = div("stat-cards");
  const card = (label, value, sub) => div("stat-card", `<div class="sc-label">${esc(label)}</div><div class="sc-value">${esc(value)}</div>${sub ? `<div class="sc-sub">${esc(sub)}</div>` : ""}`);
  cards.append(
    card("近 30 天 Token", fmtK(sum.i + sum.o), `输入 ${fmtK(sum.i)} · 输出 ${fmtK(sum.o)}`),
    card("近 30 天任务", fmtNum(sum.t)),
    card("累计 Token", fmtK((t.input_tokens || 0) + (t.output_tokens || 0)), `任务 ${fmtNum(t.tasks)} 次`),
    card("对话总数", fmtNum(t.conversations)));
  pane.appendChild(cards);
  if (r.month || r.quota) {
    const used = (r.month?.input_tokens || 0) + (r.month?.output_tokens || 0);
    const q = section("本月额度");
    if (r.quota) {
      const pct = Math.min(100, (used / r.quota) * 100);
      q.appendChild(div("", `<div class="storage-row"><span>已用 ${fmtNum(used)} tokens</span><span>额度 ${fmtNum(r.quota)}</span></div>
        <div class="progress"><div class="bar${pct > 90 ? " danger" : pct > 75 ? " warn" : ""}" style="width:${pct}%"></div></div>`));
    } else q.appendChild(h("p", { class: "muted small", text: `本月已用 ${fmtNum(used)} tokens · 无额度限制` }));
    pane.appendChild(q);
  }
  const c = section("每日 Token 用量（近 30 天）");
  c.appendChild(div("", barChart(daily, {
    series: [{ key: "input_tokens", label: "输入", color: "var(--accent)" }, { key: "output_tokens", label: "输出", color: "var(--green)" }],
    extraTip: (d) => `任务：${d.tasks || 0}`,
  })));
  pane.appendChild(c);
  const m = section("按模型统计");
  const bm = r.by_model || [];
  if (!bm.length) m.appendChild(div("", emptyState("📊", "暂无数据")));
  else {
    const total = bm.reduce((a, x) => a + (x.input_tokens || 0) + (x.output_tokens || 0), 0) || 1;
    m.appendChild(div("table-wrap", `<table class="table"><thead><tr><th>模型</th><th class="right">输入</th><th class="right">输出</th><th>占比</th></tr></thead><tbody>
      ${bm.map((x) => { const s = (x.input_tokens || 0) + (x.output_tokens || 0); const p = (s / total) * 100; return `<tr><td><b>${esc(x.model)}</b></td><td class="right mono">${fmtNum(x.input_tokens)}</td><td class="right mono">${fmtNum(x.output_tokens)}</td><td><div class="mini-bar"><i style="width:${p.toFixed(1)}%"></i></div><span class="muted small">${p.toFixed(1)}%</span></td></tr>`; }).join("")}
      </tbody></table>`));
  }
  pane.appendChild(m);
}

/* ---------------- 账号安全 ---------------- */
function parseUA(ua = "") {
  const os = /Windows/.test(ua) ? "Windows" : /iPhone|iPad/.test(ua) ? "iOS" : /Mac OS X|Macintosh/.test(ua) ? "macOS" : /Android/.test(ua) ? "Android" : /Linux/.test(ua) ? "Linux" : "未知系统";
  const br = /Edg\//.test(ua) ? "Edge" : /Chrome\//.test(ua) ? "Chrome" : /Firefox\//.test(ua) ? "Firefox" : /Safari\//.test(ua) ? "Safari" : /python|curl|httpx/i.test(ua) ? "脚本客户端" : "浏览器";
  const icon = /iPhone|Android|Mobile/.test(ua) ? "📱" : "💻";
  return { label: `${br} · ${os}`, icon };
}
async function security(pane) {
  const s1 = section("修改密码", "修改密码后，其他设备上的登录将全部失效。");
  const oldPw = h("input", { type: "password", id: "pw-old", autocomplete: "current-password" });
  const newPw = h("input", { type: "password", id: "pw-new", autocomplete: "new-password", placeholder: "至少 8 位" });
  const newPw2 = h("input", { type: "password", id: "pw-new2", autocomplete: "new-password" });
  const btn = h("button", { class: "btn primary", type: "button", text: "修改密码" });
  btn.onclick = async () => {
    if (!oldPw.value || !newPw.value) { toast("请填写完整", "warn"); return; }
    if (newPw.value.length < 8) { toast("新密码至少 8 位", "warn"); return; }
    if (newPw.value !== newPw2.value) { toast("两次输入的新密码不一致", "warn"); return; }
    btn.disabled = true;
    try {
      await post("/api/me/password", { old_password: oldPw.value, new_password: newPw.value }, { noAuthRedirect: true });
      toast("密码已修改，其他设备已退出登录", "success");
      oldPw.value = newPw.value = newPw2.value = "";
      loadDevices();
    } catch (e) { toast(e.message, "error"); }
    btn.disabled = false;
  };
  const g = div("grid-3");
  g.append(field("当前密码", oldPw), field("新密码", newPw), field("确认新密码", newPw2));
  s1.append(g, div("set-actions"));
  s1.lastChild.appendChild(btn);

  const s2 = section("登录设备", "以下是当前登录你账号的设备。如发现异常设备，请立即将其踢下线并修改密码。");
  const list = div("device-list", spinner());
  const others = h("button", { class: "btn small ghost danger-text", type: "button", text: "注销其他所有设备" });
  others.onclick = async () => {
    if (!(await confirmDialog("确定注销除当前设备外的所有登录吗？", { danger: true, okText: "全部注销" }))) return;
    try { await del("/api/me/devices/all_others"); toast("已注销其他设备", "success"); loadDevices(); } catch (e) { toast(e.message, "error"); }
  };
  s2.append(list, div("set-actions"));
  s2.lastChild.appendChild(others);
  pane.append(s1, s2);

  async function loadDevices() {
    try {
      const devs = await api("/api/me/devices");
      list.innerHTML = "";
      if (!devs.length) { list.innerHTML = emptyState("💻", "没有设备记录"); return; }
      devs.sort((a, b) => (b.current ? 1 : 0) - (a.current ? 1 : 0) || (b.last_seen || 0) - (a.last_seen || 0));
      devs.forEach((d) => {
        const ua = parseUA(d.user_agent);
        const row = div("device", `<span class="dev-ic">${ua.icon}</span><div class="dev-main"><div><b>${esc(ua.label)}</b>${d.current ? ' <span class="badge-s ok">当前设备</span>' : ""}</div>
          <div class="muted small">IP ${esc(d.ip || "—")} · 最近活动 ${fmtRelative(d.last_seen)} · 登录于 ${fmtDateTime(d.created)}</div></div>`);
        if (!d.current) {
          row.appendChild(h("button", { class: "btn small ghost danger-text", type: "button", text: "踢下线", onclick: async () => {
            try { await del(`/api/me/devices/${encodeURIComponent(d.id)}`); toast("已踢下线", "success"); loadDevices(); } catch (e) { toast(e.message, "error"); }
          } }));
        }
        list.appendChild(row);
      });
      others.hidden = !devs.some((d) => !d.current);
    } catch (e) { list.innerHTML = emptyState("⚠️", "加载失败", e.message); }
  }
  loadDevices();
}
