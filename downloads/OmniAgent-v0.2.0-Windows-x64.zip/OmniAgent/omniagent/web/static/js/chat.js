/* 对话区：WebSocket 实时流、思维链轨迹、子智能体状态、文件变更卡、输入框与附件 */
import { S, bus, isMobile } from "./state.js";
import { $, $$, esc, div, h, fmtK, basename, FILE_ICON, fileUrl } from "./util.js";
import { toast, lightbox } from "./ui.js";
import { upload } from "./api.js";
import * as R from "./render.js";
import * as panel from "./panel.js";
import { shortAgentLabel } from "./hub.js";
import { syncMemoryBadge } from "./memory.js";
import { flipMoveElement } from "./motion.js";
import { SVG } from "./icons.js";

export const TEMPLATES = [
  { icon: SVG.code, tone: "tone-cyan", cat: "code", title: "代码重构与测试验证", desc: "探索代码库 → 定位修复 → 跑通测试", mode: "code", agent: "coder",
    text: "阅读当前项目代码，梳理核心架构后：找出潜在 bug 或可优化模块并精准修复，补充单元测试，运行测试确保全部通过，最后给出变更审阅说明。" },
  { icon: SVG.rocket, tone: "tone-indigo", cat: "code", title: "从零构建全栈应用", desc: "架构设计 → 编码实现 → 自测文档", mode: "code", agent: "coder",
    text: "从零创建一个 FastAPI 待办事项 Web 应用（含现代化前端页面、SQLite 存储、增删改查 API 和自动化测试），运行测试确保全部通过，并编写 README。" },
  { icon: SVG.academic, tone: "tone-amber", cat: "research", title: "计量实证科研论文", desc: "面板数据 → 双向固定效应 → 期刊论文", mode: "office", agent: "general",
    text: "基于 uploads/ 中的省级面板数据，协同数据计量与学术写作子智能体撰写实证论文：完成描述性统计、双向固定效应基准回归、稳健性与异质性检验，绘制学术图表，输出规范 Word 论文到 outputs/。" },
  { icon: SVG.chart, tone: "tone-emerald", cat: "research", title: "深度数据分析报告", desc: "Excel/CSV → 统计建模 → 图文报告", mode: "office", agent: "analyst",
    text: "分析 uploads/ 中的业务数据：清洗缺失与异常值，按核心维度交叉统计，识别趋势与异动，绘制高分辨率图表，输出图文并茂的 Word 分析报告到 outputs/。" },
  { icon: SVG.plug, tone: "tone-violet", cat: "connect", title: "外部系统接入与分析", desc: "数据库 / API / 网页 → 采集清洗 → 报告", mode: "auto", agent: "connector",
    text: "查看已配置的外部连接器（list_connectors），探查数据结构并提取关键业务数据保存到 uploads/，完成统计清洗后生成分析汇总。" },
  { icon: SVG.slides, tone: "tone-rose", cat: "research", title: "高管汇报演示文稿", desc: "提炼材料 → 核心图表 → 专业 PPT", mode: "office", agent: "writer",
    text: "根据工作区中的资料与数据，制作一份 8-10 页的汇报 PPT，包含封面、核心结论、关键数据图表、问题剖析与行动路线图。" },
  { icon: SVG.plug, tone: "tone-amber", cat: "connect", title: "智能报销与网页填报", desc: "票据识别 → 金额核对 → 报告 → 报销系统填报", mode: "office", agent: "general",
    text: "帮我报销 uploads/ 中的票据：自动识别并检查材料是否齐全、核对金额，生成报销单、金额核对报告和报销内容审核报告供我核实；我确认后再打开报销系统 https://znfti.lczyun.com/lczPortal/home （需要登录时提示我登录）填写表单并上传附件，提交前让我确认。" },
];

const C = {
  ws: null, retry: 0, ping: null, manualClose: false, awaiting: 0, target: undefined,
  curMsg: null, curBuf: "", renderTimer: null, stepHadText: false,
  stepNum: 0,
  turnTrace: null, turnChangesEl: null, turnFiles: [], turnMemoryEl: null,
  thinkingEl: null, thinkBox: null, thinkBuf: "", thinkRecorded: false,
  subMap: new Map(), subStack: [],
  tools: {}, expectEcho: false, pendingRun: false, taskStarted: false,
  activeConvId: null,
  queue: [],
  uploading: 0, title: "",
};
let els = {};

const wsOpen = () => C.ws && C.ws.readyState === 1;
function send(obj) {
  if (!wsOpen()) return false;
  C.ws.send(JSON.stringify(obj));
  return true;
}

export const opts = () => ({
  model: els.model?.value || undefined,
  mode: els.mode?.value || "auto",
  approval: els.approval?.value || "smart",
  agent_profile: els.agent?.value || "general",
});
export const getAgent = () => els.agent?.value || "general";

/* ================= 初始化 ================= */
export function init() {
  els = {
    stream: $("#stream"), messages: $("#messages"), welcome: $("#welcome"), input: $("#input"), send: $("#btn-send"),
    stop: $("#btn-stop"), agent: $("#sel-agent"), model: $("#sel-model"), mode: $("#sel-mode"), approval: $("#sel-approval"),
    connCount: $("#conn-count"), attachments: $("#attachments"), queueTray: $("#queue-tray"),
    fab: $("#btn-bottom"), title: $("#conv-title"),
    status: $("#status"), statusText: $("#status-text"), usage: $("#usage"), fileInput: $("#file-input"), drop: $("#drop-overlay"),
  };
  renderTemplates();
  els.send.onclick = submit;
  els.stop.onclick = stop;
  $("#btn-attach").onclick = () => els.fileInput.click();
  els.fileInput.onchange = (e) => { uploadAttachments(e.target.files); e.target.value = ""; };
  els.agent.onchange = () => {
    const ag = (S.config?.agents || []).find((a) => a.name === els.agent.value);
    if (ag && ag.mode && ["auto", "code", "office"].includes(ag.mode)) {
      els.mode.value = ag.mode;
    }
  };
  els.input.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey && !e.isComposing && e.keyCode !== 229) {
      e.preventDefault();
      submit();
    }
  });
  els.input.addEventListener("input", () => { autoGrow(); updateSendState(); });
  els.input.addEventListener("paste", (e) => {
    const files = [...(e.clipboardData?.files || [])];
    if (files.length) { e.preventDefault(); uploadAttachments(files); }
  });
  els.stream.addEventListener("scroll", onScroll, { passive: true });
  els.fab.onclick = () => scrollToBottom(true, true);
  setupDragDrop();
  updateSendState();
}

function renderTemplates(filterCat = "all") {
  const box = $("#templates");
  box.innerHTML = "";
  const list = filterCat === "all" ? TEMPLATES : TEMPLATES.filter((t) => t.cat === filterCat);
  list.forEach((t, idx) => {
    const b = h("button", { class: "tpl spotlight-card", type: "button", title: t.text, style: `--stagger:${idx}` },
      h("div", { class: "tpl-top" },
        h("span", { class: `tpl-ic-badge ${t.tone || "tone-indigo"}`, html: t.icon }),
        h("span", { class: "tpl-arrow", html: SVG.arrowUpRight })),
      h("b", { text: t.title }),
      h("span", { class: "tpl-desc", text: t.desc }));
    b.onclick = () => {
      els.input.value = t.text;
      els.mode.value = t.mode;
      if (t.agent && [...els.agent.options].some((o) => o.value === t.agent)) {
        els.agent.value = t.agent;
      }
      autoGrow();
      updateSendState();
      els.input.focus();
      els.input.setSelectionRange(els.input.value.length, els.input.value.length);
    };
    box.appendChild(b);
  });

  const filterBar = $("#tpl-filters");
  if (filterBar && !filterBar._bound) {
    filterBar._bound = true;
    $$(".tpl-chip", filterBar).forEach((chip) => {
      chip.onclick = () => {
        $$(".tpl-chip", filterBar).forEach((c) => c.classList.toggle("active", c === chip));
        renderTemplates(chip.dataset.cat || "all");
      };
    });
  }
}

/** 填充模型、智能体下拉框与连接器徽章 */
export function applyConfig() {
  // 模型列表
  const models = S.config?.models || [];
  els.model.innerHTML = "";
  if (!models.length) els.model.appendChild(h("option", { value: "", text: "无可用模型" }));
  models.forEach((m) => {
    const o = h("option", { value: m.name, text: m.name + (m.available ? "" : "（未配置）"), title: `${m.provider} · ${m.model}` });
    if (!m.available) o.disabled = true;
    els.model.appendChild(o);
  });

  // 智能体列表
  const prevAgent = els.agent.value || "general";
  const agents = S.config?.agents || [];
  els.agent.innerHTML = "";
  if (!agents.length) {
    els.agent.appendChild(h("option", { value: "general", text: "◆ 全能主控" }));
  } else {
    agents.forEach((a) => {
      els.agent.appendChild(h("option", {
        value: a.name,
        text: shortAgentLabel(a),
        title: `${a.title} — ${a.description || ""}`,
      }));
    });
  }
  if ([...els.agent.options].some((o) => o.value === prevAgent)) els.agent.value = prevAgent;

  // 连接器计数徽章（同时同步输入栏胶囊与左侧栏徽章）
  const enabledConns = (S.config?.connectors || []).filter((c) => c.enabled !== false).length;
  if (els.connCount) {
    els.connCount.hidden = enabledConns === 0;
    els.connCount.textContent = String(enabledConns);
  }
  const sbConn = $("#sb-conn-badge");
  if (sbConn) {
    sbConn.hidden = enabledConns === 0;
    sbConn.textContent = String(enabledConns);
  }
  syncMemoryBadge(S.config?.memory_stats);

  applyDefaults();
}

export function applyDefaults() {
  const st = S.settings || {};
  const models = S.config?.models || [];
  const want = [st.default_model, S.config?.default_model].find((n) => n && models.some((m) => m.name === n && m.available));
  if (want) els.model.value = want;
  else { const first = models.find((m) => m.available); if (first) els.model.value = first.name; }
  if (st.default_mode) els.mode.value = st.default_mode;
  if (st.default_approval) els.approval.value = st.default_approval;
}

export function selectAgent(name, profile) {
  if (!els.agent) return;
  if (![...els.agent.options].some((o) => o.value === name)) {
    els.agent.appendChild(h("option", { value: name, text: profile ? shortAgentLabel(profile) : `🤖 ${name}` }));
  }
  els.agent.value = name;
  if (profile?.mode && ["auto", "code", "office"].includes(profile.mode)) {
    els.mode.value = profile.mode;
  }
  els.input?.focus();
}

export function insertIntoInput(snippet) {
  if (!els.input) return;
  const ta = els.input;
  const start = ta.selectionStart ?? ta.value.length;
  const end = ta.selectionEnd ?? ta.value.length;
  const prefix = start > 0 && !/\s$/.test(ta.value.slice(0, start)) ? " " : "";
  ta.setRangeText(prefix + snippet, start, end, "end");
  autoGrow();
  updateSendState();
  ta.focus();
}

export function setInputValue(text) {
  if (!els.input) return;
  els.input.value = text || "";
  autoGrow();
  updateSendState();
  els.input.focus();
  els.input.setSelectionRange(els.input.value.length, els.input.value.length);
}

/* ================= WebSocket ================= */
export function connect() {
  if (C.ws && C.ws.readyState <= 1) return;
  C.manualClose = false;
  const ws = new WebSocket(`${location.protocol === "https:" ? "wss:" : "ws:"}//${location.host}/ws`);
  C.ws = ws;
  if (C.retry) setStatus("error", "正在重新连接…");
  ws.onopen = () => {
    C.retry = 0;
    updateSendState();
    sendInit();
    clearInterval(C.ping);
    C.ping = setInterval(() => send({ type: "ping" }), 25000);
  };
  ws.onmessage = (m) => {
    let e;
    try { e = JSON.parse(m.data); } catch { return; }
    try { handle(e); } catch (err) { console.error("事件处理失败", e.type, err); }
  };
  ws.onclose = (ev) => {
    clearInterval(C.ping);
    if (C.ws !== ws) return;
    C.ws = null;
    updateSendState();
    if (ev.code === 4401) { bus.emit("unauthorized"); return; }
    if (C.manualClose) return;
    setStatus("error", "连接已断开，正在重连…");
    const delay = Math.min(15000, 800 * 2 ** C.retry++);
    setTimeout(() => { if (!C.manualClose) connect(); }, delay);
  };
}
export function disconnect() {
  C.manualClose = true;
  clearInterval(C.ping);
  if (C.ws) { try { C.ws.close(); } catch { /* ignore */ } C.ws = null; }
}

function sendInit() {
  const id = C.target !== undefined ? C.target : S.convId;
  C.awaiting++;
  if (id) send({ type: "init", conversation_id: id });
  else send({ type: "new", ...opts() });
}

/** 打开对话：id 为空表示新对话 */
export function openConversation(id) {
  id = id || null;
  if (C.target === undefined && id && id === S.convId) return;
  C.target = id;
  C.pendingRun = false;
  C.expectEcho = false;
  C.taskStarted = false;
  C.activeConvId = id;
  resetView();
  setRunning(false);
  showWelcome(!id);
  if (id) els.messages.innerHTML = `<div class="stream-loading"><span class="spinner"></span> 正在同步对话状态…</div>`;
  setTitle(id ? "加载中…" : "新对话");
  if (!id) {
    els.agent.value = "general";
    applyDefaults();
  }
  if (wsOpen()) sendInit();
  else connect();
  if (isMobile()) bus.emit("drawer:close");
  if (!id) setTimeout(() => els.input.focus(), 50);
}

/* ================= 事件处理 ================= */
function ensureTrace() {
  if (C.turnTrace && C.turnTrace.parentElement === els.messages) return C.turnTrace;
  C.turnTrace = R.createTurnTrace({ running: true, open: true });
  C.turnTrace._state.steps = Math.max(1, C.stepNum);
  // 若当前已有未完成的最终消息或文件变更卡，插到它们之前，保持轨迹在最上方
  const anchor = C.curMsg?.parentElement === els.messages ? C.curMsg
    : C.turnChangesEl?.parentElement === els.messages ? C.turnChangesEl
    : C.thinkingEl?.parentElement === els.messages ? C.thinkingEl : null;
  if (anchor) els.messages.insertBefore(C.turnTrace, anchor);
  else els.messages.appendChild(C.turnTrace);
  return C.turnTrace;
}

function resetTurnRuntime() {
  C.stepNum = 0;
  C.turnTrace = null;
  C.turnChangesEl = null;
  C.turnFiles = [];
  C.turnMemoryEl = null;
  C.thinkBox = null;
  C.thinkBuf = "";
  C.thinkRecorded = false;
  C.subMap.clear();
  C.subStack = [];
  C.tools = {};
}

function handle(e) {
  if (e.type === "sidebar_conv_state") {
    bus.emit("conv:live-state", e);
    return;
  }
  if (e.type === "ready") return onReady(e);
  if (e.type === "pong") return;
  if (C.awaiting > 0) {
    if (e.type === "error" && (!e.conversation_id || e.conversation_id === C.target)) showErrorCard(e.message);
    return;
  }
  // 严格隔离多并发对话事件流：后台运行的其他会话事件绝不混入当前视图！
  if (e.conversation_id) {
    if (C.activeConvId && e.conversation_id !== C.activeConvId) return;
    if (!C.activeConvId && !C.pendingRun) return;
  }
  const d = e.depth || 0;
  switch (e.type) {
    case "task_start":
      if (d === 0) onTaskStart(e);
      break;
    case "step":
      if (d === 0) {
        C.stepNum = e.step || (C.stepNum + 1);
        if (C.turnTrace) {
          C.turnTrace._state.steps = Math.max(C.turnTrace._state.steps, C.stepNum);
          R.refreshTraceHeader(C.turnTrace);
        }
        finalizeAssistant();
        C.stepHadText = false;
        C.thinkRecorded = false;
        showThinking(`Step ${C.stepNum} · 思考中…`);
      }
      break;
    case "thinking_delta":
      if (d === 0) onThinking(e.text || "");
      break;
    case "text_delta":
      if (d === 0) onDelta(e.text || "");
      break;
    case "assistant_message":
      onAssistantMessage(e, d);
      break;
    case "tool_start":
      onToolStart(e);
      break;
    case "tool_end":
      onToolEnd(e);
      break;
    case "file_changes":
      if (d === 0) onFileChanges(e);
      break;
    case "memory_updated":
      if (d === 0) onMemoryUpdated(e);
      break;
    case "plan_update":
      panel.renderPlan(e.todos || []);
      break;
    case "external_op":
      panel.upsertOp(e);
      break;
    case "login_required":
      onLoginRequired(e);
      break;
    case "login_resolved": {
      const c = document.getElementById("lg-" + e.id);
      if (c) resolveCard(c, esc(e.message || (e.ok ? "✅ 已登录" : "⌛ 等待登录超时")));
      setStatus("running", "执行中…");
      break;
    }
    case "approval_request":
      onApproval(e);
      break;
    case "approval_result": {
      const c = document.getElementById("ap-" + e.id);
      if (c) resolveCard(c, e.approved ? "✅ 已允许" : "⛔ 已拒绝");
      setStatus("running", "执行中…");
      break;
    }
    case "ask_user":
      onAsk(e);
      break;
    case "review":
      onReviewRound(e, d);
      break;
    case "loop_warning":
      eventLine(`⚠️ 循环检测：${e.reason || "调整执行策略"}`, d, "warn");
      break;
    case "subagent_start":
      onSubStart(e, d);
      break;
    case "subagent_end":
      onSubEnd(e);
      break;
    case "compact":
      eventLine(`🗜 上下文已自动压缩：~${fmtK(e.before)} → ~${fmtK(e.after)} tokens`, d);
      break;
    case "status":
      setStatus("running", e.message || "执行中…");
      break;
    case "usage":
      if (d === 0) renderUsage(e);
      break;
    case "error":
      onError(e);
      break;
    case "done":
      if (d === 0) onDone(e);
      break;
    case "cancelled":
      if (d === 0) {
        finalizeAssistant();
        closeThinkBox();
        removeThinking();
        if (C.turnTrace) R.finalizeTurnTrace(C.turnTrace, { collapse: false });
        eventLine("⏹ 任务已中断", 0, "warn");
      }
      break;
    case "idle":
      onIdle(e);
      break;
    case "queue_updated":
      C.queue = Array.isArray(e.queue) ? e.queue : [];
      renderQueueTray();
      break;
    case "conversation_updated":
      if (e.id === S.convId && e.title) setTitle(e.title);
      bus.emit("conv:updated", e);
      break;
    default:
      break;
  }
}

function onReady(e) {
  if (C.awaiting > 0) {
    C.awaiting--;
    if (C.awaiting > 0) return;
  }
  C.target = undefined;
  S.convId = e.conversation_id || e.session_id || null;
  C.activeConvId = (e.history && e.history.length > 0) || e.running ? S.convId : S.convId;
  const history = e.history || [];
  const persisted = history.length > 0 || !!e.running;
  resetView();
  if (persisted) {
    if (e.model && [...els.model.options].some((o) => o.value === e.model && !o.disabled)) els.model.value = e.model;
    if (e.mode) els.mode.value = e.mode;
    if (e.approval) els.approval.value = e.approval;
    if (e.agent_profile) selectAgent(e.agent_profile);
  }
  setTitle(e.title || (persisted ? "未命名对话" : "新对话"));
  showWelcome(!persisted && !C.pendingRun);
  C.queue = Array.isArray(e.queue) ? e.queue : [];
  renderQueueTray();
  panel.setChanges(e.file_changes || []);
  panel.setOps(e.external_ops || []);
  R.renderHistory(els.messages, history, { ...renderOpts(), running: !!e.running });
  panel.renderPlan(e.todos || [], { quiet: true });
  setRunning(!!e.running || C.pendingRun);
  if (e.running) {
    C.taskStarted = true;
    const traces = $$(".turn-trace.running", els.messages);
    if (traces.length) C.turnTrace = traces[traces.length - 1];
    // 恢复正在后台流式输出的中间态（思维链、活动工具与流式正文），实现多对话间无缝切回！
    const ls = e.live_state || {};
    if (ls.step) C.stepNum = ls.step;
    if (ls.thinking) onThinking(ls.thinking);
    if (Array.isArray(ls.active_tools)) {
      ls.active_tools.forEach((tc) => onToolStart({ ...tc, depth: 0 }));
    }
    if (ls.text) onDelta(ls.text);
    if (!ls.thinking && !ls.text && !(ls.active_tools && ls.active_tools.length)) {
      showThinking(ls.step ? `Step ${ls.step} · 执行中…` : "执行中…");
    }
    (e.pending_interactions || []).forEach((pi) => {
      if (pi.type === "approval_request") onApproval(pi);
      else if (pi.type === "ask_user") onAsk(pi);
      else if (pi.type === "login_required") onLoginRequired(pi);
    });
  }
  updateHash(persisted);
  updateTurnActions();
  bus.emit("conv:changed", S.convId);
  scrollToBottom(true);
}

function updateHash(persisted) {
  const want = persisted && S.convId ? `#/c/${S.convId}` : "#/";
  if (location.hash !== want && !(want === "#/" && (location.hash === "" || location.hash === "#"))) {
    history.replaceState(null, "", want);
  }
  $("#btn-conv-menu").hidden = !persisted;
  S.convPersisted = persisted;
}

function onTaskStart(e) {
  if (e.conversation_id) {
    S.convId = e.conversation_id;
    C.activeConvId = e.conversation_id;
  }
  C.taskStarted = true;
  C.pendingRun = false;
  resetTurnRuntime();
  if (e.agent_profile) selectAgent(e.agent_profile);
  if (C.expectEcho) C.expectEcho = false;
  else {
    const { text, files } = R.splitAttachments(e.task || "");
    appendRoot(R.userMsgEl(text, files, renderOpts()));
  }
  showWelcome(false);
  setRunning(true);
  if (e.title && !C.title) setTitle(e.title);
  updateHash(true);
  updateTurnActions();
  showThinking("正在理解目标与规划步骤…");
  bus.emit("conv:live-state", { id: S.convId, title: C.title || e.title || "新对话", running: true, queue_len: C.queue.length });
  bus.emit("conv:touched", S.convId);
}

function onAssistantMessage(e, d) {
  const hasTools = Array.isArray(e.tool_calls) && e.tool_calls.length > 0;
  const content = String(e.content || "").trim();
  const thinking = String(e.thinking || "").trim();

  if (d === 0) {
    closeThinkBox();
    removeThinking();

    // 若后端一次性返回了 thinking（非流式 provider），补录进思维链轨迹
    if (thinking && !C.thinkRecorded) {
      const trace = ensureTrace();
      R.addTraceThinking(trace, thinking, C.stepNum || 1);
      const thBox = document.createElement("details");
      thBox.className = "thinking";
      thBox.innerHTML = `<summary><span>💭 Step ${C.stepNum || 1} 推理思考（${thinking.length} 字）</span><span class="chev">›</span></summary><div class="think-text">${esc(thinking)}</div>`;
      trace._body.appendChild(thBox);
      C.thinkRecorded = true;
    }

    if (hasTools) {
      // 中间步骤：紧接着要执行工具，把中间说明归入步骤轨迹，避免在主消息流留下碎片气泡
      const trace = ensureTrace();
      const streamedText = C.curMsg ? C.curBuf.trim() : (!C.stepHadText ? content : "");
      if (C.curMsg) {
        clearTimeout(C.renderTimer);
        C.renderTimer = null;
        C.curMsg.remove();
        C.curMsg = null;
        C.curBuf = "";
      }
      if (streamedText) {
        if (!thinking && !C.thinkRecorded) {
          R.addTraceThinking(trace, streamedText, C.stepNum || 1);
          C.thinkRecorded = true;
        }
        const note = div("step-note md");
        R.setMarkdown(note, streamedText);
        trace._body.appendChild(note);
      }
      R.refreshTraceHeader(trace);
    } else {
      // 最终回复步骤
      if (C.curMsg) finalizeAssistant();
      else if (content && !C.stepHadText) {
        const m = R.assistantMsgEl(content);
        appendRoot(m);
      }
    }
  } else if (content) {
    appendToSubagent(div("step-note", esc(content.slice(0, 1000))));
  }
}

function onReviewRound(e, d) {
  if (d === 0) {
    // 若自检轮之前已经输出了草稿回复，将其收折进轨迹，以便自检后的最终交付保持整洁
    const kids = [...els.messages.children];
    const last = kids.reverse().find((el) => el.classList.contains("assistant"));
    if (last && last._raw) {
      const trace = ensureTrace();
      const note = div("step-note md");
      R.setMarkdown(note, last._raw);
      trace._body.appendChild(note);
      last.remove();
    }
    const trace = ensureTrace();
    trace._body.appendChild(div("event-line", `🔍 自检第 ${e.round} 轮：正在核对需求完整性与产物质量…`));
  } else {
    appendToSubagent(div("event-line", `🔍 自检第 ${e.round} 轮…`));
  }
}

function onFileChanges(e) {
  const files = e.files || [];
  if (!files.length) return;
  C.turnFiles = files;
  panel.upsertChanges(files);
  if (C.turnTrace) {
    C.turnTrace._state.changeCount = files.length;
    R.refreshTraceHeader(C.turnTrace);
  }
  if (!C.turnChangesEl || !C.turnChangesEl.parentElement) {
    C.turnChangesEl = R.fileChangesCardEl(files, renderOpts());
  } else {
    R.updateFileChangesCard(C.turnChangesEl, files, renderOpts());
  }
  // 始终置于当前轮底部（思考行之前）
  if (C.thinkingEl && C.thinkingEl.parentElement === els.messages) {
    els.messages.insertBefore(C.turnChangesEl, C.thinkingEl);
  } else {
    els.messages.appendChild(C.turnChangesEl);
  }
  scrollToBottom();
}

function onMemoryUpdated(e) {
  if (e.stats) syncMemoryBadge(e.stats);
  const events = e.events || [];
  if (!events.length) return;
  if (C.turnMemoryEl) C.turnMemoryEl.remove();
  C.turnMemoryEl = R.memoryLearnedBarEl(events, renderOpts());
  els.messages.appendChild(C.turnMemoryEl);
  scrollToBottom();
}

function onDone(e) {
  finalizeAssistant();
  closeThinkBox();
  removeThinking();
  if (e.files_changed && e.files_changed.length) {
    onFileChanges({ files: e.files_changed, final: true });
  }
  if (C.turnTrace) {
    const collapse = C.turnTrace._state.toolNames.length > 3;
    R.finalizeTurnTrace(C.turnTrace, { collapse, steps: e.steps });
  }
  // 确保文件变更摘要卡片与记忆沉淀胶囊排在最终助手消息之后
  if (C.turnChangesEl && C.turnChangesEl.parentElement === els.messages) {
    els.messages.appendChild(C.turnChangesEl);
  }
  if (!C.turnMemoryEl && e.memories_learned && e.memories_learned.length) {
    C.turnMemoryEl = R.memoryLearnedBarEl(e.memories_learned, renderOpts());
  }
  if (C.turnMemoryEl) {
    els.messages.appendChild(C.turnMemoryEl);
  }
  R.markFinals(els.messages);
  const u = e.usage || {};
  const tok = u.input_tokens != null ? ` · ↑${fmtK(u.input_tokens)} ↓${fmtK(u.output_tokens)} tokens` : "";
  eventLine(`✔ 完成 · ${e.steps ?? "?"} 步 · ${e.elapsed ?? "?"}s${tok}${e.incomplete ? " · 达步数上限" : ""}`, 0, e.incomplete ? "warn" : "ok");
  notify("✅ 任务已完成", C.title || "OmniAgent");
}

function onIdle(e) {
  C.taskStarted = false;
  C.pendingRun = false;
  if (e && Array.isArray(e.queue)) C.queue = e.queue;
  finalizeAssistant();
  closeThinkBox();
  setRunning(false);
  renderQueueTray();
  updateTurnActions();
  bus.emit("conv:live-state", { id: S.convId, title: C.title, running: false, finished: false, queue_len: C.queue.length });
  bus.emit("conv:idle", S.convId);
}

function onError(e) {
  const msg = e.message || "未知错误";
  finalizeAssistant();
  closeThinkBox();
  removeThinking();
  if (C.turnTrace) R.finalizeTurnTrace(C.turnTrace, { collapse: false });
  if (!C.taskStarted) {
    C.expectEcho = false;
    C.pendingRun = false;
    setRunning(false);
    toast(msg, "error");
  }
  showErrorCard(msg);
  setStatus("error", "出错");
}

function showErrorCard(msg) {
  const card = div("card error", `<h4>❌ 出错了</h4><pre>${esc(msg)}</pre>`);
  if (/API Key|模型密钥|没有可用的模型/.test(msg)) {
    const row = div("row");
    row.appendChild(h("button", { class: "btn small primary", type: "button", text: "去配置模型密钥", onclick: () => bus.emit("settings:open", "keys") }));
    card.appendChild(row);
  }
  els.messages.querySelector(".stream-loading")?.remove();
  appendRoot(card);
  scrollToBottom(true);
}

/* ---------------- 流式文本与实时思维链 ---------------- */
function onDelta(text) {
  removeThinking();
  closeThinkBox();
  showWelcome(false);
  C.stepHadText = true;
  if (!C.curMsg) {
    C.curMsg = R.assistantMsgEl("", { streaming: true });
    C.curBuf = "";
    if (C.turnChangesEl && C.turnChangesEl.parentElement === els.messages) {
      els.messages.insertBefore(C.curMsg, C.turnChangesEl);
    } else {
      appendRoot(C.curMsg);
    }
  }
  C.curBuf += text;
  C.curMsg._raw = C.curBuf;
  if (!C.renderTimer) {
    C.renderTimer = setTimeout(() => {
      C.renderTimer = null;
      if (C.curMsg) { C.curMsg._md.innerHTML = R.renderMarkdown(C.curBuf); scrollToBottom(); }
    }, 60);
  }
}

function finalizeAssistant() {
  clearTimeout(C.renderTimer);
  C.renderTimer = null;
  const m = C.curMsg;
  if (!m) return;
  C.curMsg = null;
  m._md.classList.remove("cursor");
  if (!C.curBuf.trim()) { m.remove(); return; }
  R.setMarkdown(m._md, C.curBuf);
  scrollToBottom();
}

function onThinking(text) {
  removeThinking();
  showWelcome(false);
  const trace = ensureTrace();
  if (!trace._userToggled) {
    trace.classList.add("open");
    trace._head.setAttribute("aria-expanded", "true");
  }
  if (!C.thinkBox) {
    C.thinkBuf = "";
    C.thinkBox = document.createElement("details");
    C.thinkBox.className = "thinking live";
    C.thinkBox.open = true;
    C.thinkBox.innerHTML = `<summary><span class="spinner sm"></span><span>💭 Step ${C.stepNum || 1} 正在深度推理…</span><span class="chev">›</span></summary><div class="think-text"></div>`;
    trace._body.appendChild(C.thinkBox);
    R.refreshTraceHeader(trace);
  }
  C.thinkBuf += text;
  const t = C.thinkBox.querySelector(".think-text");
  t.textContent = C.thinkBuf.length > 24000 ? "…" + C.thinkBuf.slice(-24000) : C.thinkBuf;
  if (C.thinkBox.open) t.scrollTop = t.scrollHeight;
  scrollToBottom();
}

function closeThinkBox() {
  if (!C.thinkBox) return;
  const step = C.stepNum || 1;
  C.thinkBox.classList.remove("live");
  C.thinkBox.querySelector("summary").innerHTML = `<span>💭 Step ${step} 推理思考（${C.thinkBuf.length} 字）</span><span class="chev">›</span>`;
  C.thinkBox.open = false;
  if (C.turnTrace && C.thinkBuf.trim()) {
    R.addTraceThinking(C.turnTrace, C.thinkBuf, step);
    C.thinkRecorded = true;
  }
  C.thinkBox = null;
}

function showThinking(text) {
  if (C.thinkBox) return;
  if (!C.thinkingEl) C.thinkingEl = div("event-line thinking-line", `<span class="dots"><i></i><i></i><i></i></span><span class="t"></span>`);
  C.thinkingEl.querySelector(".t").textContent = text;
  els.messages.appendChild(C.thinkingEl);
  scrollToBottom();
}
function removeThinking() {
  if (C.thinkingEl) { C.thinkingEl.remove(); C.thinkingEl = null; }
}

/* ---------------- 工具与子智能体 ---------------- */
function renderOpts() {
  return {
    onFile: (p) => panel.addOutput(p),
    onPreview: (p) => panel.preview(p),
    onReview: (p, mode = "diff", files = null) => panel.openReview(p, mode, files),
    onChanges: (files) => panel.upsertChanges(files, { silent: true }),
    onImage: (src) => lightbox(src),
    onOpenMemory: (tab) => bus.emit("memory:open", tab),
  };
}

function onToolStart(e) {
  showWelcome(false);
  removeThinking();
  if ((e.depth || 0) === 0) closeThinkBox();
  if (e.name === "todo_write") return;
  const el = R.toolCardEl(e.id, e.name, e.arguments || {}, e.summary);
  C.tools[e.id] = el;
  if ((e.depth || 0) === 0) {
    const trace = ensureTrace();
    trace._state.toolNames.push(e.name);
    trace._body.appendChild(el);
    R.refreshTraceHeader(trace);
  } else {
    appendToSubagent(el);
  }
  scrollToBottom();
}

function onToolEnd(e) {
  if (e.name === "todo_write") return;
  const el = C.tools[e.id];
  if (!el) return;
  R.fillToolResult(el, e.name, e.content, e.is_error, e.data, e.duration, renderOpts());
  delete C.tools[e.id];
  if ((e.depth || 0) === 0 && S.running) showThinking("分析工具输出…");
  scrollToBottom();
}

function onSubStart(e, d) {
  removeThinking();
  if (d === 0) closeThinkBox();
  const row = R.subagentRowEl({ ...e, running: true });
  if (d === 0) {
    const trace = ensureTrace();
    trace._state.subCount++;
    trace._body.appendChild(row);
    R.refreshTraceHeader(trace);
  } else {
    appendToSubagent(row);
  }
  if (e.subagent_id) C.subMap.set(e.subagent_id, row);
  C.subStack.push(row);
  scrollToBottom();
}

function onSubEnd(e) {
  let row = e.subagent_id ? C.subMap.get(e.subagent_id) : null;
  if (row && e.subagent_id) C.subMap.delete(e.subagent_id);
  if (!row) row = C.subStack.pop();
  else {
    const idx = C.subStack.indexOf(row);
    if (idx >= 0) C.subStack.splice(idx, 1);
  }
  if (row) R.completeSubagentRow(row, e);
  scrollToBottom();
}

function appendToSubagent(el) {
  const activeSub = C.subStack[C.subStack.length - 1];
  const stepsBox = activeSub?.querySelector(".sub-steps");
  if (stepsBox) stepsBox.appendChild(el);
  else ensureTrace()._body.appendChild(el);
}

/* ---------------- 审批 / 提问 ---------------- */
function onApproval(e) {
  removeThinking();
  setStatus("waiting", "等待你的确认");
  const args = e.arguments || {};
  const detail = args.command || args.code || JSON.stringify(args, null, 2);
  const c = div("card approval", `<h4>⚠️ 需要确认：${esc(e.tool)} <small>${esc(e.reason || "")}</small></h4><pre>${esc(detail)}</pre>
    <div class="row"><button type="button" class="btn primary small" data-a="yes">允许执行</button><button type="button" class="btn small" data-a="no">拒绝</button>
    <button type="button" class="btn ghost small" data-a="always">本对话全部允许</button></div>`);
  c.id = "ap-" + e.id;
  appendRoot(c);
  c.querySelectorAll("button").forEach((b) => (b.onclick = () => {
    const a = b.dataset.a;
    send({ type: "approval", id: e.id, approved: a !== "no", always: a === "always" });
    if (a === "always") els.approval.value = "auto";
    resolveCard(c, a === "no" ? "⛔ 已拒绝" : "✅ 已允许");
  }));
  scrollToBottom(true);
  notify("⚠️ 需要你的确认", `${e.tool}：${e.reason || ""}`);
}

function onAsk(e) {
  removeThinking();
  setStatus("waiting", "等待你的回答");
  const c = div("card ask", `<h4>❓ 智能体提问</h4><div class="md"></div>
    <div class="row"><textarea rows="2" placeholder="输入回答，Enter 提交，Shift+Enter 换行" aria-label="回答"></textarea><button type="button" class="btn primary small">回答</button></div>`);
  R.setMarkdown(c.querySelector(".md"), e.question || "");
  appendRoot(c);
  const input = c.querySelector("textarea"), btn = c.querySelector("button");
  const submitAnswer = () => {
    const v = input.value.trim();
    if (!v) { input.focus(); return; }
    send({ type: "answer", id: e.id, text: v });
    resolveCard(c, "💬 已回答：" + esc(v));
    setStatus("running", "执行中…");
  };
  btn.onclick = submitAnswer;
  input.onkeydown = (ev) => { if (ev.key === "Enter" && !ev.shiftKey && !ev.isComposing && ev.keyCode !== 229) { ev.preventDefault(); submitAnswer(); } };
  setTimeout(() => input.focus(), 50);
  scrollToBottom(true);
  notify("❓ 智能体向你提问", String(e.question || "").slice(0, 100));
}

function onLoginRequired(e) {
  if (document.getElementById("lg-" + e.id)) return;
  removeThinking();
  setStatus("waiting", "等待你登录外部系统");
  const shot = e.screenshot ? `<img class="login-shot" src="${fileUrl(e.screenshot)}" alt="登录页截图">` : "";
  const c = div("card login-card", `<h4>🔐 需要你登录：${esc(e.system || e.session || "外部系统")}</h4>
    <p class="login-msg">${esc(e.message || "请在弹出的浏览器窗口中完成登录，登录后智能体会自动继续。")}</p>
    ${e.url ? `<div class="login-url">🌐 <a href="${esc(e.url)}" target="_blank" rel="noopener noreferrer">${esc(e.url)}</a></div>` : ""}
    ${shot}
    <div class="row"><span class="login-wait"><span class="spinner sm"></span> 正在自动检测登录状态…</span>
    <button type="button" class="btn primary small" data-a="done">我已完成登录</button></div>`);
  c.id = "lg-" + e.id;
  appendRoot(c);
  const img = c.querySelector(".login-shot");
  if (img) img.onclick = () => lightbox(img.src);
  c.querySelector("[data-a=done]").onclick = () => {
    send({ type: "login_done", id: e.id });
    resolveCard(c, "✅ 你已确认登录，智能体继续执行");
    setStatus("running", "执行中…");
  };
  scrollToBottom(true);
  notify("🔐 需要你登录", `${e.system || "外部系统"}：请在浏览器窗口中完成登录`);
}

function resolveCard(c, html) {
  if (c.classList.contains("resolved")) return;
  c.classList.add("resolved");
  const r = c.querySelector(".row");
  if (r) r.outerHTML = `<div class="resolved-text">${html}</div>`;
}

/* ---------------- 布局辅助 ---------------- */
function appendRoot(el) {
  if (C.thinkingEl && C.thinkingEl.parentElement === els.messages) {
    els.messages.insertBefore(el, C.thinkingEl);
  } else {
    els.messages.appendChild(el);
  }
  scrollToBottom();
  return el;
}

function eventLine(text, depth = 0, kind = "") {
  const el = div(`event-line ${kind}`, esc(text));
  if (depth > 0) appendToSubagent(el);
  else appendRoot(el);
  return el;
}

function resetView() {
  finalizeAssistant();
  els.messages.innerHTML = "";
  resetTurnRuntime();
  C.queue = [];
  renderQueueTray();
  C.thinkingEl = null;
  C.curMsg = null;
  panel.resetOutputs();
  panel.setChanges([]);
  panel.setOps([]);
  panel.renderPlan([], { quiet: true });
  els.usage.textContent = "";
}

function showWelcome(v) {
  els.welcome.hidden = !v;
  const app = $("#app");
  if (app) {
    app.classList.toggle("is-welcome", !!v);
    if (v && localStorage.getItem("omni_panel_pinned") !== "1") {
      app.classList.add("panel-collapsed");
      $("#btn-toggle-panel")?.classList.remove("active");
    }
  }
  const composerEl = $("#composer");
  const targetParent = v ? $("#welcome-composer-slot") : $("#composer-dock");
  if (composerEl && targetParent && composerEl.parentElement !== targetParent) {
    const hadFocus = document.activeElement === els.input;
    flipMoveElement(composerEl, () => targetParent.appendChild(composerEl), { duration: 290 });
    autoGrow();
    if (hadFocus) els.input?.focus();
  }
}

function setTitle(t) {
  C.title = t || "";
  S.convTitle = C.title;
  els.title.textContent = C.title || "新对话";
  els.title.title = C.title;
  updateDocTitle();
}
function updateDocTitle() {
  const base = C.title && C.title !== "新对话" ? `${C.title} · OmniAgent` : "OmniAgent";
  document.title = (S.running ? "● " : "") + base;
}

export function setStatus(kind, text) {
  els.status.className = "status " + kind;
  els.statusText.textContent = text;
}
function setRunning(v) {
  S.running = v;
  els.send.hidden = false;
  els.send.classList.toggle("queue-mode", !!v);
  els.send.innerHTML = v ? SVG.queue : SVG.sendUp;
  els.stop.hidden = !v;
  if (els.input) {
    els.input.placeholder = v
      ? "当前任务执行中 — 继续输入下一条问题按 Enter 可加入排队队列（支持多条排队）…"
      : "描述你想完成的工程开发、外部系统联动、数据分析或论文报告任务，输入 @connector 可接入外部数据源…";
  }
  setStatus(v ? "running" : "idle", v ? (C.queue.length ? `执行中 · 队列 ${C.queue.length}` : "执行中…") : "就绪");
  if (!v) removeThinking();
  updateSendState();
  renderQueueTray();
  updateDocTitle();
  bus.emit("running", v);
}
function updateSendState() {
  const hasText = els.input.value.trim().length > 0;
  els.send.disabled = !hasText || C.uploading > 0 || !wsOpen();
  els.send.title = !wsOpen()
    ? "未连接到服务器"
    : C.uploading
      ? "附件上传中…"
      : S.running
        ? "加入排队队列 (Enter)"
        : "发送任务 (Enter)";
}
function renderUsage(e) {
  const parts = [];
  if (e.context_tokens != null) parts.push(`上下文 ${fmtK(e.context_tokens)}${e.context_window ? "/" + fmtK(e.context_window) : ""}`);
  parts.push(`↑${fmtK(e.input_tokens)} ↓${fmtK(e.output_tokens)}`);
  els.usage.textContent = parts.join(" · ");
  els.usage.title = `本对话累计：输入 ${e.input_tokens || 0} tokens，输出 ${e.output_tokens || 0} tokens`;
}

/* ---------------- 滚动 ---------------- */
const distToBottom = () => els.stream.scrollHeight - els.stream.scrollTop - els.stream.clientHeight;
function scrollToBottom(force, smooth) {
  if (force || distToBottom() < 160) {
    if (smooth) els.stream.scrollTo({ top: els.stream.scrollHeight, behavior: "smooth" });
    else els.stream.scrollTop = els.stream.scrollHeight;
  }
  onScroll();
}
function onScroll() { els.fab.hidden = distToBottom() < 300; }

/* ================= 发送 / 多问题排队 / 停止 / 重新生成 / 编辑 ================= */
function renderQueueTray() {
  if (!els.queueTray) return;
  const q = C.queue || [];
  if (S.running) {
    setStatus("running", q.length ? `执行中 · 排队 ${q.length}` : "执行中…");
  }
  if (!q.length) {
    els.queueTray.hidden = true;
    els.queueTray.innerHTML = "";
    return;
  }
  els.queueTray.hidden = false;
  els.queueTray.innerHTML = "";

  const head = div("qt-head");
  const left = div("qt-head-left",
    `<span class="qt-pulse"></span><span class="qt-title">问题排队队列（${q.length}）</span>`
    + `<span class="qt-hint">${S.running ? "上一问题完成后将自动依次执行" : "已暂停，可点击立即执行"}</span>`);
  const right = div("qt-head-acts");
  if (!S.running) {
    right.appendChild(h("button", {
      type: "button",
      class: "qt-btn primary",
      text: "▶ 立即执行队列",
      onclick: () => {
        C.pendingRun = true;
        setRunning(true);
        send({ type: "queue_flush" });
      },
    }));
  }
  right.appendChild(h("button", {
    type: "button",
    class: "qt-btn",
    text: "清空",
    onclick: () => send({ type: "queue_clear" }),
  }));
  head.append(left, right);

  const list = div("qt-list");
  q.forEach((item, idx) => {
    const row = div("qt-item");
    const badge = h("span", { class: "qt-idx", text: `#${idx + 1}` });
    const txt = h("span", { class: "qt-text", text: item.raw_text, title: item.raw_text });
    const attBadge = item.attachments?.length
      ? h("span", { class: "qt-att", text: `📎${item.attachments.length}` })
      : null;

    const acts = div("qt-item-acts");
    if (idx > 0) {
      acts.appendChild(h("button", {
        type: "button",
        class: "qt-ic-btn",
        title: "前移一位",
        text: "↑",
        onclick: () => send({ type: "queue_move", id: item.id, direction: "up" }),
      }));
    }
    acts.appendChild(h("button", {
      type: "button",
      class: "qt-ic-btn",
      title: "编辑排队问题",
      text: "✎",
      onclick: () => {
        const editIn = h("input", { class: "qt-edit-inp", value: item.raw_text });
        const saveEdit = () => {
          const v = editIn.value.trim();
          if (v && v !== item.raw_text) send({ type: "queue_edit", id: item.id, content: v });
          else renderQueueTray();
        };
        editIn.onkeydown = (ev) => {
          if (ev.key === "Enter") { ev.preventDefault(); saveEdit(); }
          if (ev.key === "Escape") { ev.preventDefault(); renderQueueTray(); }
        };
        editIn.onblur = saveEdit;
        txt.replaceWith(editIn);
        editIn.focus();
        editIn.select();
      },
    }));
    acts.appendChild(h("button", {
      type: "button",
      class: "qt-ic-btn danger",
      title: "移出队列",
      text: "✕",
      onclick: () => send({ type: "queue_remove", id: item.id }),
    }));

    row.append(badge, txt);
    if (attBadge) row.appendChild(attBadge);
    row.appendChild(acts);
    list.appendChild(row);
  });

  els.queueTray.append(head, list);
}

function submit() {
  const text = els.input.value.trim();
  if (!text) return;
  if (C.uploading) { toast("附件仍在上传，请稍候", "warn"); return; }
  if (!wsOpen()) { toast("尚未连接到服务器，请稍后重试", "error"); return; }
  const atts = [...S.attachments];

  // 若当前正在运行上一问题，则自动进入排队队列（支持连续添加多条排队）
  if (S.running || C.pendingRun) {
    send({ type: "queue_add", content: text, attachments: atts, ...opts() });
    els.input.value = "";
    autoGrow();
    S.attachments = [];
    renderAttachments();
    updateSendState();
    toast(`已加入排队队列（第 ${(C.queue?.length || 0) + 1} 位）`, "info", 2200);
    els.input.focus();
    return;
  }

  showWelcome(false);
  appendRoot(R.userMsgEl(text, atts, renderOpts()));
  C.expectEcho = true;
  C.pendingRun = true;
  send({ type: "task", content: text, attachments: atts, ...opts() });
  els.input.value = "";
  autoGrow();
  S.attachments = [];
  renderAttachments();
  setRunning(true);
  showThinking("思考中…");
  scrollToBottom(true);
  maybeAskNotifyPermission();
}
function stop() {
  send({ type: "stop" });
  setStatus("waiting", "正在停止…");
}
export function regenerate() {
  if (S.running || !wsOpen()) return;
  C.pendingRun = true;
  setRunning(true);
  send({ type: "regenerate", ...opts() });
}
function editLast(msgEl) {
  if (S.running) return;
  const bubble = msgEl.querySelector(".bubble");
  if (msgEl.classList.contains("editing")) return;
  msgEl.classList.add("editing");
  const ta = h("textarea", { class: "edit-area", rows: 3, "aria-label": "编辑消息" });
  ta.value = msgEl._raw || bubble.textContent;
  const cancel = h("button", { class: "btn small ghost", type: "button", text: "取消" });
  const save = h("button", { class: "btn small primary", type: "button", text: "保存并重新执行" });
  const box = div("edit-box");
  box.append(ta, div("row"));
  box.lastChild.append(cancel, save);
  bubble.hidden = true;
  msgEl.insertBefore(box, bubble);
  const grow = () => { ta.style.height = "auto"; ta.style.height = Math.min(ta.scrollHeight, 300) + "px"; };
  ta.addEventListener("input", grow);
  setTimeout(() => { grow(); ta.focus(); ta.setSelectionRange(ta.value.length, ta.value.length); }, 10);
  const close = () => { box.remove(); bubble.hidden = false; msgEl.classList.remove("editing"); };
  cancel.onclick = close;
  const doSave = () => {
    const v = ta.value.trim();
    if (!v) { ta.focus(); return; }
    if (!wsOpen()) { toast("尚未连接到服务器", "error"); return; }
    close();
    C.pendingRun = true;
    setRunning(true);
    send({ type: "edit_last", content: v, ...opts() });
  };
  save.onclick = doSave;
  ta.addEventListener("keydown", (e) => {
    if (e.key === "Escape") { e.stopPropagation(); close(); }
    if (e.key === "Enter" && (e.metaKey || e.ctrlKey) && !e.isComposing) { e.preventDefault(); doSave(); }
  });
}

/** 只在最后一轮显示「编辑 / 重新生成」 */
function updateTurnActions() {
  $$(".act-regen, .act-edit", els.messages).forEach((b) => b.remove());
  if (S.running) return;
  const kids = [...els.messages.children];
  let lastUserIdx = -1;
  kids.forEach((k, i) => { if (k.classList.contains("user")) lastUserIdx = i; });
  if (lastUserIdx < 0) return;
  const lastUser = kids[lastUserIdx];
  const ua = lastUser.querySelector(".msg-actions");
  const edit = R.actionBtn("✎", "编辑并重新执行", () => editLast(lastUser));
  edit.classList.add("act-edit");
  ua?.appendChild(edit);
  const lastAsst = kids.slice(lastUserIdx + 1).reverse().find((k) => k.classList.contains("assistant"));
  const regen = R.actionBtn("↻", "重新生成", regenerate);
  regen.classList.add("act-regen");
  (lastAsst ? lastAsst.querySelector(".msg-actions") : ua)?.appendChild(regen);
}

function autoGrow() {
  const t = els.input;
  t.style.height = "auto";
  t.style.height = Math.min(t.scrollHeight, 220) + "px";
}

/* ================= 附件 ================= */
export async function uploadAttachments(files) {
  files = [...(files || [])];
  if (!files.length) return;
  C.uploading++;
  updateSendState();
  const chip = div("chip uploading", `<span class="spinner sm"></span><span>上传 ${files.length} 个文件… <b>0%</b></span>`);
  els.attachments.appendChild(chip);
  try {
    const r = await upload(files, "uploads", (p) => { const b = chip.querySelector("b"); if (b) b.textContent = Math.round(p * 100) + "%"; });
    (r.saved || []).forEach(addAttachment);
    toast(`已上传 ${r.saved?.length || 0} 个文件`, "success");
    bus.emit("files:changed");
  } catch (e) {
    toast(e.message || "上传失败", "error");
  } finally {
    chip.remove();
    C.uploading--;
    updateSendState();
  }
}
export function addAttachment(p) {
  if (!S.attachments.includes(p)) S.attachments.push(p);
  renderAttachments();
  els.input.focus();
}
function renderAttachments() {
  $$(".chip:not(.uploading)", els.attachments).forEach((c) => c.remove());
  S.attachments.forEach((p, i) => {
    const c = h("span", { class: "chip", title: p }, h("span", { text: FILE_ICON(p) }), h("span", { class: "chip-name", text: basename(p) }),
      h("button", { class: "x", type: "button", "aria-label": `移除 ${basename(p)}`, text: "✕", onclick: () => { S.attachments.splice(i, 1); renderAttachments(); } }));
    els.attachments.insertBefore(c, els.attachments.querySelector(".uploading"));
  });
}

function setupDragDrop() {
  const main = $("#main");
  let depth = 0;
  const hasFiles = (e) => [...(e.dataTransfer?.types || [])].includes("Files");
  main.addEventListener("dragenter", (e) => { if (!hasFiles(e)) return; e.preventDefault(); depth++; els.drop.hidden = false; });
  main.addEventListener("dragover", (e) => { if (hasFiles(e)) e.preventDefault(); });
  main.addEventListener("dragleave", () => { depth = Math.max(0, depth - 1); if (!depth) els.drop.hidden = true; });
  main.addEventListener("drop", (e) => {
    if (!hasFiles(e)) return;
    e.preventDefault();
    depth = 0;
    els.drop.hidden = true;
    uploadAttachments(e.dataTransfer.files);
  });
  window.addEventListener("dragover", (e) => { if (hasFiles(e)) e.preventDefault(); });
  window.addEventListener("drop", (e) => { if (hasFiles(e)) e.preventDefault(); });
}

/* ================= 通知 ================= */
function maybeAskNotifyPermission() {
  if (S.settings?.notify_on_done && "Notification" in window && Notification.permission === "default") {
    try { Notification.requestPermission(); } catch { /* ignore */ }
  }
}
function notify(title, body) {
  if (!document.hidden || !S.settings?.notify_on_done) return;
  if (!("Notification" in window) || Notification.permission !== "granted") return;
  try {
    const n = new Notification(title, { body, tag: "omni-" + (S.convId || "x") });
    n.onclick = () => { window.focus(); n.close(); };
  } catch { /* ignore */ }
}

export const focusInput = () => els.input?.focus();
export const isConnected = wsOpen;
