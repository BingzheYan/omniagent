/* 登录 / 注册旗舰展台视图（含聚能环 3D 视差、特性轮播、数字跳动与光波主题过渡） */
import { $, $$ } from "./util.js";
import { api } from "./api.js";
import { toggleTheme } from "./state.js";
import { circularThemeTransition, prefersReducedMotion } from "./motion.js";

let onLoginCb = null;
let bound = false;
let status = { has_users: true, registration_open: true, invite_required: false };
let carouselTimer = null;
let curSlide = 0;
const SLIDE_INTERVAL = 4800;

export async function showAuth({ onLogin, message } = {}) {
  onLoginCb = onLogin;
  $("#boot").hidden = true;
  $("#auth-view").hidden = false;
  document.title = "登录 · OmniAgent";
  bind();
  startCarousel();
  runCountUp();
  try { status = await api("/api/auth/status"); } catch { /* 保持默认 */ }
  applyStatus();
  if (!status.has_users) switchTab("register");
  else switchTab("login");
  if (message) showHint(message, "warn");
  else if (!status.has_users) showHint("欢迎使用 OmniAgent！当前尚无账号，首个注册的用户将自动成为系统管理员。", "info");
  else hideHint();
}

export function hideAuth() {
  stopCarousel();
  $("#auth-view").hidden = true;
}
export const isAuthVisible = () => !$("#auth-view").hidden;

function applyStatus() {
  $("#invite-field").hidden = !status.invite_required;
  const regTab = $('.auth-tab[data-tab="register"]');
  regTab.hidden = false;
  regTab.classList.toggle("muted-tab", !status.registration_open);
}
function showHint(text, kind = "info") {
  const el = $("#auth-hint");
  el.hidden = false;
  el.className = `auth-hint ${kind}`;
  el.textContent = text;
}
function hideHint() { $("#auth-hint").hidden = true; }

function switchTab(tab) {
  $$(".auth-tab").forEach((b) => {
    const on = b.dataset.tab === tab;
    b.classList.toggle("active", on);
    b.setAttribute("aria-selected", String(on));
  });
  const closed = tab === "register" && !status.registration_open;
  $("#login-form").hidden = tab !== "login";
  $("#register-form").hidden = tab !== "register" || closed;
  $("#auth-closed").hidden = !closed;
  setErr("login-error", "");
  setErr("register-error", "");
  const activeForm = tab === "login" ? $("#login-form") : $("#register-form");
  if (activeForm && !activeForm.hidden) {
    activeForm.classList.remove("pane-enter");
    void activeForm.offsetWidth;
    activeForm.classList.add("pane-enter");
  }
  setTimeout(() => (tab === "login" ? $("#login-username") : $("#reg-username"))?.focus(), 30);
}
function setErr(id, msg) { const el = $("#" + id); el.hidden = !msg; el.textContent = msg || ""; }

function busy(form, v) {
  const b = form.querySelector("button[type=submit]");
  b.disabled = v;
  b.classList.toggle("loading", v);
}

/* ---------------- 旗舰展台微交互（轮播 / 数字递增 / 3D 能量环视差） ---------------- */
function setSlide(idx) {
  const slides = $$(".nf-car-slide");
  const tabs = $$(".nf-car-tab");
  if (!slides.length) return;
  curSlide = ((idx % slides.length) + slides.length) % slides.length;
  slides.forEach((s, i) => s.classList.toggle("active", i === curSlide));
  tabs.forEach((t, i) => t.classList.toggle("active", i === curSlide));
  const bar = $("#nf-car-bar");
  if (bar) {
    bar.style.transition = "none";
    bar.style.width = "0%";
    void bar.offsetWidth;
    bar.style.transition = `width ${SLIDE_INTERVAL}ms linear`;
    bar.style.width = "100%";
  }
}

function startCarousel() {
  stopCarousel();
  setSlide(curSlide);
  if (prefersReducedMotion()) return;
  carouselTimer = setInterval(() => {
    if (!isAuthVisible()) { stopCarousel(); return; }
    setSlide(curSlide + 1);
  }, SLIDE_INTERVAL);
}

function stopCarousel() {
  if (carouselTimer) {
    clearInterval(carouselTimer);
    carouselTimer = null;
  }
}

function runCountUp() {
  const els = $$(".nf-count");
  if (!els.length) return;
  if (prefersReducedMotion()) {
    els.forEach((el) => { el.textContent = el.dataset.target || "0"; });
    return;
  }
  const dur = 1100;
  const t0 = performance.now();
  function frame(now) {
    const p = Math.min(1, (now - t0) / dur);
    const eased = 1 - Math.pow(1 - p, 3);
    els.forEach((el) => {
      const target = Number(el.dataset.target || 0);
      el.textContent = String(Math.round(target * eased));
    });
    if (p < 1 && isAuthVisible()) requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
}

function bind() {
  if (bound) return;
  bound = true;

  $$(".auth-tab").forEach((b) => (b.onclick = () => switchTab(b.dataset.tab)));
  $$(".nf-car-tab").forEach((b) => {
    b.onclick = () => {
      setSlide(Number(b.dataset.slide || 0));
      startCarousel();
    };
  });

  const carBox = $("#nf-carousel");
  if (carBox) {
    carBox.addEventListener("pointerenter", stopCarousel);
    carBox.addEventListener("pointerleave", () => { if (isAuthVisible()) startCarousel(); });
  }

  // 3D 视差感应（鼠标划过主舞台时聚能环产生立体微倾角）
  const authView = $("#auth-view");
  const ring = $("#nf-power-ring");
  if (authView && ring) {
    authView.addEventListener("pointermove", (ev) => {
      if (prefersReducedMotion()) return;
      const rx = ((ev.clientY / window.innerHeight) - 0.5) * -16;
      const ry = ((ev.clientX / window.innerWidth) - 0.5) * 18;
      ring.style.setProperty("--rx", `${rx.toFixed(1)}deg`);
      ring.style.setProperty("--ry", `${ry.toFixed(1)}deg`);
    }, { passive: true });
  }

  $$(".pw-toggle").forEach((b) => (b.onclick = () => {
    const input = b.previousElementSibling;
    const show = input.type === "password";
    input.type = show ? "text" : "password";
    b.textContent = show ? "隐藏" : "显示";
    b.setAttribute("aria-label", show ? "隐藏密码" : "显示密码");
    b.classList.toggle("on", show);
  }));

  $("#auth-theme").onclick = (ev) => {
    circularThemeTransition(ev, () => toggleTheme());
  };

  $("#login-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const form = e.currentTarget;
    const username = $("#login-username").value.trim();
    const password = $("#login-password").value;
    if (!username || !password) { setErr("login-error", "请输入用户名和密码"); return; }
    setErr("login-error", "");
    busy(form, true);
    try {
      const r = await api("/api/auth/login", { method: "POST", body: { username, password, remember: $("#login-remember").checked } });
      $("#login-password").value = "";
      done(r.user);
    } catch (err) {
      setErr("login-error", err.status === 429 ? err.message || "尝试次数过多，请稍后再试" : err.message);
      $("#login-password").select();
    } finally { busy(form, false); }
  });

  $("#register-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const form = e.currentTarget;
    const body = {
      username: $("#reg-username").value.trim(),
      password: $("#reg-password").value,
      display_name: $("#reg-display").value.trim() || undefined,
      email: $("#reg-email").value.trim() || undefined,
    };
    if (status.invite_required) body.invite_code = $("#reg-invite").value.trim();
    if (!body.username) return setErr("register-error", "请输入用户名");
    if (body.password.length < 8) return setErr("register-error", "密码至少 8 位");
    if (body.password !== $("#reg-password2").value) return setErr("register-error", "两次输入的密码不一致");
    if (status.invite_required && !body.invite_code) return setErr("register-error", "请输入邀请码");
    if (body.email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(body.email)) return setErr("register-error", "邮箱格式不正确");
    setErr("register-error", "");
    busy(form, true);
    try {
      const r = await api("/api/auth/register", { method: "POST", body });
      done(r.user);
    } catch (err) {
      setErr("register-error", err.message);
    } finally { busy(form, false); }
  });
}

function done(user) {
  hideAuth();
  if (onLoginCb) onLoginCb(user);
}
