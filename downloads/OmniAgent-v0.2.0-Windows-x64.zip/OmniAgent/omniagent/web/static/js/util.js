/* 通用工具函数、图标映射与统一 Diff 渲染 */
export const $ = (s, el = document) => el.querySelector(s);
export const $$ = (s, el = document) => [...el.querySelectorAll(s)];

const ESC = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };
export const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ESC[c]);

export function div(cls, html) {
  const d = document.createElement("div");
  if (cls) d.className = cls;
  if (html != null) d.innerHTML = html;
  return d;
}

/** 轻量元素构建：h("button", {class: "btn", onclick: fn}, "文字") */
export function h(tag, attrs = {}, ...children) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === "class") el.className = v;
    else if (k === "html") el.innerHTML = v;
    else if (k === "text") el.textContent = v;
    else if (k.startsWith("on") && typeof v === "function") el.addEventListener(k.slice(2), v);
    else if (k === "dataset") Object.assign(el.dataset, v);
    else if (v === true) el.setAttribute(k, "");
    else el.setAttribute(k, v);
  }
  for (const c of children.flat()) {
    if (c == null || c === false) continue;
    el.appendChild(typeof c === "string" || typeof c === "number" ? document.createTextNode(String(c)) : c);
  }
  return el;
}

export const fileUrl = (p, dl = 0) => `/api/file?path=${encodeURIComponent(p)}${dl ? "&download=1" : ""}`;

export const fmtK = (n) => {
  n = Number(n) || 0;
  if (n >= 1e6) return (n / 1e6).toFixed(n >= 1e7 ? 0 : 1) + "M";
  if (n >= 1000) return (n / 1000).toFixed(n >= 1e4 ? 0 : 1) + "k";
  return String(n);
};
export const fmtNum = (n) => (Number(n) || 0).toLocaleString("zh-CN");

export function fmtBytes(b) {
  b = Number(b) || 0;
  if (b < 1024) return b + " B";
  const u = ["KB", "MB", "GB", "TB"];
  let i = -1;
  do { b /= 1024; i++; } while (b >= 1024 && i < u.length - 1);
  return (b >= 100 ? b.toFixed(0) : b.toFixed(1)) + " " + u[i];
}

const pad = (n) => String(n).padStart(2, "0");
export function fmtDateTime(ts) {
  if (!ts) return "—";
  const d = new Date(ts * 1000);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
export function fmtRelative(ts) {
  if (!ts) return "—";
  const diff = Date.now() / 1000 - ts;
  if (diff < 60) return "刚刚";
  if (diff < 3600) return Math.floor(diff / 60) + " 分钟前";
  if (diff < 86400) return Math.floor(diff / 3600) + " 小时前";
  if (diff < 86400 * 30) return Math.floor(diff / 86400) + " 天前";
  return fmtDateTime(ts).slice(0, 10);
}

export function debounce(fn, ms = 250) {
  let t;
  return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}

export async function copyText(text) {
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch { /* fallback */ }
  try {
    const ta = h("textarea", { style: "position:fixed;top:-1000px;opacity:0" });
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand("copy");
    ta.remove();
    return ok;
  } catch {
    return false;
  }
}

/** 触发浏览器下载（通过隐藏链接，保留 Cookie） */
export function download(url, filename) {
  const a = h("a", { href: url, style: "display:none" });
  if (filename) a.download = filename; else a.setAttribute("download", "");
  document.body.appendChild(a);
  a.click();
  setTimeout(() => a.remove(), 100);
}

export const initials = (name) => {
  const s = String(name || "?").trim();
  if (!s) return "?";
  if (/[\u4e00-\u9fa5]/.test(s[0])) return s.length <= 3 ? s.slice(-2) : s[0];
  const parts = s.split(/[\s._-]+/).filter(Boolean);
  return (parts.length > 1 ? parts[0][0] + parts[1][0] : s.slice(0, 2)).toUpperCase();
};

export function avatarColor(name) {
  let hue = 0;
  for (const c of String(name || "")) hue = (hue * 31 + c.charCodeAt(0)) % 360;
  return `hsl(${hue} 55% 50%)`;
}

export const ICONS = {
  read_file: "📖", write_file: "📝", edit_file: "✏️", list_dir: "📂", glob: "🔎", grep: "🔎",
  run_shell: "💻", process: "⚙️", python: "🐍",
  create_document: "📄", create_presentation: "📽", create_spreadsheet: "📗",
  web_fetch: "🌐", web_search: "🌐", browser_inspect: "🧭", desktop_inspect: "🖥",
  load_skill: "📚", view_image: "👁", check_document: "🛡",
  list_connectors: "🔌", connector_query: "🔌", connector_manage: "🔌",
  email_ops: "📧", calendar_ops: "📅", browser_session: "🧭", desktop_action: "🔔",
  tracker_manage: "📡", verify_deliverable: "🧪", edit_presentation: "📽", pdf_ops: "📕",
  memory_upsert: "✦", memory_search: "✦", memory_delete: "✦", portrait_update: "✦", project_memory: "✦",
  todo_write: "📋", ask_user: "❓", delegate_task: "🤖", delegate_parallel: "∷",
  web_automation: "🌐", expense_reimburse: "🧾",
};

export const TOOL_LABELS = {
  read_file: "读取文件", write_file: "写入文件", edit_file: "编辑文件", list_dir: "浏览目录", glob: "查找文件",
  grep: "搜索代码", run_shell: "执行命令", process: "后台进程", python: "运行 Python",
  create_document: "生成文档", create_presentation: "生成演示文稿", edit_presentation: "修改演示文稿",
  create_spreadsheet: "生成表格", pdf_ops: "处理 PDF 文档",
  web_fetch: "抓取网页", web_search: "联网搜索", browser_inspect: "浏览器探查", browser_session: "交互式网页操作",
  desktop_inspect: "桌面探查", desktop_action: "桌面系统操作",
  load_skill: "加载技能", view_image: "检视图像", check_document: "核验文档质量", verify_deliverable: "全链路实测验收",
  list_connectors: "列出连接器", connector_query: "查询连接器", connector_manage: "自主连接外部系统",
  email_ops: "收发与跟踪邮件", calendar_ops: "日历排期与提醒", tracker_manage: "管理外部动态追踪",
  memory_upsert: "写入长期记忆", memory_search: "检索长期记忆", memory_delete: "删除记忆",
  portrait_update: "更新用户画像", project_memory: "同步项目进度",
  todo_write: "更新计划", ask_user: "询问用户", delegate_task: "委派子智能体", delegate_parallel: "并行委派子智能体",
  web_automation: "操作网页业务系统", expense_reimburse: "智能报销核对",
};

const EXT_ICON = {
  py: "🐍", md: "📝", txt: "📃", docx: "📄", doc: "📄", xlsx: "📗", xls: "📗", csv: "📗", tsv: "📗", pptx: "📽",
  ppt: "📽", pdf: "📕", png: "🖼", jpg: "🖼", jpeg: "🖼", gif: "🖼", webp: "🖼", svg: "🖼", html: "🌐", htm: "🌐",
  json: "🧾", js: "📜", ts: "📜", css: "🎨", sh: "💻", sql: "🗄", yaml: "⚙️", yml: "⚙️", toml: "⚙️",
  zip: "🗜", gz: "🗜", tar: "🗜", dta: "📊", sav: "📊", r: "📊",
};
export const FILE_ICON = (name, dir) => {
  if (dir) return "📁";
  const base = basename(name).toLowerCase();
  if (base === "dockerfile" || base === ".dockerignore" || base.startsWith("docker-compose")) return "🐳";
  const ext = base.includes(".") ? base.split(".").pop() : "";
  return EXT_ICON[ext] || "📃";
};

/** File Changes 卡片专用类型徽章（精密代码/文档字母缩写徽标，告别粗糙 Emoji） */
export function fileTypeBadge(path) {
  const base = basename(path);
  const lower = base.toLowerCase();
  if (lower === "dockerfile" || lower === ".dockerignore" || lower.startsWith("docker-compose")) {
    return { text: "DK", cls: "ft-docker" };
  }
  const ext = lower.includes(".") ? lower.split(".").pop() : "";
  const map = {
    py: { text: "PY", cls: "ft-py" },
    md: { text: "M↓", cls: "ft-md" },
    mdx: { text: "M↓", cls: "ft-md" },
    ts: { text: "TS", cls: "ft-ts" },
    tsx: { text: "TS", cls: "ft-ts" },
    js: { text: "JS", cls: "ft-js" },
    jsx: { text: "JS", cls: "ft-js" },
    mjs: { text: "JS", cls: "ft-js" },
    json: { text: "{}", cls: "ft-json" },
    jsonl: { text: "{}", cls: "ft-json" },
    html: { text: "<>", cls: "ft-html" },
    htm: { text: "<>", cls: "ft-html" },
    vue: { text: "<>", cls: "ft-html" },
    css: { text: "#", cls: "ft-css" },
    scss: { text: "#", cls: "ft-css" },
    docx: { text: "DOC", cls: "ft-ts" },
    doc: { text: "DOC", cls: "ft-ts" },
    pdf: { text: "PDF", cls: "ft-html" },
    xlsx: { text: "XLS", cls: "ft-json" },
    xls: { text: "XLS", cls: "ft-json" },
    csv: { text: "CSV", cls: "ft-json" },
    tsv: { text: "TSV", cls: "ft-json" },
    pptx: { text: "PPT", cls: "ft-js" },
    ppt: { text: "PPT", cls: "ft-js" },
    png: { text: "IMG", cls: "ft-md" },
    jpg: { text: "IMG", cls: "ft-md" },
    jpeg: { text: "IMG", cls: "ft-md" },
    gif: { text: "IMG", cls: "ft-md" },
    webp: { text: "IMG", cls: "ft-md" },
    svg: { text: "SVG", cls: "ft-md" },
    sh: { text: "SH", cls: "ft-py" },
    sql: { text: "SQL", cls: "ft-js" },
    yaml: { text: "YML", cls: "" },
    yml: { text: "YML", cls: "" },
    toml: { text: "CFG", cls: "" },
  };
  return map[ext] || { text: "FILE", cls: "" };
}

const BINARY_ONLY_EXTS = new Set([
  "docx", "doc", "xlsx", "xls", "pptx", "ppt", "pdf",
  "png", "jpg", "jpeg", "gif", "webp", "bmp", "ico",
  "zip", "gz", "tar", "7z", "dta", "sav", "sqlite", "db",
]);
export function isBinaryPath(path) {
  const base = basename(path).toLowerCase();
  const ext = base.includes(".") ? base.split(".").pop() : "";
  return BINARY_ONLY_EXTS.has(ext);
}

export const basename = (p) => String(p || "").split("/").filter(Boolean).pop() || p;
export const dirname = (p) => {
  const parts = String(p || "").split("/").filter(Boolean);
  parts.pop();
  return parts.length ? parts.join("/") : ".";
};
export function shortDir(p) {
  const d = dirname(p);
  if (!d || d === ".") return "";
  const parts = d.split("/").filter(Boolean);
  if (parts.length <= 2 && d.length <= 28) return d;
  return "…/" + parts.slice(-2).join("/");
}
export const joinPath = (dir, name) => (!dir || dir === "." ? name : `${dir.replace(/\/$/, "")}/${name}`);

/** 解析统一 Diff 文本并生成带双列行号的 HTML 表格 */
export function renderUnifiedDiffHtml(diffText) {
  const lines = String(diffText || "").replace(/\r\n/g, "\n").split("\n");
  if (lines.length && lines[lines.length - 1] === "") lines.pop();
  let oldLn = 0, newLn = 0;
  const rows = [];
  for (const line of lines) {
    if (line.startsWith("--- ") || line.startsWith("+++ ") || line.startsWith("diff --git") || line.startsWith("index ")) {
      continue;
    }
    const hm = /^@@\s+-(\d+)(?:,\d+)?\s+\+(\d+)(?:,\d+)?\s+@@(.*)/.exec(line);
    if (hm) {
      oldLn = parseInt(hm[1], 10);
      newLn = parseInt(hm[2], 10);
      rows.push(`<tr class="hunk-row"><td class="diff-ln">…</td><td class="diff-ln">…</td><td class="diff-sign">@@</td><td class="diff-code">${esc(line)}</td></tr>`);
      continue;
    }
    if (line.startsWith("+")) {
      const n = newLn ? newLn++ : "";
      rows.push(`<tr class="add-row"><td class="diff-ln"></td><td class="diff-ln">${n}</td><td class="diff-sign">+</td><td class="diff-code">${esc(line.slice(1)) || " "}</td></tr>`);
    } else if (line.startsWith("-")) {
      const o = oldLn ? oldLn++ : "";
      rows.push(`<tr class="del-row"><td class="diff-ln">${o}</td><td class="diff-ln"></td><td class="diff-sign">-</td><td class="diff-code">${esc(line.slice(1)) || " "}</td></tr>`);
    } else if (line.startsWith("\\")) {
      rows.push(`<tr><td class="diff-ln"></td><td class="diff-ln"></td><td class="diff-sign"></td><td class="diff-code muted">${esc(line)}</td></tr>`);
    } else {
      const o = oldLn ? oldLn++ : "";
      const n = newLn ? newLn++ : "";
      const code = line.startsWith(" ") ? line.slice(1) : line;
      rows.push(`<tr><td class="diff-ln">${o}</td><td class="diff-ln">${n}</td><td class="diff-sign"> </td><td class="diff-code">${esc(code) || " "}</td></tr>`);
    }
  }
  if (!rows.length) return `<div class="empty"><div class="empty-ic">📄</div><div>无差异行</div></div>`;
  return `<div class="diff-wrap"><table class="diff-table"><tbody>${rows.join("")}</tbody></table></div>`;
}
