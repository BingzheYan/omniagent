/* UI 组件：Toast、模态框、确认/输入对话框、下拉菜单、灯箱 */
import { $, esc, h } from "./util.js";
import { SVG } from "./icons.js";

/* ---------------- Toast ---------------- */
export function toast(message, kind = "info", ms = 2600) {
  let box = $("#toasts");
  if (!box) {
    box = h("div", { id: "toasts", "aria-live": "polite" });
    document.body.appendChild(box);
  }
  const icon = { success: "✓", error: "✕", warn: "!", info: "i" }[kind] || "i";
  const t = h("div", { class: `toast ${kind}`, role: kind === "error" ? "alert" : "status" },
    h("span", { class: "toast-ic", text: icon }), h("span", { class: "toast-msg", text: message }));
  box.appendChild(t);
  requestAnimationFrame(() => t.classList.add("show"));
  const close = () => { t.classList.remove("show"); setTimeout(() => t.remove(), 250); };
  t.onclick = close;
  setTimeout(close, kind === "error" ? Math.max(ms, 4500) : ms);
}

/* ---------------- Modal ---------------- */
const modalStack = [];

/**
 * openModal({title, content, size, actions, onClose, dismissible})
 * actions: [{label, kind: "primary"|"danger"|"ghost", onClick(ctx) -> false 可阻止关闭, value}]
 * 返回 {el, body, close(value), promise}
 */
export function openModal({ title, content, size = "md", actions = [], onClose, dismissible = true, className = "" } = {}) {
  let resolveFn;
  const promise = new Promise((r) => (resolveFn = r));
  const prevFocus = document.activeElement;
  const overlay = h("div", { class: "modal-overlay" });
  const dialog = h("div", { class: `modal modal-${size} ${className}`, role: "dialog", "aria-modal": "true", "aria-label": title || "对话框" });
  const head = h("div", { class: "modal-head" },
    h("h3", { text: title || "" }),
    dismissible ? h("button", { class: "icon-btn modal-x", "aria-label": "关闭", text: "✕", onclick: () => close(undefined) }) : null);
  const body = h("div", { class: "modal-body" });
  if (typeof content === "string") body.innerHTML = content;
  else if (content) body.appendChild(content);
  const foot = h("div", { class: "modal-foot" });
  const errBox = h("div", { class: "modal-error", hidden: true });
  const ctx = { el: dialog, body, close, setError, setBusy, promise };
  actions.forEach((a) => {
    const b = h("button", { class: `btn ${a.kind || ""}`, type: "button", text: a.label });
    b.onclick = async () => {
      setError("");
      if (a.onClick) {
        try {
          setBusy(true, b);
          const r = await a.onClick(ctx);
          setBusy(false, b);
          if (r === false) return;
          close(a.value !== undefined ? a.value : r);
        } catch (e) {
          setBusy(false, b);
          setError(e.message || String(e));
        }
      } else close(a.value);
    };
    foot.appendChild(b);
  });
  dialog.append(head, body, errBox);
  if (actions.length) dialog.appendChild(foot);
  overlay.appendChild(dialog);
  overlay.addEventListener("mousedown", (e) => { if (e.target === overlay && dismissible) close(undefined); });
  document.body.appendChild(overlay);
  requestAnimationFrame(() => overlay.classList.add("show"));
  const entry = { overlay, close: () => close(undefined), dismissible };
  modalStack.push(entry);

  function setError(msg) { errBox.hidden = !msg; errBox.textContent = msg || ""; }
  function setBusy(v, btn) {
    foot.querySelectorAll("button").forEach((x) => (x.disabled = v));
    if (btn) btn.classList.toggle("loading", v);
  }
  let closed = false;
  function close(value) {
    if (closed) return;
    closed = true;
    const i = modalStack.indexOf(entry);
    if (i >= 0) modalStack.splice(i, 1);
    overlay.classList.remove("show");
    setTimeout(() => overlay.remove(), 180);
    if (onClose) onClose(value);
    resolveFn(value);
    if (prevFocus && prevFocus.focus) try { prevFocus.focus(); } catch { /* ignore */ }
  }
  setTimeout(() => {
    const f = dialog.querySelector("[autofocus], input:not([type=hidden]):not([disabled]), textarea, select") || foot.querySelector(".primary, .danger");
    if (f) f.focus();
  }, 30);
  return ctx;
}

export function closeTopModal() {
  const top = modalStack[modalStack.length - 1];
  if (top && top.dismissible) { top.close(); return true; }
  return false;
}
export const hasModal = () => modalStack.length > 0;

export function confirmDialog(message, { title = "确认操作", okText = "确定", cancelText = "取消", danger = false } = {}) {
  const m = openModal({
    title, size: "sm",
    content: h("p", { class: "confirm-text", text: message }),
    actions: [{ label: cancelText, kind: "ghost", value: false }, { label: okText, kind: danger ? "danger" : "primary", value: true }],
  });
  return m.promise.then((v) => v === true);
}

export function alertDialog(message, { title = "提示", okText = "知道了" } = {}) {
  return openModal({ title, size: "sm", content: h("p", { class: "confirm-text", text: message }), actions: [{ label: okText, kind: "primary", value: true }] }).promise;
}

/**
 * formDialog({title, fields, okText, onSubmit(values) -> 抛出错误则显示}) => Promise<values|null>
 * field: {name, label, type: text|password|email|number|textarea|select|checkbox, value, placeholder, required, options:[{value,label}], hint, autocomplete}
 */
export function formDialog({ title, fields, okText = "确定", cancelText = "取消", danger = false, onSubmit, size = "sm", intro } = {}) {
  const form = h("form", { class: "form", autocomplete: "off" });
  if (intro) form.appendChild(h("p", { class: "form-intro", text: intro }));
  const inputs = {};
  fields.forEach((f, i) => {
    let input;
    const id = `fd-${f.name}-${Math.random().toString(36).slice(2, 7)}`;
    if (f.type === "textarea") input = h("textarea", { id, rows: f.rows || 4, placeholder: f.placeholder || "" });
    else if (f.type === "select") {
      input = h("select", { id });
      (f.options || []).forEach((o) => input.appendChild(h("option", { value: o.value, text: o.label ?? o.value })));
    } else input = h("input", { id, type: f.type || "text", placeholder: f.placeholder || "", autocomplete: f.autocomplete || "off" });
    if (f.type === "checkbox") input.checked = !!f.value;
    else if (f.value != null) input.value = f.value;
    if (f.required) input.required = true;
    if (f.min != null) input.min = f.min;
    if (i === 0) input.setAttribute("autofocus", "");
    inputs[f.name] = input;
    const field = f.type === "checkbox"
      ? h("label", { class: "field check", for: id }, input, h("span", { text: f.label }))
      : h("div", { class: "field" }, h("label", { for: id, text: f.label + (f.required ? " *" : "") }), input,
        f.hint ? h("div", { class: "hint", text: f.hint }) : null);
    form.appendChild(field);
  });
  const collect = () => {
    const v = {};
    for (const f of fields) {
      const el = inputs[f.name];
      v[f.name] = f.type === "checkbox" ? el.checked : f.type === "number" ? (el.value === "" ? null : Number(el.value)) : el.value;
    }
    return v;
  };
  const submitAction = {
    label: okText, kind: danger ? "danger" : "primary",
    onClick: async (ctx) => {
      for (const f of fields) {
        if (f.required && f.type !== "checkbox" && !String(inputs[f.name].value).trim()) {
          inputs[f.name].focus();
          throw new Error(`请填写「${f.label}」`);
        }
      }
      const values = collect();
      if (onSubmit) await onSubmit(values, ctx);
      return values;
    },
  };
  const m = openModal({ title, size, content: form, actions: [{ label: cancelText, kind: "ghost", value: null }, submitAction] });
  form.addEventListener("submit", (e) => { e.preventDefault(); m.el.querySelector(".modal-foot .btn:last-child").click(); });
  form.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && e.target.tagName === "INPUT" && !e.isComposing) { e.preventDefault(); m.el.querySelector(".modal-foot .btn:last-child").click(); }
  });
  return m.promise.then((v) => (v && typeof v === "object" ? v : null));
}

export async function promptDialog({ title, label = "", value = "", placeholder = "", okText = "确定", type = "text", hint } = {}) {
  const r = await formDialog({ title, okText, fields: [{ name: "v", label, value, placeholder, type, hint, required: true }] });
  return r ? r.v.trim() : null;
}

/* ---------------- 下拉菜单 ---------------- */
let openMenuEl = null;
export function closeMenu() {
  if (openMenuEl) { openMenuEl.remove(); openMenuEl = null; }
  document.querySelectorAll("[aria-expanded=true]").forEach((b) => b.setAttribute("aria-expanded", "false"));
}

/**
 * openMenu(anchor, items, {align: "left"|"right", placement: "below"|"above"})
 * item: {label, icon, onClick, danger, divider, hidden, disabled, checked, header}
 */
export function openMenu(anchor, items, { align = "right", placement = "below" } = {}) {
  const wasOpen = openMenuEl && openMenuEl._anchor === anchor;
  closeMenu();
  if (wasOpen) return;
  const menu = h("div", { class: "menu", role: "menu" });
  menu._anchor = anchor;
  for (const it of items) {
    if (!it || it.hidden) continue;
    if (it.divider) { menu.appendChild(h("div", { class: "menu-div", role: "separator" })); continue; }
    if (it.header) { menu.appendChild(h("div", { class: "menu-header", text: it.header })); continue; }
    const icSpan = h("span", { class: "mi-ic" });
    if (it.checked) icSpan.innerHTML = SVG.check;
    else if (typeof it.icon === "string" && it.icon.trim().startsWith("<svg")) icSpan.innerHTML = it.icon;
    else icSpan.textContent = it.icon || "";
    const b = h("button", {
      class: `menu-item${it.danger ? " danger" : ""}${it.checked ? " checked" : ""}`, role: "menuitem", type: "button",
      disabled: it.disabled,
    }, icSpan, h("span", { class: "mi-label", text: it.label }),
    it.hint ? h("span", { class: "mi-hint", text: it.hint }) : null);
    b.onclick = (e) => { e.stopPropagation(); closeMenu(); it.onClick && it.onClick(); };
    menu.appendChild(b);
  }
  document.body.appendChild(menu);
  openMenuEl = menu;
  anchor.setAttribute("aria-expanded", "true");
  const r = anchor.getBoundingClientRect();
  const mw = menu.offsetWidth, mh = menu.offsetHeight;
  let top = placement === "above" ? r.top - mh - 6 : r.bottom + 4;
  if (top + mh > innerHeight - 8) top = Math.max(8, r.top - mh - 4);
  if (top < 8) top = 8;
  let left = align === "right" ? r.right - mw : r.left;
  left = Math.max(8, Math.min(left, innerWidth - mw - 8));
  menu.style.top = top + "px";
  menu.style.left = left + "px";
  const first = menu.querySelector(".menu-item:not([disabled])");
  if (first) first.focus({ preventScroll: true });
  menu.addEventListener("keydown", (e) => {
    const btns = [...menu.querySelectorAll(".menu-item:not([disabled])")];
    const i = btns.indexOf(document.activeElement);
    if (e.key === "ArrowDown") { e.preventDefault(); btns[(i + 1) % btns.length]?.focus(); }
    if (e.key === "ArrowUp") { e.preventDefault(); btns[(i - 1 + btns.length) % btns.length]?.focus(); }
  });
}
document.addEventListener("mousedown", (e) => {
  if (openMenuEl && !openMenuEl.contains(e.target) && !openMenuEl._anchor.contains(e.target)) closeMenu();
});
window.addEventListener("resize", closeMenu);
document.addEventListener("scroll", (e) => { if (openMenuEl && !openMenuEl.contains(e.target)) closeMenu(); }, true);
export const isMenuOpen = () => !!openMenuEl;

/* ---------------- 灯箱 ---------------- */
export function lightbox(src) {
  const lb = h("div", { class: "lightbox", role: "dialog", "aria-label": "图片预览" }, h("img", { src, alt: "" }));
  lb.onclick = () => lb.remove();
  const onKey = (e) => { if (e.key === "Escape") { lb.remove(); document.removeEventListener("keydown", onKey, true); } };
  document.addEventListener("keydown", onKey, true);
  document.body.appendChild(lb);
}

export function spinner(text = "") {
  return `<div class="loading"><span class="spinner"></span>${text ? `<span>${esc(text)}</span>` : ""}</div>`;
}
const EMPTY_SVG_MAP = {
  "🔍": SVG.search,
  "🗄": SVG.archive,
  "💬": SVG.chatEmpty,
  "📋": SVG.plan,
  "📦": SVG.box,
  "👁": SVG.eye,
  "🗂": SVG.folder,
  "📁": SVG.folder,
  "⚠️": SVG.shield,
};
export function emptyState(icon, text, sub = "") {
  const mapped = EMPTY_SVG_MAP[icon] || (typeof icon === "string" && icon.trim().startsWith("<svg") ? icon : esc(icon));
  return `<div class="empty"><div class="empty-ic">${mapped}</div><div>${esc(text)}</div>${sub ? `<div class="empty-sub">${esc(sub)}</div>` : ""}</div>`;
}
