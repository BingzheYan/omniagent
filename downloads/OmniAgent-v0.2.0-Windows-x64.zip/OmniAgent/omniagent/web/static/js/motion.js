/* 全局丝滑过渡与微交互引擎（Motion Choreography Engine）
 * 参考 Linear / Vercel Geist (Rauno Freiberg) / Emil Kowalski 动效工程范式：
 * 1. View Transitions API 圆形扩散主题切换与跨视图丝滑转场
 * 2. Web Animations API 可打断的 <details> 手风琴平滑展开/收起（思维链、工具卡、子智能体）
 * 3. FLIP 空间连续性过渡（欢迎页居中输入台 → 底部悬浮坞平滑滑落）
 */

const SPRING_EASE = "cubic-bezier(0.22, 1, 0.36, 1)";

export const prefersReducedMotion = () =>
  typeof window !== "undefined" && window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches;

/** 通用跨视图丝滑过渡（对话切换、登录进出、模态内容切换） */
export function smoothViewSwitch(mutateDom) {
  if (prefersReducedMotion() || typeof document.startViewTransition !== "function") {
    mutateDom();
    return;
  }
  try {
    document.startViewTransition(() => {
      mutateDom();
    });
  } catch {
    mutateDom();
  }
}

/** 从点击坐标向外圆形扩散的丝滑深浅色主题切换（Raycast / Vercel 风格） */
export function circularThemeTransition(ev, applyFn) {
  if (prefersReducedMotion() || typeof document.startViewTransition !== "function") {
    applyFn();
    return;
  }
  const x = ev?.clientX ?? window.innerWidth - 60;
  const y = ev?.clientY ?? 28;
  const endRadius = Math.hypot(Math.max(x, window.innerWidth - x), Math.max(y, window.innerHeight - y));

  document.documentElement.classList.add("vt-theme-ripple");
  let transition;
  try {
    transition = document.startViewTransition(() => {
      applyFn();
    });
  } catch {
    document.documentElement.classList.remove("vt-theme-ripple");
    applyFn();
    return;
  }

  transition.ready
    .then(() => {
      document.documentElement.animate(
        {
          clipPath: [
            `circle(0px at ${x}px ${y}px)`,
            `circle(${Math.ceil(endRadius)}px at ${x}px ${y}px)`,
          ],
        },
        {
          duration: 420,
          easing: SPRING_EASE,
          pseudoElement: "::view-transition-new(root)",
        }
      );
    })
    .catch(() => {})
    .finally(() => {
      transition.finished?.finally(() => {
        document.documentElement.classList.remove("vt-theme-ripple");
      });
    });
}

/** FLIP 空间位移过渡：让元素从原容器移动到新容器时平滑滑行而非突兀闪现 */
export function flipMoveElement(el, moveDomFn, { duration = 300 } = {}) {
  if (!el || prefersReducedMotion()) {
    moveDomFn();
    return;
  }
  const first = el.getBoundingClientRect();
  moveDomFn();
  if (!first.width || !first.height) return;
  const last = el.getBoundingClientRect();
  const dx = first.left - last.left;
  const dy = first.top - last.top;
  if (Math.abs(dx) < 2 && Math.abs(dy) < 2) return;

  el.animate(
    [
      { transform: `translate(${dx}px, ${dy}px)`, opacity: 0.92 },
      { transform: "translate(0, 0)", opacity: 1 },
    ],
    { duration, easing: SPRING_EASE }
  );
}

/** 全局代理所有 <details> 折叠组件的丝滑高度过渡（支持动画中途随时反向打断） */
const activeDetailAnims = new WeakMap();

export function initSmoothAccordions() {
  document.addEventListener("click", (e) => {
    const summary = e.target?.closest?.("summary");
    if (!summary) return;
    const details = summary.parentElement;
    if (!details || details.tagName !== "DETAILS" || prefersReducedMotion()) return;

    e.preventDefault();
    const prevAnim = activeDetailAnims.get(details);
    if (prevAnim) {
      prevAnim.cancel();
      activeDetailAnims.delete(details);
    }

    const startHeight = details.offsetHeight;
    const summaryHeight = summary.offsetHeight;
    const isClosing = details.open;

    details.style.overflow = "hidden";

    if (isClosing) {
      const endHeight = summaryHeight + 2;
      const anim = details.animate(
        [
          { height: `${startHeight}px` },
          { height: `${endHeight}px` },
        ],
        { duration: 195, easing: SPRING_EASE }
      );
      activeDetailAnims.set(details, anim);
      anim.onfinish = () => {
        details.open = false;
        details.style.height = "";
        details.style.overflow = "";
        activeDetailAnims.delete(details);
      };
      anim.oncancel = () => {
        details.style.height = "";
        details.style.overflow = "";
      };
    } else {
      details.style.height = `${startHeight}px`;
      details.open = true;
      requestAnimationFrame(() => {
        const endHeight = details.scrollHeight;
        const anim = details.animate(
          [
            { height: `${startHeight}px` },
            { height: `${endHeight}px` },
          ],
          { duration: 245, easing: SPRING_EASE }
        );
        activeDetailAnims.set(details, anim);
        anim.onfinish = () => {
          details.style.height = "";
          details.style.overflow = "";
          activeDetailAnims.delete(details);
        };
        anim.oncancel = () => {
          details.style.height = "";
          details.style.overflow = "";
        };
      });
    }
  });
}
