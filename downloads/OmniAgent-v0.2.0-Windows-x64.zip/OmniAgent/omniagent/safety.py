"""安全策略：危险命令拦截 + 审批判定。"""
from __future__ import annotations

import re
from typing import Any

# 永远禁止（任何审批模式下都不执行）
BLOCKED_PATTERNS = [
    (r"\brm\s+(-[a-zA-Z]*\s+)*(-[a-zA-Z]*[rR][a-zA-Z]*)\s+(-[a-zA-Z]*\s+)*(/|~|\$HOME|/\*)(\s|$)", "递归删除根目录/家目录"),
    (r"\bmkfs(\.\w+)?\b", "格式化磁盘"),
    (r"\bdd\s+.*\bof=/dev/", "直接写入块设备"),
    (r":\(\)\s*\{\s*:\|:&\s*\};:", "fork 炸弹"),
    (r"\b(shutdown|reboot|halt|poweroff)\b", "关机/重启"),
    (r">\s*/dev/(sd|nvme|disk)", "覆盖磁盘设备"),
    (r"\bchmod\s+-R\s+0?777\s+/(\s|$)", "修改根目录权限"),
]

# smart 模式下需要人工确认
RISKY_PATTERNS = [
    (r"\brm\s+.*-[a-zA-Z]*[rRf]", "递归/强制删除文件"),
    (r"\bsudo\b", "提权执行"),
    (r"\bgit\s+push\b", "推送到远程仓库"),
    (r"\bgit\s+reset\s+--hard\b", "丢弃本地修改"),
    (r"\bgit\s+clean\s+-[a-zA-Z]*f", "删除未跟踪文件"),
    (r"\bgit\s+checkout\s+--\s", "丢弃文件修改"),
    (r"(curl|wget)[^|]*\|\s*(ba|z)?sh\b", "下载并执行远程脚本"),
    (r"\b(npm|pnpm|yarn)\s+publish\b|\btwine\s+upload\b", "发布软件包"),
    (r"\bdocker\s+(rm|rmi|system\s+prune)\b", "删除容器/镜像"),
    (r"\bkill(all)?\s+-9\b|\bpkill\b", "强制结束进程"),
    (r"\b(drop|truncate)\s+(table|database)\b", "删除数据库数据"),
    (r"\bchown\b|\bchmod\s+-R\b", "批量修改权限"),
]


def check_blocked(tool_name: str, args: dict[str, Any]) -> str | None:
    if tool_name == "run_shell":
        cmd = args.get("command", "")
        for pat, why in BLOCKED_PATTERNS:
            if re.search(pat, cmd, re.IGNORECASE):
                return f"命令被安全策略禁止（{why}）：{cmd}"
    return None


def approval_reason(tool_name: str, risk: str, args: dict[str, Any], policy: str) -> str | None:
    """返回需要审批的原因；None 表示无需审批。

    policy:
      auto   - 全自动，不询问（危险命令仍会被禁止）
      smart  - 仅对高风险 shell 命令请求确认（默认）
      always - 所有写文件 / 执行操作都请求确认
    """
    # 外部业务系统的最终提交（报销/审批/申请）不可撤回：无论何种审批策略都必须由用户亲自确认
    if tool_name == "web_automation" and args.get("action") == "submit":
        return f"在外部业务系统中执行最终提交（{args.get('note') or args.get('target') or '提交'}），提交后通常不可撤回，请先核对报告与表单截图"
    if policy == "auto":
        return None
    if policy == "always" and risk in ("write", "exec"):
        return f"{'写入文件' if risk == 'write' else '执行代码/命令'}"
    if tool_name == "run_shell":
        cmd = args.get("command", "")
        for pat, why in RISKY_PATTERNS:
            if re.search(pat, cmd, re.IGNORECASE):
                return why
    # smart 模式下对不可逆的外部系统写操作（外发邮件、提交网页申请表单、外部写接口）请求用户确认
    if tool_name == "email_ops" and args.get("action") in ("send_email", "send_reply"):
        return f"向外部收件人发送正式邮件（收件人：{args.get('to') or '原发件人'}）"
    if tool_name == "browser_session" and args.get("action") == "submit":
        return "向外部网站/系统提交表单或申请"
    if tool_name == "connector_query" and str(args.get("method") or "GET").upper() in ("POST", "PUT", "PATCH", "DELETE"):
        return f"向外部系统 `{args.get('connector')}` 发起 {str(args.get('method')).upper()} 写入操作"
    return None
