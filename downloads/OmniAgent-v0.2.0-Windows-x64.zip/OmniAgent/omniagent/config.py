"""配置加载：内置模型档案 + 用户 YAML 配置 + 环境变量。

查找顺序（后者覆盖前者）:
  1. 内置默认值
  2. ~/.omniagent/config.yaml
  3. <workspace>/.omniagent/config.yaml
  4. 环境变量 OMNI_MODEL / OMNI_APPROVAL / OMNI_MAX_STEPS
"""
from __future__ import annotations

import dataclasses
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

try:
    from dotenv import load_dotenv
except ImportError:  # pragma: no cover
    load_dotenv = None


# 模型名中包含这些片段时，默认认为支持图像输入（可在配置中用 vision: true/false 显式覆盖）
_VISION_HINTS = ("claude", "gpt-4o", "gpt-4.1", "gpt-5", "o3", "o4", "gemini", "-vl", "vl-", "vision", "4v",
                 "llava", "pixtral", "qvq", "minicpm-v", "internvl")


def infer_vision(provider: str, model: str) -> bool:
    if provider == "mock":
        return True
    m = (model or "").lower()
    return any(h in m for h in _VISION_HINTS)


@dataclass
class ModelProfile:
    name: str
    provider: str  # "openai" (OpenAI 兼容协议) | "anthropic" | "mock"
    model: str
    base_url: str | None = None
    api_key_env: str | None = None
    api_key: str | None = None
    max_tokens: int = 8192
    context_window: int = 128_000
    temperature: float | None = None
    extra: dict[str, Any] = field(default_factory=dict)
    # 是否支持图像输入（view_image 等）。None 表示根据模型名自动推断，初始化后总是 bool。
    vision: bool | None = None
    # Anthropic 兼容网关常用 Bearer Token（ANTHROPIC_AUTH_TOKEN）而非 x-api-key
    auth_token_env: str | None = None
    # base_url 为空时从该环境变量读取（如 ANTHROPIC_BASE_URL）
    base_url_env: str | None = None

    def __post_init__(self):
        if self.vision is None:
            self.vision = infer_vision(self.provider, self.model)
        else:
            self.vision = bool(self.vision)

    def resolve_api_key(self) -> str | None:
        if self.api_key:
            return self.api_key
        if self.api_key_env:
            return os.environ.get(self.api_key_env) or None
        return None

    def resolve_auth_token(self) -> str | None:
        if self.api_key:  # 显式提供的 key 优先，不再混用环境中的 token
            return None
        if self.auth_token_env:
            return os.environ.get(self.auth_token_env) or None
        return None

    def resolve_base_url(self) -> str | None:
        if self.base_url:
            return self.base_url
        if self.base_url_env:
            return os.environ.get(self.base_url_env) or None
        return None

    @property
    def key_hint(self) -> str:
        """未配置凭据时提示用户应设置的环境变量。"""
        envs = [e for e in (self.api_key_env, self.auth_token_env) if e]
        return " 或 ".join(envs) or "api_key"

    @property
    def available(self) -> bool:
        if self.provider == "mock":
            return True
        base = self.resolve_base_url() or ""
        if "localhost" in base or "127.0.0.1" in base:
            return True
        return bool(self.resolve_api_key() or self.resolve_auth_token())


def profile_with_key(profile: ModelProfile, api_key: str, base_url: str | None = None) -> ModelProfile:
    """基于已有档案生成使用指定（如每个用户自己的）API Key 的新档案，不修改原档案。

    显式 key 会屏蔽 ANTHROPIC_AUTH_TOKEN 等环境凭据；base_url 未提供时沿用原档案的地址。
    """
    kwargs: dict[str, Any] = {"api_key": api_key, "auth_token_env": None, "extra": dict(profile.extra)}
    if base_url:
        kwargs["base_url"] = base_url
    return dataclasses.replace(profile, **kwargs)


BUILTIN_MODELS: dict[str, dict[str, Any]] = {
    "claude": {
        "provider": "anthropic",
        "model": "claude-sonnet-4-5",
        "api_key_env": "ANTHROPIC_API_KEY",
        "auth_token_env": "ANTHROPIC_AUTH_TOKEN",
        "base_url_env": "ANTHROPIC_BASE_URL",
        "context_window": 200_000,
        "max_tokens": 16000,
        "vision": True,
    },
    "deepseek": {
        "provider": "openai",
        "base_url": "https://api.deepseek.com/v1",
        "model": "deepseek-chat",
        "api_key_env": "DEEPSEEK_API_KEY",
        "vision": False,
        "context_window": 128_000,
        "max_tokens": 8192,
    },
    "deepseek-reasoner": {
        "provider": "openai",
        "base_url": "https://api.deepseek.com/v1",
        "model": "deepseek-reasoner",
        "api_key_env": "DEEPSEEK_API_KEY",
        "vision": False,
        "context_window": 128_000,
        "max_tokens": 16000,
    },
    "qwen": {
        "provider": "openai",
        "base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1",
        "model": "qwen-max-latest",
        "api_key_env": "DASHSCOPE_API_KEY",
        "vision": False,
        "context_window": 128_000,
    },
    "kimi": {
        "provider": "openai",
        "base_url": "https://api.moonshot.cn/v1",
        "model": "kimi-k2-0905-preview",
        "api_key_env": "MOONSHOT_API_KEY",
        "vision": False,
        "context_window": 256_000,
    },
    "glm": {
        "provider": "openai",
        "base_url": "https://open.bigmodel.cn/api/paas/v4",
        "model": "glm-4.6",
        "api_key_env": "ZHIPUAI_API_KEY",
        "vision": False,
        "context_window": 128_000,
    },
    "openai": {
        "provider": "openai",
        "model": "gpt-4.1",
        "api_key_env": "OPENAI_API_KEY",
        "vision": True,
        "context_window": 1_000_000,
        "max_tokens": 16000,
    },
    "ollama": {
        "provider": "openai",
        "base_url": "http://localhost:11434/v1",
        "model": "qwen2.5-coder:14b",
        "api_key": "ollama",
        "vision": False,
        "context_window": 32_000,
        "max_tokens": 4096,
    },
    "mock": {"provider": "mock", "model": "mock", "context_window": 32_000, "vision": True},
}


@dataclass
class Settings:
    default_model: str = "auto"
    models: dict[str, ModelProfile] = field(default_factory=dict)
    approval: str = "smart"  # auto | smart | always
    max_steps: int = 80
    max_reviews: int = 2  # 完成前最多自检轮数
    allow_outside_workspace: bool = False
    shell_timeout: int = 180
    python_timeout: int = 300
    tavily_api_key: str | None = None
    python_executable: str | None = None  # python 工具使用的解释器，默认与 OmniAgent 相同

    def get_model(self, name: str | None = None) -> ModelProfile:
        name = name or self.default_model
        if name in (None, "", "auto"):
            # 自动选择第一个可用（已配置 API Key）的模型
            for key in ["claude", "deepseek", "openai", "qwen", "kimi", "glm"]:
                if key in self.models and self.models[key].available:
                    return self.models[key]
            for prof in self.models.values():
                if prof.available and prof.provider != "mock" and "localhost" not in (prof.base_url or ""):
                    return prof
            raise RuntimeError(
                "没有找到可用的模型。请设置任一 API Key 环境变量（如 DEEPSEEK_API_KEY / ANTHROPIC_API_KEY（或 ANTHROPIC_AUTH_TOKEN）/ "
                "OPENAI_API_KEY / DASHSCOPE_API_KEY），或使用 --model ollama / --model mock。"
            )
        if name not in self.models:
            raise KeyError(f"未知模型档案 '{name}'。可用: {', '.join(self.models)}")
        return self.models[name]


def _merge_models(target: dict[str, ModelProfile], raw: dict[str, Any]) -> None:
    for name, spec in (raw or {}).items():
        base: dict[str, Any] = {}
        if name in target:
            p = target[name]
            base = {k: getattr(p, k) for k in p.__dataclass_fields__ if k != "name"}
            base["extra"] = dict(p.extra)
            spec = spec or {}
            if "model" in spec and "vision" not in spec:
                base["vision"] = None  # 换了模型：重新根据模型名推断是否支持视觉
        base.update(spec or {})
        known = {k: v for k, v in base.items() if k in ModelProfile.__dataclass_fields__ and k != "name"}
        extra = {k: v for k, v in base.items() if k not in ModelProfile.__dataclass_fields__}
        known.setdefault("extra", {}).update(extra)
        target[name] = ModelProfile(name=name, **known)


def load_settings(workspace: str | Path | None = None) -> Settings:
    workspace = Path(workspace or os.getcwd()).resolve()
    pkg_root = Path(__file__).resolve().parent.parent
    if load_dotenv:
        load_dotenv(Path.home() / ".omniagent" / ".env", override=False)
        load_dotenv(workspace / ".env", override=False)
        load_dotenv(pkg_root / ".env", override=False)

    settings = Settings()
    _merge_models(settings.models, BUILTIN_MODELS)

    for path in [Path.home() / ".omniagent" / "config.yaml", workspace / ".omniagent" / "config.yaml"]:
        if path.exists():
            data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
            _merge_models(settings.models, data.pop("models", {}) or {})
            for k, v in data.items():
                if hasattr(settings, k):
                    setattr(settings, k, v)

    settings.default_model = os.environ.get("OMNI_MODEL", settings.default_model)
    settings.approval = os.environ.get("OMNI_APPROVAL", settings.approval)
    if os.environ.get("OMNI_MAX_STEPS"):
        settings.max_steps = int(os.environ["OMNI_MAX_STEPS"])
    settings.tavily_api_key = settings.tavily_api_key or os.environ.get("TAVILY_API_KEY")
    return settings
