"""规划与协作工具：任务清单、向用户提问、专业子智能体（单个与并行委派）。"""
from __future__ import annotations

from .base import ToolContext, ToolError, ToolResult, tool

STATUS_ICON = {"pending": "☐", "in_progress": "▶", "completed": "☑", "cancelled": "✗"}


def render_todos(todos: list[dict]) -> str:
    return "\n".join(f"{STATUS_ICON.get(t.get('status'), '☐')} {t.get('content')}" for t in todos)


@tool(
    "todo_write",
    "创建/更新当前任务的执行计划（任务清单）。复杂任务（3 步以上）开始时必须先用它拆解任务；"
    "每开始一项把它标为 in_progress（同一时间只有一项），完成后立即标为 completed。每次都提交完整列表。",
    {
        "todos": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "content": {"type": "string", "description": "具体、可验证的步骤描述"},
                    "status": {"type": "string", "enum": ["pending", "in_progress", "completed", "cancelled"]},
                },
                "required": ["content", "status"],
            },
        }
    },
    ["todos"],
)
async def todo_write(args, ctx: ToolContext):
    todos = args.get("todos") or []
    for t in todos:
        if t.get("status") not in STATUS_ICON:
            t["status"] = "pending"
    ctx.state["todos"] = todos
    await ctx.emit({"type": "plan_update", "todos": todos})
    done = sum(t["status"] == "completed" for t in todos)
    return ToolResult(f"计划已更新（{done}/{len(todos)} 完成）：\n{render_todos(todos)}", data={"todos": todos})


@tool(
    "ask_user",
    "仅当缺少关键信息、且无法通过查看文件或合理假设解决时，向用户提问并等待回答。不要为可以自行决定的小事打扰用户。",
    {"question": {"type": "string", "description": "清晰具体的问题，可附带选项"}},
    ["question"],
    summary_keys=("question",),
)
async def ask_user(args, ctx: ToolContext):
    if ctx.ask_user is None:
        return "用户当前不可用（非交互模式）。请基于最合理的假设继续执行，并在最终报告中说明你的假设。"
    answer = await ctx.ask_user(args["question"])
    if not answer:
        return "用户未回答。请基于最合理的假设继续，并在最终报告中说明。"
    return f"用户回答：{answer}"


@tool(
    "delegate_task",
    "把一个边界清晰、相对独立的子任务委派给专业子智能体执行（拥有独立上下文与专业系统提示词）。\n"
    "内置 agent_type 可选：\n"
    "- researcher：只读快速调研（代码库搜索、网页抓取、外部数据源探查）\n"
    "- coder：软件开发与测试修复\n"
    "- analyst：Python 数据清洗、统计与计量回归、学术/商业绘图\n"
    "- writer：学术论文、党政公文、分析报告、PPT 撰写与排版校验\n"
    "- connector：外部应用 API、SQLite 数据库、MCP 服务与动态网页读取\n"
    "- reviewer：独立代码审查、测试运行、文档打分与图表核验\n"
    "任务描述必须完整自包含（目标、文件路径、约束、期望交付物）。返回子智能体的最终报告。",
    {
        "task": {"type": "string", "description": "完整自包含的子任务描述"},
        "agent_type": {
            "type": "string",
            "description": "子智能体类型：researcher | coder | analyst | writer | connector | reviewer 或自定义智能体名",
        },
        "role": {"type": "string", "description": "可选：具体职责标题，如 '财政数据计量分析员'、'前端架构审查员'"},
        "max_steps": {"type": "integer", "description": "最大步数，默认按角色配置（通常 35-50）"},
    },
    ["task"],
    risk="exec",
    summary_keys=("agent_type", "role", "task"),
)
async def delegate_task(args, ctx: ToolContext):
    parent = ctx.agent
    if parent is None:
        raise ToolError("当前环境不支持子智能体")
    if parent.depth >= 2:
        raise ToolError("子智能体嵌套层数已达上限，请自行完成该任务")
    agent_type = args.get("agent_type")
    role = args.get("role")
    max_steps = int(args["max_steps"]) if args.get("max_steps") else None
    report = await parent.spawn_subagent(args["task"], role or agent_type or "助手", max_steps=max_steps,
                                         agent_type=agent_type)
    label = role or agent_type or "助手"
    return ToolResult(f"子智能体（{label}）报告：\n{report}")


@tool(
    "delegate_parallel",
    "并行启动多个专业子智能体同时执行互不冲突的独立子任务（例如：并行调研多个模块、并行读取多个外部数据源、"
    "并行审查代码与核验文档）。注意：并行子任务若需写入文件，必须写入不同的目标文件以避免冲突。",
    {
        "tasks": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "task": {"type": "string", "description": "完整自包含的子任务描述"},
                    "agent_type": {"type": "string", "description": "researcher | coder | analyst | writer | connector | reviewer"},
                    "role": {"type": "string", "description": "职责标题"},
                    "max_steps": {"type": "integer"},
                },
                "required": ["task"],
            },
        }
    },
    ["tasks"],
    risk="exec",
)
async def delegate_parallel(args, ctx: ToolContext):
    parent = ctx.agent
    if parent is None:
        raise ToolError("当前环境不支持子智能体")
    if parent.depth >= 2:
        raise ToolError("子智能体嵌套层数已达上限，请自行完成任务")
    specs = args.get("tasks") or []
    if not specs:
        raise ToolError("tasks 不能为空")
    if len(specs) > 6:
        raise ToolError("单次并行子智能体最多 6 个")
    reports = await parent.spawn_subagents_parallel(specs)
    parts = [f"已完成 {len(reports)} 个并行子智能体任务："]
    for i, (label, rep) in enumerate(reports, 1):
        parts.append(f"\n### [{i}] {label}\n{rep}")
    return ToolResult("\n".join(parts))


PLANNING_TOOLS = [todo_write, ask_user, delegate_task, delegate_parallel]
