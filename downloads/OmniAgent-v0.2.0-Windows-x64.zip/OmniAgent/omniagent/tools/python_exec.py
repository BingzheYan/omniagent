"""持久化 Python 执行工具：数据分析、计算、绘图、批量文件处理。"""
from __future__ import annotations

import asyncio
import json
import os
import sys
from pathlib import Path

from .base import ToolContext, ToolError, ToolResult, tool, truncate

MARKER = "<<<OMNI_RESULT>>>"
DRIVER = Path(__file__).with_name("kernel_driver.py")


class PythonKernel:
    def __init__(self, workspace: Path, python: str | None = None):
        self.workspace = workspace
        self.python = python or sys.executable
        self.proc: asyncio.subprocess.Process | None = None
        self.fig_dir = workspace / "outputs" / "figures"
        self._lock = asyncio.Lock()

    async def start(self):
        env = {**os.environ, "PYTHONIOENCODING": "utf-8", "MPLBACKEND": "Agg", "PYTHONUNBUFFERED": "1"}
        self.proc = await asyncio.create_subprocess_exec(
            self.python, "-u", str(DRIVER), str(self.fig_dir),
            cwd=str(self.workspace), env=env,
            stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT,
            limit=32 * 1024 * 1024,
        )

    async def stop(self):
        if self.proc and self.proc.returncode is None:
            self.proc.kill()
            try:
                await asyncio.wait_for(self.proc.wait(), 5)
            except asyncio.TimeoutError:
                pass
        self.proc = None

    async def execute(self, code: str, timeout: int) -> tuple[dict, bool]:
        """返回 (结果, 是否重启过内核)。"""
        async with self._lock:
            restarted = False
            if self.proc is None or self.proc.returncode is not None:
                restarted = self.proc is not None
                await self.start()
            assert self.proc and self.proc.stdin and self.proc.stdout
            self.proc.stdin.write((json.dumps({"code": code}) + "\n").encode())
            await self.proc.stdin.drain()
            stray: list[str] = []

            async def read_result():
                while True:
                    raw = await self.proc.stdout.readline()
                    if not raw:
                        return {"ok": False, "output": "Python 内核意外退出（可能内存不足或调用了 os._exit）。",
                                "result": None, "figures": []}
                    line = raw.decode("utf-8", "replace")
                    if line.startswith(MARKER):
                        return json.loads(line[len(MARKER):])
                    stray.append(line)

            try:
                res = await asyncio.wait_for(read_result(), timeout=timeout)
            except asyncio.TimeoutError:
                await self.stop()
                raise ToolError(f"Python 代码执行超时（{timeout}s），内核已重启，之前定义的变量已丢失。") from None
            except asyncio.CancelledError:
                await self.stop()
                raise
            if stray:
                res["output"] = "".join(stray) + (res.get("output") or "")
            return res, restarted


@tool(
    "python",
    "在持久化的 Python 会话中执行代码（变量跨调用保留，类似 Jupyter），工作目录为工作区。已安装 pandas、numpy、"
    "matplotlib、openpyxl、python-docx、python-pptx、pypdf 等。适合数据清洗/统计分析/建模/绘图/批量处理文件。"
    "最后一行表达式的值会自动显示；matplotlib 图会自动保存到 outputs/figures/ 并返回路径（无需 plt.show()），"
    "中文字体已自动配置。用 print() 输出关键结果，避免一次打印超大数据。",
    {
        "code": {"type": "string", "description": "要执行的 Python 代码"},
        "timeout": {"type": "integer", "description": "超时秒数，默认 300"},
    },
    ["code"],
    risk="exec",
    summary_keys=("code",),
)
async def python_exec(args, ctx: ToolContext):
    kernel: PythonKernel | None = ctx.state.get("kernel")
    if kernel is None:
        kernel = PythonKernel(ctx.workspace, ctx.settings.__dict__.get("python_executable"))
        ctx.state["kernel"] = kernel
    timeout = int(args.get("timeout") or ctx.settings.python_timeout)
    res, restarted = await kernel.execute(args["code"], timeout)
    parts = []
    if restarted:
        parts.append("[注意：内核此前已退出并被重启，之前的变量已丢失]")
    if res.get("output"):
        parts.append(res["output"].rstrip())
    if res.get("result") is not None:
        parts.append(f"Out: {res['result']}")
    figs = [f for f in res.get("figures", []) if not f.startswith("(")]
    rel_figs = []
    for f in figs:
        p = Path(f)
        p = p if p.is_absolute() else ctx.workspace / p
        rel_figs.append(ctx.rel(p.resolve()))
    if rel_figs:
        if ctx.agent is not None and getattr(ctx.agent, "tools", None) is not None and \
                ctx.agent.tools.get("view_image") is not None:
            parts.append("（提示：交付前请用 view_image 查看下列图像，核验标题/坐标轴/中文显示/数据是否正确）")
        parts.append("已保存图像: " + ", ".join(rel_figs))
    text = "\n".join(parts) or "(执行成功，无输出)"
    return ToolResult(truncate(text), is_error=not res.get("ok", False), data={"images": rel_figs})


async def shutdown_kernel(state: dict) -> None:
    k = state.pop("kernel", None)
    if k:
        await k.stop()


PYTHON_TOOLS = [python_exec]
