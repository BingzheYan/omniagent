"""全链路实测验收工具集（Live Acceptance & Verification Harness）：
为代码审查修改、后端/全栈 Web 应用编写、CLI 程序以及 Word/PPT/Excel/PDF 交付物提供一站式实测验收，
确保智能体在交付前完成真正的启动运行、接口断言、语法扫描、公式排错与版面核验。
"""
from __future__ import annotations

import ast
import asyncio
import os
import re
import signal
import socket
import sys
import time
from pathlib import Path
from typing import Any

import httpx

from omniagent.connectors import render_url_content

from .base import ToolContext, ToolError, ToolResult, tool, truncate

_PLACEHOLDER_RE = re.compile(r"(<<<<<<<|=======|>>>>>>>|\bTODO\b|\bFIXME\b|\[待填写?\]|\[待补充\]|Lorem ipsum)", re.I)
_EXCEL_ERR_TOKENS = {"#REF!", "#DIV/0!", "#VALUE!", "#NAME?", "#N/A", "#NUM!"}


def _free_local_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return int(s.getsockname()[1])


def _scan_python_files(root: Path, target_paths: list[str] | None = None) -> tuple[list[str], list[str], int]:
    """扫描 Python 文件的 AST 语法错误与遗留占位符/冲突标记。"""
    syntax_errs: list[str] = []
    hygiene_warns: list[str] = []
    checked = 0
    files: list[Path] = []
    if target_paths:
        for tp in target_paths:
            p = (root / tp).resolve()
            if p.is_file() and p.suffix == ".py":
                files.append(p)
            elif p.is_dir():
                files.extend(p.rglob("*.py"))
    else:
        for p in root.rglob("*.py"):
            if any(part in {".venv", "venv", "node_modules", "__pycache__", ".git", ".omniagent"} for part in p.parts):
                continue
            files.append(p)

    for p in files[:200]:
        checked += 1
        rel = str(p.relative_to(root)) if p.is_relative_to(root) else str(p)
        src = p.read_text(encoding="utf-8", errors="replace")
        try:
            ast.parse(src, filename=rel)
        except SyntaxError as e:
            syntax_errs.append(f"`{rel}:{e.lineno}` SyntaxError: {e.msg}")
        for idx, line in enumerate(src.splitlines(), 1):
            if _PLACEHOLDER_RE.search(line):
                hygiene_warns.append(f"`{rel}:{idx}` 发现疑似未完成占位符或冲突标记: `{line.strip()[:80]}`")
                if len(hygiene_warns) >= 12:
                    break
    return syntax_errs, hygiene_warns, checked


async def _verify_web_service(
    ctx: ToolContext,
    command: str,
    endpoints: list[dict[str, Any]],
    capture_screenshot: bool = False,
    startup_timeout: float = 12.0,
) -> tuple[bool, list[str], str | None]:
    port = _free_local_port()
    cmd_rendered = command.replace("{port}", str(port)).replace("$PORT", str(port))
    env = {**os.environ, "PORT": str(port), "PYTHONUNBUFFERED": "1"}
    kwargs: dict[str, Any] = {}
    if os.name != "nt":
        kwargs["start_new_session"] = True

    proc = await asyncio.create_subprocess_shell(
        cmd_rendered,
        cwd=str(ctx.workspace),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
        env=env,
        **kwargs,
    )
    report: list[str] = [f"- **启动命令**: `{cmd_rendered}`（沙箱端口 `{port}`）"]
    shot_rel: str | None = None
    all_ok = True

    try:
        # 等待端口监听就绪
        ready = False
        deadline = time.time() + startup_timeout
        while time.time() < deadline:
            if proc.returncode is not None:
                break
            try:
                with socket.create_connection(("127.0.0.1", port), timeout=0.4):
                    ready = True
                    break
            except OSError:
                await asyncio.sleep(0.25)

        if not ready:
            out_bytes = b""
            try:
                out_bytes = await asyncio.wait_for(proc.stdout.read(4096), timeout=1.0) if proc.stdout else b""
            except Exception:  # noqa: BLE001
                pass
            report.append(f"- ❌ **服务启动失败**：在 {startup_timeout}s 内未监听端口 `{port}`（退出码 {proc.returncode}）")
            if out_bytes:
                try:
                    err_txt = out_bytes.decode("utf-8")
                except UnicodeDecodeError:
                    err_txt = out_bytes.decode("gb18030" if os.name == "nt" else "utf-8", errors="replace")
                report.append(f"```\n{err_txt[:1500]}\n```")
            return False, report, None

        report.append(f"- ✅ **服务进程已就绪**：成功监听 `http://127.0.0.1:{port}`")
        checks = endpoints or [{"path": "/", "method": "GET", "expect_status": 200}]

        async with httpx.AsyncClient(base_url=f"http://127.0.0.1:{port}", follow_redirects=True, timeout=10.0) as client:
            for ep in checks:
                path = str(ep.get("path") or "/")
                method = str(ep.get("method") or "GET").upper()
                exp_status = int(ep.get("expect_status") or 200)
                exp_sub = str(ep.get("expect_contains") or "")
                t0 = time.time()
                r = await client.request(method, path, json=ep.get("json"), params=ep.get("params"))
                ms = round((time.time() - t0) * 1000, 1)
                ok = (r.status_code == exp_status) and (not exp_sub or exp_sub in r.text)
                if not ok:
                    all_ok = False
                mark = "✅" if ok else "❌"
                detail = f"`{method} {path}` → HTTP `{r.status_code}`（期望 `{exp_status}`，耗时 {ms}ms）"
                if exp_sub:
                    detail += f" · 包含 `{exp_sub}`: {'是' if exp_sub in r.text else '否'}"
                report.append(f"- {mark} {detail}")

        if capture_screenshot:
            shot_p = ctx.workspace / "outputs" / "figures" / f"qa_web_{int(time.time())}.png"
            await render_url_content(f"http://127.0.0.1:{port}/", render_js=True, screenshot_path=shot_p, timeout=15)
            if shot_p.is_file():
                shot_rel = ctx.rel(shot_p)
                report.append(f"- 🖼 **页面渲染实测截图**: `{shot_rel}`")
    finally:
        if proc.returncode is None:
            try:
                if os.name != "nt":
                    os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
                else:
                    import subprocess

                    await asyncio.to_thread(
                        subprocess.run,
                        ["taskkill", "/F", "/T", "/PID", str(proc.pid)],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                        timeout=5,
                    )
                await asyncio.wait_for(proc.wait(), timeout=3.0)
            except Exception:  # noqa: BLE001
                try:
                    proc.kill()
                except Exception:  # noqa: BLE001
                    pass
    return all_ok, report, shot_rel


def _verify_office_file(ctx: ToolContext, rel_path: str) -> tuple[bool, list[str]]:
    p = ctx.resolve(rel_path, must_exist=True, read_only=True)
    ext = p.suffix.lower()
    size = p.stat().st_size
    if size == 0:
        return False, [f"- ❌ 文件 `{ctx.rel(p)}` 为 0 字节空文件"]

    lines = [f"- **目标文件**: `{ctx.rel(p)}`（大小 {size:,} 字节）"]
    ok = True

    if ext == ".pptx":
        from pptx import Presentation

        prs = Presentation(str(p))
        n = len(prs.slides)
        if n == 0:
            return False, lines + ["- ❌ PPTX 幻灯片页数为 0"]
        empty_slides = []
        placeholders = []
        for idx, sl in enumerate(prs.slides, 1):
            texts = [sh.text_frame.text.strip() for sh in sl.shapes if sh.has_text_frame and sh.text_frame.text.strip()]
            joined = "\n".join(texts)
            if not joined and not any(sh.shape_type == 13 for sh in sl.shapes):  # 13 = PICTURE
                empty_slides.append(idx)
            if _PLACEHOLDER_RE.search(joined):
                placeholders.append(idx)
        lines.append(f"- {'✅' if not empty_slides else '⚠️'} **幻灯片结构**：共 {n} 页"
                     + (f"（空白页：{empty_slides}）" if empty_slides else "，每页均有实质内容"))
        if placeholders:
            ok = False
            lines.append(f"- ❌ 第 {placeholders} 页检测到未替换占位符（TODO / 待补充）")
        return ok and not empty_slides, lines

    if ext in (".xlsx", ".xlsm"):
        import openpyxl

        wb = openpyxl.load_workbook(str(p), data_only=False)
        err_cells: list[str] = []
        total_rows = 0
        for sname in wb.sheetnames:
            ws = wb[sname]
            total_rows += ws.max_row
            for row in ws.iter_rows(values_only=False):
                for c in row:
                    val = str(c.value or "").strip()
                    if val in _EXCEL_ERR_TOKENS:
                        err_cells.append(f"{sname}!{c.coordinate}={val}")
        lines.append(f"- ✅ **工作簿结构**：共 {len(wb.sheetnames)} 个工作表（{', '.join(wb.sheetnames)}），累计 {total_rows} 行")
        if err_cells:
            ok = False
            lines.append(f"- ❌ **公式/数值错误单元格**：{', '.join(err_cells[:15])}")
        else:
            lines.append("- ✅ **零公式错误**：未发现 `#REF!` / `#DIV/0!` / `#VALUE!` 等异常单元格")
        return ok, lines

    if ext == ".pdf":
        from pypdf import PdfReader

        rd = PdfReader(str(p))
        n = len(rd.pages)
        if n == 0:
            return False, lines + ["- ❌ PDF 页数为 0"]
        sample_txt = "\n".join((pg.extract_text() or "") for pg in rd.pages[:5])
        lines.append(f"- ✅ **PDF 可读性校验**：共 {n} 页，首 {min(n, 5)} 页提取文本 {len(sample_txt)} 字符")
        if _PLACEHOLDER_RE.search(sample_txt):
            ok = False
            lines.append("- ❌ PDF 正文中检测到未替换的 TODO / 待填写 占位符")
        return ok, lines

    if ext in (".docx", ".md"):
        from .research import inspect_document

        res = inspect_document(p, ctx.workspace)
        score = res.get("score", 100)
        errs = [i for i in res.get("issues", []) if i.get("severity") == "error"]
        lines.append(f"- {'✅' if score >= 85 and not errs else '❌'} **文档规范评分**：`{score}/100`（错误 {len(errs)} 项）")
        for issue in res.get("issues", [])[:8]:
            lines.append(f"  - [{issue['severity']}] {issue['message']}")
        return (score >= 80 and not errs), lines

    return True, lines + ["- ✅ 文件存在且非空"]


@tool(
    "verify_deliverable",
    "【交付前实测验收引擎】对编写/修改的代码工程、Web/API 应用服务、命令行脚本或 Office/PDF 文档执行自动化实测验收：\n"
    "- python_code: 扫描全部 Python AST 语法、未解决 TODO/冲突标记，并实际运行单元测试或验收命令；\n"
    "- web_service: 在独立空闲沙箱端口真实拉起 Web 服务（用 `{port}` 占位符传入端口），并发探测 HTTP/API 路由状态码与响应内容，可选截取渲染图，最后自动清理子进程；\n"
    "- office_file: 深度校验 .pptx / .xlsx / .pdf / .docx / .md 是否存在空页、Excel 公式报错（#REF!/#DIV/0!）、遗留占位符或排版缺陷。",
    {
        "kind": {
            "type": "string",
            "enum": ["python_code", "web_service", "office_file"],
            "description": "验收对象类型",
        },
        "paths": {
            "type": "array",
            "items": {"type": "string"},
            "description": "python_code 要扫描的路径列表，或 office_file 要验收的文档路径列表",
        },
        "test_command": {
            "type": "string",
            "description": "python_code 模式下执行的测试/验证命令（默认自动检测 pytest / unittest）",
        },
        "server_command": {
            "type": "string",
            "description": "web_service 模式下启动服务的命令（用 {port} 代表动态分配的空闲端口，如 'python -m uvicorn app:app --port {port}'）",
        },
        "endpoints": {
            "type": "array",
            "description": "web_service 要实测请求的接口断言列表",
            "items": {
                "type": "object",
                "properties": {
                    "path": {"type": "string"},
                    "method": {"type": "string"},
                    "expect_status": {"type": "integer"},
                    "expect_contains": {"type": "string"},
                    "json": {"type": "object"},
                },
            },
        },
        "screenshot": {
            "type": "boolean",
            "description": "web_service 模式下是否用无头浏览器打开首页截图验收",
        },
    },
    ["kind"],
    risk="exec",
    summary_keys=("kind", "server_command", "test_command"),
)
async def verify_deliverable(args: dict[str, Any], ctx: ToolContext) -> ToolResult:
    kind = args["kind"]

    if kind == "python_code":
        syn_errs, warns, count = await asyncio.to_thread(_scan_python_files, ctx.workspace, args.get("paths"))
        lines = [f"### 🧪 代码实测验收报告（扫描 {count} 个 Python 文件）"]
        passed = not syn_errs
        if syn_errs:
            lines.append("- ❌ **AST 语法检查未通过**：\n  - " + "\n  - ".join(syn_errs))
        else:
            lines.append("- ✅ **AST 语法检查通过**：0 处语法错误")
        if warns:
            lines.append("- ⚠️ **代码卫生提示（TODO/占位符）**：\n  - " + "\n  - ".join(warns[:6]))
        else:
            lines.append("- ✅ **代码卫生检查**：无遗留冲突标记或未完成 TODO")

        cmd = str(args.get("test_command") or "").strip()
        if not cmd and ((ctx.workspace / "tests").exists() or list(ctx.workspace.glob("test_*.py")) or list(ctx.workspace.glob("*_test.py"))):
            cmd = f'"{sys.executable}" -m pytest -q'
        if cmd:
            proc = await asyncio.create_subprocess_shell(
                cmd, cwd=str(ctx.workspace), stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT
            )
            out, _ = await asyncio.wait_for(proc.communicate(), timeout=90)
            out_txt = out.decode("utf-8", "replace").strip()
            cmd_ok = proc.returncode == 0
            passed = passed and cmd_ok
            lines.append(f"- {'✅' if cmd_ok else '❌'} **测试套件执行** (`{cmd}`，退出码 `{proc.returncode}`)：")
            if out_txt:
                lines.append(f"```\n{truncate(out_txt, 6000)}\n```")
        return ToolResult("\n".join(lines), is_error=not passed, data={"passed": passed})

    if kind == "web_service":
        scmd = str(args.get("server_command") or "").strip()
        if not scmd:
            raise ToolError("web_service 验收需要提供 server_command（例如 'python app.py --port {port}'）")
        ok, rep_lines, shot_rel = await _verify_web_service(
            ctx, scmd, list(args.get("endpoints") or []), bool(args.get("screenshot", False))
        )
        head = f"### 🌐 Web 应用实测启动验收：{'✅ 全部通过' if ok else '❌ 存在未通过项'}"
        data: dict[str, Any] = {"passed": ok}
        if shot_rel:
            data["images"] = [shot_rel]
        return ToolResult(head + "\n" + "\n".join(rep_lines), is_error=not ok, data=data)

    if kind == "office_file":
        paths = list(args.get("paths") or [])
        if not paths:
            raise ToolError("office_file 验收请在 paths 中提供至少一个文档路径")
        all_ok = True
        blocks = ["### 📄 办公与出版文档质量验收报告"]
        for rp in paths:
            ok, info = await asyncio.to_thread(_verify_office_file, ctx, rp)
            all_ok = all_ok and ok
            blocks.extend(info)
        return ToolResult("\n".join(blocks), is_error=not all_ok, data={"passed": all_ok})

    raise ToolError(f"未知验收类型: {kind}")


VERIFICATION_TOOLS = [verify_deliverable]
