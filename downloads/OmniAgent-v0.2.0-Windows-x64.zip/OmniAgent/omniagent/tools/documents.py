"""办公文档：读取（docx/pdf/xlsx/pptx）与生成（Word 报告/学术论文、PDF、HTML、PPT、Excel）。

Markdown → Word 支持三种版式（style）：
- ``academic``：GB 风格中文学术论文（黑体标题、宋体小四 + Times New Roman 正文、1.5 倍行距、首行缩进 2 字符、
  摘要/关键词块、三线表、图题在下/表题在上、注释小字、LaTeX 公式渲染并右侧编号、参考文献悬挂缩进、页码）。
- ``report``（默认）：商务报告（彩色标题、表头着色的表格、图表题注、页码）。
- ``plain``：朴素版式（与早期版本一致）。

学术版式 Markdown 约定::

    # 论文标题
    摘要：……            关键词：A；B；C
    Abstract: ...         Keywords: ...
    ## 一、引言 / ### （一）… / #### 1. …
    ![图1 标题](outputs/figures/fig1.png)      → 居中图片 + 图题（下）
    表1 标题  (紧接在 Markdown 表格前一行)       → 表题（上）+ 三线表
    注：… / 资料来源：…  (紧跟图/表)            → 小号注释
    $$ y_{it} = \\alpha + \\beta x_{it} + \\varepsilon_{it} $$   → 渲染公式 + 编号 (1)
    \\newpage                                  → 分页
    ## 参考文献  然后 [1] ……                    → 悬挂缩进
"""
from __future__ import annotations

import asyncio
import base64
import functools
import hashlib
import html as htmllib
import mimetypes
import os
import re
import shutil
import subprocess
import tempfile
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .base import ToolContext, ToolError, ToolResult, tool

DOC_EXTS = {".docx", ".pdf", ".xlsx", ".xlsm", ".xls", ".pptx"}
STYLES = ("academic", "report", "plain")


# ============================================================================= 读取

def _table_md(rows: list[list[Any]]) -> str:
    if not rows:
        return ""
    width = max(len(r) for r in rows)
    norm = [[("" if c is None else str(c)).replace("\n", " ").replace("|", "\\|") for c in r] + [""] * (width - len(r))
            for r in rows]
    out = ["| " + " | ".join(norm[0]) + " |", "|" + "---|" * width]
    out += ["| " + " | ".join(r) + " |" for r in norm[1:]]
    return "\n".join(out)


def _para_has_image(p_el) -> bool:
    return bool(p_el.findall(".//" + "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}drawing")) or \
        bool(p_el.findall(".//{urn:schemas-microsoft-com:vml}imagedata"))


def extract_text(p: Path) -> str:
    ext = p.suffix.lower()
    if ext == ".docx":
        import docx
        from docx.table import Table
        from docx.text.paragraph import Paragraph

        d = docx.Document(str(p))
        parts: list[str] = []
        for child in d.element.body.iterchildren():
            tag = child.tag.split("}")[-1]
            if tag == "p":
                para = Paragraph(child, d)
                text = para.text
                style = (para.style.name if para.style is not None else "") or ""
                if _para_has_image(child):
                    stripped = text.strip()
                    if re.fullmatch(r"[（(]\s*[\w.\-]+\s*[)）]", stripped):
                        parts.append(f"[公式] {stripped}")
                    else:
                        parts.append("[图片]" + (f" {stripped}" if stripped else ""))
                    continue
                if not text.strip():
                    continue
                m = re.match(r"Heading (\d)", style)
                if m:
                    parts.append("#" * int(m.group(1)) + " " + text)
                elif style == "Title":
                    parts.append("# " + text)
                elif "List" in style:
                    parts.append("- " + text)
                else:
                    parts.append(text)
            elif tag == "tbl":
                table = Table(child, d)
                parts.append(_table_md([[c.text for c in row.cells] for row in table.rows]))
        return "\n\n".join(parts)
    if ext == ".pdf":
        from pypdf import PdfReader

        reader = PdfReader(str(p))
        pages = []
        for i, page in enumerate(reader.pages, 1):
            pages.append(f"--- 第 {i} 页 ---\n{(page.extract_text() or '').strip()}")
        return "\n\n".join(pages)
    if ext in (".xlsx", ".xlsm", ".xls"):
        import pandas as pd

        sheets = pd.read_excel(p, sheet_name=None, header=None)
        parts = []
        for name, df in sheets.items():
            df = df.dropna(how="all").dropna(axis=1, how="all")
            parts.append(f"## 工作表: {name}（{df.shape[0]} 行 × {df.shape[1]} 列）")
            shown = df.head(200).fillna("")
            parts.append(_table_md(shown.astype(str).values.tolist()))
            if df.shape[0] > 200:
                parts.append(f"... 仅显示前 200 行；完整分析请使用 python 工具（pandas.read_excel）")
        return "\n\n".join(parts)
    if ext == ".pptx":
        from pptx import Presentation

        prs = Presentation(str(p))
        parts = []
        for i, slide in enumerate(prs.slides, 1):
            texts = []
            for shape in slide.shapes:
                if shape.has_text_frame and shape.text_frame.text.strip():
                    texts.append(shape.text_frame.text.strip())
                if getattr(shape, "has_table", False) and shape.has_table:
                    texts.append(_table_md([[c.text for c in r.cells] for r in shape.table.rows]))
            notes = ""
            if slide.has_notes_slide and slide.notes_slide.notes_text_frame is not None:
                notes = slide.notes_slide.notes_text_frame.text.strip()
            parts.append(f"--- 幻灯片 {i} ---\n" + "\n".join(texts) + (f"\n[备注] {notes}" if notes else ""))
        return "\n\n".join(parts)
    return p.read_text(encoding="utf-8", errors="replace")


# ============================================================================= Markdown 块解析（docx / html / check_document 共用）

@dataclass
class Block:
    kind: str  # heading para image table equation code bullet number quote note ref pagebreak footnote_def abstract...
    text: str = ""
    level: int = 0
    rows: list[list[str]] = field(default_factory=list)
    aligns: list[str] = field(default_factory=list)
    caption: str = ""
    src: str = ""
    extra: dict[str, Any] = field(default_factory=dict)
    line: int = 0


_CJK = re.compile(r"[\u3400-\u9fff\uf900-\ufaff\u3000-\u303f\uff00-\uffef]")
FIG_CAP_RE = re.compile(r"^(?:续)?图\s*([0-9]+(?:[-–.．][0-9]+)?)(?:[\s\u3000:：.、]+(.*))?$")
TAB_CAP_RE = re.compile(r"^(?:续)?表\s*([0-9]+(?:[-–.．][0-9]+)?)(?:[\s\u3000:：.、]+(.*))?$")
NOTE_RE = re.compile(r"^(?:\*\*)?(注释?|说明|资料来源|数据来源|来源|Notes?|Sources?)(?:\*\*)?\s*[：:]")
REF_HEAD_RE = re.compile(r"^(?:[一二三四五六七八九十]+[、.．]\s*|\d+[.、\s]\s*)?(参考文献|主要参考文献|References|Bibliography)\s*$",
                         re.I)
PAGEBREAK_RE = re.compile(r"^(\\newpage|\\pagebreak|<!--\s*pagebreak\s*-->|<div[^>]*page-break-after[^>]*>\s*</div>)$",
                          re.I)
_LABELS = [
    ("abstract", r"摘\s*要|内容提要|提\s*要"),
    ("keywords", r"关键词|关键字|关\s*键\s*词"),
    ("abstract_en", r"Abstract|ABSTRACT"),
    ("keywords_en", r"Key\s*words|KEYWORDS|Key\s*Words|Keywords"),
    ("meta", r"中图分类号|文献标识码|文章编号|JEL\s*分类号|JEL\s*Classification|基金项目|作者简介"),
]


def _strip_md(s: str) -> str:
    return re.sub(r"\*\*|__|`", "", s).strip()


def parse_label(s: str) -> tuple[str, str, str] | None:
    """识别 '摘要：…' / '**关键词**：…' / '【摘要】…' / 'Abstract: …' → (kind, 原标签, 内容)。"""
    t = s.strip()
    for kind, pat in _LABELS:
        m = re.match(rf"^(?:\*\*)?[【\[]?\s*({pat})\s*(?:[】\]](?:\*\*)?\s*[：:]?|(?:\*\*)?\s*[：:](?:\*\*)?)\s*(.*)$", t)
        if m:
            return kind, m.group(1), m.group(2).strip()
    return None


def caption_match(s: str, kind: str) -> re.Match | None:
    t = _strip_md(s)
    if len(t) > 90 or "。" in t:
        return None
    return (FIG_CAP_RE if kind == "figure" else TAB_CAP_RE).match(t)


def _join_lines(lines: list[str]) -> str:
    out = ""
    for ln in lines:
        ln = ln.strip()
        if not out:
            out = ln
        elif _CJK.search(out[-1:]) or _CJK.search(ln[:1]):
            out += ln
        else:
            out += " " + ln
    return out


def _split_row(line: str) -> list[str]:
    row = line.strip()
    if row.startswith("|"):
        row = row[1:]
    if row.endswith("|") and not row.endswith("\\|"):
        row = row[:-1]
    return [c.strip().replace("\\|", "|") for c in re.split(r"(?<!\\)\|", row)]


def parse_markdown_blocks(md: str) -> list[Block]:
    lines = md.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    blocks: list[Block] = []
    buf: list[str] = []
    buf_line = 0
    in_refs = False
    refs_level = 0
    i = 0

    def prev_kind() -> str:
        return blocks[-1].kind if blocks else ""

    def flush():
        nonlocal buf
        if not buf:
            return
        text = _join_lines(buf)
        buf = []
        lab = parse_label(text)
        if in_refs:
            blocks.append(Block("ref", text, line=buf_line))
        elif lab:
            blocks.append(Block(lab[0], lab[2], extra={"label": lab[1]}, line=buf_line))
        elif NOTE_RE.match(text) and prev_kind() in ("table", "image", "note"):
            blocks.append(Block("note", text, line=buf_line))
        elif m := re.match(r"^\[\^([^\]]+)\]:\s*(.*)$", text):
            blocks.append(Block("footnote_def", m.group(2), extra={"key": m.group(1)}, line=buf_line))
        else:
            blocks.append(Block("para", text, line=buf_line))

    def next_nonblank(j: int) -> int:
        while j < len(lines) and not lines[j].strip():
            j += 1
        return j

    while i < len(lines):
        raw = lines[i]
        s = raw.strip()
        # 代码块
        if s.startswith("```") or s.startswith("~~~"):
            flush()
            fence = s[:3]
            lang = s[3:].strip().lower()
            code = []
            i += 1
            while i < len(lines) and not lines[i].strip().startswith(fence):
                code.append(lines[i])
                i += 1
            i += 1
            if lang in ("math", "latex", "tex"):
                blocks.append(_equation_block("\n".join(code), i))
            else:
                blocks.append(Block("code", "\n".join(code), extra={"lang": lang}, line=i))
            continue
        # 公式块 $$...$$ / \[...\]
        if s.startswith("$$") or s.startswith("\\["):
            flush()
            closer = "$$" if s.startswith("$$") else "\\]"
            body = s[2:]
            start = i
            if body.rstrip().endswith(closer) and len(body.strip()) >= len(closer):
                body = body.rstrip()[: -len(closer)]
                i += 1
            else:
                parts = [body]
                i += 1
                while i < len(lines) and closer not in lines[i]:
                    parts.append(lines[i])
                    i += 1
                if i < len(lines):
                    parts.append(lines[i].split(closer)[0])
                    i += 1
                body = "\n".join(parts)
            blocks.append(_equation_block(body, start + 1))
            continue
        if not s:
            flush()
            i += 1
            continue
        if s.startswith("<!--") and s.endswith("-->") and not PAGEBREAK_RE.match(s):
            flush()
            i += 1
            continue
        if PAGEBREAK_RE.match(s):
            flush()
            blocks.append(Block("pagebreak", line=i + 1))
            i += 1
            continue
        if m := re.match(r"^(#{1,6})\s+(.*?)\s*#*\s*$", s):
            flush()
            text = m.group(2).strip()
            level = len(m.group(1))
            if in_refs and level <= refs_level:
                in_refs = False
            if REF_HEAD_RE.match(_strip_md(text)):
                in_refs, refs_level = True, level
            blocks.append(Block("heading", text, level=level, line=i + 1))
            i += 1
            continue
        if m := re.match(r'^!\[(.*?)\]\(\s*<?([^)>"\s]+)>?(?:\s+"(.*?)")?\s*\)\s*(\{[^}]*\})?\s*$', s):
            flush()
            alt, src, attrs = m.group(1).strip(), m.group(2).strip(), m.group(4) or ""
            b = Block("image", src=src, caption=alt, line=i + 1)
            wm = re.search(r"width\s*=\s*([\d.]+)\s*(cm|in|%)?", attrs)
            if wm:
                b.extra["width"] = (float(wm.group(1)), wm.group(2) or "cm")
            j = next_nonblank(i + 1)
            if j < len(lines) and caption_match(lines[j], "figure") and not lines[j].strip().startswith(("|", "!")):
                cap = _strip_md(lines[j])
                if not alt or not FIG_CAP_RE.match(alt) or alt == cap:
                    b.caption = cap
                    i = j
            blocks.append(b)
            i += 1
            continue
        if s.startswith("|"):
            flush()
            rows: list[list[str]] = []
            aligns: list[str] = []
            start = i
            while i < len(lines) and lines[i].strip().startswith("|"):
                cells = _split_row(lines[i])
                if cells and all(re.fullmatch(r":?-{2,}:?", c) for c in cells if c) and any(cells):
                    aligns = ["center" if c.startswith(":") and c.endswith(":") else "right" if c.endswith(":")
                              else "left" if c.startswith(":") else "" for c in cells]
                else:
                    rows.append(cells)
                i += 1
            b = Block("table", rows=rows, aligns=aligns, line=start + 1)
            # 表题：紧邻前一段（单行）为“表N 标题”
            if blocks and blocks[-1].kind == "para" and caption_match(blocks[-1].text, "table"):
                b.caption = _strip_md(blocks.pop().text)
            blocks.append(b)
            continue
        if in_refs:
            flush()
            text = re.sub(r"^[-*+]\s+", "", s)
            blocks.append(Block("ref", text, line=i + 1))
            i += 1
            continue
        if m := re.match(r"^(\s*)[-*+]\s+(.*)", raw):
            flush()
            blocks.append(Block("bullet", m.group(2).strip(), level=len(m.group(1).expandtabs(4)) // 2, line=i + 1))
            i += 1
            continue
        if m := re.match(r"^(\s*)(\d+)[.)]\s+(.*)", raw):
            flush()
            blocks.append(Block("number", m.group(3).strip(), level=len(m.group(1)) // 2,
                                extra={"num": m.group(2), "marker": s[: len(m.group(2)) + 1]}, line=i + 1))
            i += 1
            continue
        if s.startswith(">"):
            flush()
            blocks.append(Block("quote", s.lstrip(">").strip(), line=i + 1))
            i += 1
            continue
        if re.fullmatch(r"-{3,}|\*{3,}|_{3,}", s):
            flush()
            blocks.append(Block("hr", line=i + 1))
            i += 1
            continue
        # 单行的标签段（摘要/关键词/注）不与后续行合并
        if not buf:
            buf_line = i + 1
        if (parse_label(s) or NOTE_RE.match(s) or caption_match(s, "table") or caption_match(s, "figure")) and buf:
            flush()
            buf_line = i + 1
        buf.append(s)
        if parse_label(s) or (NOTE_RE.match(s) and prev_kind() in ("table", "image", "note")):
            flush()
        i += 1
    flush()
    return blocks


def _equation_block(body: str, line: int) -> Block:
    tex = body.strip()
    tag = None
    if m := re.search(r"\\tag\*?\{([^}]*)\}", tex):
        tag = m.group(1).strip()
        tex = (tex[: m.start()] + tex[m.end():]).strip()
    return Block("equation", tex, extra={"tag": tag}, line=line)


# ============================================================================= LaTeX 数学

_GREEK = {"alpha": "α", "beta": "β", "gamma": "γ", "delta": "δ", "epsilon": "ϵ", "varepsilon": "ε", "zeta": "ζ",
          "eta": "η", "theta": "θ", "vartheta": "ϑ", "iota": "ι", "kappa": "κ", "lambda": "λ", "mu": "μ", "nu": "ν",
          "xi": "ξ", "pi": "π", "rho": "ρ", "sigma": "σ", "tau": "τ", "upsilon": "υ", "phi": "ϕ", "varphi": "φ",
          "chi": "χ", "psi": "ψ", "omega": "ω", "Gamma": "Γ", "Delta": "Δ", "Theta": "Θ", "Lambda": "Λ", "Xi": "Ξ",
          "Pi": "Π", "Sigma": "Σ", "Phi": "Φ", "Psi": "Ψ", "Omega": "Ω"}
_SYMS = {"times": "×", "cdot": "·", "leq": "≤", "le": "≤", "geq": "≥", "ge": "≥", "neq": "≠", "ne": "≠",
         "approx": "≈", "in": "∈", "sum": "∑", "prod": "∏", "pm": "±", "infty": "∞", "rightarrow": "→", "to": "→",
         "leftarrow": "←", "leftrightarrow": "↔", "Leftarrow": "⇐", "Leftrightarrow": "⇔", "propto": "∝",
         "partial": "∂", "nabla": "∇", "dots": "…", "ldots": "…", "cdots": "⋯", "ell": "ℓ", "emptyset": "∅",
         "%": "%", ",": "\u2009", ";": " ", ":": " ", "!": "",
         "quad": "\u2003", "qquad": "\u2003\u2003", " ": " ", "{": "{", "}": "}", "_": "_", "#": "#", "&": "&",
         "mid": "|", "sim": "~", "perp": "⊥", "forall": "∀", "exists": "∃", "Rightarrow": "⇒", "ast": "*",
         "lvert": "|", "rvert": "|", "vert": "|", "langle": "⟨", "rangle": "⟩", "prime": "′", "circ": "∘"}
_ACCENTS = {"hat": "\u0302", "widehat": "\u0302", "bar": "\u0304", "overline": "\u0304", "tilde": "\u0303",
            "widetilde": "\u0303", "dot": "\u0307", "vec": "\u20d7"}
_FUNCS = {"ln", "log", "exp", "max", "min", "sin", "cos", "tan", "lim", "Pr", "det", "arg", "sup", "inf"}
_UPRIGHT = {"mathrm", "text", "textrm", "operatorname", "mathbf", "textbf", "boldsymbol", "bm", "mathit", "textit"}
_SKIP = {"left", "right", "big", "Big", "bigg", "Bigg", "bigl", "bigr", "Bigl", "Bigr", "displaystyle", "limits",
         "nolimits", "textstyle"}


class _Unsupported(Exception):
    pass


def _tex_group(s: str, i: int) -> tuple[str, int]:
    while i < len(s) and s[i] == " ":
        i += 1
    if i >= len(s):
        return "", i
    if s[i] == "{":
        depth, j = 0, i
        while j < len(s):
            if s[j] == "{" and (j == 0 or s[j - 1] != "\\"):
                depth += 1
            elif s[j] == "}" and s[j - 1] != "\\":
                depth -= 1
                if depth == 0:
                    return s[i + 1: j], j + 1
            j += 1
        raise _Unsupported("unbalanced")
    if s[i] == "\\":
        m = re.match(r"\\([A-Za-z]+|.)", s[i:])
        return m.group(0), i + len(m.group(0))
    return s[i], i + 1


def tex_to_runs(s: str, vert: str | None = None, upright: bool = False, bold: bool = False) -> list[tuple[str, dict]]:
    """把简单的行内 LaTeX 转为带格式的文本片段 [(text, {italic, vert, bold})]；遇到复杂结构抛 _Unsupported。"""
    runs: list[tuple[str, dict]] = []
    i = 0

    def add(text, italic=False):
        runs.append((text, {"italic": italic and not upright, "vert": vert, "bold": bold}))

    while i < len(s):
        c = s[i]
        if c == "\\":
            m = re.match(r"\\([A-Za-z]+|.)", s[i:])
            name = m.group(1)
            i += len(m.group(0))
            if name in _GREEK:
                add(_GREEK[name], italic=name[0].islower())
            elif name in _SYMS:
                add(_SYMS[name])
            elif name in _FUNCS:
                add(name)
            elif name in _UPRIGHT:
                arg, i = _tex_group(s, i)
                is_bold = name in ("mathbf", "textbf", "boldsymbol", "bm")
                runs += tex_to_runs(arg, vert, upright=name not in ("mathit", "textit", "boldsymbol", "bm"),
                                    bold=bold or is_bold)
            elif name in _ACCENTS:
                arg, i = _tex_group(s, i)
                sub = tex_to_runs(arg, vert, upright, bold)
                if sub:
                    sub[-1] = (sub[-1][0] + _ACCENTS[name], sub[-1][1])
                    runs += sub
            elif name in _SKIP:
                continue
            else:
                raise _Unsupported(name)
        elif c in "_^":
            arg, i = _tex_group(s, i + 1)
            runs += tex_to_runs(arg, "subscript" if c == "_" else "superscript", upright, bold)
        elif c == "{":
            arg, i = _tex_group(s, i)
            runs += tex_to_runs(arg, vert, upright, bold)
        elif c == "}":
            i += 1
        elif c.isalpha() and c.isascii():
            add(c, italic=True)
            i += 1
        elif c == " ":
            i += 1
        elif c in "+=<>" and vert is None:
            add(f" {c} ")
            i += 1
        elif c == "-":
            add(" − " if vert is None and runs else "−")
            i += 1
        elif c == "'":
            add("′")
            i += 1
        else:
            add(c)
            i += 1
    return runs


def _merge_runs(runs):
    out: list[tuple[str, dict]] = []
    for t, f in runs:
        if out and out[-1][1] == f:
            out[-1] = (out[-1][0] + t, f)
        else:
            out.append((t, f))
    return out


def _prep_tex_lines(tex: str) -> list[str]:
    t = tex
    t = re.sub(r"\\(begin|end)\{[^}]*\}(\{[^}]*\})?", "", t)
    t = re.sub(r"\\label\{[^}]*\}|\\nonumber|\\notag", "", t)
    t = re.sub(r"\\(text|textrm|operatorname\*?|mathop|textnormal)\s*\{", r"\\mathrm{", t)
    t = re.sub(r"\\(textbf|boldsymbol|bm)\s*\{", r"\\mathbf{", t)
    t = re.sub(r"\\textit\s*\{", r"\\mathit{", t)
    t = re.sub(r"\\[dt]frac", r"\\frac", t)
    t = re.sub(r"\\(bigg|Bigg|big|Big)[lr]?(?![A-Za-z])", "", t)
    t = re.sub(r"\\(displaystyle|textstyle|limits|nolimits)(?![A-Za-z])", "", t)
    t = t.replace("&", "")

    def fix_rm(m):
        return "\\mathrm{" + m.group(1).replace(" ", "\\ ") + "}"

    t = re.sub(r"\\mathrm\{([^{}]*)\}", fix_rm, t)
    lines = [ln.strip() for ln in re.split(r"\\\\", t) if ln.strip()]
    return [" ".join(ln.split()) for ln in lines] or [t.strip()]


_CJK_FONT_CACHE: list[str | None] = []


def _cjk_font_name(kind: str = "serif") -> str | None:
    try:
        from matplotlib import font_manager
    except Exception:  # noqa: BLE001
        return None
    names = {f.name for f in font_manager.fontManager.ttflist}
    cands = (["Songti SC", "STSong", "SimSun", "Noto Serif CJK SC", "Source Han Serif SC", "AR PL UMing CN"]
             if kind == "serif" else [])
    cands += ["PingFang SC", "Heiti SC", "STHeiti", "SimHei", "Microsoft YaHei", "Noto Sans CJK SC",
              "Source Han Sans SC", "WenQuanYi Micro Hei", "Arial Unicode MS"]
    return next((c for c in cands if c in names), None)


def render_math_png(tex: str, path: Path, fontsize: float = 12.0, dpi: int = 300) -> tuple[float, float] | None:
    """用 matplotlib mathtext 渲染公式为 PNG，返回 (宽, 高) 英寸；不支持时返回 None。"""
    try:
        import matplotlib
        from matplotlib.backends.backend_agg import FigureCanvasAgg
        from matplotlib.figure import Figure
        from PIL import Image
    except Exception:  # noqa: BLE001
        return None
    lines = _prep_tex_lines(tex)
    rc = {"mathtext.fontset": "stix", "font.family": "STIXGeneral", "font.size": fontsize}
    if _CJK.search(tex):
        cjk = _cjk_font_name("serif")
        if cjk:
            rc.update({"mathtext.fontset": "custom", "mathtext.rm": cjk, "mathtext.it": "STIXGeneral:italic",
                       "mathtext.bf": "STIXGeneral:bold", "mathtext.sf": cjk, "mathtext.fallback": "stix"})
    try:
        with matplotlib.rc_context(rc):
            fig = Figure(figsize=(1, 1))
            FigureCanvasAgg(fig)
            fig.text(0.5, 0.5, "\n".join(f"${ln}$" for ln in lines), ha="center", va="center", fontsize=fontsize,
                     multialignment="center", linespacing=1.9)
            fig.savefig(str(path), dpi=dpi, bbox_inches="tight", pad_inches=0.02, facecolor="white")
        with Image.open(path) as im:
            w, h = im.size
        return w / dpi, h / dpi
    except Exception:  # noqa: BLE001
        try:
            path.unlink()
        except OSError:
            pass
        return None


def _looks_like_math(s: str) -> bool:
    if _CJK.search(s) or not s.strip():
        return False
    if re.fullmatch(r"[\d.,\s]+", s):
        return False
    return bool(re.search(r"[\\_^=+<>]", s)) or bool(re.fullmatch(r"[A-Za-z][A-Za-z0-9]{0,8}", s.strip()))


# ============================================================================= 字体与 OOXML 小工具

# PDF 转换时的中文字体替换候选（LibreOffice 在 macOS 上按本地化族名识别系统字体，如 “宋体-简”）
_EAST_FALLBACK = {
    "宋体": ["SimSun", "宋体-简", "华文宋体", "Noto Serif CJK SC", "Source Han Serif SC", "Noto Serif SC",
           "AR PL UMing CN", "Songti SC", "STSong"],
    "黑体": ["SimHei", "黑体-简", "华文黑体", "Noto Sans CJK SC", "Source Han Sans SC", "Noto Sans SC",
           "WenQuanYi Zen Hei", "WenQuanYi Micro Hei", "苹方-简", "Heiti SC", "STHeiti", "PingFang SC"],
    "楷体": ["KaiTi", "楷体-简", "华文楷体", "AR PL UKai CN", "Kaiti SC", "STKaiti"],
    "仿宋": ["FangSong", "华文仿宋", "STFangsong", "Noto Serif CJK SC", "宋体-简"],
    "微软雅黑": ["Microsoft YaHei", "苹方-简", "冬青黑体简体中文", "Noto Sans CJK SC", "Source Han Sans SC",
             "WenQuanYi Micro Hei", "黑体-简", "PingFang SC", "Hiragino Sans GB"],
}
_EAST_FALLBACK["仿宋_GB2312"] = ["仿宋", "FangSong_GB2312"] + _EAST_FALLBACK["仿宋"]
_EAST_FALLBACK["楷体_GB2312"] = ["楷体", "KaiTi_GB2312"] + _EAST_FALLBACK["楷体"]
_EAST_FALLBACK["方正小标宋简体"] = ["FZXiaoBiaoSong-B05S", "宋体", "SimSun", "宋体-简", "华文宋体", "Noto Serif CJK SC"]


@functools.lru_cache(maxsize=1)
def _installed_fonts() -> frozenset[str]:
    names: set[str] = set()
    try:
        from matplotlib import font_manager

        names |= {f.name for f in font_manager.fontManager.ttflist}
    except Exception:  # noqa: BLE001
        pass
    if shutil.which("fc-list"):
        try:
            out = subprocess.run(["fc-list", ":", "family"], capture_output=True, text=True, timeout=20).stdout
            for line in out.splitlines():
                names |= {x.strip().replace("\\-", "-") for x in line.split(",") if x.strip()}
        except Exception:  # noqa: BLE001
            pass
    # macOS/Windows 系统字体集合在 matplotlib 中常暴露英文族名，补充中英文族名双向映射
    for en_name, zh_name in (
        ("Kaiti SC", "楷体-简"), ("STKaiti", "华文楷体"), ("STFangsong", "华文仿宋"),
        ("Songti SC", "宋体-简"), ("Heiti SC", "黑体-简"), ("PingFang SC", "苹方-简"),
        ("SimSun", "宋体"), ("SimHei", "黑体"), ("Microsoft YaHei", "微软雅黑"),
        ("KaiTi", "楷体"), ("FangSong", "仿宋"), ("NSimSun", "新宋体"),
    ):
        if en_name in names:
            names.add(zh_name)
        elif zh_name in names:
            names.add(en_name)
    return frozenset(names)


def _ln(el) -> str:
    return el.tag.split("}")[-1]


def _insert_ordered(parent, child, order: list[str]):
    name = _ln(child)
    for ex in list(parent):
        if _ln(ex) == name:
            parent.remove(ex)
    idx = order.index(name)
    for ex in parent:
        n = _ln(ex)
        if n in order and order.index(n) > idx:
            ex.addprevious(child)
            return child
    parent.append(child)
    return child


_TBLPR_ORDER = ["tblStyle", "tblpPr", "tblOverlap", "bidiVisual", "tblStyleRowBandSize", "tblStyleColBandSize", "tblW",
                "jc", "tblCellSpacing", "tblInd", "tblBorders", "shd", "tblLayout", "tblCellMar", "tblLook",
                "tblCaption", "tblDescription"]
_TCPR_ORDER = ["cnfStyle", "tcW", "gridSpan", "hMerge", "vMerge", "tcBorders", "shd", "noWrap", "tcMar",
               "textDirection", "tcFitText", "vAlign", "hideMark"]
_PPR_ORDER = ["pStyle", "keepNext", "keepLines", "pageBreakBefore", "framePr", "widowControl", "numPr",
              "suppressLineNumbers", "pBdr", "shd", "tabs", "suppressAutoHyphens", "kinsoku", "wordWrap",
              "overflowPunct", "topLinePunct", "autoSpaceDE", "autoSpaceDN", "bidi", "adjustRightInd", "snapToGrid",
              "spacing", "ind", "contextualSpacing", "mirrorIndents", "suppressOverlap", "jc", "textDirection",
              "textAlignment", "textboxTightWrap", "outlineLvl", "divId", "cnfStyle", "rPr", "sectPr", "pPrChange"]
_TRPR_ORDER = ["cnfStyle", "divId", "gridBefore", "gridAfter", "wBefore", "wAfter", "cantSplit", "trHeight",
               "tblHeader", "tblCellSpacing", "jc", "hidden"]


def _el(tag: str, **attrs):
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn

    e = OxmlElement(tag)
    for k, v in attrs.items():
        e.set(qn(f"w:{k}"), str(v))
    return e


def _set_fonts(rpr, east: str | None = None, latin: str | None = None):
    from docx.oxml.ns import qn

    rfonts = rpr.get_or_add_rFonts()
    for a in ("w:asciiTheme", "w:hAnsiTheme", "w:eastAsiaTheme", "w:cstheme"):
        rfonts.attrib.pop(qn(a), None)
    if latin:
        for a in ("w:ascii", "w:hAnsi", "w:cs"):
            rfonts.set(qn(a), latin)
    if east:
        rfonts.set(qn("w:eastAsia"), east)


def _set_color(font, hex_color: str):
    from docx.oxml.ns import qn
    from docx.shared import RGBColor

    font.color.rgb = RGBColor.from_string(hex_color)
    try:
        c = font._element.rPr.find(qn("w:color"))  # noqa: SLF001
    except AttributeError:
        c = None
    if c is not None:
        for a in ("w:themeColor", "w:themeShade", "w:themeTint"):
            c.attrib.pop(qn(a), None)


def _style_font(style, east, latin, size=None, bold=None, italic=None, color=None):
    from docx.shared import Pt

    f = style.font
    if latin:
        f.name = latin
    if size:
        f.size = Pt(size)
    if bold is not None:
        f.bold = bold
    if italic is not None:
        f.italic = italic
    _set_fonts(style.element.get_or_add_rPr(), east, latin)
    if color:
        _set_color(f, color)


def _run_font(run, east=None, latin=None, size=None, bold=None, italic=None, color=None):
    from docx.shared import Pt

    if size:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if italic is not None:
        run.italic = italic
    if east or latin:
        _set_fonts(run._r.get_or_add_rPr(), east, latin)  # noqa: SLF001
    if color:
        _set_color(run.font, color)


def _add_field(paragraph, instr: str, placeholder: str = ""):
    from docx.oxml.ns import qn

    def r_with(el):
        r = paragraph.add_run()
        r._r.append(el)  # noqa: SLF001
        return r

    r_with(_el("w:fldChar", fldCharType="begin"))
    instr_el = _el("w:instrText")
    instr_el.set(qn("xml:space"), "preserve")
    instr_el.text = f" {instr} "
    r_with(instr_el)
    r_with(_el("w:fldChar", fldCharType="separate"))
    paragraph.add_run(placeholder)
    r_with(_el("w:fldChar", fldCharType="end"))


def _shade(tc, fill: str):
    tcpr = tc.get_or_add_tcPr()
    _insert_ordered(tcpr, _el("w:shd", val="clear", color="auto", fill=fill), _TCPR_ORDER)


def _cell_borders(tc, **edges):
    """edges: top=('single', 12, '000000') / bottom=('nil',)"""
    tcpr = tc.get_or_add_tcPr()
    b = _el("w:tcBorders")
    for edge in ("top", "left", "bottom", "right"):
        if edge in edges:
            spec = edges[edge]
            e = _el(f"w:{edge}", val=spec[0])
            if spec[0] not in ("nil", "none"):
                e.set(_q("w:sz"), str(spec[1]))
                e.set(_q("w:space"), "0")
                e.set(_q("w:color"), spec[2] if len(spec) > 2 else "000000")
            b.append(e)
    _insert_ordered(tcpr, b, _TCPR_ORDER)


def _q(tag):
    from docx.oxml.ns import qn

    return qn(tag)


def _table_borders(tbl, spec: dict[str, tuple]):
    tblpr = tbl.tblPr
    b = _el("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        s = spec.get(edge, ("nil",))
        e = _el(f"w:{edge}", val=s[0])
        if s[0] not in ("nil", "none"):
            e.set(_q("w:sz"), str(s[1]))
            e.set(_q("w:space"), "0")
            e.set(_q("w:color"), s[2] if len(s) > 2 else "000000")
        b.append(e)
    _insert_ordered(tblpr, b, _TBLPR_ORDER)


def _disp_len(s: str) -> int:
    return sum(2 if _CJK.match(ch) else 1 for ch in s)


_NUM_CELL = re.compile(r"^[\s(（\[]*[-−+]?[\d,]*\.?\d+(?:[eE][-+]?\d+)?\s*%?\s*[)）\]]?\s*\**\s*$|^[-—–]{1,2}$")


# ============================================================================= Markdown -> DOCX

class _DocxBuilder:
    def __init__(self, style: str, base_dir: Path, title: str | None, opts: dict[str, Any]):
        import docx

        if style not in STYLES:
            raise ToolError(f"未知 style: {style}（可选 {', '.join(STYLES)}）")
        self.style = style
        self.base_dir = base_dir
        self.title = title
        self.opts = opts
        self.d = docx.Document()
        self.tmp = Path(tempfile.mkdtemp(prefix="omni_doc_"))
        self.fig_no = 0
        self.tab_no = 0
        self.eq_no = 0
        self.ref_no = 0
        self.footnotes: dict[str, str] = {}
        self.fn_order: list[str] = []
        self.warnings: list[str] = []
        self.stats = {"figures": 0, "tables": 0, "equations": 0, "references": 0, "missing_images": 0}
        self.pending_label: str | None = None
        self.last_kind = ""
        self.text_width_cm = 14.66

    # ------------------------------------------------------------------ 样式
    def _ensure_style(self, name: str, base: str = "Normal"):
        from docx.enum.style import WD_STYLE_TYPE

        try:
            return self.d.styles[name]
        except KeyError:
            st = self.d.styles.add_style(name, WD_STYLE_TYPE.PARAGRAPH)
            st.base_style = self.d.styles[base]
            st.quick_style = True
            return st

    def _setup(self):
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.oxml.ns import qn
        from docx.shared import Cm, Pt

        d = self.d
        sec = d.sections[0]
        sec.page_width, sec.page_height = Cm(21), Cm(29.7)
        if self.style == "academic":
            sec.top_margin = sec.bottom_margin = Cm(2.54)
            sec.left_margin = sec.right_margin = Cm(3.17)
        else:
            sec.top_margin = sec.bottom_margin = Cm(2.3)
            sec.left_margin = sec.right_margin = Cm(2.5)
        sec.header_distance, sec.footer_distance = Cm(1.5), Cm(1.5)
        self.text_width_cm = 21 - (sec.left_margin.cm + sec.right_margin.cm)
        # docDefaults 去掉主题字体
        try:
            rpr_default = d.styles.element.find(qn("w:docDefaults")).find(qn("w:rPrDefault")).find(qn("w:rPr"))
            _set_fonts(rpr_default, None, None)
        except AttributeError:
            pass

        st = self.style
        if st == "plain":
            normal = d.styles["Normal"]
            _style_font(normal, "微软雅黑", "Calibri", 11)
            for s in ["Title", "Heading 1", "Heading 2", "Heading 3", "Heading 4"]:
                try:
                    _set_fonts(d.styles[s].element.get_or_add_rPr(), "微软雅黑", None)
                except KeyError:
                    pass
            self.body_east, self.body_latin, self.body_size = "微软雅黑", "Calibri", 11
            self._ensure_style("Caption")
            return

        academic = st == "academic"
        self.body_east, self.body_latin = ("宋体", "Times New Roman") if academic else ("微软雅黑", "Calibri")
        self.body_size = 12 if academic else 10.5
        normal = d.styles["Normal"]
        _style_font(normal, self.body_east, self.body_latin, self.body_size)
        pf = normal.paragraph_format
        pf.space_before, pf.space_after = Pt(0), Pt(0 if academic else 6)
        pf.line_spacing = 1.5 if academic else 1.35
        pf.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        pf.widow_control = True
        if academic:
            pf.first_line_indent = Pt(24)
            ind = normal.element.get_or_add_pPr().find(qn("w:ind"))
            if ind is not None:
                ind.set(qn("w:firstLineChars"), "200")
        lang = _el("w:lang", val="en-US", eastAsia="zh-CN")
        normal.element.get_or_add_rPr().append(lang)

        def heading(name, east, latin, size, bold, color, align=WD_ALIGN_PARAGRAPH.LEFT, before=12, after=6,
                    indent=0, border=None):
            s = d.styles[name]
            _style_font(s, east, latin, size, bold=bold, italic=False, color=color)
            p = s.paragraph_format
            p.alignment = align
            p.space_before, p.space_after = Pt(before), Pt(after)
            p.first_line_indent = Pt(indent)
            p.left_indent = Pt(0)
            p.keep_with_next = True
            p.line_spacing = (1.25 if name == "Title" else 1.5) if academic else 1.2
            ppr = s.element.get_or_add_pPr()
            ind = ppr.find(qn("w:ind"))
            if ind is not None:
                ind.set(qn("w:firstLineChars"), str(int(indent / 12 * 100)) if academic else "0")
            old = ppr.find(qn("w:pBdr"))
            if old is not None:
                ppr.remove(old)
            if border:
                bd = _el("w:pBdr")
                bd.append(_el("w:bottom", val="single", sz=border[0], space="4", color=border[1]))
                _insert_ordered(ppr, bd, _PPR_ORDER)
            return s

        if academic:
            heading("Title", "黑体", "Times New Roman", 18, False, "000000", WD_ALIGN_PARAGRAPH.CENTER, 12, 12)
            heading("Heading 1", "黑体", "Times New Roman", 14, False, "000000", before=12, after=6)
            heading("Heading 2", "楷体", "Times New Roman", 12, True, "000000", before=6, after=3, indent=24)
            heading("Heading 3", "宋体", "Times New Roman", 12, True, "000000", before=3, after=0, indent=24)
            heading("Heading 4", "宋体", "Times New Roman", 12, False, "000000", before=0, after=0, indent=24)
        else:
            heading("Title", "微软雅黑", "Calibri", 24, True, "1F3864", WD_ALIGN_PARAGRAPH.CENTER, 24, 6)
            heading("Heading 1", "微软雅黑", "Calibri", 16, True, "1F4E79", before=18, after=8, border=(8, "1F4E79"))
            heading("Heading 2", "微软雅黑", "Calibri", 13, True, "2E75B6", before=12, after=6)
            heading("Heading 3", "微软雅黑", "Calibri", 11.5, True, "404040", before=8, after=4)
            heading("Heading 4", "微软雅黑", "Calibri", 10.5, True, "404040", before=6, after=3)

        def para_style(name, east, latin, size, align=WD_ALIGN_PARAGRAPH.JUSTIFY, line=1.0, before=0, after=0,
                       first=0, left=0, right=0, bold=None, italic=None, color=None):
            s = self._ensure_style(name)
            _style_font(s, east, latin, size, bold=bold, italic=italic, color=color)
            p = s.paragraph_format
            p.alignment = align
            p.line_spacing = line
            p.space_before, p.space_after = Pt(before), Pt(after)
            p.first_line_indent = Pt(first)
            p.left_indent, p.right_indent = Pt(left), Pt(right)
            ind = s.element.get_or_add_pPr().find(qn("w:ind"))
            if ind is not None:
                ind.set(qn("w:firstLineChars"), "0")
            return s

        C = WD_ALIGN_PARAGRAPH.CENTER
        if academic:
            para_style("Caption", "黑体", "Times New Roman", 10.5, C, 1.25, 3, 6, bold=False, italic=False,
                       color="000000")
            para_style("OA Figure", None, None, 10.5, C, 1.0, 6, 0)
            para_style("OA Note", "宋体", "Times New Roman", 9, line=1.25, before=0, after=6)
            para_style("OA Table", "宋体", "Times New Roman", 10.5, C, 1.0)
            para_style("OA Equation", None, None, 12, WD_ALIGN_PARAGRAPH.LEFT, 1.0, 6, 6)
            para_style("OA Reference", "宋体", "Times New Roman", 10.5, line=1.3, first=-21, left=21)
            para_style("OA Abstract", "楷体", "Times New Roman", 10.5, line=1.5, left=21, right=21, after=0)
            para_style("OA Author", "楷体", "Times New Roman", 12, C, 1.5, 0, 0)
            para_style("OA Affiliation", "宋体", "Times New Roman", 9, C, 1.3, 0, 12)
            para_style("OA Code", None, "Consolas", 9, WD_ALIGN_PARAGRAPH.LEFT, 1.0, 3, 3)
            para_style("OA List", self.body_east, self.body_latin, 12, line=1.5, first=0, left=24)
            para_style("OA Quote", "楷体", "Times New Roman", 12, line=1.5, first=24, left=24, right=24)
        else:
            para_style("Caption", "微软雅黑", "Calibri", 9.5, C, 1.2, 3, 8, bold=True, italic=False, color="404040")
            para_style("OA Figure", None, None, 10.5, C, 1.0, 6, 0)
            para_style("OA Note", "微软雅黑", "Calibri", 8.5, line=1.2, before=0, after=8, color="595959")
            para_style("OA Table", "微软雅黑", "Calibri", 9.5, WD_ALIGN_PARAGRAPH.LEFT, 1.1)
            para_style("OA Equation", None, None, 10.5, WD_ALIGN_PARAGRAPH.LEFT, 1.0, 6, 6)
            para_style("OA Reference", "微软雅黑", "Calibri", 9.5, line=1.25, first=-21, left=21, after=3)
            para_style("OA Abstract", "微软雅黑", "Calibri", 10.5, line=1.4, left=8, right=8, before=4, after=4)
            para_style("OA Author", "微软雅黑", "Calibri", 11, C, 1.3, 0, 2, color="595959")
            para_style("OA Affiliation", "微软雅黑", "Calibri", 10, C, 1.3, 0, 18, color="7F7F7F")
            para_style("OA Code", None, "Consolas", 9, WD_ALIGN_PARAGRAPH.LEFT, 1.0, 3, 3)
            para_style("OA List", self.body_east, self.body_latin, 10.5, line=1.35, first=0, left=18, after=3)
            para_style("OA Quote", "微软雅黑", "Calibri", 10.5, line=1.4, left=12, right=12, before=4, after=8,
                       color="1F3864")

    # ------------------------------------------------------------------ 行内
    _INLINE = re.compile(
        r"((?<!\*)\*\*(?![*\s])(?=[^*\n]*[\w\u3400-\u9fff])[^*\n]+?(?<![*\s])\*\*(?!\*)"
        r"|(?<!_)__(?![_\s])(?=[^_\n]*[\w\u3400-\u9fff])[^_\n]+?(?<![_\s])__(?!_)"
        r"|(?<![\w*\\])\*(?![\s*])(?=[^*\n]*[\w\u3400-\u9fff])[^*\n]+?(?<![\s*])\*(?![\w*])"
        r"|`[^`]+`"
        r"|\$(?![\s$])[^$\n]+?(?<![\s\\])\$|\[\^[^\]]+\]|<sup>.*?</sup>|<sub>.*?</sub>"
        r"|\[[^\]\n]+\]\((?:https?://|mailto:)[^)\s]+\)|<br\s*/?>)"
    )

    def inline(self, paragraph, text: str, *, bold: bool | None = None, italic: bool | None = None,
               size: float | None = None, color: str | None = None):
        from docx.enum.text import WD_BREAK

        text = text.replace("\\$", "\x00")
        for tok in self._INLINE.split(text):
            if not tok:
                continue
            tok_r = tok.replace("\x00", "$")
            run = None
            if tok.startswith("**") and tok.endswith("**") and len(tok) > 4 or \
                    tok.startswith("__") and tok.endswith("__") and len(tok) > 4:
                self.inline(paragraph, tok[2:-2], bold=True, italic=italic, size=size, color=color)
                continue
            if tok.startswith("`") and tok.endswith("`") and len(tok) > 2:
                run = paragraph.add_run(tok_r[1:-1])
                _run_font(run, latin="Consolas", color=None if self.style == "academic" else "C7254E")
            elif tok.startswith("*") and tok.endswith("*") and len(tok) > 2:
                self.inline(paragraph, tok[1:-1], bold=bold, italic=True, size=size, color=color)
                continue
            elif tok.startswith("$") and tok.endswith("$") and len(tok) > 2 and _looks_like_math(tok[1:-1]):
                self.inline_math(paragraph, tok[1:-1].replace("\x00", "\\$"), size=size)
                continue
            elif tok.startswith("[^") and tok.endswith("]"):
                key = tok[2:-1]
                if key not in self.fn_order:
                    self.fn_order.append(key)
                run = paragraph.add_run(f"[{self.fn_order.index(key) + 1}]")
                run.font.superscript = True
            elif tok.startswith("<sup>"):
                run = paragraph.add_run(re.sub(r"</?sup>", "", tok_r))
                run.font.superscript = True
            elif tok.startswith("<sub>"):
                run = paragraph.add_run(re.sub(r"</?sub>", "", tok_r))
                run.font.subscript = True
            elif re.match(r"<br\s*/?>", tok):
                paragraph.add_run().add_break(WD_BREAK.LINE)
                continue
            elif m := re.match(r"\[([^\]]+)\]\(([^)]+)\)", tok):
                run = paragraph.add_run(m.group(1))
                if self.style != "academic":
                    _run_font(run, color="2E75B6")
                    run.underline = True
            else:
                run = paragraph.add_run(tok_r)
            if bold:
                run.bold = True
            if italic:
                run.italic = True
            if size:
                _run_font(run, size=size)
            if color:
                _run_font(run, color=color)

    def inline_math(self, paragraph, tex: str, size: float | None = None):
        from docx.shared import Inches

        try:
            runs = _merge_runs(tex_to_runs(tex))
            for t, f in runs:
                r = paragraph.add_run(t)
                _run_font(r, latin="Times New Roman", size=size)
                if f.get("italic"):
                    r.italic = True
                if f.get("bold"):
                    r.bold = True
                if f.get("vert") == "subscript":
                    r.font.subscript = True
                elif f.get("vert") == "superscript":
                    r.font.superscript = True
            return
        except _Unsupported:
            pass
        png = self.tmp / f"im_{hashlib.md5(tex.encode()).hexdigest()[:12]}.png"
        dims = render_math_png(tex, png, fontsize=size or self.body_size)
        if dims:
            paragraph.add_run().add_picture(str(png), width=Inches(dims[0]))
        else:
            r = paragraph.add_run(tex)
            r.italic = True

    # ------------------------------------------------------------------ 块
    def _resolve(self, src: str) -> Path:
        p = Path(src).expanduser()
        return p if p.is_absolute() else (self.base_dir / p)

    def para(self, text, style=None, align=None, first_indent=None):
        p = self.d.add_paragraph(style=style)
        if align is not None:
            p.alignment = align
        if first_indent is not None:
            from docx.shared import Pt

            p.paragraph_format.first_line_indent = Pt(first_indent)
        self.inline(p, text)
        return p

    def title_block(self, title: str):
        from docx.enum.text import WD_ALIGN_PARAGRAPH

        p = self.d.add_paragraph(style="Title")
        self.inline(p, _strip_md(title) if self.style != "plain" else title)
        if self.style == "plain":
            return
        author, aff = self.opts.get("author"), self.opts.get("affiliation")
        date = self.opts.get("date")
        if author:
            self.para(author, "OA Author", WD_ALIGN_PARAGRAPH.CENTER)
        if aff or (self.style == "report" and date):
            line = aff or ""
            if self.style == "report" and date:
                line = f"{line}　{date}".strip()
            self.para(line, "OA Affiliation", WD_ALIGN_PARAGRAPH.CENTER)
        elif author:
            from docx.shared import Pt

            self.d.paragraphs[-1].paragraph_format.space_after = Pt(12)

    def heading(self, text: str, level: int):
        h = self.d.add_heading(level=max(1, min(level, 4)))
        self.inline(h, text if self.style == "plain" else _strip_md(text))
        if self.style == "academic" and REF_HEAD_RE.match(_strip_md(text)):
            from docx.enum.text import WD_ALIGN_PARAGRAPH

            h.alignment = WD_ALIGN_PARAGRAPH.LEFT

    def labeled(self, kind: str, label: str, text: str):
        """摘要 / 关键词 / Abstract / Keywords / 分类号等。"""
        from docx.shared import Pt

        if self.style == "plain":
            p = self.d.add_paragraph()
            r = p.add_run(f"{label}：")
            r.bold = True
            self.inline(p, text)
            return
        p = self.d.add_paragraph(style="OA Abstract")
        en = kind.endswith("_en")
        disp = {"abstract": "摘　要：", "keywords": "关键词："}.get(kind, f"{label}：")
        if en:
            disp = "Abstract: " if kind == "abstract_en" else "Key words: "
        r = p.add_run(disp)
        if self.style == "academic":
            _run_font(r, east="黑体", latin="Times New Roman", bold=True)
        else:
            _run_font(r, bold=True, color="1F4E79")
        if en and self.style == "academic":
            q = len(p.runs)
            self.inline(p, text)
            for rr in p.runs[q:]:
                _run_font(rr, latin="Times New Roman")
        else:
            self.inline(p, text)
        if self.style == "report":
            ppr = p._p.get_or_add_pPr()  # noqa: SLF001
            _insert_ordered(ppr, _el("w:shd", val="clear", color="auto", fill="EEF3FA"), _PPR_ORDER)
        if kind in ("keywords", "keywords_en", "meta"):
            p.paragraph_format.space_after = Pt(6 if kind != "meta" else 0)

    def image(self, b: Block):
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.shared import Cm

        img = self._resolve(b.src)
        cap = b.caption.strip()
        if self.style != "plain" and cap:
            m = FIG_CAP_RE.match(_strip_md(cap))
            if m:
                try:
                    self.fig_no = int(re.split(r"[-–.．]", m.group(1))[0]) if "-" not in m.group(1) else self.fig_no + 1
                except ValueError:
                    self.fig_no += 1
            else:
                self.fig_no += 1
                cap = f"图{self.fig_no}　{cap}"
        if b.src.startswith(("http://", "https://")) or not img.exists():
            self.stats["missing_images"] += 1
            self.warnings.append(f"图片缺失: {b.src}")
            p = self.d.add_paragraph(f"[图片缺失: {b.src}]", style="OA Figure" if self.style != "plain" else None)
            if self.style != "plain":
                _run_font(p.runs[0], color="C00000")
        else:
            maxw = {"academic": 14.0, "report": 15.5, "plain": 15.24}[self.style]
            maxw = min(maxw, self.text_width_cm)
            width_cm = maxw
            try:
                from PIL import Image

                with Image.open(img) as im:
                    px_w, px_h = im.size
                    dpi = (im.info.get("dpi") or (96, 96))[0] or 96
                natural = px_w / float(dpi) * 2.54
                width_cm = min(maxw, natural)
                if self.style == "academic" and px_h / max(px_w, 1) > 0.9:
                    width_cm = min(width_cm, 11.0)  # 竖长图不过宽
            except Exception:  # noqa: BLE001
                pass
            if "width" in b.extra:
                val, unit = b.extra["width"]
                width_cm = {"cm": val, "in": val * 2.54, "%": self.text_width_cm * val / 100}[unit]
                width_cm = min(width_cm, self.text_width_cm)
            if self.style == "plain":
                self.d.add_picture(str(img), width=Cm(width_cm))
                p = self.d.paragraphs[-1]
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            else:
                p = self.d.add_paragraph(style="OA Figure")
                p.add_run().add_picture(str(img), width=Cm(width_cm))
            p.paragraph_format.keep_with_next = bool(cap)
            self.stats["figures"] += 1
        if cap:
            if self.style == "plain":
                c = self.d.add_paragraph(cap)
                c.alignment = WD_ALIGN_PARAGRAPH.CENTER
                c.runs[0].italic = True
            else:
                c = self.d.add_paragraph(style="Caption")
                self.inline(c, _strip_md(cap))

    def table(self, b: Block):
        from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.shared import Cm, Pt

        rows = b.rows
        if not rows:
            return
        width = max(len(r) for r in rows)
        rows = [r + [""] * (width - len(r)) for r in rows]
        if b.caption and self.style != "plain":
            c = self.d.add_paragraph(style="Caption")
            c.paragraph_format.space_before = Pt(6)
            c.paragraph_format.space_after = Pt(3)
            c.paragraph_format.keep_with_next = True
            self.inline(c, b.caption)
        elif b.caption:
            c = self.d.add_paragraph()
            c.alignment = WD_ALIGN_PARAGRAPH.CENTER
            r = c.add_run(b.caption)
            r.bold = True
        self.stats["tables"] += 1
        t = self.d.add_table(rows=len(rows), cols=width)
        if self.style == "plain":
            t.style = "Table Grid"
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        # 列宽
        cw = 0.19 if self.style == "academic" else 0.18
        lens = [max(4, min(36, max(_disp_len(_strip_md(r[ci])) for r in rows))) for ci in range(width)]
        widths = [n * cw + 0.45 for n in lens]
        tw = self.text_width_cm
        total = sum(widths)
        target = min(max(total, tw * (0.6 if width > 2 else 0.45)), tw)
        widths = [w * target / total for w in widths]
        small = width >= 8 or (self.style == "academic" and total > tw * 1.25)
        aligns = b.aligns + [""] * (width - len(b.aligns))
        for ri, r in enumerate(rows):
            row = t.rows[ri]
            trpr = row._tr.get_or_add_trPr()  # noqa: SLF001
            _insert_ordered(trpr, _el("w:cantSplit"), _TRPR_ORDER)
            if ri == 0:
                _insert_ordered(trpr, _el("w:tblHeader"), _TRPR_ORDER)
            for ci in range(width):
                cell = t.cell(ri, ci)
                cell.width = Cm(widths[ci])
                cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
                txt = r[ci]
                p = cell.paragraphs[0]
                if self.style != "plain":
                    p.style = self.d.styles["OA Table"]
                if ri > 0 and ri + 1 < len(rows) and width > 1 and _strip_md(rows[ri][0]) and not _strip_md(rows[ri + 1][0]):
                    p.paragraph_format.keep_with_next = True
                is_num = bool(_NUM_CELL.match(_strip_md(txt))) if txt else False
                if self.style == "academic":
                    al = WD_ALIGN_PARAGRAPH.CENTER
                    if ci == 0 and ri > 0 and not is_num and width > 1:
                        al = WD_ALIGN_PARAGRAPH.LEFT
                elif self.style == "report":
                    al = WD_ALIGN_PARAGRAPH.CENTER if ri == 0 else (
                        WD_ALIGN_PARAGRAPH.RIGHT if is_num else WD_ALIGN_PARAGRAPH.LEFT)
                else:
                    al = None
                a = aligns[ci]
                if a and ri > 0 and self.style != "academic":
                    al = {"center": WD_ALIGN_PARAGRAPH.CENTER, "right": WD_ALIGN_PARAGRAPH.RIGHT,
                          "left": WD_ALIGN_PARAGRAPH.LEFT}[a]
                if al is not None:
                    p.alignment = al
                self.inline(p, txt, bold=True if (ri == 0 and self.style != "academic") else None,
                            size=9 if small else None, color="FFFFFF" if (ri == 0 and self.style == "report") else None)
                if self.style == "report":
                    if ri == 0:
                        _shade(cell._tc, "1F4E79")  # noqa: SLF001
                    elif ri % 2 == 0:
                        _shade(cell._tc, "F2F6FA")  # noqa: SLF001
        if self.style == "academic":
            t.autofit = False
            _table_borders(t._tbl, {"top": ("single", 12), "bottom": ("single", 12)})  # noqa: SLF001
            for cell in t.rows[0].cells:
                _cell_borders(cell._tc, bottom=("single", 6, "000000"))  # noqa: SLF001
        elif self.style == "report":
            t.autofit = False
            g = ("single", 4, "BFBFBF")
            _table_borders(t._tbl, {"top": ("single", 8, "1F4E79"), "bottom": ("single", 8, "1F4E79"),  # noqa: SLF001
                                    "insideH": g, "left": ("nil",), "right": ("nil",), "insideV": ("nil",)})
        if self.style == "plain":
            self.d.add_paragraph()

    def equation(self, b: Block):
        from docx.enum.text import WD_TAB_ALIGNMENT
        from docx.shared import Cm, Inches

        tag = b.extra.get("tag")
        if tag is None:
            self.eq_no += 1
            tag = str(self.eq_no)
        self.stats["equations"] += 1
        p = self.d.add_paragraph(style="OA Equation" if self.style != "plain" else None)
        tw = self.text_width_cm
        p.paragraph_format.tab_stops.add_tab_stop(Cm(tw / 2), WD_TAB_ALIGNMENT.CENTER)
        p.paragraph_format.tab_stops.add_tab_stop(Cm(tw - 0.1), WD_TAB_ALIGNMENT.RIGHT)
        p.paragraph_format.keep_together = True
        p.add_run("\t")
        png = self.tmp / f"eq_{hashlib.md5(b.text.encode()).hexdigest()[:12]}.png"
        dims = render_math_png(b.text, png, fontsize=self.body_size)
        if dims:
            w_in = dims[0]
            max_in = (tw - 2.2) / 2.54
            if w_in > max_in:
                w_in = max_in
            p.add_run().add_picture(str(png), width=Inches(w_in))
        else:
            self.warnings.append(f"公式无法渲染，已以文本显示: {b.text[:60]}")
            try:
                for t, f in _merge_runs(tex_to_runs(" ".join(_prep_tex_lines(b.text)))):
                    r = p.add_run(t)
                    r.italic = bool(f.get("italic"))
                    r.font.subscript = f.get("vert") == "subscript"
                    r.font.superscript = f.get("vert") == "superscript"
            except _Unsupported:
                r = p.add_run(b.text)
                r.italic = True
        if tag != "":
            p.add_run(f"\t({tag})")

    def reference(self, text: str):
        self.ref_no += 1
        self.stats["references"] += 1
        t = text.strip()
        if not re.match(r"^\[\d+\]", t):
            m = re.match(r"^(\d+)[.、)．]\s*(.*)", t)
            t = f"[{m.group(1)}] {m.group(2)}" if m else f"[{self.ref_no}] {t}"
        if self.style == "plain":
            self.d.add_paragraph(t)
        else:
            p = self.d.add_paragraph(style="OA Reference")
            self.inline(p, t)

    def note(self, text: str):
        if self.d.paragraphs and self.last_kind in ("image", "table"):
            self.d.paragraphs[-1].paragraph_format.keep_with_next = True  # 图题与注释不分页
        if self.style == "plain":
            p = self.d.add_paragraph()
            self.inline(p, text, size=9)
            return
        p = self.d.add_paragraph(style="OA Note")
        self.inline(p, text)

    def code(self, text: str):
        from docx.shared import Pt

        style = "OA Code" if self.style != "plain" else None
        p = self.d.add_paragraph(style=style)
        r = p.add_run(text)
        _run_font(r, latin="Consolas", size=9)
        if self.style == "plain":
            r.font.name = "Consolas"
            r.font.size = Pt(9)
        if self.style == "report":
            ppr = p._p.get_or_add_pPr()  # noqa: SLF001
            _insert_ordered(ppr, _el("w:shd", val="clear", color="auto", fill="F3F4F6"), _PPR_ORDER)

    def page_numbers(self):
        from docx.enum.text import WD_ALIGN_PARAGRAPH

        for sec in self.d.sections:
            p = sec.footer.paragraphs[0] if sec.footer.paragraphs else sec.footer.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.first_line_indent = 0
            if self.style == "report":
                p.add_run("第 ")
                _add_field(p, "PAGE", "1")
                p.add_run(" 页 / 共 ")
                _add_field(p, "NUMPAGES", "1")
                p.add_run(" 页")
            else:
                p.add_run("— ")
                _add_field(p, "PAGE", "1")
                p.add_run(" —")
            for r in p.runs:
                _run_font(r, east=self.body_east, latin=self.body_latin, size=9)

    def toc(self):
        from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK

        h = self.d.add_paragraph(style="Caption" if self.style != "plain" else None)
        r = h.add_run("目　录")
        _run_font(r, size=14, bold=True)
        h.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p = self.d.add_paragraph()
        _add_field(p, 'TOC \\o "1-3" \\h \\z \\u', "（目录：在 Word 中右键此处 → 更新域，即可生成）")
        self.d.add_paragraph().add_run().add_break(WD_BREAK.PAGE)
        settings = self.d.settings.element
        if settings.find(_q("w:updateFields")) is None:
            settings.append(_el("w:updateFields", val="true"))

    # ------------------------------------------------------------------ 主流程
    def build(self, blocks: list[Block]):
        from docx.enum.text import WD_BREAK

        self._setup()
        title = self.title
        heads = [b for b in blocks if b.kind == "heading"]
        h1 = [b for b in heads if b.level == 1]
        shift = 0
        first_head_idx = next((k for k, b in enumerate(blocks) if b.kind == "heading"), None)
        title_idx = None
        if heads:
            first = blocks[first_head_idx]
            only_h1_first = first.level == 1 and len(h1) == 1
            if only_h1_first and (not title or _strip_md(first.text) == _strip_md(title)):
                title = title or first.text
                title_idx = first_head_idx
                shift = 1
            elif not h1:
                shift = min(b.level for b in heads) - 1
            if title and not title_idx and self.style != "plain" and only_h1_first and \
                    _strip_md(first.text) != _strip_md(title):
                shift = 0
        if title:
            self.title_block(title)
        toc_done = not self.opts.get("toc")
        body_started = False
        for k, b in enumerate(blocks):
            if k == title_idx:
                continue
            kind = b.kind
            if not toc_done and kind == "heading" and not (
                    self.style == "academic" and parse_label(_strip_md(b.text) + "：x")):
                self.toc()
                toc_done = True
            if kind == "heading":
                txt = _strip_md(b.text)
                if self.style == "academic" and parse_label(txt + "：x") and parse_label(txt + "：x")[0] != "meta" \
                        and k + 1 < len(blocks) and blocks[k + 1].kind == "para":
                    self.pending_label = txt
                    continue
                self.heading(b.text, b.level - shift)
                body_started = True
            elif kind == "para":
                if self.pending_label:
                    lab = parse_label(self.pending_label + "：" + b.text)
                    self.pending_label = None
                    if lab:
                        self.labeled(lab[0], lab[1], lab[2])
                        continue
                if self.style == "academic" and NOTE_RE.match(b.text) and self.last_kind in ("table", "image"):
                    self.note(b.text)
                else:
                    self.para(b.text)
            elif kind in ("abstract", "keywords", "abstract_en", "keywords_en", "meta"):
                self.labeled(kind, b.extra.get("label", ""), b.text)
            elif kind == "image":
                self.image(b)
            elif kind == "table":
                self.table(b)
            elif kind == "note":
                self.note(b.text)
            elif kind == "equation":
                self.equation(b)
            elif kind == "code":
                self.code(b.text)
            elif kind == "ref":
                self.reference(b.text)
            elif kind == "bullet":
                if self.style == "plain":
                    p = self.d.add_paragraph(style="List Bullet" if b.level == 0 else "List Bullet 2")
                    self.inline(p, b.text)
                else:
                    from docx.shared import Pt

                    p = self.d.add_paragraph(style="OA List")
                    p.paragraph_format.left_indent = Pt(18 + 18 * b.level)
                    p.paragraph_format.first_line_indent = Pt(-12)
                    p.add_run("• " if b.level == 0 else "◦ ")
                    self.inline(p, b.text)
            elif kind == "number":
                if self.style == "plain":
                    self.inline(self.d.add_paragraph(style="List Number"), b.text)
                else:
                    from docx.shared import Pt

                    p = self.d.add_paragraph(style="OA List")
                    p.paragraph_format.left_indent = Pt(24 + 18 * b.level) if self.style == "report" else Pt(0)
                    p.paragraph_format.first_line_indent = Pt(-14) if self.style == "report" else Pt(24)
                    p.add_run(b.extra.get("marker", "1.") + " ")
                    self.inline(p, b.text)
            elif kind == "quote":
                if self.style == "plain":
                    self.inline(self.d.add_paragraph(style="Quote"), b.text)
                else:
                    p = self.d.add_paragraph(style="OA Quote")
                    self.inline(p, b.text)
                    if self.style == "report":
                        ppr = p._p.get_or_add_pPr()  # noqa: SLF001
                        bd = _el("w:pBdr")
                        bd.append(_el("w:left", val="single", sz=24, space="8", color="2E75B6"))
                        _insert_ordered(ppr, bd, _PPR_ORDER)
                        _insert_ordered(ppr, _el("w:shd", val="clear", color="auto", fill="EEF3FA"), _PPR_ORDER)
            elif kind == "pagebreak":
                self.d.add_paragraph().add_run().add_break(WD_BREAK.PAGE)
            elif kind == "footnote_def":
                self.footnotes[b.extra["key"]] = b.text
            elif kind == "hr":
                pass
            if kind not in ("footnote_def",):
                self.last_kind = kind if kind != "note" else self.last_kind
        _ = body_started
        if self.fn_order:
            self.heading("注释", 1)
            for n, key in enumerate(self.fn_order, 1):
                self.note(f"[{n}] {self.footnotes.get(key, '')}")
        if self.style != "plain":
            self.page_numbers()
        self.d.core_properties.title = _strip_md(title or "")
        if self.opts.get("author"):
            self.d.core_properties.author = str(self.opts["author"])[:200]
        return self.d

    def cleanup(self):
        shutil.rmtree(self.tmp, ignore_errors=True)


def markdown_to_docx(md: str, out: Path, base_dir: Path, title: str | None = None, style: str = "report",
                     **opts) -> dict[str, Any]:
    """Markdown → .docx。返回统计信息与警告（figures/tables/equations/references/missing_images/warnings）。"""
    b = _DocxBuilder(style, Path(base_dir), title, opts)
    try:
        doc = b.build(parse_markdown_blocks(md))
        out = Path(out)
        out.parent.mkdir(parents=True, exist_ok=True)
        doc.save(str(out))
    finally:
        b.cleanup()
    return {**b.stats, "warnings": b.warnings}


# ============================================================================= DOCX -> PDF（LibreOffice）

def find_soffice() -> str | None:
    env = os.environ.get("OMNI_SOFFICE")
    if env and Path(env).exists():
        return env
    for name in ("soffice", "libreoffice"):
        p = shutil.which(name)
        if p:
            return p
    for cand in ["/Applications/LibreOffice.app/Contents/MacOS/soffice", "/usr/bin/soffice", "/usr/local/bin/soffice",
                 "/opt/homebrew/bin/soffice", "/snap/bin/libreoffice",
                 r"C:\Program Files\LibreOffice\program\soffice.exe",
                 r"C:\Program Files (x86)\LibreOffice\program\soffice.exe"]:
        if Path(cand).exists():
            return cand
    for cand in sorted(Path("/opt").glob("libreoffice*/program/soffice")):
        return str(cand)
    return None


def _font_substitutions() -> dict[str, str]:
    names = _installed_fonts()
    subs = {}
    for logical, cands in _EAST_FALLBACK.items():
        if logical in names:
            continue
        for c in cands:
            if c in names:
                if c != logical:
                    subs[logical] = c
                break
    return subs


def _substitute_fonts_in_docx(src: Path, dst: Path, subs: dict[str, str]) -> None:
    with zipfile.ZipFile(src) as zin, zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if subs and item.filename.startswith("word/") and item.filename.endswith(".xml"):
                text = data.decode("utf-8")
                for a, b in subs.items():
                    text = text.replace(f'="{a}"', f'="{htmllib.escape(b)}"')
                data = text.encode("utf-8")
            zout.writestr(item, data)


def _windows_office_docx_to_pdf(docx_path: Path, pdf_path: Path, timeout: int = 240) -> bool:
    """在 Windows 上使用已安装的 Microsoft Word 或 WPS 文字 COM 接口导出 PDF。"""
    if os.name != "nt":
        return False
    ps = shutil.which("powershell") or shutil.which("powershell.exe")
    if not ps:
        return False
    Path(pdf_path).parent.mkdir(parents=True, exist_ok=True)
    ps_script = r'''
$ErrorActionPreference = 'Stop'
$src = [System.IO.Path]::GetFullPath($env:OMNI_DOCX_SRC)
$dst = [System.IO.Path]::GetFullPath($env:OMNI_PDF_DST)
foreach ($prog in @('Word.Application', 'KWPS.Application', 'WPS.Application')) {
    $app = $null
    $doc = $null
    try {
        $app = New-Object -ComObject $prog
        $app.Visible = $false
        $app.DisplayAlerts = 0
        $doc = $app.Documents.Open($src, $false, $true)
        $doc.ExportAsFixedFormat($dst, 17)
        $doc.Close(0)
        $app.Quit()
        if (Test-Path $dst) { exit 0 }
    } catch {
        if ($doc) { try { $doc.Close(0) } catch {} }
        if ($app) { try { $app.Quit() } catch {} }
    }
}
exit 2
'''
    env = {**os.environ, "OMNI_DOCX_SRC": str(Path(docx_path).resolve()), "OMNI_PDF_DST": str(Path(pdf_path).resolve())}
    try:
        res = subprocess.run(
            [ps, "-NoProfile", "-NonInteractive", "-Command", ps_script],
            capture_output=True, text=True, env=env, timeout=timeout,
        )
        return res.returncode == 0 and Path(pdf_path).is_file()
    except Exception:  # noqa: BLE001
        return False


def docx_to_pdf(docx_path: Path, pdf_path: Path, timeout: int = 240) -> Path:
    soffice = find_soffice()
    if not soffice:
        if _windows_office_docx_to_pdf(docx_path, pdf_path, timeout=timeout):
            return Path(pdf_path)
        raise ToolError("未找到 LibreOffice（soffice）或本地 Word/WPS，无法导出 PDF。请安装 LibreOffice（Windows: "
                        "winget install TheDocumentFoundation.LibreOffice；macOS: brew install --cask libreoffice；"
                        "Ubuntu: apt install libreoffice-writer；或设置环境变量 OMNI_SOFFICE 指向 soffice），"
                        "或改为输出 .docx 后在 Word/WPS 中“另存为 PDF”。")
    with tempfile.TemporaryDirectory(prefix="omni_pdf_") as td:
        tdp = Path(td)
        src = tdp / "document.docx"
        _substitute_fonts_in_docx(Path(docx_path), src, _font_substitutions())
        profile = tdp / "lo_profile"
        cmd = [soffice, f"-env:UserInstallation={profile.as_uri()}", "--headless", "--norestore", "--nologo",
               "--convert-to", "pdf:writer_pdf_Export", "--outdir", str(tdp), str(src)]
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        except subprocess.TimeoutExpired:
            raise ToolError(f"LibreOffice 转换 PDF 超时（{timeout}s）") from None
        out = tdp / "document.pdf"
        if not out.exists():
            raise ToolError(f"LibreOffice 转换失败（退出码 {proc.returncode}）：{(proc.stderr or proc.stdout)[-800:]}")
        Path(pdf_path).parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(out), str(pdf_path))
    return Path(pdf_path)


def pdf_to_pngs(pdf_path: Path, out_dir: Path, dpi: int = 110, first: int = 1, last: int | None = None) -> list[Path]:
    """PDF 页面转 PNG（优先 pdftoppm，其次 PyMuPDF），便于用视觉工具检查版面。"""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = Path(pdf_path).stem
    if shutil.which("pdftoppm"):
        cmd = ["pdftoppm", "-png", "-r", str(dpi), "-f", str(first)]
        if last:
            cmd += ["-l", str(last)]
        subprocess.run(cmd + [str(pdf_path), str(out_dir / stem)], check=True, capture_output=True, timeout=300)
        return sorted(out_dir.glob(f"{stem}-*.png"))
    try:
        import fitz  # type: ignore

        doc = fitz.open(str(pdf_path))
        outs = []
        for i in range(first - 1, min(last or doc.page_count, doc.page_count)):
            pix = doc[i].get_pixmap(dpi=dpi)
            p = out_dir / f"{stem}-{i + 1:02d}.png"
            pix.save(str(p))
            outs.append(p)
        return outs
    except ImportError:
        raise ToolError("需要 pdftoppm（poppler）或 PyMuPDF 才能把 PDF 转为图片") from None


# ============================================================================= Markdown -> HTML

_HTML_CSS = {
    "report": """
body{font-family:-apple-system,"PingFang SC","Microsoft YaHei",Segoe UI,sans-serif;max-width:920px;margin:40px auto;
padding:0 28px;color:#1f2328;line-height:1.75;background:#fff}
h1.title{text-align:center;color:#1F3864;border:none;font-size:2em;margin-bottom:.2em}
.author,.affiliation{text-align:center;color:#666;margin:.2em 0}
h1,h2{color:#1F4E79} h2{border-bottom:2px solid #1F4E79;padding-bottom:.25em;margin-top:2em} h3{color:#2E75B6}
table{border-collapse:collapse;margin:.4em auto 1em;font-size:14px;min-width:60%}
th,td{border-bottom:1px solid #d0d7de;padding:6px 12px} th{background:#1F4E79;color:#fff}
tr:nth-child(even) td{background:#F2F6FA} td.num{text-align:right}
figure{margin:1.2em 0;text-align:center} figure img{max-width:100%;border-radius:6px;box-shadow:0 2px 10px rgba(0,0,0,.08)}
figcaption,.table-caption{text-align:center;font-weight:600;color:#404040;font-size:14px;margin:.4em 0}
.note{font-size:12.5px;color:#595959;margin:.2em 0 1em}
.abstract{background:#EEF3FA;padding:10px 14px;border-radius:6px;margin:.6em 0}
.eq{display:flex;align-items:center;justify-content:center;position:relative;margin:.8em 0}
.eq .eqno{position:absolute;right:0} .refs p{padding-left:2em;text-indent:-2em;font-size:14px;margin:.2em 0}
code{background:#f3f4f6;padding:2px 5px;border-radius:4px;font-size:90%} pre{background:#0f172a;color:#e2e8f0;padding:14px;border-radius:8px;overflow:auto}
pre code{background:none;color:inherit} blockquote{border-left:4px solid #2E75B6;margin:1em 0;padding:.5em 1em;background:#eef3fa;color:#1F3864}
img.math{vertical-align:middle}
""",
    "academic": """
body{font-family:"Times New Roman","Songti SC","STSong","SimSun",serif;max-width:800px;margin:40px auto;padding:0 32px;
color:#000;line-height:1.9;background:#fff;font-size:16px}
p{text-indent:2em;text-align:justify;margin:0}
h1.title{font-family:"Heiti SC","SimHei","PingFang SC",sans-serif;text-align:center;font-weight:normal;font-size:1.7em;margin:.6em 0 .3em}
.author{text-align:center;font-family:"Kaiti SC","KaiTi",serif;text-indent:0} .affiliation{text-align:center;font-size:13px;text-indent:0;margin-bottom:1em}
h2{font-family:"Heiti SC","SimHei",sans-serif;font-weight:normal;font-size:1.2em;margin:1.2em 0 .4em}
h3{font-family:"Kaiti SC","KaiTi",serif;font-size:1.05em;margin:.8em 0 .3em;text-indent:2em}
h4{font-size:1em;margin:.5em 0 .2em;text-indent:2em}
.abstract{font-family:"Kaiti SC","KaiTi",serif;font-size:14px;margin:.3em 2em;text-indent:0}
.abstract b{font-family:"Heiti SC","SimHei",sans-serif}
figure{margin:1em 0 .2em;text-align:center} figure img{max-width:88%}
figcaption,.table-caption{text-align:center;font-family:"Heiti SC","SimHei",sans-serif;font-size:14px;text-indent:0;margin:.3em 0}
table{border-collapse:collapse;margin:.2em auto .4em;font-size:14px;border-top:2px solid #000;border-bottom:2px solid #000;min-width:60%}
th{border-bottom:1px solid #000;font-weight:normal;padding:4px 10px} td{padding:3px 10px;text-align:center}
td:first-child{text-align:left}
.note{font-size:12px;text-indent:0;margin:.2em 0 .9em}
.eq{display:flex;align-items:center;justify-content:center;position:relative;margin:.6em 0;text-indent:0}
.eq .eqno{position:absolute;right:0}
.refs p{padding-left:2em;text-indent:-2em;font-size:14px}
img.math{vertical-align:middle}
pre{background:#f6f6f6;padding:10px;overflow:auto;font-size:13px}
""",
}
_HTML_CSS["plain"] = _HTML_CSS["report"]

HTML_TEMPLATE = """<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>{title}</title>
<style>{css}</style></head><body>{body}</body></html>"""


class _HtmlBuilder:
    def __init__(self, style: str, base_dir: Path, opts: dict[str, Any]):
        self.style = style
        self.base_dir = base_dir
        self.opts = opts
        self.tmp = Path(tempfile.mkdtemp(prefix="omni_html_"))
        self.fig_no = 0
        self.eq_no = 0
        self.fn_order: list[str] = []
        self.warnings: list[str] = []

    def _data_uri(self, p: Path) -> str:
        mime = mimetypes.guess_type(str(p))[0] or "image/png"
        return f"data:{mime};base64,{base64.b64encode(p.read_bytes()).decode()}"

    def math_inline(self, tex: str) -> str:
        try:
            out = []
            for t, f in _merge_runs(tex_to_runs(tex)):
                h = htmllib.escape(t)
                if f.get("italic"):
                    h = f"<i>{h}</i>"
                if f.get("bold"):
                    h = f"<b>{h}</b>"
                if f.get("vert") == "subscript":
                    h = f"<sub>{h}</sub>"
                elif f.get("vert") == "superscript":
                    h = f"<sup>{h}</sup>"
                out.append(h)
            return "".join(out)
        except _Unsupported:
            png = self.tmp / f"im_{hashlib.md5(tex.encode()).hexdigest()[:12]}.png"
            dims = render_math_png(tex, png, fontsize=12, dpi=200)
            if dims:
                return f'<img class="math" style="height:{dims[1] * 96 * 1.15:.0f}px" src="{self._data_uri(png)}" ' \
                       f'alt="{htmllib.escape(tex)}">'
            return f"<i>{htmllib.escape(tex)}</i>"

    def inline(self, text: str) -> str:
        text = text.replace("\\$", "\x00")
        out = []
        for tok in _DocxBuilder._INLINE.split(text):
            if not tok:
                continue
            if (tok.startswith("**") and tok.endswith("**") or tok.startswith("__") and tok.endswith("__")) \
                    and len(tok) > 4:
                out.append(f"<strong>{self.inline(tok[2:-2])}</strong>")
            elif tok.startswith("`") and tok.endswith("`") and len(tok) > 2:
                out.append(f"<code>{htmllib.escape(tok[1:-1])}</code>")
            elif tok.startswith("*") and tok.endswith("*") and len(tok) > 2:
                out.append(f"<em>{self.inline(tok[1:-1])}</em>")
            elif tok.startswith("$") and tok.endswith("$") and len(tok) > 2 and _looks_like_math(tok[1:-1]):
                out.append(self.math_inline(tok[1:-1]))
            elif tok.startswith("[^") and tok.endswith("]"):
                key = tok[2:-1]
                if key not in self.fn_order:
                    self.fn_order.append(key)
                out.append(f"<sup>[{self.fn_order.index(key) + 1}]</sup>")
            elif tok.startswith(("<sup>", "<sub>")):
                tagname = tok[1:4]
                out.append(f"<{tagname}>{htmllib.escape(tok[5:-6])}</{tagname}>")
            elif re.match(r"<br\s*/?>", tok):
                out.append("<br>")
            elif m := re.match(r"\[([^\]]+)\]\(([^)]+)\)", tok):
                out.append(f'<a href="{htmllib.escape(m.group(2))}">{htmllib.escape(m.group(1))}</a>')
            else:
                out.append(htmllib.escape(tok))
        return "".join(out).replace("\x00", "$")

    def build(self, blocks: list[Block], title: str | None) -> tuple[str, str]:
        parts: list[str] = []
        heads = [b for b in blocks if b.kind == "heading"]
        h1 = [b for b in heads if b.level == 1]
        title_idx = None
        if heads and heads[0].level == 1 and len(h1) == 1 and (not title or _strip_md(heads[0].text) == _strip_md(title)):
            title = title or heads[0].text
            title_idx = blocks.index(heads[0])
        if title:
            parts.append(f'<h1 class="title">{self.inline(_strip_md(title))}</h1>')
            if self.opts.get("author"):
                parts.append(f'<p class="author">{self.inline(str(self.opts["author"]))}</p>')
            if self.opts.get("affiliation"):
                parts.append(f'<p class="affiliation">{self.inline(str(self.opts["affiliation"]))}</p>')
        in_refs = False
        list_open = None
        footnotes = {}
        for k, b in enumerate(blocks):
            if k == title_idx:
                continue
            if list_open and b.kind not in ("bullet", "number"):
                parts.append(f"</{list_open}>")
                list_open = None
            if in_refs and b.kind != "ref":
                parts.append("</div>")
                in_refs = False
            kind = b.kind
            if kind == "heading":
                lvl = max(1, min(6, b.level + (1 if title_idx is not None or (title and not h1) else 0)))
                parts.append(f"<h{lvl}>{self.inline(_strip_md(b.text))}</h{lvl}>")
            elif kind == "para":
                parts.append(f"<p>{self.inline(b.text)}</p>")
            elif kind in ("abstract", "keywords", "abstract_en", "keywords_en", "meta"):
                label = {"abstract": "摘要：", "keywords": "关键词：", "abstract_en": "Abstract: ",
                         "keywords_en": "Keywords: "}.get(kind, b.extra.get("label", "") + "：")
                parts.append(f'<p class="abstract"><b>{label}</b>{self.inline(b.text)}</p>')
            elif kind == "image":
                img = Path(b.src) if Path(b.src).is_absolute() else self.base_dir / b.src
                cap = b.caption
                if cap and not FIG_CAP_RE.match(_strip_md(cap)) and self.style != "plain":
                    self.fig_no += 1
                    cap = f"图{self.fig_no}　{cap}"
                if b.src.startswith(("http://", "https://", "data:")):
                    src = b.src
                elif img.exists():
                    src = self._data_uri(img)
                else:
                    src = htmllib.escape(b.src)
                    self.warnings.append(f"图片缺失: {b.src}")
                parts.append(f'<figure><img src="{src}" alt="{htmllib.escape(_strip_md(cap))}">'
                             + (f"<figcaption>{self.inline(_strip_md(cap))}</figcaption>" if cap else "")
                             + "</figure>")
            elif kind == "table":
                if b.caption:
                    parts.append(f'<p class="table-caption">{self.inline(b.caption)}</p>')
                rows = b.rows
                width = max(len(r) for r in rows) if rows else 0
                html_rows = []
                for ri, r in enumerate(rows):
                    cells = []
                    for ci in range(width):
                        txt = r[ci] if ci < len(r) else ""
                        tagname = "th" if ri == 0 else "td"
                        cls = ' class="num"' if ri and _NUM_CELL.match(_strip_md(txt) or "x") else ""
                        cells.append(f"<{tagname}{cls}>{self.inline(txt)}</{tagname}>")
                    html_rows.append("<tr>" + "".join(cells) + "</tr>")
                head = f"<thead>{html_rows[0]}</thead>" if html_rows else ""
                body = "<tbody>" + "".join(html_rows[1:]) + "</tbody>"
                parts.append(f"<table>{head}{body}</table>")
            elif kind == "note":
                parts.append(f'<p class="note">{self.inline(b.text)}</p>')
            elif kind == "equation":
                tag = b.extra.get("tag")
                if tag is None:
                    self.eq_no += 1
                    tag = str(self.eq_no)
                png = self.tmp / f"eq_{hashlib.md5(b.text.encode()).hexdigest()[:12]}.png"
                dims = render_math_png(b.text, png, fontsize=13, dpi=200)
                inner = (f'<img class="math" style="height:{dims[1] * 96:.0f}px" src="{self._data_uri(png)}" '
                         f'alt="{htmllib.escape(b.text)}">') if dims else f"<i>{htmllib.escape(b.text)}</i>"
                parts.append(f'<div class="eq">{inner}<span class="eqno">({htmllib.escape(tag)})</span></div>')
            elif kind == "code":
                lang = b.extra.get("lang") or ""
                parts.append(f'<pre><code class="language-{htmllib.escape(lang)}">{htmllib.escape(b.text)}</code></pre>')
            elif kind == "ref":
                if not in_refs:
                    parts.append('<div class="refs">')
                    in_refs = True
                parts.append(f"<p>{self.inline(b.text)}</p>")
            elif kind in ("bullet", "number"):
                tagname = "ul" if kind == "bullet" else "ol"
                if list_open != tagname:
                    if list_open:
                        parts.append(f"</{list_open}>")
                    parts.append(f"<{tagname}>")
                    list_open = tagname
                parts.append(f"<li>{self.inline(b.text)}</li>")
            elif kind == "quote":
                parts.append(f"<blockquote>{self.inline(b.text)}</blockquote>")
            elif kind == "pagebreak":
                parts.append('<div style="page-break-after:always"></div>')
            elif kind == "hr":
                parts.append("<hr>")
            elif kind == "footnote_def":
                footnotes[b.extra["key"]] = b.text
        if list_open:
            parts.append(f"</{list_open}>")
        if in_refs:
            parts.append("</div>")
        if self.fn_order:
            parts.append("<hr><ol class=\"footnotes\">" + "".join(
                f"<li>{self.inline(footnotes.get(k, ''))}</li>" for k in self.fn_order) + "</ol>")
        return "\n".join(parts), title or ""


def markdown_to_html(md: str, out: Path, base_dir: Path, title: str | None = None, style: str = "report",
                     **opts) -> dict[str, Any]:
    if style not in STYLES:
        raise ToolError(f"未知 style: {style}（可选 {', '.join(STYLES)}）")
    hb = _HtmlBuilder(style, Path(base_dir), opts)
    try:
        body, t = hb.build(parse_markdown_blocks(md), title)
    finally:
        shutil.rmtree(hb.tmp, ignore_errors=True)
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(HTML_TEMPLATE.format(title=htmllib.escape(_strip_md(t) or out.stem), css=_HTML_CSS[style],
                                        body=body), encoding="utf-8")
    return {"warnings": hb.warnings}


# ============================================================================= Tools

@tool(
    "create_document",
    "把 Markdown 生成正式文档。output_path 扩展名决定格式：.docx（Word）、.pdf（先生成 Word 再用 LibreOffice 转换）、"
    ".html（单文件网页，图片/公式内嵌）或 .md。可直接传 markdown，或用 source_path 指定已有 .md 文件（长文推荐）。\n"
    "style：report（默认，商务报告：彩色标题、表头着色表格）| academic（中文学术论文/GB 版式：黑体标题、宋体小四+Times New Roman、"
    "1.5 倍行距、首行缩进、摘要/关键词块、三线表、图题在下/表题在上、注释小字、公式编号、参考文献悬挂缩进、页码）| plain。\n"
    "约定：图片 `![图1 标题](outputs/figures/fig1.png)`（路径相对工作区，图题自动放在图下）；表题写在表格上一行 `表1 标题`；"
    "图/表后紧跟 `注：…` 或 `资料来源：…` 为注释；独立行 `$$ LaTeX $$` 为编号公式（`\\tag{3}` 自定义编号），行内 `$x_{it}$`；"
    "`摘要：…`、`关键词：…`、`Abstract: …`、`Keywords: …` 为摘要块；`## 参考文献` 下每行一条 `[1] …`；`\\newpage` 分页。",
    {
        "output_path": {"type": "string", "description": "输出路径，如 outputs/论文.docx / outputs/论文.pdf / outputs/报告.html"},
        "markdown": {"type": "string", "description": "Markdown 正文"},
        "source_path": {"type": "string", "description": "可选：已有 Markdown 文件路径（长文档推荐先 write_file 再引用）"},
        "title": {"type": "string", "description": "可选：文档标题（若正文首行已有唯一一级标题可不填）"},
        "style": {"type": "string", "enum": list(STYLES), "description": "版式：report（默认）/ academic / plain"},
        "author": {"type": "string", "description": "可选：作者行（标题下方居中）"},
        "affiliation": {"type": "string", "description": "可选：作者单位行，如 “（某某大学 财政税务学院，北京 100081）”"},
        "date": {"type": "string", "description": "可选：日期（report 版式显示在标题下）"},
        "toc": {"type": "boolean", "description": "可选：是否插入目录域（Word 中更新域后生成），默认 false"},
    },
    ["output_path"],
    risk="write",
    summary_keys=("output_path",),
)
async def create_document(args, ctx: ToolContext):
    out = ctx.resolve(args["output_path"])
    if args.get("source_path"):
        src = ctx.resolve(args["source_path"], must_exist=True)
        md = src.read_text(encoding="utf-8")
    elif args.get("markdown"):
        md = args["markdown"]
    else:
        raise ToolError("需要提供 markdown 或 source_path")
    style = (args.get("style") or "report").strip().lower()
    if style not in STYLES:
        raise ToolError(f"未知 style: {style}（可选 {', '.join(STYLES)}）")
    opts = {k: args[k] for k in ("author", "affiliation", "date", "toc") if args.get(k)}
    ext = out.suffix.lower()
    info: dict[str, Any] = {}
    if ext == ".docx":
        info = await asyncio.to_thread(markdown_to_docx, md, out, ctx.workspace, args.get("title"), style, **opts)
    elif ext == ".pdf":
        with tempfile.TemporaryDirectory(prefix="omni_mk_") as td:
            tmp_docx = Path(td) / (out.stem + ".docx")
            info = await asyncio.to_thread(markdown_to_docx, md, tmp_docx, ctx.workspace, args.get("title"), style,
                                           **opts)
            await asyncio.to_thread(docx_to_pdf, tmp_docx, out)
    elif ext in (".html", ".htm"):
        info = await asyncio.to_thread(markdown_to_html, md, out, ctx.workspace, args.get("title"), style, **opts)
    elif ext == ".md":
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text((f"# {args['title']}\n\n" if args.get("title") else "") + md, encoding="utf-8")
    else:
        raise ToolError("仅支持 .docx / .pdf / .html / .md")
    msg = [f"已生成文档 {ctx.rel(out)}（{max(1, out.stat().st_size // 1024)} KB，版式 {style}）。"]
    if info.get("figures") is not None:
        msg.append(f"包含图 {info.get('figures', 0)} 幅、表 {info.get('tables', 0)} 张、公式 {info.get('equations', 0)} 个、"
                   f"参考文献 {info.get('references', 0)} 条。")
    if info.get("warnings"):
        msg.append("⚠️ 警告：\n- " + "\n- ".join(info["warnings"][:20]))
    tip = "建议用 read_file 打开检查内容"
    if style == "academic":
        tip += "，并用 check_document 做结构与图表规范自检"
    msg.append(tip + "。")
    return ToolResult("\n".join(msg), data={"path": ctx.rel(out), **{k: v for k, v in info.items() if k != "warnings"}})


@tool(
    "create_presentation",
    "生成 PowerPoint 演示文稿（.pptx）。每页可包含标题、要点列表、图片和演讲者备注。",
    {
        "output_path": {"type": "string"},
        "title": {"type": "string", "description": "封面标题"},
        "subtitle": {"type": "string", "description": "封面副标题"},
        "slides": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "title": {"type": "string"},
                    "bullets": {"type": "array", "items": {"type": "string"}, "description": "要点；以两个空格开头表示二级要点"},
                    "image": {"type": "string", "description": "可选：图片路径"},
                    "notes": {"type": "string", "description": "可选：演讲者备注"},
                },
                "required": ["title"],
            },
        },
    },
    ["output_path", "title", "slides"],
    risk="write",
    summary_keys=("output_path",),
)
async def create_presentation(args, ctx: ToolContext):
    out = ctx.resolve(args["output_path"])

    def build():
        from pptx import Presentation
        from pptx.util import Inches, Pt

        prs = Presentation()
        prs.slide_width, prs.slide_height = Inches(13.333), Inches(7.5)
        cover = prs.slides.add_slide(prs.slide_layouts[0])
        cover.shapes.title.text = args["title"]
        if args.get("subtitle") and len(cover.placeholders) > 1:
            cover.placeholders[1].text = args["subtitle"]
        for spec in args.get("slides", []):
            img = spec.get("image")
            img_path = ctx.resolve(img) if img else None
            bullets = spec.get("bullets") or []
            layout = prs.slide_layouts[5] if (img_path and not bullets) else prs.slide_layouts[1]
            slide = prs.slides.add_slide(layout)
            slide.shapes.title.text = spec["title"]
            if layout is prs.slide_layouts[1]:
                body = slide.placeholders[1]
                if img_path and img_path.exists():
                    body.width = Inches(6.2)
                tf = body.text_frame
                tf.clear()
                for j, b in enumerate(bullets):
                    level = 1 if b.startswith("  ") else 0
                    para = tf.paragraphs[0] if j == 0 else tf.add_paragraph()
                    para.text = b.strip().lstrip("-• ")
                    para.level = level
                    para.font.size = Pt(20 if level == 0 else 16)
            if img_path and img_path.exists():
                if bullets:
                    slide.shapes.add_picture(str(img_path), Inches(6.9), Inches(1.6), width=Inches(6))
                else:
                    slide.shapes.add_picture(str(img_path), Inches(1.9), Inches(1.5), height=Inches(5.6))
            if spec.get("notes"):
                slide.notes_slide.notes_text_frame.text = spec["notes"]
        out.parent.mkdir(parents=True, exist_ok=True)
        prs.save(str(out))
        return len(prs.slides)

    n = await asyncio.to_thread(build)
    return ToolResult(f"已生成演示文稿 {ctx.rel(out)}，共 {n} 页", data={"path": ctx.rel(out)})


@tool(
    "create_spreadsheet",
    "生成格式化的 Excel 文件（.xlsx）：表头加粗着色、自动列宽、冻结首行。复杂数据处理建议先用 python 工具。",
    {
        "output_path": {"type": "string"},
        "sheets": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "rows": {"type": "array", "items": {"type": "array", "items": {}}, "description": "二维数组，第一行为表头"},
                },
                "required": ["name", "rows"],
            },
        },
    },
    ["output_path", "sheets"],
    risk="write",
    summary_keys=("output_path",),
)
async def create_spreadsheet(args, ctx: ToolContext):
    out = ctx.resolve(args["output_path"])

    def build():
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Font, PatternFill
        from openpyxl.utils import get_column_letter

        wb = Workbook()
        wb.remove(wb.active)
        for sh in args["sheets"]:
            ws = wb.create_sheet(str(sh["name"])[:31])
            for row in sh["rows"]:
                ws.append(row)
            if ws.max_row >= 1:
                for c in ws[1]:
                    c.font = Font(bold=True, color="FFFFFF")
                    c.fill = PatternFill("solid", fgColor="4F46E5")
                    c.alignment = Alignment(horizontal="center")
                ws.freeze_panes = "A2"
            for col in ws.columns:
                width = max((len(str(c.value)) * (2 if any("\u4e00" <= ch <= "\u9fff" for ch in str(c.value)) else 1)
                             for c in col if c.value is not None), default=8)
                ws.column_dimensions[get_column_letter(col[0].column)].width = min(max(width + 2, 8), 60)
        out.parent.mkdir(parents=True, exist_ok=True)
        wb.save(str(out))

    await asyncio.to_thread(build)
    return ToolResult(f"已生成 Excel {ctx.rel(out)}", data={"path": ctx.rel(out)})


@tool(
    "edit_presentation",
    "读取并修改已有的 PowerPoint 演示文稿（.pptx）：支持全篇文本批量替换（保留原版式字体）、按页码修改指定页标题/要点/备注/配图、"
    "新增幻灯片或删除指定页。默认输出到 output_path（未指定时自动生成 `_修订版.pptx` 保留原稿）。",
    {
        "input_path": {"type": "string", "description": "原 .pptx 文件路径"},
        "output_path": {"type": "string", "description": "输出 .pptx 路径（可选，默认 原名_修订版.pptx；若需原地覆盖可传与 input_path 相同路径）"},
        "replacements": {
            "type": "array",
            "description": "全篇文本替换列表 [{old: '原词', new: '新词'}]，覆盖所有文本框、表格单元格与演讲备注",
            "items": {
                "type": "object",
                "properties": {"old": {"type": "string"}, "new": {"type": "string"}},
                "required": ["old", "new"],
            },
        },
        "slide_updates": {
            "type": "array",
            "description": "按 1 起始页码更新指定页内容",
            "items": {
                "type": "object",
                "properties": {
                    "slide": {"type": "integer", "description": "页码（从 1 开始）"},
                    "title": {"type": "string"},
                    "bullets": {"type": "array", "items": {"type": "string"}},
                    "notes": {"type": "string"},
                    "image": {"type": "string"},
                },
                "required": ["slide"],
            },
        },
        "add_slides": {
            "type": "array",
            "description": "追加新幻灯片列表",
            "items": {
                "type": "object",
                "properties": {
                    "title": {"type": "string"},
                    "bullets": {"type": "array", "items": {"type": "string"}},
                    "notes": {"type": "string"},
                    "image": {"type": "string"},
                },
                "required": ["title"],
            },
        },
        "delete_slides": {
            "type": "array",
            "items": {"type": "integer"},
            "description": "要删除的页码列表（从 1 开始）",
        },
    },
    ["input_path"],
    risk="write",
    summary_keys=("input_path", "output_path"),
)
async def edit_presentation(args: dict[str, Any], ctx: ToolContext) -> ToolResult:
    src = ctx.resolve(args["input_path"], must_exist=True, read_only=True)
    if src.suffix.lower() != ".pptx":
        raise ToolError("edit_presentation 仅支持 .pptx 文件")
    out = ctx.resolve(args.get("output_path") or str(src.with_name(f"{src.stem}_修订版.pptx")))

    def _modify() -> tuple[int, int]:
        from pptx import Presentation
        from pptx.util import Inches, Pt

        prs = Presentation(str(src))
        rep_count = 0
        reps = [(str(r["old"]), str(r["new"])) for r in (args.get("replacements") or []) if r.get("old")]

        def _replace_in_tf(tf):
            nonlocal rep_count
            for para in tf.paragraphs:
                for old_s, new_s in reps:
                    if old_s in para.text:
                        replaced_in_run = False
                        for run in para.runs:
                            if old_s in run.text:
                                run.text = run.text.replace(old_s, new_s)
                                rep_count += 1
                                replaced_in_run = True
                        if not replaced_in_run:
                            full = para.text.replace(old_s, new_s)
                            if para.runs:
                                para.runs[0].text = full
                                for r in para.runs[1:]:
                                    r.text = ""
                            else:
                                para.text = full
                            rep_count += 1

        if reps:
            for slide in prs.slides:
                for sh in slide.shapes:
                    if sh.has_text_frame:
                        _replace_in_tf(sh.text_frame)
                    if sh.has_table:
                        for row in sh.table.rows:
                            for cell in row.cells:
                                _replace_in_tf(cell.text_frame)
                if slide.has_notes_slide and slide.notes_slide.notes_text_frame:
                    _replace_in_tf(slide.notes_slide.notes_text_frame)

        # 按页更新
        for upd in args.get("slide_updates") or []:
            idx = int(upd["slide"]) - 1
            if idx < 0 or idx >= len(prs.slides):
                raise ToolError(f"页码超出范围: 第 {upd['slide']} 页（共 {len(prs.slides)} 页）")
            sl = prs.slides[idx]
            if "title" in upd and upd["title"] is not None and sl.shapes.title is not None:
                sl.shapes.title.text = str(upd["title"])
            if "bullets" in upd and upd["bullets"] is not None:
                body_sh = None
                for sh in sl.placeholders:
                    if sh.placeholder_format.idx != 0 and sh.has_text_frame:
                        body_sh = sh
                        break
                if body_sh is None:
                    body_sh = sl.shapes.add_textbox(Inches(0.8), Inches(1.6), Inches(11.5), Inches(5.0))
                tf = body_sh.text_frame
                tf.clear()
                for j, b in enumerate(upd["bullets"]):
                    p = tf.paragraphs[0] if j == 0 else tf.add_paragraph()
                    p.text = str(b).strip().lstrip("-• ")
                    p.font.size = Pt(20)
            if upd.get("image"):
                ip = ctx.resolve(upd["image"], must_exist=True, read_only=True)
                sl.shapes.add_picture(str(ip), Inches(6.8), Inches(1.6), width=Inches(5.6))
            if "notes" in upd and upd["notes"] is not None:
                sl.notes_slide.notes_text_frame.text = str(upd["notes"])

        # 删除指定页（倒序删除保持索引稳定）
        for del_num in sorted({int(x) for x in (args.get("delete_slides") or [])}, reverse=True):
            idx = del_num - 1
            if 0 <= idx < len(prs.slides):
                r_id = prs.slides._sldIdLst[idx].rId
                prs.part.drop_rel(r_id)
                del prs.slides._sldIdLst[idx]

        # 追加新幻灯片
        for spec in args.get("add_slides") or []:
            layout = prs.slide_layouts[1 if len(prs.slide_layouts) > 1 else 0]
            sl = prs.slides.add_slide(layout)
            if sl.shapes.title:
                sl.shapes.title.text = str(spec["title"])
            bullets = spec.get("bullets") or []
            if bullets:
                body_sh = next((sh for sh in sl.placeholders if sh.placeholder_format.idx != 0 and sh.has_text_frame), None)
                if body_sh is None:
                    body_sh = sl.shapes.add_textbox(Inches(0.8), Inches(1.6), Inches(11.5), Inches(5.0))
                tf = body_sh.text_frame
                tf.clear()
                for j, b in enumerate(bullets):
                    p = tf.paragraphs[0] if j == 0 else tf.add_paragraph()
                    p.text = str(b).strip().lstrip("-• ")
                    p.font.size = Pt(20)
            if spec.get("image"):
                ip = ctx.resolve(spec["image"], must_exist=True, read_only=True)
                sl.shapes.add_picture(str(ip), Inches(6.8), Inches(1.6), width=Inches(5.6))
            if spec.get("notes"):
                sl.notes_slide.notes_text_frame.text = str(spec["notes"])

        out.parent.mkdir(parents=True, exist_ok=True)
        prs.save(str(out))
        return len(prs.slides), rep_count

    total_slides, reps_done = await asyncio.to_thread(_modify)
    return ToolResult(
        f"✅ 已修订演示文稿 `{ctx.rel(out)}`（当前共 {total_slides} 页，完成 {reps_done} 处文本替换）",
        data={"path": ctx.rel(out)},
    )


def _parse_page_spec(spec: str | list[int], total: int) -> list[int]:
    """将 '1-3,5' 或 [1,2,5] 解析为 0-based 页索引列表。"""
    if isinstance(spec, list):
        idxs = [int(x) - 1 for x in spec]
    else:
        idxs = []
        for part in str(spec or "").split(","):
            s = part.strip()
            if not s:
                continue
            if "-" in s:
                a, b = s.split("-", 1)
                idxs.extend(range(int(a) - 1, int(b)))
            else:
                idxs.append(int(s) - 1)
    return [i for i in idxs if 0 <= i < total]


@tool(
    "pdf_ops",
    "专业 PDF 文档处理与改写工具：\n"
    "- info: 查看 PDF 页数、尺寸、元数据及可填写的表单字段（AcroForm）；\n"
    "- merge: 将多份 PDF 合并为一份完整 PDF；\n"
    "- extract_pages: 按页码范围（如 '1-3,5'）提取或裁剪指定页生成新 PDF；\n"
    "- stamp_text: 为 PDF 批量添加页眉、页脚或半透明斜向水印（如「内部审阅稿」「机密」）；\n"
    "- fill_form: 自动填写 PDF 交互式表单字段（如申请表、备案表）并输出新 PDF。",
    {
        "action": {
            "type": "string",
            "enum": ["info", "merge", "extract_pages", "stamp_text", "fill_form"],
        },
        "input_path": {"type": "string", "description": "输入 PDF 路径（info / extract_pages / stamp_text / fill_form 使用）"},
        "input_paths": {"type": "array", "items": {"type": "string"}, "description": "merge 时待合并的多个 PDF 文件路径"},
        "output_path": {"type": "string", "description": "输出 PDF 路径"},
        "pages": {"type": "string", "description": "extract_pages 页码范围（1 起始，如 '1-3,5'）"},
        "stamp": {"type": "string", "description": "stamp_text 要加盖的水印或页眉文字"},
        "position": {"type": "string", "enum": ["watermark", "header", "footer"], "description": "stamp_text 位置（默认 watermark）"},
        "form_fields": {"type": "object", "description": "fill_form 字段键值对 {字段名: 值}"},
    },
    ["action"],
    risk="write",
    summary_keys=("action", "input_path", "output_path"),
)
async def pdf_ops(args: dict[str, Any], ctx: ToolContext) -> ToolResult:
    act = args["action"]

    def _work() -> tuple[str, str | None]:
        from pypdf import PdfReader, PdfWriter

        if act == "info":
            src = ctx.resolve(args.get("input_path"), must_exist=True, read_only=True)
            reader = PdfReader(str(src))
            n = len(reader.pages)
            box = reader.pages[0].mediabox if n else None
            size_str = f"{float(box.width):.0f} × {float(box.height):.0f} pt" if box else "未知"
            fields = reader.get_fields() or {}
            lines = [
                f"### PDF 文档信息：`{ctx.rel(src)}`",
                f"- **页数**: {n} 页  |  **首页面积**: {size_str}",
                f"- **元数据**: {dict(reader.metadata or {})}",
            ]
            if fields:
                lines.append(f"- **可填写表单字段（{len(fields)} 个）**: {', '.join(list(fields.keys())[:40])}")
            return "\n".join(lines), None

        if act == "merge":
            in_list = args.get("input_paths") or []
            if len(in_list) < 2:
                raise ToolError("merge 至少需要提供 2 个 PDF 文件路径")
            out = ctx.resolve(args.get("output_path") or "outputs/merged.pdf")
            writer = PdfWriter()
            total = 0
            for raw_p in in_list:
                rp = ctx.resolve(raw_p, must_exist=True, read_only=True)
                rd = PdfReader(str(rp))
                for pg in rd.pages:
                    writer.add_page(pg)
                    total += 1
            out.parent.mkdir(parents=True, exist_ok=True)
            with open(out, "wb") as f:
                writer.write(f)
            return f"✅ 已将 {len(in_list)} 份 PDF 合并为 `{ctx.rel(out)}`（共 {total} 页）", ctx.rel(out)

        src = ctx.resolve(args.get("input_path"), must_exist=True, read_only=True)
        out = ctx.resolve(args.get("output_path") or str(src.with_name(f"{src.stem}_修订版.pdf")))
        reader = PdfReader(str(src))

        if act == "extract_pages":
            idxs = _parse_page_spec(args.get("pages") or "1", len(reader.pages))
            if not idxs:
                raise ToolError("未匹配到有效页码")
            writer = PdfWriter()
            for i in idxs:
                writer.add_page(reader.pages[i])
            out.parent.mkdir(parents=True, exist_ok=True)
            with open(out, "wb") as f:
                writer.write(f)
            return f"✅ 已提取 {len(idxs)} 页生成新 PDF `{ctx.rel(out)}`", ctx.rel(out)

        if act == "stamp_text":
            stamp = str(args.get("stamp") or "").strip()
            if not stamp:
                raise ToolError("stamp_text 需要提供 stamp 文本")
            pos = str(args.get("position") or "watermark")
            import io as _io
            import matplotlib
            matplotlib.use("Agg")
            import matplotlib.pyplot as plt
            from omniagent.research.plots import academic_style

            academic_style()
            pg0 = reader.pages[0]
            w_in = float(pg0.mediabox.width) / 72.0
            h_in = float(pg0.mediabox.height) / 72.0
            fig = plt.figure(figsize=(w_in, h_in))
            fig.patch.set_alpha(0.0)
            ax = fig.add_axes([0, 0, 1, 1])
            ax.set_axis_off()
            ax.patch.set_alpha(0.0)
            if pos == "header":
                ax.text(0.5, 0.965, stamp, ha="center", va="top", fontsize=9.5, color="#64748b", alpha=0.85)
            elif pos == "footer":
                ax.text(0.5, 0.03, stamp, ha="center", va="bottom", fontsize=9.5, color="#64748b", alpha=0.85)
            else:
                ax.text(0.5, 0.5, stamp, ha="center", va="center", fontsize=34, color="#64748b", alpha=0.16, rotation=32)
            buf = _io.BytesIO()
            fig.savefig(buf, format="pdf", transparent=True)
            plt.close(fig)
            buf.seek(0)
            stamp_page = PdfReader(buf).pages[0]

            writer = PdfWriter(clone_from=reader)
            for pg in writer.pages:
                pg.merge_page(stamp_page)
            out.parent.mkdir(parents=True, exist_ok=True)
            with open(out, "wb") as f:
                writer.write(f)
            return f"✅ 已为 {len(reader.pages)} 页添加{pos}标记「{stamp}」并输出至 `{ctx.rel(out)}`", ctx.rel(out)

        if act == "fill_form":
            fdata = dict(args.get("form_fields") or {})
            if not fdata:
                raise ToolError("fill_form 需要提供 form_fields 字典")
            writer = PdfWriter()
            writer.append(reader)
            for pg in writer.pages:
                writer.update_page_form_field_values(pg, {str(k): str(v) for k, v in fdata.items()})
            out.parent.mkdir(parents=True, exist_ok=True)
            with open(out, "wb") as f:
                writer.write(f)
            return f"✅ 已填写 {len(fdata)} 个 PDF 表单字段并保存至 `{ctx.rel(out)}`", ctx.rel(out)

        raise ToolError(f"未知 pdf_ops 操作: {act}")

    msg, rel_out = await asyncio.to_thread(_work)
    return ToolResult(msg, data={"path": rel_out} if rel_out else {})


DOCUMENT_TOOLS = [create_document, create_presentation, create_spreadsheet, edit_presentation, pdf_ops]
