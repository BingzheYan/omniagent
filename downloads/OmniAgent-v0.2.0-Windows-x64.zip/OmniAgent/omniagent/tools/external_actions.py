"""自主外部系统发现接入、双向操作与动态跟踪工具集（External Actions & Autonomous Integration Tools）：
1. connector_manage — 智能体自主发现（OpenAPI/Swagger/GraphQL/环境变量）、动态注册与测试外部软件连接器
2. email_ops        — 双向邮件自动化（收件读取、草拟/发送线程回复、附件提取、往来动态持续追踪）
3. calendar_ops     — 日历与日程提醒自动化（读取日程、冲突检测、新增/改期/取消活动、生成 .ics 邀请、检查到期提醒）
4. browser_session  — 有状态交互式网页操作（跨步浏览、岗位/工单读取、自动填表、上传简历/盖章件、提交投递）
5. desktop_action   — 本机桌面联动操作（系统通知提醒弹窗、写入剪贴板、调用系统应用）
6. tracker_manage   — 外部事项持续追踪器（邮件回信监控、求职投递流水线、日程提醒、外部接口变更轮询）
"""
from __future__ import annotations

import asyncio
import json
import os
import platform
import re
from pathlib import Path
from typing import Any

import httpx

from omniagent.connectors import CONNECTOR_KINDS, ConnectorSpec, load_file_connectors, test_connector
from omniagent.connectors.protocols import (
    CalendarBackend,
    EmailBackend,
    InteractiveWebSession,
    TrackerStore,
    generate_ics_event,
    parse_ics_text,
)

from .base import ToolContext, ToolError, ToolResult, tool, truncate
from .integrations import get_available_connectors


def _save_workspace_connector(workspace: Path, spec: ConnectorSpec) -> None:
    cfg_file = workspace / ".omniagent" / "connectors.json"
    cfg_file.parent.mkdir(parents=True, exist_ok=True)
    existing: list[dict[str, Any]] = []
    if cfg_file.is_file():
        try:
            raw = json.loads(cfg_file.read_text(encoding="utf-8"))
            existing = list(raw.get("connectors", raw) if isinstance(raw, dict) else raw)
        except Exception:  # noqa: BLE001
            existing = []
    entry = {
        "name": spec.name,
        "title": spec.title,
        "kind": spec.kind,
        "description": spec.description,
        "config": spec.config,
        "enabled": spec.enabled,
    }
    existing = [x for x in existing if isinstance(x, dict) and x.get("name") != spec.name]
    existing.append(entry)
    cfg_file.write_text(json.dumps({"connectors": existing}, ensure_ascii=False, indent=2), encoding="utf-8")


def _connector_cfg_of_kind(ctx: ToolContext, kind: str, name: str = "") -> dict[str, Any]:
    conns = get_available_connectors(ctx)
    if name and name in conns:
        return dict(conns[name].config or {})
    for c in conns.values():
        if c.kind == kind:
            return dict(c.config or {})
    return {}


def _get_tracker_store(ctx: ToolContext) -> TrackerStore:
    st = ctx.state.get("_tracker_store")
    if isinstance(st, TrackerStore):
        return st
    st = TrackerStore(ctx.workspace / ".omniagent" / "trackers.db")
    ctx.state["_tracker_store"] = st
    return st


# ============================================================================ 1. 自主连接器发现与注册

@tool(
    "connector_manage",
    "智能体自主发现、动态接入并测试外部软件或 API 接口（无需人工预先配置）：\n"
    "- discover: 自动探测给定 URL 的 OpenAPI / Swagger 文档（/openapi.json, /swagger.json, /api/docs）或扫描工作区 .env 中的外部服务凭据；\n"
    "- register: 将外部软件/API/邮箱/日历/数据库/Webhook/MCP 动态注册为持久连接器，立即可用；\n"
    "- test: 验证连接器连通性与权限；\n"
    "- send_webhook: 直接向飞书/钉钉/企业微信/Slack/自定义 Webhook 推送消息卡片或通知。",
    {
        "action": {
            "type": "string",
            "enum": ["discover", "register", "test", "send_webhook"],
            "description": "操作类型",
        },
        "name": {"type": "string", "description": "连接器唯一标识（如 company_mail、ats_api、feishu_bot）"},
        "title": {"type": "string", "description": "连接器显示名称"},
        "kind": {
            "type": "string",
            "enum": list(CONNECTOR_KINDS),
            "description": "连接器协议类型：http_api / sqlite / local_folder / web_app / mcp / email / calendar / webhook / graphql",
        },
        "url": {"type": "string", "description": "discover 探测的基础 URL，或 webhook 地址"},
        "description": {"type": "string", "description": "用途与接口说明"},
        "config": {"type": "object", "description": "连接配置（如 base_url, auth_type, token, imap_host, smtp_host, caldav_url 等）"},
        "message": {"type": "string", "description": "send_webhook 时发送的通知正文（支持 Markdown）"},
    },
    ["action"],
    risk="write",
    summary_keys=("action", "name", "url", "kind"),
)
async def connector_manage(args: dict[str, Any], ctx: ToolContext) -> ToolResult:
    act = args["action"]

    if act == "discover":
        lines: list[str] = []
        url = str(args.get("url") or "").strip().rstrip("/")
        if url.startswith(("http://", "https://")):
            async with httpx.AsyncClient(follow_redirects=True, timeout=15) as client:
                found_spec = None
                for suffix in ("/openapi.json", "/swagger.json", "/api/openapi.json", "/v1/openapi.json", ""):
                    try:
                        r = await client.get(url + suffix)
                        if r.status_code < 400 and "json" in r.headers.get("content-type", ""):
                            data = r.json()
                            if isinstance(data, dict) and ("paths" in data or "openapi" in data or "swagger" in data):
                                found_spec = (url + suffix, data)
                                break
                    except Exception:  # noqa: BLE001
                        continue
                if found_spec:
                    spec_url, spec_json = found_spec
                    info = spec_json.get("info") or {}
                    paths = spec_json.get("paths") or {}
                    lines.append(f"✅ 成功发现 OpenAPI 接口规范：{info.get('title', url)} ({spec_url})")
                    lines.append(f"共包含 {len(paths)} 个 API 路径（前 25 个）：")
                    for p, methods in list(paths.items())[:25]:
                        if isinstance(methods, dict):
                            ms = ", ".join(m.upper() for m in methods.keys() if m.lower() in ("get", "post", "put", "patch", "delete"))
                            summary = next((v.get("summary", "") for v in methods.values() if isinstance(v, dict) and v.get("summary")), "")
                            lines.append(f"- `{ms}` `{p}` {summary}")
                else:
                    lines.append(f"未在 `{url}` 发现标准 OpenAPI JSON，可直接用 `browser_session` 或 `connector_manage(action='register', kind='http_api')` 接入。")

        # 扫描工作区 .env 变量名（只显示键名，不泄露密钥值）
        env_p = ctx.workspace / ".env"
        if env_p.is_file():
            keys = [
                line.split("=", 1)[0].strip()
                for line in env_p.read_text(encoding="utf-8", errors="replace").splitlines()
                if "=" in line and not line.strip().startswith("#")
            ]
            if keys:
                lines.append("工作区 `.env` 中检测到的配置键：" + ", ".join(keys[:30]))
        return ToolResult("\n".join(lines) or "请提供待探测的外部系统 URL 或检查工作区环境。")

    if act == "register":
        name = re.sub(r"[^\w.\-]", "", str(args.get("name") or "").strip())[:40]
        kind = str(args.get("kind") or "http_api")
        if not name or kind not in CONNECTOR_KINDS:
            raise ToolError(f"请提供合法的 name 与 kind（可选：{', '.join(CONNECTOR_KINDS)}）")
        cfg = dict(args.get("config") or {})
        if args.get("url") and "base_url" not in cfg and "url" not in cfg:
            cfg["base_url" if kind in ("http_api", "graphql") else "url"] = args["url"]
        spec = ConnectorSpec(
            name=name,
            title=str(args.get("title") or name),
            kind=kind,
            description=str(args.get("description") or ""),
            config=cfg,
            enabled=True,
            source="workspace",
        )
        _save_workspace_connector(ctx.workspace, spec)
        extra = [c for c in (ctx.state.get("extra_connectors") or []) if getattr(c, "name", None) != name]
        extra.append(spec)
        ctx.state["extra_connectors"] = extra
        return ToolResult(f"✅ 已动态注册外部连接器 `{name}`（{spec.title}，类型 `{kind}`），现在可直接调用对应工具交互。")

    if act == "test":
        conns = get_available_connectors(ctx)
        name = str(args.get("name") or "").strip()
        if name not in conns:
            raise ToolError(f"未找到连接器 `{name}`")
        res = await test_connector(conns[name])
        return ToolResult(f"{'✅' if res.get('ok') else '❌'} {res.get('summary')}", is_error=not res.get("ok"))

    if act == "send_webhook":
        conns = get_available_connectors(ctx)
        name = str(args.get("name") or "").strip()
        url = str(args.get("url") or "")
        if not url and name in conns:
            url = str(conns[name].config.get("webhook_url") or conns[name].config.get("url") or "")
        if not url.startswith(("http://", "https://")):
            raise ToolError("send_webhook 需要提供合法的 webhook url 或已注册的 webhook 连接器名称")
        msg = str(args.get("message") or "")
        # 自动适配飞书 / 钉钉 / 企业微信 / Slack / 通用 JSON 格式
        if "feishu" in url or "larksuite" in url:
            payload = {"msg_type": "text", "content": {"text": msg}}
        elif "dingtalk" in url or "oapi.dingtalk" in url:
            payload = {"msgtype": "text", "text": {"content": msg}}
        elif "qyapi.weixin" in url:
            payload = {"msgtype": "markdown", "markdown": {"content": msg}}
        else:
            payload = {"text": msg, "content": msg}
        async with httpx.AsyncClient(timeout=20) as client:
            r = await client.post(url, json=payload)
        return ToolResult(f"[HTTP {r.status_code}] 已推送外部 Webhook 消息：{r.text[:400]}", is_error=r.status_code >= 400)

    raise ToolError(f"未知操作: {act}")


# ============================================================================ 2. 双向邮件自动化与动态追踪

@tool(
    "email_ops",
    "连接用户邮箱（IMAP/SMTP 或本地沙箱邮箱）执行全流程邮件自动化：\n"
    "- list: 列出收件箱/已发送/草稿箱邮件（支持仅看未读 unread_only 与关键词 query 搜索）；\n"
    "- read: 读取单封邮件全文、往来线程历史，并可将附件提取保存到工作区 uploads/；\n"
    "- draft_reply / send_reply: 针对指定邮件草拟或直接发送回复（自动维护 In-Reply-To 与 References 邮件线程）；\n"
    "- send_email: 发送新邮件（支持附带工作区生成的报告/简历附件）；\n"
    "- track_thread: 对重要邮件线程开启后续回信跟踪，或立即检查对方是否已回信；\n"
    "- seed_inbound: （测试/模拟专用）向本地沙箱收件箱注入一封模拟外部来信。",
    {
        "action": {
            "type": "string",
            "enum": ["list", "read", "draft_reply", "send_reply", "send_email", "track_thread", "seed_inbound"],
        },
        "connector": {"type": "string", "description": "可选：指定已注册的 email 连接器名称"},
        "folder": {"type": "string", "description": "邮箱文件夹：INBOX / SENT / DRAFTS（默认 INBOX）"},
        "unread_only": {"type": "boolean", "description": "list 时是否只看未读邮件"},
        "query": {"type": "string", "description": "主题/发件人/正文检索词"},
        "message_id": {"type": "string", "description": "read / draft_reply / send_reply / track_thread 的目标邮件 ID"},
        "to": {"type": "string", "description": "收件人邮箱地址（send_email 必填；reply 时默认回复原发件人）"},
        "cc": {"type": "string", "description": "抄送邮箱地址"},
        "subject": {"type": "string", "description": "邮件主题"},
        "body": {"type": "string", "description": "邮件正文内容"},
        "attachments": {"type": "array", "items": {"type": "string"}, "description": "要随信发送的工作区附件路径列表"},
        "auto_track": {"type": "boolean", "description": "回复或发送后是否自动加入回信跟踪器（默认 true）"},
    },
    ["action"],
    risk="exec",
    summary_keys=("action", "subject", "to", "message_id", "query"),
)
async def email_ops(args: dict[str, Any], ctx: ToolContext) -> ToolResult:
    act = args["action"]
    cfg = _connector_cfg_of_kind(ctx, "email", str(args.get("connector") or ""))
    mb = EmailBackend(ctx.workspace, cfg)
    try:
        if act == "seed_inbound":
            rec = await asyncio.to_thread(
                mb.seed_inbound,
                sender=str(args.get("to") or "hr@techcorp.example"),
                subject=str(args.get("subject") or "外部来信"),
                body=str(args.get("body") or ""),
                in_reply_to=str(args.get("message_id") or ""),
                attachments=list(args.get("attachments") or []),
            )
            return ToolResult(f"已在沙箱收件箱收到外部邮件 `{rec['id']}`（Message-ID: {rec['message_id']}）：{rec['subject']}", data={"email": rec})

        if act == "list":
            msgs = await asyncio.to_thread(
                mb.list_messages,
                folder=str(args.get("folder") or "INBOX"),
                unread_only=bool(args.get("unread_only", False)),
                query=str(args.get("query") or ""),
            )
            if not msgs:
                return ToolResult("当前邮箱文件夹中没有匹配的邮件。")
            lines = [f"### 邮件列表（共 {len(msgs)} 封 · 模式: {mb.mode}）"]
            for m in msgs:
                flag = "🔵[未读]" if not m.get("is_read") else "⚪[已读]"
                lines.append(f"- `{m['id']}` {flag} **{m['subject']}** — 来自 `{m['sender']}`")
            return ToolResult("\n".join(lines), data={"messages": msgs})

        if act == "read":
            mid = str(args.get("message_id") or "").strip()
            if not mid:
                raise ToolError("read 操作需要提供 message_id")
            att_dir = ctx.workspace / "uploads" / "mail_attachments"
            msg = await asyncio.to_thread(mb.read_message, mid, save_attachments_dir=att_dir)
            lines = [
                f"### 📧 {msg['subject']}",
                f"- **ID**: `{msg['id']}`  |  **Message-ID**: `{msg['message_id']}`  |  **线程**: `{msg['thread_id']}`",
                f"- **发件人**: {msg['sender']}",
                f"- **收件人**: {msg['recipients']}",
            ]
            if msg.get("attachments"):
                lines.append(f"- **附件**: {', '.join(msg['attachments'])}")
            lines.append("\n" + str(msg.get("body") or ""))
            if len(msg.get("thread_messages") or []) > 1:
                lines.append(f"\n---\n*该邮件线程共 {len(msg['thread_messages'])} 封往来记录。*")
            return ToolResult(truncate("\n".join(lines), 25_000), data={"email": msg})

        if act in ("draft_reply", "send_reply", "send_email"):
            draft_only = act == "draft_reply"
            reply_id = str(args.get("message_id") or "") if act != "send_email" else ""
            if act != "send_email" and not reply_id:
                raise ToolError(f"{act} 需要提供原邮件的 message_id")
            att_paths = [ctx.resolve(p, must_exist=True) for p in (args.get("attachments") or [])]
            res = await asyncio.to_thread(
                mb.send_or_draft,
                to=str(args.get("to") or ""),
                cc=str(args.get("cc") or ""),
                subject=str(args.get("subject") or ""),
                body=str(args.get("body") or ""),
                reply_to_id=reply_id,
                attachments=att_paths,
                draft_only=draft_only,
            )
            if not draft_only and args.get("auto_track", True):
                trk = _get_tracker_store(ctx)
                trk.upsert(
                    kind="email_thread",
                    title=f"邮件跟进：{res['subject']} ({res['to']})",
                    target_ref=res["thread_id"],
                    status="waiting_reply",
                    meta={"to": res["to"], "last_sent_id": res["id"], "message_id": res["message_id"]},
                    note=f"已发送邮件至 {res['to']}，持续跟踪后续回复",
                )
            verb = "已保存回复草稿" if draft_only else "已成功发送邮件并开启线程动态追踪"
            return ToolResult(
                f"✅ {verb}：`{res['subject']}` → `{res['to']}`（ID: `{res['id']}`, Thread: `{res['thread_id']}`）",
                data={"result": res},
            )

        if act == "track_thread":
            mid = str(args.get("message_id") or "").strip()
            if not mid:
                raise ToolError("track_thread 需要提供 message_id 或 thread_id")
            st = await asyncio.to_thread(mb.thread_status, mid)
            if not st["found"]:
                raise ToolError(f"未找到邮件线程: {mid}")
            trk = _get_tracker_store(ctx)
            new_status = "reply_received" if st["has_new_external_reply"] else "waiting_reply"
            rec = trk.upsert(
                kind="email_thread",
                title=f"邮件跟进：{st['latest_subject']}",
                target_ref=st["thread_id"],
                status=new_status,
                note=f"最新状态检查：共 {st['message_count']} 封往来，最新发件人 {st['latest_sender']}",
            )
            return ToolResult(
                f"### 邮件线程追踪状态 (`{st['thread_id']}`)\n"
                f"- **往来封数**: {st['message_count']}\n"
                f"- **是否有对方新回复**: {'✅ 是（收件箱有新回信）' if st['has_new_external_reply'] else '⏳ 暂未收到新回信'}\n"
                f"- **最新摘要**: [{st['latest_sender']}] {st['latest_snippet']}\n"
                f"- **跟踪器 ID**: `{rec['id']}`",
                data={"thread": st, "tracker": rec},
            )

        raise ToolError(f"未知 email_ops 操作: {act}")
    finally:
        mb.close()


# ============================================================================ 3. 日历与提醒自动化

@tool(
    "calendar_ops",
    "连接日历系统读取日程、检测时间冲突、创建/修改/取消活动并管理到期提醒（支持 CalDAV 同步与标准 .ics 日历文件导入导出）：\n"
    "- list: 查询指定时间范围内的日程安排；\n"
    "- check_conflicts: 检查拟安排时段是否与现有会议冲突；\n"
    "- add / update: 新建或修改日历活动（自动设置提前提醒分钟数，可选导出标准 .ics 会议邀请文件）；\n"
    "- delete: 取消并删除日程；\n"
    "- reminders: 检查即将到期的日程提醒；\n"
    "- import_ics: 从外部 .ics 日历文件批量导入日程。",
    {
        "action": {
            "type": "string",
            "enum": ["list", "check_conflicts", "add", "update", "delete", "reminders", "import_ics"],
        },
        "connector": {"type": "string", "description": "可选：已注册的 calendar 连接器名称"},
        "event_id": {"type": "string", "description": "update / delete 时的日程 ID"},
        "title": {"type": "string", "description": "活动/会议标题"},
        "start_time": {"type": "string", "description": "开始时间 ISO 格式，如 2026-11-24T14:00"},
        "end_time": {"type": "string", "description": "结束时间 ISO 格式，如 2026-11-24T15:30"},
        "location": {"type": "string", "description": "地点或线上会议链接"},
        "description": {"type": "string", "description": "议程说明或备注"},
        "attendees": {"type": "array", "items": {"type": "string"}, "description": "参会人邮箱列表"},
        "reminder_minutes": {"type": "integer", "description": "提前提醒分钟数（默认 15 分钟）"},
        "export_ics_path": {"type": "string", "description": "可选：同时将日程导出为标准 .ics 文件（如 outputs/invite.ics）"},
        "ics_path": {"type": "string", "description": "import_ics 时要读取的 .ics 文件路径"},
        "within_minutes": {"type": "integer", "description": "reminders 检查未来多少分钟内的提醒（默认 120）"},
    },
    ["action"],
    risk="write",
    summary_keys=("action", "title", "start_time", "event_id"),
)
async def calendar_ops(args: dict[str, Any], ctx: ToolContext) -> ToolResult:
    act = args["action"]
    cfg = _connector_cfg_of_kind(ctx, "calendar", str(args.get("connector") or ""))
    cb = CalendarBackend(ctx.workspace, cfg)
    try:
        if act == "list":
            evs = cb.list_events(start_iso=str(args.get("start_time") or ""), end_iso=str(args.get("end_time") or ""))
            if not evs:
                return ToolResult("指定时间段内暂无日程安排。")
            lines = [f"### 📅 日程安排（共 {len(evs)} 项）"]
            for e in evs:
                loc = f" @ {e['location']}" if e.get("location") else ""
                lines.append(f"- `{e['id']}` **{e['start_iso']} ~ {e['end_iso']}** · {e['title']}{loc}（提前 {e['reminder_minutes']}m 提醒）")
            return ToolResult("\n".join(lines), data={"events": evs})

        if act == "check_conflicts":
            st, et = str(args.get("start_time") or ""), str(args.get("end_time") or "")
            if not st or not et:
                raise ToolError("check_conflicts 需要提供 start_time 与 end_time")
            conflicts = cb.check_conflicts(st, et)
            if not conflicts:
                return ToolResult(f"✅ 时段 `{st} ~ {et}` 空闲，无任何日程冲突。")
            lines = [f"⚠️ 检测到 {len(conflicts)} 项时间冲突："]
            for c in conflicts:
                lines.append(f"- `{c['id']}` {c['title']}（{c['start_iso']} ~ {c['end_iso']}）")
            return ToolResult("\n".join(lines), data={"conflicts": conflicts})

        if act in ("add", "update"):
            title = str(args.get("title") or "").strip()
            st = str(args.get("start_time") or "").strip()
            if not title or not st:
                raise ToolError("新建或更新日程需要提供 title 和 start_time")
            ev = await cb.upsert_event(
                title=title,
                start_iso=st,
                end_iso=str(args.get("end_time") or ""),
                location=str(args.get("location") or ""),
                description=str(args.get("description") or ""),
                attendees=list(args.get("attendees") or []),
                reminder_minutes=int(args.get("reminder_minutes") if args.get("reminder_minutes") is not None else 15),
                event_id=str(args.get("event_id") or ""),
            )
            saved_ics = None
            if args.get("export_ics_path"):
                p = ctx.resolve(args["export_ics_path"])
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text(generate_ics_event(ev), encoding="utf-8")
                saved_ics = ctx.rel(p)

            # 同步登记到外部跟踪器以便统一提醒
            _get_tracker_store(ctx).upsert(
                kind="calendar_reminder",
                title=f"日程：{ev['title']}",
                target_ref=ev["id"],
                status="scheduled",
                due_iso=ev["start_iso"],
                meta={"location": ev["location"], "reminder_minutes": ev["reminder_minutes"]},
                note=f"已排期 {ev['start_iso']}，提前 {ev['reminder_minutes']} 分钟提醒",
            )
            warn = f"\n⚠️ 注意：与现有 {len(ev['conflicts'])} 个日程存在时间重叠！" if ev.get("conflicts") else ""
            ics_note = f"\n📎 已导出标准日历邀请文件：`{saved_ics}`" if saved_ics else ""
            return ToolResult(
                f"✅ 已排定日程 `{ev['id']}`：**{ev['title']}**（{ev['start_iso']} ~ {ev['end_iso']}，提前 {ev['reminder_minutes']} 分钟提醒）{warn}{ics_note}",
                data={"event": ev, **({"path": saved_ics} if saved_ics else {})},
            )

        if act == "delete":
            eid = str(args.get("event_id") or "").strip()
            ok = cb.delete_event(eid)
            return ToolResult(f"{'✅ 已取消日程' if ok else '未找到日程'} `{eid}`")

        if act == "reminders":
            mins = int(args.get("within_minutes") or 120)
            due = cb.due_reminders(within_minutes=mins)
            if not due:
                return ToolResult(f"未来 {mins} 分钟内暂无即将触发的日程提醒。")
            lines = [f"🔔 即将到来的日程提醒（{len(due)} 项）："]
            for e in due:
                lines.append(f"- **{e['title']}** · 开始时间 `{e['start_iso']}` · 地点：{e.get('location') or '未指定'}")
            return ToolResult("\n".join(lines), data={"reminders": due})

        if act == "import_ics":
            p = ctx.resolve(args.get("ics_path"), must_exist=True, read_only=True)
            parsed = parse_ics_text(p.read_text(encoding="utf-8", errors="replace"))
            imported = []
            for item in parsed:
                ev = await cb.upsert_event(
                    title=item["title"], start_iso=item["start_iso"], end_iso=item["end_iso"],
                    location=item["location"], description=item["description"],
                )
                imported.append(ev)
            return ToolResult(f"✅ 已从 `{ctx.rel(p)}` 导入 {len(imported)} 项日程。", data={"events": imported})

        raise ToolError(f"未知日历操作: {act}")
    finally:
        cb.close()


# ============================================================================ 4. 有状态交互式网页自动化（求职投递 / OA / CRM / 工单填报）

def _format_web_snap(snap: dict[str, Any], note: str = "") -> str:
    head = f"{note + chr(10) if note else ''}🌐 [{snap['status']}] **{snap['title'] or snap['url']}**  (`{snap['url']}`)"
    parts = [head]
    if snap["text"]:
        parts.append("\n### 页面内容摘录\n" + snap["text"][:8000])
    if snap["controls"]:
        parts.append(f"\n### 可交互控件与表单项（共 {len(snap['controls'])} 个，表单 {snap['form_count']} 个）")
        parts.extend(f"- {c}" for c in snap["controls"])
    return "\n".join(parts)


@tool(
    "browser_session",
    "有状态的交互式浏览器会话引擎（支持跨步登录态保持、链接点击、表单自动填写、文件/简历上传与申请提交）：\n"
    "适用于求职招聘网站（读取岗位 JD → 根据个人经历定制求职信 → 填写基本信息 → 上传简历 PDF → 提交投递）、企业 OA 审批、CRM 录入、工单系统等需要真实网页交互的场景。\n"
    "操作步骤：\n"
    "1. open: 打开目标网址并返回带编号 `[e1]..[eN]` 的页面控件快照；\n"
    "2. fill: 按控件引用（如 `e2`）或字段名填写文本（也可传 `fields` 字典一次性批量填写多个字段！）；\n"
    "3. upload: 将工作区内的文件（如定制好的简历/Cover Letter PDF）挂载到文件上传框；\n"
    "4. click: 点击页面链接跳转；\n"
    "5. submit: 提交当前填写完毕的表单并返回提交结果页快照；\n"
    "6. snapshot / close: 查看当前页状态或关闭会话。",
    {
        "action": {
            "type": "string",
            "enum": ["open", "snapshot", "fill", "upload", "click", "submit", "close"],
        },
        "session_name": {"type": "string", "description": "会话槽名称（默认 default，可同时维护多个外部网站会话）"},
        "url": {"type": "string", "description": "open 时的目标 URL"},
        "target": {"type": "string", "description": "控件编号（如 e1）或 input 的 name / label"},
        "value": {"type": "string", "description": "fill 时填入单个控件的值"},
        "fields": {"type": "object", "description": "fill 时可一次性传入 {字段名或控件编号: 填写值} 批量填表"},
        "file_path": {"type": "string", "description": "upload 时工作区内的文件路径（如 outputs/cover_letter.pdf）"},
        "headers": {"type": "object", "description": "open 时可选附加的认证请求头或 Cookie"},
    },
    ["action"],
    risk="exec",
    summary_keys=("action", "url", "target", "file_path"),
)
async def browser_session(args: dict[str, Any], ctx: ToolContext) -> ToolResult:
    act = args["action"]
    sname = str(args.get("session_name") or "default")
    pool: dict[str, InteractiveWebSession] = ctx.state.setdefault("_web_sessions", {})

    if act == "close":
        sess = pool.pop(sname, None)
        if sess:
            await sess.close()
        return ToolResult(f"已关闭交互式网页会话 `{sname}`。")

    if act == "open":
        url = str(args.get("url") or "").strip()
        if not url.startswith(("http://", "https://")):
            raise ToolError("open 需要提供以 http:// 或 https:// 开头的完整 URL")
        old = pool.pop(sname, None)
        if old:
            await old.close()
        sess = InteractiveWebSession(headers=args.get("headers"))
        pool[sname] = sess
        snap = await sess.goto(url)
        return ToolResult(_format_web_snap(snap), is_error=snap["status"] >= 400, data={"snapshot": snap})

    sess = pool.get(sname)
    if sess is None:
        raise ToolError(f"网页会话 `{sname}` 尚未打开，请先调用 browser_session(action='open', url=...)")

    if act == "snapshot":
        return ToolResult(_format_web_snap(sess.snapshot()))

    if act == "fill":
        logs: list[str] = []
        if isinstance(args.get("fields"), dict) and args["fields"]:
            for k, v in args["fields"].items():
                logs.append(sess.fill(str(k), str(v)))
        elif args.get("target") is not None:
            logs.append(sess.fill(str(args["target"]), str(args.get("value") or "")))
        else:
            raise ToolError("fill 需要提供 target + value，或提供 fields 字典")
        return ToolResult("✅ 表单填写完成：\n- " + "\n- ".join(logs))

    if act == "upload":
        if not args.get("target") or not args.get("file_path"):
            raise ToolError("upload 需要同时提供 target（文件控件引用或字段名）和 file_path")
        fpath = ctx.resolve(args["file_path"], must_exist=True, read_only=True)
        msg = sess.upload_file(str(args["target"]), fpath)
        return ToolResult(f"✅ {msg}")

    if act in ("click", "submit"):
        snap = await sess.click_or_submit(str(args.get("target") or ""))
        verb = "已点击跳转" if act == "click" else "✅ 已提交表单，服务器响应如下："
        return ToolResult(_format_web_snap(snap, verb), is_error=snap["status"] >= 400, data={"snapshot": snap})

    raise ToolError(f"未知 browser_session 操作: {act}")


# ============================================================================ 5. 本机桌面系统联动操作

@tool(
    "desktop_action",
    "在本机桌面环境执行跨应用辅助操作：发送操作系统桌面通知提醒（notify）、向系统剪贴板写入生成好的文案/代码（set_clipboard）。",
    {
        "action": {"type": "string", "enum": ["notify", "set_clipboard"]},
        "title": {"type": "string", "description": "notify 通知标题"},
        "message": {"type": "string", "description": "通知正文或要写入剪贴板的文本"},
    },
    ["action", "message"],
    risk="exec",
    summary_keys=("action", "title"),
)
async def desktop_action(args: dict[str, Any], ctx: ToolContext) -> ToolResult:
    if not getattr(ctx.settings, "allow_desktop_inspect", True):
        raise ToolError("当前多租户服务器已禁用本机桌面控制。")
    act = args["action"]
    msg = str(args.get("message") or "")
    sys_name = platform.system()

    if act == "notify":
        title = str(args.get("title") or "OmniAgent 提醒").replace('"', "'")
        clean_msg = msg.replace('"', "'")[:240]
        if sys_name == "Darwin" and not os.environ.get("PYTEST_CURRENT_TEST"):
            script = f'display notification "{clean_msg}" with title "{title}"'
            proc = await asyncio.create_subprocess_exec("osascript", "-e", script,
                                                        stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL)
            await asyncio.wait_for(proc.wait(), timeout=8)
        elif sys_name == "Windows" and not os.environ.get("PYTEST_CURRENT_TEST"):
            ps_notify = (
                "Add-Type -AssemblyName System.Windows.Forms; Add-Type -AssemblyName System.Drawing; "
                "$n = New-Object System.Windows.Forms.NotifyIcon; "
                "$n.Icon = [System.Drawing.SystemIcons]::Information; $n.Visible = $true; "
                "$n.ShowBalloonTip(5000, $env:OMNI_NT_TITLE, $env:OMNI_NT_MSG, [System.Windows.Forms.ToolTipIcon]::Info); "
                "Start-Sleep -Milliseconds 1200; $n.Dispose()"
            )
            try:
                proc = await asyncio.create_subprocess_exec(
                    "powershell", "-NoProfile", "-NonInteractive", "-WindowStyle", "Hidden", "-Command", ps_notify,
                    env={**os.environ, "OMNI_NT_TITLE": title, "OMNI_NT_MSG": clean_msg},
                    stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL,
                )
                await asyncio.wait_for(proc.wait(), timeout=8)
            except Exception:  # noqa: BLE001
                pass
        await ctx.emit({"type": "status", "message": f"🔔 {title}：{clean_msg}"})
        return ToolResult(f"🔔 已发送系统提醒：【{title}】{clean_msg}")

    if act == "set_clipboard":
        if sys_name == "Darwin" and not os.environ.get("PYTEST_CURRENT_TEST"):
            proc = await asyncio.create_subprocess_exec("pbcopy", stdin=asyncio.subprocess.PIPE)
            await asyncio.wait_for(proc.communicate(msg.encode("utf-8")), timeout=8)
            return ToolResult(f"✅ 已将 {len(msg)} 字符写入系统剪贴板。")
        if sys_name == "Windows" and not os.environ.get("PYTEST_CURRENT_TEST"):
            proc = await asyncio.create_subprocess_exec(
                "powershell", "-NoProfile", "-NonInteractive", "-Command",
                "[Console]::InputEncoding=[System.Text.Encoding]::UTF8; Set-Clipboard -Value ([Console]::In.ReadToEnd())",
                stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL,
            )
            await asyncio.wait_for(proc.communicate(msg.encode("utf-8")), timeout=8)
            return ToolResult(f"✅ 已将 {len(msg)} 字符写入系统剪贴板。")
        return ToolResult(f"✅ 已准备剪贴板内容（{len(msg)} 字符）。")

    raise ToolError(f"未知桌面操作: {act}")


# ============================================================================ 6. 跨会话外部事项持续追踪器

@tool(
    "tracker_manage",
    "管理跨会话的【外部事项动态追踪器】（如：持续跟踪已回复的重要邮件是否收到回信、管理求职岗位投递台账与 Cover Letter 记录、监控外部 API 状态变更、巡检即将到期的日程提醒）：\n"
    "- upsert: 创建或更新一条追踪记录（kind 支持 email_thread / job_application / calendar_reminder / api_monitor / general）；\n"
    "- list: 查看当前活跃的追踪事项与历史变更轨迹；\n"
    "- poll: 立即主动巡检所有活跃追踪项（自动查收邮件新回复、检查近 1 小时日程提醒、轮询监控接口变化）；\n"
    "- delete: 移除追踪项。",
    {
        "action": {"type": "string", "enum": ["upsert", "list", "poll", "delete"]},
        "tracker_id": {"type": "string", "description": "更新或删除时的追踪 ID"},
        "kind": {
            "type": "string",
            "enum": ["email_thread", "job_application", "calendar_reminder", "api_monitor", "general"],
        },
        "title": {"type": "string", "description": "事项名称（如：投递字节跳动高级后端工程师 / 跟进供应商报价邮件）"},
        "target_ref": {"type": "string", "description": "外部关联标识（如邮件 Thread-ID、岗位 URL、监控 API URL、日程 ID）"},
        "status": {"type": "string", "description": "当前状态（如 watching / waiting_reply / submitted / interview / completed）"},
        "due_time": {"type": "string", "description": "可选跟进截止时间 ISO 格式"},
        "meta": {"type": "object", "description": "附加结构化信息（如 company, role, cover_letter_path, resume_path）"},
        "note": {"type": "string", "description": "本次状态更新备注"},
    },
    ["action"],
    summary_keys=("action", "kind", "title", "status"),
)
async def tracker_manage(args: dict[str, Any], ctx: ToolContext) -> ToolResult:
    st = _get_tracker_store(ctx)
    act = args["action"]

    if act == "upsert":
        title = str(args.get("title") or "").strip()
        if not title and not args.get("tracker_id"):
            raise ToolError("新建追踪项需要提供 title")
        rec = st.upsert(
            tracker_id=str(args.get("tracker_id") or ""),
            kind=str(args.get("kind") or "general"),
            title=title,
            target_ref=str(args.get("target_ref") or ""),
            status=str(args.get("status") or "watching"),
            due_iso=str(args.get("due_time") or ""),
            meta=args.get("meta") or {},
            note=str(args.get("note") or ""),
        )
        return ToolResult(f"✅ 已记录外部追踪项 `{rec['id']}`：【{rec['kind']}】{rec['title']}（状态: `{rec['status']}`）",
                          data={"tracker": rec})

    if act == "list":
        items = st.list_trackers(kind=str(args.get("kind") or ""), status=str(args.get("status") or ""))
        if not items:
            return ToolResult("当前暂无外部追踪事项。")
        lines = [f"### 📡 外部动态追踪台账（共 {len(items)} 项）"]
        for it in items:
            last_note = it["history"][-1]["note"] if it.get("history") else ""
            lines.append(f"- `{it['id']}` [{it['kind']} · **{it['status']}**] **{it['title']}**"
                         + (f" (`{it['target_ref']}`)" if it["target_ref"] else "")
                         + (f"\n  - 最新动态：{last_note}" if last_note else ""))
        return ToolResult("\n".join(lines), data={"trackers": items})

    if act == "poll":
        email_cfg = _connector_cfg_of_kind(ctx, "email")
        cal_cfg = _connector_cfg_of_kind(ctx, "calendar")
        alerts = await st.poll_updates(ctx.workspace, email_cfg=email_cfg, calendar_cfg=cal_cfg)
        if not alerts:
            return ToolResult("✅ 已完成全量外部追踪巡检：暂无新邮件回复、到期提醒或接口异动。")
        lines = [f"🔔 巡检发现 {len(alerts)} 项外部新动态/提醒："]
        for a in alerts:
            lines.append(f"- **[{a['kind']}] {a['title']}** — {a['detail']}")
        return ToolResult("\n".join(lines), data={"alerts": alerts})

    if act == "delete":
        ok = st.delete(str(args.get("tracker_id") or ""))
        return ToolResult(f"{'已删除' if ok else '未找到'}追踪项 `{args.get('tracker_id')}`")

    raise ToolError(f"未知 tracker_manage 操作: {act}")


EXTERNAL_ACTION_TOOLS = [connector_manage, email_ops, calendar_ops, browser_session, desktop_action, tracker_manage]
