from __future__ import annotations

import logging

from .base import Tool, ToolContext, ToolError, ToolRegistry, ToolResult, tool
from .documents import DOCUMENT_TOOLS
from .files import FILE_TOOLS
from .planning import PLANNING_TOOLS
from .python_exec import PYTHON_TOOLS
from .shell import SHELL_TOOLS
from .web import WEB_TOOLS

__all__ = ["Tool", "ToolContext", "ToolError", "ToolRegistry", "ToolResult", "tool", "build_default_registry"]
log = logging.getLogger(__name__)


def _optional(module: str, attr: str) -> list[Tool]:
    """可选工具模块（research / skills / vision 等），缺失时不影响启动。"""
    try:
        mod = __import__(f"omniagent.tools.{module}", fromlist=[attr])
        return list(getattr(mod, attr, []))
    except ImportError as e:
        log.debug("optional tools %s unavailable: %s", module, e)
        return []


def build_default_registry(settings=None) -> ToolRegistry:
    tools = PLANNING_TOOLS + FILE_TOOLS + SHELL_TOOLS + PYTHON_TOOLS + DOCUMENT_TOOLS + WEB_TOOLS
    tools += _optional("skills", "SKILL_TOOLS")
    tools += _optional("vision", "VISION_TOOLS")
    tools += _optional("research", "RESEARCH_TOOLS")
    tools += _optional("integrations", "INTEGRATION_TOOLS")
    tools += _optional("external_actions", "EXTERNAL_ACTION_TOOLS")
    tools += _optional("verification", "VERIFICATION_TOOLS")
    tools += _optional("memory", "MEMORY_TOOLS")
    tools += _optional("expense", "EXPENSE_TOOLS")
    tools += _optional("web_automation", "WEB_AUTOMATION_TOOLS")
    reg = ToolRegistry(tools)
    if settings is not None and not getattr(settings, "tavily_api_key", None):
        reg.unregister("web_search")
    return reg
