"""持久化 Python 内核驱动（作为子进程运行）。

协议：每行一个 JSON 请求 {"code": "..."}；执行结束后输出一行
  <<<OMNI_RESULT>>>{"ok":..,"output":..,"result":..,"figures":[..]}
变量在多次执行之间保留（类似 Jupyter）。matplotlib 图像会被自动保存为 PNG。
"""
import ast
import contextlib
import io
import json
import os
import sys
import traceback

os.environ.setdefault("MPLBACKEND", "Agg")
MARKER = "<<<OMNI_RESULT>>>"
FIG_DIR = sys.argv[1] if len(sys.argv) > 1 else "outputs/figures"
_real_stdout = sys.stdout
_ns = {"__name__": "__main__"}
_counter = [0]


def _setup_matplotlib():
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        from matplotlib import font_manager

        # 自动配置中文字体，避免中文显示为方框
        candidates = ["PingFang SC", "Heiti SC", "Hiragino Sans GB", "Arial Unicode MS", "Microsoft YaHei",
                      "SimHei", "Noto Sans CJK SC", "Source Han Sans SC", "WenQuanYi Micro Hei"]
        available = {f.name for f in font_manager.fontManager.ttflist}
        chosen = [c for c in candidates if c in available]
        if chosen:
            plt.rcParams["font.sans-serif"] = chosen + list(plt.rcParams.get("font.sans-serif", []))
        plt.rcParams["axes.unicode_minus"] = False
    except Exception:
        pass


def _save_figures():
    paths = []
    plt = sys.modules.get("matplotlib.pyplot")
    if plt is None:
        return paths
    try:
        nums = plt.get_fignums()
        if nums:
            os.makedirs(FIG_DIR, exist_ok=True)
        for num in nums:
            _counter[0] += 1
            name = f"figure_{os.getpid()}_{_counter[0]}.png"
            path = os.path.join(FIG_DIR, name)
            plt.figure(num).savefig(path, dpi=130, bbox_inches="tight")
            paths.append(path)
        plt.close("all")
    except Exception as e:  # noqa: BLE001
        paths.append(f"(保存图像失败: {e})")
    return paths


def _run(code):
    buf = io.StringIO()
    ok, result = True, None
    with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
        try:
            tree = ast.parse(code, "<cell>", "exec")
            last = None
            if tree.body and isinstance(tree.body[-1], ast.Expr):
                last = ast.Expression(tree.body.pop().value)
            exec(compile(tree, "<cell>", "exec"), _ns)
            if last is not None:
                val = eval(compile(last, "<cell>", "eval"), _ns)
                if val is not None:
                    try:
                        import pandas as pd  # noqa: F401

                        if hasattr(val, "to_string") and hasattr(val, "shape"):
                            result = val.to_string(max_rows=60, max_cols=30)
                        elif type(val).__module__ == "numpy" and getattr(val, "shape", None) == ():
                            result = str(val)
                        else:
                            result = repr(val)
                    except Exception:
                        result = repr(val)
        except SystemExit as e:
            print(f"SystemExit: {e.code}")
        except BaseException:
            ok = False
            tb = traceback.format_exc()
            # 去掉驱动自身的栈帧
            lines = [l for l in tb.splitlines() if "kernel_driver.py" not in l]
            print("\n".join(lines))
    return {"ok": ok, "output": buf.getvalue(), "result": result, "figures": _save_figures()}


def main():
    for stream in (sys.stdin, _real_stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            with contextlib.suppress(Exception):
                stream.reconfigure(encoding="utf-8", errors="replace")
    _setup_matplotlib()
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
            resp = _run(req.get("code", ""))
        except Exception as e:  # noqa: BLE001
            resp = {"ok": False, "output": f"内核错误: {e}", "result": None, "figures": []}
        _real_stdout.write(MARKER + json.dumps(resp, ensure_ascii=False) + "\n")
        _real_stdout.flush()


if __name__ == "__main__":
    main()
