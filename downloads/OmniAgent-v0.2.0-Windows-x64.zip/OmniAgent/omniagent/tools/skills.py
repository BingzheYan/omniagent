"""技能系统（Skills）：可按需加载的领域工作流说明书，类似 Claude Code 的 skills。

技能目录结构：
    <root>/<skill-name>/SKILL.md      必需；YAML frontmatter 至少包含 name、description
    <root>/<skill-name>/...           可选的模板、示例、脚本等附加文件（read_file 可直接读取）

扫描位置（后者同名覆盖前者）：
    1. 内置：omniagent/skills/*/SKILL.md
    2. 用户：~/.omniagent/skills/*/SKILL.md
    3. 工作区：<workspace>/.omniagent/skills/*/SKILL.md

系统提示词中只列出技能的 name + description；模型在任务匹配时调用 load_skill(name) 读取完整内容。
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path

import yaml

from .base import ToolContext, ToolError, ToolResult, tool

log = logging.getLogger(__name__)

BUILTIN_SKILLS_DIR = Path(__file__).resolve().parent.parent / "skills"
SKILL_FILE = "SKILL.md"
MAX_EXTRA_FILES = 60


@dataclass
class Skill:
    name: str
    description: str
    path: Path  # 技能目录
    source: str  # builtin | user | workspace

    @property
    def file(self) -> Path:
        return self.path / SKILL_FILE

    def body(self) -> str:
        _, body = parse_skill_file(self.file.read_text(encoding="utf-8", errors="replace"))
        return body

    def extra_files(self) -> list[Path]:
        out: list[Path] = []
        for f in sorted(self.path.rglob("*")):
            if not f.is_file() or f.name == SKILL_FILE:
                continue
            rel_parts = f.relative_to(self.path).parts
            if any(part.startswith(".") or part == "__pycache__" for part in rel_parts):
                continue
            out.append(f)
            if len(out) >= MAX_EXTRA_FILES:
                break
        return out


def parse_skill_file(text: str) -> tuple[dict, str]:
    """解析 SKILL.md：返回 (frontmatter 字典, 正文)。没有 frontmatter 时返回 ({}, 全文)。"""
    text = text.lstrip("\ufeff")
    if not text.startswith("---"):
        return {}, text.strip()
    lines = text.splitlines()
    if lines[0].strip() != "---":
        return {}, text.strip()
    for i in range(1, len(lines)):
        if lines[i].strip() in ("---", "..."):
            raw = "\n".join(lines[1:i])
            try:
                meta = yaml.safe_load(raw) or {}
            except yaml.YAMLError as e:
                log.warning("SKILL.md frontmatter 解析失败: %s", e)
                meta = {}
            if not isinstance(meta, dict):
                meta = {}
            return meta, "\n".join(lines[i + 1:]).strip()
    return {}, text.strip()


def skill_roots(workspace: Path | str | None = None) -> list[Path]:
    """所有可能存放技能的根目录（按优先级从低到高）。"""
    roots = [BUILTIN_SKILLS_DIR, Path.home() / ".omniagent" / "skills"]
    if workspace is not None:
        roots.append(Path(workspace) / ".omniagent" / "skills")
    out = []
    for r in roots:
        try:
            out.append(r.resolve())
        except OSError:
            continue
    return out


def _first_paragraph(body: str) -> str:
    for line in body.splitlines():
        s = line.strip()
        if s and not s.startswith("#"):
            return s[:200]
    return ""


def discover_skills(workspace: Path | str | None = None) -> dict[str, Skill]:
    """扫描全部技能，返回 {name: Skill}（工作区 > 用户 > 内置）。"""
    found: dict[str, Skill] = {}
    sources = ["builtin", "user", "workspace"]
    for source, root in zip(sources, skill_roots(workspace)):
        if not root.is_dir():
            continue
        for d in sorted(root.iterdir()):
            f = d / SKILL_FILE
            if not d.is_dir() or not f.is_file():
                continue
            try:
                meta, body = parse_skill_file(f.read_text(encoding="utf-8", errors="replace"))
            except OSError as e:
                log.warning("读取技能 %s 失败: %s", f, e)
                continue
            name = str(meta.get("name") or d.name).strip()
            desc = " ".join(str(meta.get("description") or _first_paragraph(body)).split())
            found[name] = Skill(name=name, description=desc, path=d.resolve(), source=source)
    return found


def _human_size(n: int) -> str:
    return f"{n}B" if n < 1024 else (f"{n / 1024:.1f}KB" if n < 1 << 20 else f"{n / (1 << 20):.1f}MB")


@tool(
    "load_skill",
    "加载一个技能（Skill）的完整说明。技能是针对特定任务类型的专业工作流程、规范与模板（见系统提示中的“可用技能”列表）。"
    "当任务与某个技能的描述匹配时，必须在动手之前先调用本工具读取技能内容，并严格按其流程执行。"
    "返回 SKILL.md 正文以及技能目录中的附加文件列表（模板/示例/脚本，可用 read_file 按绝对路径读取）。",
    {"name": {"type": "string", "description": "技能名称（与可用技能列表中的 name 完全一致）"}},
    ["name"],
    summary_keys=("name",),
)
async def load_skill(args, ctx: ToolContext):
    name = str(args.get("name") or "").strip()
    skills = discover_skills(ctx.workspace)
    sk = skills.get(name)
    if sk is None:  # 宽松匹配：忽略大小写 / 下划线与连字符
        norm = name.lower().replace("_", "-")
        sk = next((s for n, s in skills.items() if n.lower().replace("_", "-") == norm), None)
    if sk is None:
        avail = ", ".join(sorted(skills)) or "（无）"
        raise ToolError(f"找不到技能 '{name}'。可用技能: {avail}")
    body = sk.body()
    extras = sk.extra_files()
    parts = [f"# 技能：{sk.name}", f"来源：{sk.source} · 目录：{sk.path}", "", body or "(SKILL.md 正文为空)"]
    if extras:
        parts += ["", "---", "技能目录中的附加文件（需要时用 read_file 读取下列绝对路径；脚本可用 run_shell/python 执行）："]
        for f in extras:
            try:
                size = _human_size(f.stat().st_size)
            except OSError:
                size = "?"
            parts.append(f"- {f}  ({size})")
    loaded = ctx.state.setdefault("loaded_skills", [])
    if sk.name not in loaded:
        loaded.append(sk.name)
    return ToolResult("\n".join(parts), data={"skill": sk.name, "path": str(sk.path), "files": [str(f) for f in extras]})


SKILL_TOOLS = [load_skill]
