"""真实浏览器自动化工具：接入需要登录的企业业务系统（报销平台 / OA / ERP / CRM / 招聘网站等）并按步骤操作，
每一步自动截图，实时同步到工作台右侧「操作」栏。"""
from __future__ import annotations

import asyncio
import json
import re
import time
from typing import Any

from .base import ToolContext, ToolError, ToolResult, tool, truncate

SNAP_ACTIONS = {"open", "snapshot", "click", "submit", "back", "wait_login", "press"}


def _pool(ctx: ToolContext) -> dict[str, Any]:
    return ctx.state.setdefault("_pw_sessions", {})


async def _progress(ctx: ToolContext, detail: str, shot: str = "", url: str = "", status: str = "running") -> None:
    op_id = ctx.state.get("_active_tool_id")
    if not op_id:
        return
    ev = {"type": "external_op", "id": op_id, "status": status, "detail": detail, "ts": time.time()}
    if shot:
        ev["screenshot"] = shot
    if url:
        ev["url"] = url
    await ctx.emit(ev)


def _format_snapshot(snap: dict[str, Any], head: str = "", max_controls: int = 160) -> str:
    parts = []
    if head:
        parts.append(head)
    parts.append(f"🌐 **{snap.get('title') or '(无标题)'}**  `{snap['url']}`  · {snap['frames']} 个 frame"
                 + ("  · ⚠️ 当前为登录页" if snap.get("login_page") else ""))
    if snap.get("text"):
        parts.append("\n### 页面文字摘录\n" + snap["text"][:3500])
    ctrls = snap.get("controls") or []
    if ctrls:
        parts.append(f"\n### 可交互控件（{len(ctrls)} 个，用 target='e编号' 操作）")
        parts.extend(f"- {c}" for c in ctrls[:max_controls])
        if len(ctrls) > max_controls:
            parts.append(f"- …其余 {len(ctrls) - max_controls} 个控件已省略（可 scroll 后重新 snapshot）")
    return "\n".join(parts)


@tool(
    "web_automation",
    "用真实浏览器（本机 Chrome，登录态持久保存）接入并操作需要登录的网页业务系统，如报销系统、OA 审批、ERP、CRM、招聘网站、政务/银行门户。"
    "每一步自动截图并在工作台右侧「操作」栏实时展示。典型流程：\n"
    "1. open(url) 打开系统 → 若出现登录页，调用 wait_login 让用户在弹出的浏览器窗口中亲自登录（扫码/验证码均可），登录成功后自动继续；\n"
    "2. snapshot 获取页面控件编号 [eN]（含 iframe 内的表单），click 进入菜单/新建单据；\n"
    "3. fill（支持 fields 字典批量填写，键可为控件编号或字段标签名）/ select 下拉 / check 勾选 / upload 上传附件；\n"
    "4. 填写完成后先 screenshot 并请用户核对，最终提交使用 submit（会触发用户审批确认）；\n"
    "5. read_tables 可读取页面中的列表/表格数据用于分析。\n"
    "安全约束：不得用本工具填写密码（登录交给用户在浏览器窗口完成）；不得绕过验证码；提交/付款/删除等不可逆操作必须用 submit。",
    {
        "action": {"type": "string", "enum": ["open", "snapshot", "click", "fill", "select", "check", "upload", "press",
                                               "scroll", "wait", "wait_login", "read_tables", "screenshot", "back",
                                               "submit", "close"]},
        "session": {"type": "string", "description": "会话名（每个业务系统一个，如 reimburse / oa），默认 default；登录态按会话名持久保存"},
        "url": {"type": "string", "description": "open 时的网址"},
        "target": {"type": "string", "description": "控件编号（如 e12）、字段标签/按钮文字（如『报销事由』『新建报销单』）或 css= 选择器"},
        "value": {"type": "string", "description": "fill/select 的值；press 的按键（如 Enter）；scroll 的方向 up/down"},
        "fields": {"type": "object", "description": "fill 批量填写：{控件编号或字段标签: 值}"},
        "files": {"type": "array", "items": {"type": "string"}, "description": "upload：工作区内要上传的文件路径列表（可直接传附件包中的文件）"},
        "checked": {"type": "boolean", "description": "check：true 勾选 / false 取消"},
        "text": {"type": "string", "description": "wait：等待页面出现的文字；wait_login：登录成功后页面会出现的文字（可选）"},
        "seconds": {"type": "number", "description": "wait：固定等待秒数；wait_login：最长等待秒数（默认 300）"},
        "headless": {"type": "boolean", "description": "open：是否无界面运行（默认本机有界面，便于用户登录与旁观）"},
        "note": {"type": "string", "description": "本步操作说明（会显示在操作栏中，如『填写报销单表头』）"},
    },
    ["action"],
    risk="exec",
    summary_keys=("note", "action", "url", "target"),
)
async def web_automation(args: dict[str, Any], ctx: ToolContext) -> ToolResult:
    from omniagent.connectors.browser_driver import BrowserAutomationSession

    act = args["action"]
    name = re.sub(r"[^\w.\-]", "_", str(args.get("session") or "default"))[:40] or "default"
    pool = _pool(ctx)
    sess: BrowserAutomationSession | None = pool.get(name)
    note = str(args.get("note") or "")

    if act == "close":
        if sess:
            await sess.close()
            pool.pop(name, None)
        return ToolResult(f"已关闭浏览器会话 `{name}`（登录态已保存在本机，下次打开可免登录）。", data={"op_title": "关闭浏览器"})

    if act == "open":
        url = str(args.get("url") or "").strip()
        if not url.startswith(("http://", "https://")):
            raise ToolError("open 需要以 http:// 或 https:// 开头的完整网址")
        if sess is None:
            sess = BrowserAutomationSession(
                name,
                profile_dir=ctx.workspace / ".omniagent" / "browser_profiles" / name,
                shots_dir=ctx.workspace / "outputs" / "web_ops" / f"{name}_{time.strftime('%Y%m%d_%H%M%S')}",
                headless=args.get("headless"),
                rel=ctx.rel,
            )
            await _progress(ctx, f"正在启动浏览器（{'无界面' if sess.headless else '有界面窗口'}）…")
            try:
                await sess.start()
            except Exception as e:  # noqa: BLE001
                raise ToolError(str(e)) from None
            pool[name] = sess
        try:
            await sess.goto(url)
        except Exception as e:  # noqa: BLE001
            shot = await sess.screenshot("open_failed")
            return ToolResult(f"打开 {url} 失败：{e}", is_error=True, data={"screenshot": shot, "url": url})
    elif sess is None:
        raise ToolError(f"浏览器会话 `{name}` 尚未打开，请先 web_automation(action='open', url=..., session='{name}')")

    head = ""
    try:
        if act == "snapshot":
            head = "页面快照"
        elif act in ("click", "submit"):
            if not args.get("target"):
                raise ToolError(f"{act} 需要 target")
            head = ("✅ 已提交：" if act == "submit" else "") + await sess.click(str(args["target"]))
        elif act == "fill":
            fields = args.get("fields") if isinstance(args.get("fields"), dict) else None
            if not fields:
                if args.get("target") is None:
                    raise ToolError("fill 需要 target+value 或 fields 字典")
                fields = {str(args["target"]): args.get("value", "")}
            if not sess.items:
                await sess.snapshot()
            logs, errs = [], []
            for k, v in fields.items():
                loc_item = sess.items.get(str(k)) if re.fullmatch(r"e\d+", str(k)) else None
                if (loc_item and loc_item.get("type") == "password") or re.search(r"密码|password|passwd", str(k), re.I):
                    errs.append(f"「{k}」为密码字段：出于安全考虑请用户在浏览器窗口中自行输入（可调用 wait_login）")
                    continue
                try:
                    if isinstance(v, bool):
                        logs.append(await sess.check(str(k), v))
                    else:
                        logs.append(await sess.fill(str(k), "" if v is None else str(v)))
                except Exception as e:  # noqa: BLE001
                    errs.append(f"「{k}」填写失败：{e}")
                await _progress(ctx, f"填写中 {len(logs)}/{len(fields)}：{logs[-1] if logs else ''}")
            head = "✅ 已填写：\n- " + "\n- ".join(logs) if logs else ""
            if errs:
                head += ("\n" if head else "") + "⚠️ 未完成：\n- " + "\n- ".join(errs)
        elif act == "select":
            head = await sess.select(str(args.get("target") or ""), str(args.get("value") or ""))
        elif act == "check":
            head = await sess.check(str(args.get("target") or ""), bool(args.get("checked", True)))
        elif act == "upload":
            files = [ctx.resolve(f, must_exist=True, read_only=True) for f in (args.get("files") or [])]
            if not files:
                raise ToolError("upload 需要 files（工作区内的文件路径列表）")
            head = await sess.upload(str(args.get("target") or ""), files)
        elif act == "press":
            head = await sess.press(str(args.get("value") or "Enter"))
        elif act == "scroll":
            head = await sess.scroll(str(args.get("value") or "down"))
        elif act == "back":
            await sess.page.go_back()
            await sess._settle()
            head = "已返回上一页"
        elif act == "wait":
            head = await sess.wait_for(str(args.get("text") or ""), float(args.get("seconds") or 0),
                                       timeout=float(args.get("seconds") or 30) if args.get("text") else 30)
        elif act == "wait_login":
            timeout = float(args.get("seconds") or 600)
            until = str(args.get("text") or "")
            if await sess.is_logged_in(until):
                head = "✅ 当前已处于登录状态（使用已保存的登录态）"
            else:
                if sess.headless:
                    import os

                    if os.environ.get("PYTEST_CURRENT_TEST") or os.environ.get("OMNI_BROWSER_HEADLESS"):
                        shot = await sess.screenshot("无法登录")
                        tip = ("当前浏览器为无界面模式，用户看不到窗口、无法亲自登录。请以 headless=false 重新 open，"
                               "或请用户在本机桌面端/CLI 中运行后再登录。")
                        return ToolResult(tip, is_error=True, data={"screenshot": shot, "url": sess.page.url, "op_title": "等待用户登录"})
                    # 自动切换为有界面窗口（同一浏览器配置目录，登录态与当前页面保留），以便用户亲自登录
                    cur_url = sess.page.url
                    await _progress(ctx, "需要登录：正在切换为有界面浏览器窗口，方便您亲自登录…")
                    await sess.close()
                    sess.headless = False
                    await sess.start()
                    await sess.goto(cur_url)
                ok, shot = await _wait_for_user_login(ctx, sess, name, until, timeout, note)
                if not ok:
                    return ToolResult(f"等待 {int(timeout)} 秒后仍未检测到登录成功（或用户取消）。请询问用户是否已登录，"
                                      "必要时再次调用 wait_login；在用户登录之前不要尝试任何业务操作。",
                                      is_error=True, data={"screenshot": shot, "url": sess.page.url, "op_title": "等待用户登录"})
                await sess._settle(10000)
                head = "✅ 用户已登录成功，继续自动化操作"
        elif act == "read_tables":
            tables = await sess.tables()
            if not tables:
                head = "页面中没有 HTML 表格（可用 snapshot 查看页面文字）"
            else:
                out_dir = ctx.workspace / "outputs" / "web_ops" / "tables"
                out_dir.mkdir(parents=True, exist_ok=True)
                saved = []
                lines = [f"读取到 {len(tables)} 张表格："]
                for i, t in enumerate(tables, 1):
                    p = out_dir / f"{name}_{int(time.time())}_{i}.json"
                    p.write_text(json.dumps(t, ensure_ascii=False, indent=1), encoding="utf-8")
                    saved.append(ctx.rel(p))
                    lines.append(f"\n#### 表 {i}（{len(t)} 行，已保存 `{ctx.rel(p)}`）")
                    for row in t[:25]:
                        lines.append("| " + " | ".join(c[:30] for c in row) + " |")
                shot = await sess.screenshot("读取表格")
                return ToolResult(truncate("\n".join(lines), 25000),
                                  data={"screenshot": shot, "url": sess.page.url, "outputs": saved, "op_title": "读取表格"})
        elif act == "screenshot":
            shot = await sess.screenshot(note or "截图")
            from .vision import encode_image, model_supports_vision  # 供视觉模型直接查看

            images = []
            if shot and model_supports_vision(ctx):
                try:
                    enc = await asyncio.to_thread(encode_image, ctx.workspace / shot)
                    images = [{"media_type": enc["media_type"], "data": enc["data"], "path": shot}]
                except Exception:  # noqa: BLE001
                    pass
            return ToolResult(f"🖼 已截图：`{shot}`（{sess.page.url}）", images=images,
                              data={"screenshot": shot, "url": sess.page.url, "op_title": note or "页面截图"})
    except ToolError:
        raise
    except Exception as e:  # noqa: BLE001
        shot = await sess.screenshot("操作失败")
        snap = await sess.snapshot()
        return ToolResult(truncate(_format_snapshot(snap, f"❌ {act} 失败：{e}\n请根据下方最新控件列表调整 target 后重试。", 120), 26000),
                          is_error=True, data={"screenshot": shot, "url": snap["url"], "title": snap["title"]})

    shot = await sess.screenshot(note or act)
    if act in SNAP_ACTIONS:
        snap = await sess.snapshot()
        if act != "wait_login" and (snap.get("login_page") or not await sess.is_logged_in()):
            head = (head + "\n" if head else "") + (
                "🔐 **检测到该系统需要登录（或登录已失效）**。请立即调用 "
                f"`web_automation(action='wait_login', session='{name}')`：系统会提示用户在弹出的浏览器窗口中亲自登录，"
                "登录成功后再继续；不要尝试代填账号密码或绕过验证码。")
        content = _format_snapshot(snap, head)
        return ToolResult(truncate(content, 28000), data={"screenshot": shot, "url": snap["url"], "title": snap["title"],
                                                          "op_title": note or head.split("\n")[0][:60]})
    return ToolResult(head or "完成", data={"screenshot": shot, "url": sess.page.url, "op_title": note or (head or act).split("\n")[0][:60]})


async def _notify_os(title: str, message: str) -> None:
    import os
    import platform

    if os.environ.get("PYTEST_CURRENT_TEST"):
        return
    sys_name = platform.system()
    if sys_name == "Darwin":
        script = f'display notification "{message[:180].replace(chr(34), chr(39))}" with title "{title.replace(chr(34), chr(39))}" sound name "Glass"'
        try:
            proc = await asyncio.create_subprocess_exec("osascript", "-e", script, stdout=asyncio.subprocess.DEVNULL,
                                                        stderr=asyncio.subprocess.DEVNULL)
            await asyncio.wait_for(proc.wait(), timeout=5)
        except Exception:  # noqa: BLE001
            pass
    elif sys_name == "Windows":
        ps_notify = (
            "Add-Type -AssemblyName System.Windows.Forms; Add-Type -AssemblyName System.Drawing; "
            "$n = New-Object System.Windows.Forms.NotifyIcon; "
            "$n.Icon = [System.Drawing.SystemIcons]::Information; $n.Visible = $true; "
            "$n.ShowBalloonTip(6000, $env:OMNI_NT_TITLE, $env:OMNI_NT_MSG, [System.Windows.Forms.ToolTipIcon]::Info); "
            "Start-Sleep -Milliseconds 1200; $n.Dispose()"
        )
        try:
            proc = await asyncio.create_subprocess_exec(
                "powershell", "-NoProfile", "-NonInteractive", "-WindowStyle", "Hidden", "-Command", ps_notify,
                env={**os.environ, "OMNI_NT_TITLE": title[:80], "OMNI_NT_MSG": message[:200]},
                stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL,
            )
            await asyncio.wait_for(proc.wait(), timeout=6)
        except Exception:  # noqa: BLE001
            pass


async def _wait_for_user_login(ctx: ToolContext, sess, name: str, until: str, timeout: float, note: str) -> tuple[bool, str]:
    """提示用户登录并等待：在对话中弹出登录提示卡片 + 系统通知 + 浏览器窗口置前；
    自动检测登录成功，或用户点击「我已完成登录」后继续。"""
    shot = await sess.screenshot("等待用户登录")
    login_id = f"login_{int(time.time() * 1000)}"
    url = sess.page.url
    if sess.headless:
        tip = "当前浏览器为无界面模式，用户无法登录。请以 headless=false 重新 open 后再调用 wait_login。"
        await _progress(ctx, "🔐 " + tip, shot, url, status="error")
        return False, shot
    from urllib.parse import urlparse

    try:
        page_title = (await sess.page.title()).strip()
    except Exception:  # noqa: BLE001
        page_title = ""
    host = urlparse(url).netloc
    system = page_title if page_title and not re.search(r"登录|login", page_title, re.I) else (host or name)
    msg = (f"「{system}」需要登录后才能继续。请在已自动弹出的 Chrome 浏览器窗口中亲自完成登录"
           "（账号密码 / 扫码 / 短信验证码均由您操作，智能体不会读取您的密码）。登录成功后智能体将自动继续；"
           "若未自动继续，可点击「我已完成登录」。")
    pending = {"id": login_id, "session": name, "url": url, "system": system, "message": msg, "screenshot": shot,
               "started": time.time()}
    ctx.state["_login_pending"] = pending
    confirmed: set = ctx.state.setdefault("_login_confirmed", set())
    await ctx.emit({"type": "login_required", **pending})
    await ctx.emit({"type": "status", "message": "🔐 等待您在浏览器窗口中登录…"})
    await _progress(ctx, "🔐 已提示用户登录，等待用户在浏览器窗口中完成登录…", shot, url)
    await _notify_os("OmniAgent · 需要您登录", f"请在弹出的浏览器窗口中登录「{system}」，登录后智能体自动继续")
    try:
        await sess.page.bring_to_front()
    except Exception:  # noqa: BLE001
        pass
    ok, by_user = False, False
    deadline = time.time() + timeout
    last_shot = time.time()
    try:
        while time.time() < deadline:
            await asyncio.sleep(1.5)
            if login_id in confirmed:
                by_user = True
                ok = True  # 用户明确确认已登录，以用户为准
                break
            try:
                if await sess.is_logged_in(until):
                    # 登录后页面常有多次跳转（扫码回调 → 空白页 → 首页），需连续两次确认已稳定处于登录态
                    await sess._settle(6000)
                    await asyncio.sleep(1.5)
                    if await sess.is_logged_in(until):
                        ok = True
                        break
            except Exception:  # noqa: BLE001
                continue
            if time.time() - last_shot > 10:
                last_shot = time.time()
                remain = int(deadline - time.time())
                shot = await sess.screenshot("等待用户登录")
                await _progress(ctx, f"🔐 等待用户登录中…（剩余 {remain // 60} 分 {remain % 60} 秒）", shot, sess.page.url)
    finally:
        ctx.state["_login_pending"] = None
        confirmed.discard(login_id)
        await ctx.emit({"type": "login_resolved", "id": login_id, "ok": ok,
                        "message": ("✅ 用户已确认登录，继续执行" if by_user else "✅ 已检测到登录成功，继续执行") if ok
                        else "⌛ 等待登录超时"})
    shot = await sess.screenshot("登录成功" if ok else "登录超时")
    return ok, shot


async def close_web_sessions(state: dict[str, Any]) -> None:
    for s in list((state.get("_pw_sessions") or {}).values()):
        try:
            await s.close()
        except Exception:  # noqa: BLE001
            pass
    if state.get("_pw_sessions"):
        state["_pw_sessions"].clear()


WEB_AUTOMATION_TOOLS = [web_automation]

__all__ = ["WEB_AUTOMATION_TOOLS", "close_web_sessions", "web_automation"]
