"""外部应用、动态网页、数据库、MCP 与桌面软件接入工具集。"""
from __future__ import annotations

import asyncio
import json
import platform
import shutil
import time
from pathlib import Path
from typing import Any

from omniagent.connectors import (
    ConnectorSpec,
    execute_http_api,
    execute_local_folder,
    execute_mcp,
    execute_sqlite,
    load_file_connectors,
    render_url_content,
    rows_to_csv_bytes,
)

from .base import ToolContext, ToolError, ToolResult, tool, truncate


def get_available_connectors(ctx: ToolContext) -> dict[str, ConnectorSpec]:
    merged = load_file_connectors(ctx.workspace)
    for spec in ctx.state.get("extra_connectors") or []:
        if isinstance(spec, ConnectorSpec) and spec.enabled:
            merged[spec.name] = spec
        elif isinstance(spec, dict) and spec.get("name") and spec.get("enabled", True):
            merged[spec["name"]] = ConnectorSpec(
                name=spec["name"], title=spec.get("title") or spec["name"], kind=spec.get("kind") or "http_api",
                description=spec.get("description") or "", config=dict(spec.get("config") or {}), source="user",
            )
    return merged


def _table_preview(rows: list[list[Any]], columns: list[str] | None = None, max_rows: int = 30) -> str:
    all_rows = ([columns] if columns else []) + rows[:max_rows]
    if not all_rows:
        return "(空表)"
    w = max(len(r) for r in all_rows)
    norm = [[str("" if c is None else c).replace("\n", " ").replace("|", "\\|")[:80] for c in r] + [""] * (w - len(r))
            for r in all_rows]
    md = ["| " + " | ".join(norm[0]) + " |", "|" + "---|" * w]
    md += ["| " + " | ".join(r) + " |" for r in norm[1:]]
    if len(rows) > max_rows:
        md.append(f"\n... 共 {len(rows)} 行，仅预览前 {max_rows} 行")
    return "\n".join(md)


@tool(
    "list_connectors",
    "列出当前已接入的所有外部应用、数据库（SQLite）、外部软件数据目录、业务网页与 MCP 服务连接器。"
    "当用户提到“查看某软件/系统/数据库/连接器中的数据”或指令中带有 @connector:名称 时，先用本工具查看可用连接器。",
    {},
)
async def list_connectors(args, ctx: ToolContext):
    conns = get_available_connectors(ctx)
    if not conns:
        return (
            "当前尚未配置预置连接器。\n"
            "- 若用户给出了网页链接或本地服务地址，可直接调用 browser_inspect 或 web_fetch 读取；\n"
            "- 若在本机桌面模式下需要读取剪贴板/已打开网页/备忘录等，可调用 desktop_inspect；\n"
            "- 用户也可以在界面「🔌 应用接入」中添加 API / SQLite 数据库 / 外部软件目录 / 网页 / MCP 连接器。"
        )
    lines = [f"共 {len(conns)} 个已接入连接器："]
    for c in conns.values():
        lines.append(f"- **{c.name}**（{c.title}）[{c.kind}]：{c.description or '无描述'}")
    return "\n".join(lines)


@tool(
    "connector_query",
    "读取或调用已接入的外部软件连接器，获取其中的数据与内容并可保存到工作区供 Python 深度分析。\n"
    "按连接器类型支持的 action：\n"
    "- sqlite（外部软件数据库）: action='schema' 查看所有表与字段；action='query' 执行只读 SELECT SQL（参数 sql），"
    "可设 save_to='uploads/xxx.csv' 直接保存为 CSV！\n"
    "- http_api（外部系统/SaaS API）: action='request'，可选 endpoint, method, params, body，可设 save_to 保存 JSON。\n"
    "- local_folder（外部软件目录）: action='list' 列出文件（可选 subpath, pattern）；action='read' 读取文档/表格内容；"
    "action='import' 把外部文件复制到工作区 uploads/。\n"
    "- web_app（外部业务网页）: action='read' 抓取并渲染网页正文与所有表格（可选 subpath 覆盖路径，save_to 保存表格 CSV）。\n"
    "- mcp（MCP 服务）: action='list_tools' | 'call_tool'（传 tool_name 与 arguments）| 'list_resources' | 'read_resource'。",
    {
        "connector": {"type": "string", "description": "连接器名称（如 erp_db / crm_api）"},
        "action": {"type": "string", "description": "操作类型：schema | query | request | list | read | import | list_tools | call_tool"},
        "sql": {"type": "string", "description": "sqlite 查询语句（SELECT ...）"},
        "endpoint": {"type": "string", "description": "http_api 子路径或完整 URL"},
        "method": {"type": "string", "description": "HTTP 方法，默认 GET"},
        "params": {"type": "object", "description": "URL 查询参数"},
        "body": {"type": "object", "description": "POST/PUT JSON 请求体"},
        "subpath": {"type": "string", "description": "local_folder 相对路径或 web_app 子路径"},
        "pattern": {"type": "string", "description": "local_folder 文件通配符，默认 *"},
        "tool_name": {"type": "string", "description": "MCP 工具名"},
        "arguments": {"type": "object", "description": "MCP 工具参数"},
        "save_to": {"type": "string", "description": "可选：将提取的数据保存到工作区路径（如 uploads/data.csv 或 uploads/api.json）"},
    },
    ["connector"],
    summary_keys=("connector", "action", "sql", "endpoint", "subpath"),
)
async def connector_query(args, ctx: ToolContext):
    conns = get_available_connectors(ctx)
    name = str(args["connector"]).lstrip("@").replace("connector:", "")
    if name not in conns:
        raise ToolError(f"未找到连接器 '{name}'。可用连接器: {', '.join(conns) or '无'}")
    spec = conns[name]
    action = args.get("action") or {
        "sqlite": "schema", "http_api": "request", "local_folder": "list", "web_app": "read", "mcp": "list_tools",
    }.get(spec.kind, "read")
    save_to = args.get("save_to")
    saved_rel = None

    try:
        if spec.kind == "sqlite":
            res = await asyncio.to_thread(execute_sqlite, spec, action=action, sql=args.get("sql") or "")
            if action == "schema":
                lines = [f"数据库 `{spec.title}` 共 {len(res['tables'])} 张表："]
                for tname, info in res["tables"].items():
                    cols = ", ".join(f"{c['name']}({c['type']})" for c in info["columns"])
                    lines.append(f"- **{tname}**（{info['rows']} 行）：{cols}")
                return ToolResult("\n".join(lines))
            if save_to:
                out_p = ctx.resolve(save_to)
                out_p.parent.mkdir(parents=True, exist_ok=True)
                out_p.write_bytes(rows_to_csv_bytes(res["rows"], res["columns"]))
                saved_rel = ctx.rel(out_p)
            body = _table_preview(res["rows"], res["columns"])
            note = f"\n\n✅ 已将 {res['returned']} 行查询结果保存到 `{saved_rel}`，可用 python(pandas) 直接分析。" if saved_rel else ""
            return ToolResult(f"SQL 查询返回 {res['returned']} 行：\n\n{body}{note}",
                              data={"path": saved_rel} if saved_rel else {})

        if spec.kind == "http_api":
            res = await execute_http_api(
                spec, endpoint=args.get("endpoint") or "", method=args.get("method") or "GET",
                params=args.get("params"), json_body=args.get("body"),
            )
            if save_to:
                out_p = ctx.resolve(save_to)
                out_p.parent.mkdir(parents=True, exist_ok=True)
                text = json.dumps(res["json"], ensure_ascii=False, indent=2) if res["json"] is not None else res["text"]
                out_p.write_text(text, encoding="utf-8")
                saved_rel = ctx.rel(out_p)
            preview = json.dumps(res["json"], ensure_ascii=False, indent=2)[:15_000] if res["json"] is not None else res["text"][:15_000]
            note = f"\n\n✅ 已保存响应到 `{saved_rel}`" if saved_rel else ""
            return ToolResult(f"[HTTP {res['status']}] {res['url']}\n\n{preview}{note}",
                              is_error=res["status"] >= 400, data={"path": saved_rel} if saved_rel else {})

        if spec.kind == "local_folder":
            if action == "import":
                info = await asyncio.to_thread(execute_local_folder, spec, action="read", subpath=args.get("subpath") or "")
                src = Path(info["full_path"])
                dest = ctx.resolve(save_to or f"uploads/{src.name}")
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dest)
                saved_rel = ctx.rel(dest)
                return ToolResult(f"✅ 已将外部文件 `{src.name}` 导入到工作区 `{saved_rel}`（{dest.stat().st_size} 字节）",
                                  data={"path": saved_rel})
            res = await asyncio.to_thread(
                execute_local_folder, spec, action=action,
                subpath=args.get("subpath") or "", pattern=args.get("pattern") or "*",
            )
            if action == "list":
                lines = [f"外部目录 `{spec.title}` 共 {len(res['files'])} 个文件："]
                for f in res["files"][:150]:
                    lines.append(f"- `{f['path']}` ({f['size']} B)")
                return ToolResult("\n".join(lines))
            return ToolResult(f"外部文件 `{res['path']}` 内容：\n\n{truncate(res['content'], 25_000)}")

        if spec.kind == "web_app":
            base_url = str(spec.config.get("url") or "")
            sub = str(args.get("subpath") or args.get("endpoint") or "")
            url = sub if sub.startswith(("http://", "https://")) else (base_url.rstrip("/") + "/" + sub.lstrip("/") if sub else base_url)
            res = await render_url_content(
                url, headers=spec.config.get("headers"), cookies=spec.config.get("cookies"),
                render_js=bool(spec.config.get("render_js", True)),
            )
            parts = [f"# {res['title'] or url}", f"状态: HTTP {res['status']} · 提取表格: {len(res['tables'])} 张\n",
                     res["text"][:15_000]]
            for idx, tbl in enumerate(res["tables"][:5], 1):
                parts.append(f"\n### 页面表格 {idx}\n{_table_preview(tbl[1:], tbl[0] if tbl else None)}")
            if save_to and res["tables"]:
                out_p = ctx.resolve(save_to)
                out_p.parent.mkdir(parents=True, exist_ok=True)
                out_p.write_bytes(rows_to_csv_bytes(res["tables"][0]))
                saved_rel = ctx.rel(out_p)
                parts.append(f"\n✅ 第一张表格已保存为 `{saved_rel}`")
            return ToolResult("\n".join(parts), data={"path": saved_rel} if saved_rel else {})

        if spec.kind == "mcp":
            res = await execute_mcp(
                spec, action=action, tool_name=args.get("tool_name") or "",
                arguments=args.get("arguments") or {}, resource_uri=args.get("endpoint") or "",
            )
            return ToolResult(truncate(json.dumps(res, ensure_ascii=False, indent=2), 25_000))

        raise ToolError(f"未知的连接器类型: {spec.kind}")
    except ToolError:
        raise
    except Exception as e:  # noqa: BLE001
        raise ToolError(f"调用连接器 {name} 失败: {e}") from None


@tool(
    "browser_inspect",
    "打开并读取任意网页或 Web 应用内容（支持 Headless Chrome 动态 JS 渲染、提取网页内所有 HTML 数据表格、网页截图）。"
    "当用户在指令中给出网址/后台地址并要求读取其中的内容或表格数据进行分析时优先使用。",
    {
        "url": {"type": "string", "description": "完整网址（http:// 或 https://）"},
        "render_js": {"type": "boolean", "description": "是否启用无头浏览器渲染动态 JS，默认 true"},
        "screenshot": {"type": "boolean", "description": "是否截取网页可视化图片以便检查布局，默认 false"},
        "save_tables_dir": {"type": "string", "description": "可选：把网页中的所有表格自动保存为 CSV 到该目录（如 'uploads/web_tables'）"},
        "headers": {"type": "object", "description": "可选：自定义请求头"},
    },
    ["url"],
    summary_keys=("url",),
)
async def browser_inspect(args, ctx: ToolContext):
    url = str(args["url"]).strip()
    if not url.startswith(("http://", "https://")):
        raise ToolError("URL 必须以 http:// 或 https:// 开头")
    shot_path = None
    shot_rel = None
    if args.get("screenshot"):
        shot_path = ctx.workspace / "outputs" / "figures" / f"web_{int(time.time() * 1000)}.png"
    try:
        res = await render_url_content(
            url, headers=args.get("headers"), render_js=bool(args.get("render_js", True)),
            screenshot_path=shot_path,
        )
    except Exception as e:  # noqa: BLE001
        raise ToolError(f"读取网页失败: {e}") from None

    saved_csvs: list[str] = []
    if args.get("save_tables_dir") and res["tables"]:
        out_dir = ctx.resolve(args["save_tables_dir"])
        out_dir.mkdir(parents=True, exist_ok=True)
        for i, tbl in enumerate(res["tables"], 1):
            p = out_dir / f"table_{i}.csv"
            p.write_bytes(rows_to_csv_bytes(tbl))
            saved_csvs.append(ctx.rel(p))

    if shot_path and shot_path.is_file():
        shot_rel = ctx.rel(shot_path)

    lines = [
        f"[HTTP {res['status']}] {res['title'] or url}  ({'JS动态渲染' if res['rendered_js'] else '静态抓取'})",
        f"共发现 {len(res['tables'])} 张数据表，{len(res['links'])} 个链接。",
        "",
        res["text"][:18_000],
    ]
    for i, tbl in enumerate(res["tables"][:5], 1):
        lines.append(f"\n### 表格 {i}（{len(tbl)} 行）\n{_table_preview(tbl[1:], tbl[0] if tbl else None, max_rows=15)}")
    if saved_csvs:
        lines.append("\n✅ 已保存表格 CSV: " + ", ".join(saved_csvs))
    if shot_rel:
        lines.append(f"\n🖼 已保存网页截图: {shot_rel}")
    data: dict[str, Any] = {}
    if shot_rel:
        data["images"] = [shot_rel]
    if saved_csvs:
        data["path"] = saved_csvs[0]
    return ToolResult(truncate("\n".join(lines), 28_000), is_error=res["status"] >= 400, data=data)


@tool(
    "desktop_inspect",
    "在本机桌面/CLI 模式下读取电脑端其他应用的信息与内容：查看正在运行的桌面软件、读取系统剪贴板中的数据/文本、"
    "读取当前浏览器打开的标签页标题与网址、或读取 macOS 备忘录（Notes）内容。"
    "适合用户说“分析我剪贴板里的数据”“看看我浏览器当前打开的页面”“读取备忘录里的会议纪要”等场景。",
    {
        "action": {
            "type": "string",
            "enum": ["apps", "clipboard", "browser_tabs", "notes"],
            "description": "apps: 运行中的桌面应用 | clipboard: 系统剪贴板内容 | browser_tabs: 浏览器打开的标签页 | notes: 备忘录列表与近期内容",
        },
        "query": {"type": "string", "description": "action='notes' 时可选的标题搜索关键词"},
        "save_to": {"type": "string", "description": "可选：把剪贴板或读取到的内容保存到工作区文件"},
    },
    ["action"],
    risk="exec",
    summary_keys=("action", "query"),
)
async def desktop_inspect(args, ctx: ToolContext):
    if not getattr(ctx.settings, "allow_desktop_inspect", True):
        raise ToolError("当前多租户服务器已禁用本机桌面探查（仅在本机 CLI / 桌面端或管理员开启时可用）。请使用 connector_query 或上传文件。")
    action = args["action"]
    sys_name = platform.system()

    async def _cmd(*argv: str) -> str:
        proc = await asyncio.create_subprocess_exec(*argv, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        out, err = await asyncio.wait_for(proc.communicate(), timeout=15)
        if proc.returncode != 0:
            raise ToolError((err or out).decode("utf-8", "replace").strip() or "命令执行失败")
        return out.decode("utf-8", "replace")

    if action == "clipboard":
        if sys_name == "Darwin":
            text = await _cmd("pbpaste")
        elif shutil.which("xclip"):
            text = await _cmd("xclip", "-selection", "clipboard", "-o")
        elif sys_name == "Windows":
            text = await _cmd(
                "powershell", "-NoProfile", "-NonInteractive", "-Command",
                "[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; Get-Clipboard -Raw",
            )
        else:
            raise ToolError("当前系统不支持直接读取剪贴板")
        saved = None
        if args.get("save_to"):
            p = ctx.resolve(args["save_to"])
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(text, encoding="utf-8")
            saved = ctx.rel(p)
        return ToolResult(
            f"剪贴板内容（{len(text)} 字符）{f'，已保存到 {saved}' if saved else ''}：\n\n{truncate(text, 25_000)}",
            data={"path": saved} if saved else {},
        )

    if action == "apps":
        if sys_name == "Darwin":
            script = 'tell application "System Events" to get name of every process whose background only is false'
            out = await _cmd("osascript", "-e", script)
            return ToolResult(f"当前前台可见桌面应用：{out.strip()}")
        if sys_name == "Windows":
            ps_cmd = (
                "[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; "
                "$w = Get-Process | Where-Object { $_.MainWindowTitle } | "
                "Select-Object -ExpandProperty ProcessName -Unique; "
                "if ($w) { $w -join ', ' } else { "
                "(Get-Process | Select-Object -ExpandProperty ProcessName -Unique | Select-Object -First 60) -join ', ' }"
            )
            out = await _cmd("powershell", "-NoProfile", "-NonInteractive", "-Command", ps_cmd)
            return ToolResult(f"当前桌面运行应用：{out.strip()}")
        out = await _cmd("ps", "-eo", "comm")
        apps = sorted({l.strip().split("/")[-1] for l in out.splitlines()[1:] if l.strip()})[:80]
        return ToolResult("运行中进程摘录：" + ", ".join(apps))

    if action == "browser_tabs":
        if sys_name != "Darwin":
            raise ToolError("browser_tabs 仅在 macOS 桌面环境支持；其他平台请直接提供网址并用 browser_inspect。")
        results = []
        for app_name, script in (
            ("Google Chrome", 'tell application "Google Chrome" to if it is running then get {title, URL} of active tab of every window'),
            ("Safari", 'tell application "Safari" to if it is running then get {name, URL} of current tab of every window'),
        ):
            try:
                out = (await _cmd("osascript", "-e", script)).strip()
                if out:
                    results.append(f"- **{app_name}**: {out}")
            except Exception:  # noqa: BLE001
                continue
        return ToolResult("\n".join(results) if results else "未检测到正在运行且授权访问的 Chrome/Safari 窗口。")

    if action == "notes":
        if sys_name != "Darwin":
            raise ToolError("notes 仅支持 macOS 备忘录应用")
        kw = (args.get("query") or "").replace('"', "")
        script = (
            f'tell application "Notes"\n'
            f'  set outList to {{}}\n'
            f'  repeat with n in (notes' + (f' whose name contains "{kw}"' if kw else '') + ')\n'
            f'    set end of outList to (name of n & " :: " & (text 1 thru (min of {{300, length of (plaintext of n)}}) of (plaintext of n)))\n'
            f'    if (count of outList) >= 15 then exit repeat\n'
            f'  end repeat\n'
            f'  return outList\n'
            f'end tell'
        )
        out = await _cmd("osascript", "-e", script)
        return ToolResult(f"备忘录读取结果：\n{truncate(out.strip(), 20_000)}")

    raise ToolError(f"未知操作: {action}")


INTEGRATION_TOOLS = [list_connectors, connector_query, browser_inspect, desktop_inspect]
