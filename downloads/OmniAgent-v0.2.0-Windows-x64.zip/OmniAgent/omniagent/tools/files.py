"""文件操作工具：读取（含 Office/PDF 文档）、写入、精确编辑、目录浏览、搜索。"""
from __future__ import annotations

import asyncio
import difflib
import fnmatch
import os
import re
import shutil
from pathlib import Path

from .base import ToolContext, ToolError, ToolResult, tool, truncate
from .documents import DOC_EXTS, extract_text

IGNORE_DIRS = {".git", "node_modules", "__pycache__", ".venv", "venv", ".omniagent", ".mypy_cache",
               ".pytest_cache", ".idea", ".vscode", "dist", "build", ".next", ".tox", ".ruff_cache"}
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".svg"}


def _is_binary(p: Path) -> bool:
    try:
        with open(p, "rb") as f:
            return b"\x00" in f.read(8192)
    except OSError:
        return False


def _make_diff(old: str, new: str, path: str, max_lines: int = 80) -> tuple[str, int, int]:
    diff = list(difflib.unified_diff(old.splitlines(), new.splitlines(), f"a/{path}", f"b/{path}", lineterm="", n=2))
    added = sum(1 for l in diff if l.startswith("+") and not l.startswith("+++"))
    removed = sum(1 for l in diff if l.startswith("-") and not l.startswith("---"))
    text = "\n".join(diff[:max_lines]) + (f"\n... (diff 共 {len(diff)} 行，已截断)" if len(diff) > max_lines else "")
    return text, added, removed


# ---------------------------------------------------------------- 读后编辑 / 过期检测
def _stamp(p: Path) -> tuple[int, int]:
    st = p.stat()
    return st.st_mtime_ns, st.st_size


def record_file_state(ctx: ToolContext, p: Path) -> None:
    """记录本会话已读取/写入的文件及其磁盘状态（mtime + size），供 edit_file 做读后编辑与过期检测。"""
    try:
        ctx.state.setdefault("file_stamps", {})[str(p)] = _stamp(p)
    except OSError:
        return
    ctx.state.setdefault("read_files", set()).add(str(p))


def check_fresh(ctx: ToolContext, p: Path) -> None:
    stamps = ctx.state.get("file_stamps") or {}
    key = str(p)
    if key not in stamps:
        raise ToolError(
            f"{ctx.rel(p)} 在本次会话中尚未被读取。为避免基于猜测或过时的内容修改文件，"
            f"请先用 read_file 读取它（至少读取要修改的部分），然后再调用 edit_file。")
    if stamps[key] != _stamp(p):
        raise ToolError(
            f"{ctx.rel(p)} 自你上次读取/写入后已在磁盘上被修改（可能来自 shell 命令、python 脚本、格式化工具或用户）。"
            f"请重新 read_file 获取最新内容后再编辑。")


# ---------------------------------------------------------------- 空白容错匹配
_LINE_NO_PREFIX = re.compile(r"^\s*\d+\t")


def _similar_hint(text: str, old: str) -> str:
    first = next((l.strip() for l in old.splitlines() if l.strip()), "")
    if not first:
        return ""
    for ln, line in enumerate(text.splitlines(), 1):
        if first in line:
            return f"\n提示：第 {ln} 行包含相似内容：{line.strip()[:200]}（请检查缩进/空白/上下文是否一致）"
    return ""


def _leading_ws(s: str) -> str:
    return s[: len(s) - len(s.lstrip())]


class _Ambiguous(Exception):
    pass


def _line_match(text: str, old: str, new: str, eol: str, mode: str) -> str | None:
    """按行匹配：mode='rstrip' 忽略行尾空白；mode='indent' 忽略行首缩进与行尾空白。唯一匹配时返回新文本。"""
    old_lines = old.split("\n")
    trailing = len(old_lines) > 1 and old_lines[-1] == ""
    if trailing:
        old_lines = old_lines[:-1]
    if not any(l.strip() for l in old_lines):
        return None
    lines = text.splitlines(keepends=True)
    norm = (lambda s: s.rstrip()) if mode == "rstrip" else (lambda s: s.strip())
    content = [l.rstrip("\r\n") for l in lines]
    target = [norm(l) for l in old_lines]
    n = len(target)
    matches = [i for i in range(len(lines) - n + 1)
               if all(norm(content[i + j]) == target[j] for j in range(n))]
    if not matches:
        return None
    if len(matches) > 1:
        raise _Ambiguous(len(matches))
    i = matches[0]
    offsets = [0]
    for l in lines:
        offsets.append(offsets[-1] + len(l))
    start = offsets[i]
    last = i + n - 1
    end = offsets[last + 1] if trailing else offsets[last] + len(content[last])
    new_text = new
    if mode == "indent":
        j = next(k for k, l in enumerate(old_lines) if l.strip())
        file_indent, old_indent = _leading_ws(content[i + j]), _leading_ws(old_lines[j])
        if file_indent != old_indent:
            adjusted = []
            for l in new.split("\n"):
                if l.strip() and l.startswith(old_indent):
                    l = file_indent + l[len(old_indent):]
                adjusted.append(l)
            new_text = "\n".join(adjusted)
    if eol != "\n":
        new_text = new_text.replace("\n", eol)
    return text[:start] + new_text + text[end:]


def fuzzy_replace(text: str, old: str, new: str) -> tuple[str, str] | None:
    """精确匹配失败时的容错替换（依次尝试，只在唯一匹配时应用）：
    1) 统一换行符；2) 去掉误带的 read_file 行号前缀；3) 逐行忽略行尾空白；4) 忽略缩进差异。
    返回 (新文本, 使用的匹配方式)；无匹配返回 None；匹配不唯一时抛出 ToolError。
    """
    eol = "\r\n" if "\r\n" in text else "\n"
    old_n, new_n = old.replace("\r\n", "\n"), new.replace("\r\n", "\n")
    kinds: list[str] = []
    cand_old, cand_new = old_n.replace("\n", eol), new_n.replace("\n", eol)
    if cand_old != old:
        c = text.count(cand_old)
        if c == 1:
            return text.replace(cand_old, cand_new, 1), "统一换行符 CRLF/LF"
        if c > 1:
            raise ToolError(f"old_string 在统一换行符后匹配到 {c} 处，无法唯一定位；请提供更多上下文")
    old_lines = [l for l in old_n.split("\n") if l.strip()]
    if old_lines and all(_LINE_NO_PREFIX.match(l) for l in old_lines):
        old_n = "\n".join(_LINE_NO_PREFIX.sub("", l, count=1) for l in old_n.split("\n"))
        new_lines = [l for l in new_n.split("\n") if l.strip()]
        if new_lines and all(_LINE_NO_PREFIX.match(l) for l in new_lines):
            new_n = "\n".join(_LINE_NO_PREFIX.sub("", l, count=1) for l in new_n.split("\n"))
        kinds.append("去除了 read_file 行号前缀")
        cand_old, cand_new = old_n.replace("\n", eol), new_n.replace("\n", eol)
        c = text.count(cand_old)
        if c == 1:
            return text.replace(cand_old, cand_new, 1), "；".join(kinds)
        if c > 1:
            raise ToolError(f"old_string（去除行号前缀后）匹配到 {c} 处，无法唯一定位；请提供更多上下文")
    for mode, label in (("rstrip", "忽略行尾空白"), ("indent", "忽略缩进差异，new_string 已按文件实际缩进调整")):
        try:
            res = _line_match(text, old_n, new_n, eol, mode)
        except _Ambiguous as e:
            raise ToolError(f"old_string 在{label.split('，')[0]}后匹配到 {e.args[0]} 处，无法唯一定位；"
                            f"请提供更多上下文使其唯一（并确保空白与原文一致）") from None
        if res is not None:
            return res, "；".join(kinds + [label])
    return None



@tool(
    "read_file",
    "读取文件内容。文本/代码文件返回带行号的内容；.docx/.pdf/.xlsx/.xls/.pptx 等办公文档会自动提取为文本"
    "（表格转为 Markdown）。大文件请用 offset/limit 分段读取。修改文件前应先读取。",
    {
        "path": {"type": "string", "description": "文件路径（相对工作区或绝对路径）"},
        "offset": {"type": "integer", "description": "起始行号（从 1 开始），可选"},
        "limit": {"type": "integer", "description": "最多读取行数，默认 2000"},
    },
    ["path"],
    summary_keys=("path",),
)
async def read_file(args, ctx: ToolContext):
    p = ctx.resolve(args["path"], must_exist=True, read_only=True)
    if p.is_dir():
        raise ToolError(f"{ctx.rel(p)} 是目录，请使用 list_dir。")
    ext = p.suffix.lower()
    if ext in IMAGE_EXTS:
        hint = "如需查看图片内容，请使用 view_image 工具。" if ext != ".svg" else "SVG 可按文本读取，或用 python 转为 PNG 后用 view_image 查看。"
        return ToolResult(f"[图片文件] {ctx.rel(p)}，大小 {p.stat().st_size} 字节。{hint}",
                          data={"image": ctx.rel(p)})
    if ext in DOC_EXTS:
        text = await asyncio.to_thread(extract_text, p)
    else:
        if _is_binary(p):
            raise ToolError(f"{ctx.rel(p)} 是二进制文件，无法以文本读取。可以用 python 工具处理。")
        text = p.read_text(encoding="utf-8", errors="replace")
    record_file_state(ctx, p)
    lines = text.splitlines()
    offset = max(int(args.get("offset") or 1), 1)
    limit = int(args.get("limit") or 2000)
    chunk = lines[offset - 1: offset - 1 + limit]
    if not chunk:
        return ToolResult(f"(文件为空或 offset 超出范围；共 {len(lines)} 行)")
    body = "\n".join(f"{i:>6}\t{l[:2000]}" for i, l in enumerate(chunk, start=offset))
    end = offset + len(chunk) - 1
    if end < len(lines):
        body += f"\n\n[显示第 {offset}-{end} 行，共 {len(lines)} 行。用 offset={end + 1} 继续读取]"
    return ToolResult(truncate(body))


@tool(
    "write_file",
    "创建新文件或整体覆盖已有文件（自动创建父目录）。修改已有文件的局部内容时优先使用 edit_file。",
    {
        "path": {"type": "string", "description": "文件路径"},
        "content": {"type": "string", "description": "完整文件内容"},
    },
    ["path", "content"],
    risk="write",
    summary_keys=("path",),
)
async def write_file(args, ctx: ToolContext):
    p = ctx.resolve(args["path"])
    content = args.get("content", "")
    old = p.read_text(encoding="utf-8", errors="replace") if p.exists() and not _is_binary(p) else ""
    existed = p.exists()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")
    record_file_state(ctx, p)
    diff, a, r = _make_diff(old, content, ctx.rel(p), max_lines=400)
    verb = "已覆盖" if existed else "已创建"
    return ToolResult(
        f"{verb} {ctx.rel(p)}（{len(content.splitlines())} 行，+{a} -{r}）",
        data={"path": ctx.rel(p), "diff": diff, "added": a, "removed": r,
              "status": "modified" if existed else "added"},
    )


@tool(
    "edit_file",
    "对已有文件做精确的字符串替换。必须先在本会话中 read_file 读取过该文件；若文件在读取后被修改，需要重新读取。"
    "old_string 应与文件内容完全一致（包括缩进与换行，不要包含 read_file 输出的行号前缀），且默认要求在文件中唯一；"
    "如需替换所有出现位置，设置 replace_all=true。可通过 edits 数组一次提交多处修改（按顺序应用）。"
    "精确匹配失败时会尝试唯一的空白容错匹配（换行符/行尾空白/缩进），并在结果中注明。",
    {
        "path": {"type": "string"},
        "old_string": {"type": "string", "description": "要被替换的原文"},
        "new_string": {"type": "string", "description": "替换后的新文本"},
        "replace_all": {"type": "boolean", "description": "是否替换全部出现位置，默认 false"},
        "edits": {
            "type": "array",
            "description": "可选：多处修改 [{old_string, new_string, replace_all}]，提供时忽略顶层 old/new",
            "items": {
                "type": "object",
                "properties": {
                    "old_string": {"type": "string"},
                    "new_string": {"type": "string"},
                    "replace_all": {"type": "boolean"},
                },
                "required": ["old_string", "new_string"],
            },
        },
    },
    ["path"],
    risk="write",
    summary_keys=("path",),
)
async def edit_file(args, ctx: ToolContext):
    p = ctx.resolve(args["path"], must_exist=True)
    if p.is_dir():
        raise ToolError(f"{ctx.rel(p)} 是目录，无法编辑。")
    check_fresh(ctx, p)
    if _is_binary(p):
        raise ToolError(f"{ctx.rel(p)} 是二进制文件，无法用 edit_file 编辑。")
    with open(p, encoding="utf-8", errors="replace", newline="") as f:  # newline="" 保留原有 CRLF
        original = f.read()
    edits = args.get("edits") or [
        {"old_string": args.get("old_string"), "new_string": args.get("new_string"), "replace_all": args.get("replace_all")}
    ]
    text = original
    notes: list[str] = []
    for i, e in enumerate(edits, 1):
        old, new = e.get("old_string"), e.get("new_string")
        if old is None or new is None:
            raise ToolError(f"第 {i} 处修改缺少 old_string 或 new_string")
        if old == new:
            raise ToolError(f"第 {i} 处修改 old_string 与 new_string 相同")
        if old == "":
            raise ToolError("old_string 不能为空；创建新文件请使用 write_file")
        count = text.count(old)
        if count == 0:
            fuzzy = fuzzy_replace(text, old, new)
            if fuzzy is not None:
                text, kind = fuzzy
                notes.append(f"第 {i} 处修改未找到精确匹配，已使用模糊匹配（{kind}）并唯一定位，请核对下方 diff")
                continue
            raise ToolError(f"第 {i} 处修改：在 {ctx.rel(p)} 中找不到 old_string。请先 read_file 确认原文。"
                            f"{_similar_hint(text, old)}")
        if count > 1 and not e.get("replace_all"):
            raise ToolError(f"第 {i} 处修改：old_string 在文件中出现了 {count} 次，请提供更多上下文使其唯一，或设置 replace_all=true")
        text = text.replace(old, new) if e.get("replace_all") else text.replace(old, new, 1)
    with open(p, "w", encoding="utf-8", newline="") as f:
        f.write(text)
    record_file_state(ctx, p)
    diff, a, r = _make_diff(original, text, ctx.rel(p), max_lines=400)
    head = f"已编辑 {ctx.rel(p)}（{len(edits)} 处修改，+{a} -{r}）"
    if notes:
        head += "\n⚠ " + "\n⚠ ".join(notes)
    return ToolResult(
        f"{head}\n{diff}",
        data={"path": ctx.rel(p), "diff": diff, "added": a, "removed": r,
              "status": "modified", "fuzzy": bool(notes)},
    )


@tool(
    "list_dir",
    "列出目录结构（树形，自动忽略 .git/node_modules 等）。",
    {
        "path": {"type": "string", "description": "目录路径，默认工作区根目录"},
        "depth": {"type": "integer", "description": "递归深度，默认 2"},
    },
    summary_keys=("path",),
)
async def list_dir(args, ctx: ToolContext):
    root = ctx.resolve(args.get("path") or ".", must_exist=True, read_only=True)
    depth = int(args.get("depth") or 2)
    lines: list[str] = [f"{ctx.rel(root)}/"]
    count = 0

    def walk(d: Path, prefix: str, level: int):
        nonlocal count
        try:
            entries = sorted(d.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower()))
        except PermissionError:
            return
        entries = [e for e in entries if e.name not in IGNORE_DIRS and not e.name.startswith(".DS_Store")]
        for e in entries:
            count += 1
            if count > 500:
                return
            if e.is_dir():
                lines.append(f"{prefix}{e.name}/")
                if level < depth:
                    walk(e, prefix + "  ", level + 1)
            else:
                size = e.stat().st_size
                s = f"{size}B" if size < 1024 else (f"{size / 1024:.1f}KB" if size < 1 << 20 else f"{size / (1 << 20):.1f}MB")
                lines.append(f"{prefix}{e.name}  ({s})")

    walk(root, "  ", 1)
    if count > 500:
        lines.append("... (条目过多已截断，请指定子目录)")
    if len(lines) == 1:
        lines.append("  (空目录)")
    return "\n".join(lines)


def _iter_files(root: Path):
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in IGNORE_DIRS]
        for f in filenames:
            yield Path(dirpath) / f


@tool(
    "glob",
    "按通配符查找文件，如 '**/*.py'、'src/**/*.ts'、'*.xlsx'。按修改时间倒序返回。",
    {"pattern": {"type": "string"}, "path": {"type": "string", "description": "搜索根目录，默认工作区"}},
    ["pattern"],
    summary_keys=("pattern",),
)
async def glob_files(args, ctx: ToolContext):
    root = ctx.resolve(args.get("path") or ".", must_exist=True, read_only=True)
    pattern = args["pattern"]
    matches = []
    norm_pat = pattern.replace("\\", "/")
    for f in _iter_files(root):
        rel = f.relative_to(root).as_posix()
        if fnmatch.fnmatch(rel, norm_pat) or fnmatch.fnmatch(f.name, norm_pat) or \
                (norm_pat.startswith("**/") and fnmatch.fnmatch(rel, norm_pat[3:])):
            matches.append(f)
    matches.sort(key=lambda x: x.stat().st_mtime, reverse=True)
    if not matches:
        return "没有匹配的文件"
    out = [ctx.rel(m) for m in matches[:300]]
    if len(matches) > 300:
        out.append(f"... 共 {len(matches)} 个，仅显示前 300 个")
    return "\n".join(out)


@tool(
    "grep",
    "在文件内容中搜索正则表达式（优先使用 ripgrep）。返回 文件:行号:内容。",
    {
        "pattern": {"type": "string", "description": "正则表达式"},
        "path": {"type": "string", "description": "搜索目录或文件，默认工作区"},
        "glob": {"type": "string", "description": "文件名过滤，如 '*.py'"},
        "ignore_case": {"type": "boolean"},
    },
    ["pattern"],
    summary_keys=("pattern",),
)
async def grep(args, ctx: ToolContext):
    root = ctx.resolve(args.get("path") or ".", must_exist=True, read_only=True)
    pattern = args["pattern"]
    rg = shutil.which("rg")
    if rg:
        cmd = [rg, "-n", "--no-heading", "--color", "never", "-M", "300", "--max-count", "50"]
        if args.get("ignore_case"):
            cmd.append("-i")
        if args.get("glob"):
            cmd += ["-g", args["glob"]]
        cmd += ["-e", pattern, str(root)]
        proc = await asyncio.create_subprocess_exec(*cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        out, err = await proc.communicate()
        ws_prefix = str(ctx.workspace) + os.sep
        text = out.decode("utf-8", "replace").replace(ws_prefix, "")
        if os.name == "nt":
            text = "\n".join(
                (ln.split(":", 1)[0].replace("\\", "/") + ":" + ln.split(":", 1)[1]) if ":" in ln else ln
                for ln in text.splitlines()
            )
        if proc.returncode not in (0, 1):
            raise ToolError(err.decode("utf-8", "replace"))
        return truncate(text.strip() or "没有匹配结果", 20_000)
    flags = re.IGNORECASE if args.get("ignore_case") else 0
    try:
        rx = re.compile(pattern, flags)
    except re.error as e:
        raise ToolError(f"正则表达式错误: {e}") from None
    results = []
    files = [root] if root.is_file() else _iter_files(root)
    for f in files:
        if args.get("glob") and not fnmatch.fnmatch(f.name, args["glob"]):
            continue
        if _is_binary(f) or f.stat().st_size > 5_000_000:
            continue
        try:
            for i, line in enumerate(f.read_text(encoding="utf-8", errors="ignore").splitlines(), 1):
                if rx.search(line):
                    results.append(f"{ctx.rel(f)}:{i}:{line[:300]}")
                    if len(results) >= 500:
                        break
        except OSError:
            continue
        if len(results) >= 500:
            break
    return truncate("\n".join(results) or "没有匹配结果", 20_000)


FILE_TOOLS = [read_file, write_file, edit_file, list_dir, glob_files, grep]
