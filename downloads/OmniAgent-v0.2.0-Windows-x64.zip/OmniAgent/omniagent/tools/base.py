"""工具系统基础：Tool 定义、执行上下文、注册表。"""
from __future__ import annotations

import inspect
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Awaitable, Callable

from omniagent.llm.types import ToolSchema

MAX_TOOL_OUTPUT = 30_000  # 返回给模型的单次工具输出上限（字符）


class ToolError(Exception):
    """工具执行中可预期的错误，会作为 is_error 结果返回给模型以便其自我修正。"""


@dataclass
class ToolResult:
    content: str
    is_error: bool = False
    data: dict[str, Any] = field(default_factory=dict)  # 给 UI 的结构化附加信息（diff、图片路径等）
    # 发送给模型的图片：[{"media_type": "image/png", "data": "<base64>", "path": "相对路径"}]
    # Agent 会把它放进 tool 消息的 meta["images"]，由各 provider 按协议转换。
    images: list[dict[str, str]] = field(default_factory=list)


@dataclass
class ToolContext:
    workspace: Path
    settings: Any
    emit: Callable[[dict[str, Any]], Awaitable[None]]
    ask_user: Callable[[str], Awaitable[str | None]] | None = None
    state: dict[str, Any] = field(default_factory=dict)
    agent: Any = None  # 当前 Agent 实例（供子智能体工具使用）

    def extra_read_roots(self) -> list[Path]:
        """工作区之外允许只读访问的目录（技能目录等）。"""
        roots = list(self.state.get("extra_read_roots") or [])
        try:
            from .skills import skill_roots

            roots += skill_roots(self.workspace)
        except Exception:  # noqa: BLE001  skills 模块缺失时忽略
            pass
        return roots

    def resolve(self, path: str | None, *, must_exist: bool = False, read_only: bool = False) -> Path:
        """解析路径并做沙箱检查。read_only=True 时额外允许读取技能目录等只读根目录。"""
        if not path:
            path = "."
        p = Path(path).expanduser()
        if not p.is_absolute():
            p = self.workspace / p
        p = p.resolve()
        if not self.settings.allow_outside_workspace:
            try:
                p.relative_to(self.workspace)
            except ValueError:
                if read_only and any(_is_within(p, r) for r in self.extra_read_roots()):
                    if must_exist and not p.exists():
                        raise ToolError(f"路径不存在: {p}") from None
                    return p
                raise ToolError(
                    f"路径 {p} 位于工作区 {self.workspace} 之外，已被安全策略拒绝。请使用工作区内的相对路径。"
                ) from None
        if must_exist and not p.exists():
            raise ToolError(f"路径不存在: {self.rel(p)}")
        return p

    def rel(self, p: Path) -> str:
        try:
            return p.relative_to(self.workspace).as_posix() or "."
        except ValueError:
            return str(p)


def _is_within(p: Path, root: Path) -> bool:
    try:
        p.relative_to(Path(root).resolve())
        return True
    except (ValueError, OSError):
        return False


class Tool:
    name: str = ""
    description: str = ""
    parameters: dict[str, Any] = {"type": "object", "properties": {}}
    risk: str = "read"  # read | write | exec
    summary_keys: tuple[str, ...] = ()

    async def run(self, args: dict[str, Any], ctx: ToolContext) -> ToolResult:  # pragma: no cover
        raise NotImplementedError

    def schema(self) -> ToolSchema:
        return ToolSchema(self.name, self.description.strip(), self.parameters)

    def summarize(self, args: dict[str, Any]) -> str:
        for k in self.summary_keys:
            if args.get(k):
                v = str(args[k]).replace("\n", " ⏎ ")
                return v if len(v) <= 120 else v[:117] + "..."
        return ""


class FunctionTool(Tool):
    def __init__(self, fn, name, description, parameters, risk="read", summary_keys=()):
        self.fn = fn
        self.name = name
        self.description = description
        self.parameters = parameters
        self.risk = risk
        self.summary_keys = tuple(summary_keys)

    async def run(self, args, ctx):
        out = self.fn(args, ctx)
        if inspect.isawaitable(out):
            out = await out
        if isinstance(out, ToolResult):
            return out
        return ToolResult(content=str(out))


def tool(name: str, description: str, properties: dict[str, Any], required: list[str] | None = None,
         risk: str = "read", summary_keys: tuple[str, ...] = ()):
    """装饰器：把 `async def fn(args, ctx)` 变成 Tool。"""

    def deco(fn):
        params = {"type": "object", "properties": properties, "required": required or []}
        return FunctionTool(fn, name, description, params, risk, summary_keys)

    return deco


class ToolRegistry:
    def __init__(self, tools: list[Tool] | None = None):
        self._tools: dict[str, Tool] = {}
        for t in tools or []:
            self.register(t)

    def register(self, t: Tool) -> None:
        self._tools[t.name] = t

    def unregister(self, name: str) -> None:
        self._tools.pop(name, None)

    def get(self, name: str) -> Tool | None:
        return self._tools.get(name)

    def names(self) -> list[str]:
        return list(self._tools)

    def schemas(self) -> list[ToolSchema]:
        return [t.schema() for t in self._tools.values()]

    def subset(self, exclude: set[str]) -> "ToolRegistry":
        return ToolRegistry([t for n, t in self._tools.items() if n not in exclude])


def truncate(text: str, limit: int = MAX_TOOL_OUTPUT) -> str:
    if len(text) <= limit:
        return text
    head = int(limit * 0.6)
    tail = limit - head
    omitted = len(text) - limit
    return f"{text[:head]}\n\n... [已省略 {omitted} 个字符] ...\n\n{text[-tail:]}"
