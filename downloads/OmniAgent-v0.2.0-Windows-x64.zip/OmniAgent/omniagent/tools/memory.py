"""长期记忆、用户画像与在办项目连续性工具集（Memory Tools）。"""
from __future__ import annotations

from typing import Any

from omniagent.memory import MEMORY_CATEGORIES, PORTRAIT_DIMENSIONS, PROJECT_KINDS, MemoryStore

from .base import ToolContext, ToolError, ToolResult, tool


def _get_store(ctx: ToolContext) -> MemoryStore:
    store = ctx.state.get("memory_store")
    if isinstance(store, MemoryStore):
        return store
    store = MemoryStore(ctx.workspace / ".omniagent" / "memory.db")
    ctx.state["memory_store"] = store
    ctx.state["_owned_memory_store"] = True
    return store


def _record_turn_event(ctx: ToolContext, ev: dict[str, Any]) -> None:
    events: list[dict[str, Any]] = ctx.state.setdefault("_turn_memory_events", [])
    events.append(ev)


@tool(
    "memory_upsert",
    "将高价值的跨会话信息写入长期记忆（如用户的公文/论文排版格式要求、写作禁忌、历史纠错教训、数据统计口径、编程习惯偏好等）。"
    "当用户表达明确偏好、纠正你的输出或确立某项长期体例标准时，请主动调用本工具保存；若同类习惯发生变化，传入相同 topic_key 会自动覆盖旧规则。",
    {
        "content": {
            "type": "string",
            "description": "清晰、具体、可跨会话直接复用的记忆条目（切勿写入密码或 API 密钥）",
        },
        "category": {
            "type": "string",
            "enum": list(MEMORY_CATEGORIES.keys()),
            "description": "类别：format_spec（格式与体例规范）/ correction（纠错与避坑教训）/ preference（个人习惯偏好）/ domain_fact（业务口径与事实）/ episodic（里程碑纪要）",
        },
        "topic_key": {
            "type": "string",
            "description": "可选主题键（如 official_doc_font、reg_parentheses、chart_palette），后续用户调整同类偏好时会自动覆盖旧条目",
        },
        "tags": {
            "type": "array",
            "items": {"type": "string"},
            "description": "检索标签列表",
        },
        "importance": {
            "type": "integer",
            "description": "重要度 1~5（4~5 会作为核心规范常驻注入系统提示词）",
        },
        "pinned": {
            "type": "boolean",
            "description": "是否置顶为必须遵守的铁律",
        },
        "portrait_dimension": {
            "type": "string",
            "enum": list(PORTRAIT_DIMENSIONS.keys()),
            "description": "可选：同步写入用户画像维度（identity / official_doc_format / academic_paper_format / writing_style / coding_prefs / data_and_workflow）",
        },
        "portrait_key": {
            "type": "string",
            "description": "可选：同步更新用户画像时的特征键名",
        },
    },
    ["content"],
    summary_keys=("content", "category"),
)
async def memory_upsert(args: dict[str, Any], ctx: ToolContext) -> ToolResult:
    store = _get_store(ctx)
    conv_id = getattr(ctx.agent, "session_id", "") if ctx.agent else ""
    rec = store.upsert_memory(
        args["content"],
        category=args.get("category") or "preference",
        topic_key=args.get("topic_key") or "",
        tags=args.get("tags") or [],
        importance=int(args.get("importance") or 4),
        pinned=bool(args.get("pinned", False)),
        source="agent_tool",
        conv_id=conv_id,
    )
    if not rec:
        raise ToolError("记忆内容过短或无效，未能保存。")
    ev = {"kind": "memory", "category": rec["category"], "summary": rec["content"], "id": rec["id"]}
    _record_turn_event(ctx, ev)

    dim = args.get("portrait_dimension")
    if dim and dim in PORTRAIT_DIMENSIONS:
        pkey = args.get("portrait_key") or args.get("topic_key") or rec["id"]
        tr = store.upsert_trait(dim, pkey, rec["content"], confidence=0.92, source="explicit")
        if tr:
            _record_turn_event(ctx, {
                "kind": "portrait",
                "dimension": dim,
                "summary": f"{PORTRAIT_DIMENSIONS[dim]['title']}：{tr['value']}",
            })

    return ToolResult(
        f"已写入长期记忆 [{rec['id']}]（{rec['category_label']}，重要度 {rec['importance']}）：{rec['content']}",
        data={"memory": rec},
    )


@tool(
    "memory_search",
    "检索长期记忆库、用户画像与在办文稿/项目记录。续写历史文章报告、回忆用户特定排版体例或核对过往业务口径时调用。",
    {
        "query": {"type": "string", "description": "检索关键词或自然语言问题（留空则列出核心常驻记忆与活跃项目）"},
        "category": {
            "type": "string",
            "description": "可选过滤类别：format_spec / correction / preference / domain_fact / episodic",
        },
        "include_projects": {
            "type": "boolean",
            "description": "是否同时检索并返回在办文稿/项目进度（默认 true）",
        },
    },
    [],
    summary_keys=("query", "category"),
)
async def memory_search(args: dict[str, Any], ctx: ToolContext) -> ToolResult:
    store = _get_store(ctx)
    q = str(args.get("query") or "").strip()
    cat = str(args.get("category") or "").strip()
    inc_proj = args.get("include_projects", True)

    mems = store.search_memories(q, category=cat, limit=12) if q else store.list_memories(category=cat, limit=12)
    lines: list[str] = []
    if mems:
        lines.append(f"### 匹配长期记忆（{len(mems)} 条）")
        for m in mems:
            pin = "📌" if m["pinned"] else ""
            lines.append(f"- `{m['id']}` {pin}[{m['category_label']} · ★{m['importance']}] {m['content']}")
    else:
        lines.append("（未检索到匹配的原子记忆条目）")

    if inc_proj:
        projs = store.list_projects(limit=8)
        if q:
            matched = store.find_matching_project(q)
            if matched:
                projs = [matched] + [p for p in projs if p["slug"] != matched["slug"]][:3]
            else:
                projs = projs[:4]
        if projs:
            lines.append("\n### 在办工作与文稿进度")
            for p in projs[:5]:
                lines.append(f"- **{p['title']}** (`{p['slug']}` · {p['kind_label']} · {p['status']} · 进度 {p['progress_pct']}%)")
                if p["completed_items"]:
                    lines.append("  - 已完成：" + "；".join(p["completed_items"][:6]))
                if p["pending_items"]:
                    lines.append("  - 待完善：" + "；".join(p["pending_items"][:6]))
                if p["artifacts"]:
                    lines.append("  - 关联文件：" + ", ".join(p["artifacts"][:6]))

    return ToolResult("\n".join(lines), data={"count": len(mems)})


@tool(
    "memory_delete",
    "删除一条已过时、错误或用户要求遗忘的长期记忆条目。",
    {
        "memory_id": {"type": "string", "description": "要删除的记忆 ID（如 mem_xxxxxxxx）"},
    },
    ["memory_id"],
    summary_keys=("memory_id",),
)
async def memory_delete(args: dict[str, Any], ctx: ToolContext) -> ToolResult:
    store = _get_store(ctx)
    mid = str(args["memory_id"]).strip()
    ok = store.delete_memory(mid)
    if not ok:
        raise ToolError(f"未找到记忆条目 `{mid}`")
    return ToolResult(f"已删除记忆条目 `{mid}`")


@tool(
    "portrait_update",
    "结构化更新【用户画像（User Persona Portrait）】的某个维度特征，如公文排版规范、目标学术期刊风格、写作语调与禁忌、主力技术栈或数据口径习惯。",
    {
        "dimension": {
            "type": "string",
            "enum": list(PORTRAIT_DIMENSIONS.keys()),
            "description": "画像维度：identity / official_doc_format / academic_paper_format / writing_style / coding_prefs / data_and_workflow",
        },
        "trait_key": {
            "type": "string",
            "description": "特征键名（如 gongwen_standard、target_journal、forbidden_words、python_tooling）",
        },
        "value": {
            "type": "string",
            "description": "该维度的具体用户习惯与标准描述",
        },
        "source": {
            "type": "string",
            "enum": ["explicit", "inferred"],
            "description": "explicit 表示用户明确提出的要求；inferred 表示从行为与文稿风格归纳",
        },
    },
    ["dimension", "trait_key", "value"],
    summary_keys=("dimension", "value"),
)
async def portrait_update(args: dict[str, Any], ctx: ToolContext) -> ToolResult:
    store = _get_store(ctx)
    dim = str(args["dimension"])
    tr = store.upsert_trait(
        dim,
        str(args["trait_key"]),
        str(args["value"]),
        confidence=0.95 if args.get("source") != "inferred" else 0.82,
        source=args.get("source") or "explicit",
    )
    if not tr:
        raise ToolError("画像特征值无效。")
    dim_title = PORTRAIT_DIMENSIONS.get(dim, {}).get("title", dim)
    _record_turn_event(ctx, {
        "kind": "portrait",
        "dimension": dim,
        "summary": f"{dim_title}：{tr['value']}",
    })
    return ToolResult(f"已更新用户画像【{dim_title} / {tr['trait_key']}】：{tr['value']}", data={"trait": tr})


@tool(
    "project_memory",
    "跨对话记录或查询【在办工作与文稿连续性进度】（如同一篇学术论文、研究报告、公文方案或软件工程已经完成了哪些章节/分析，还有哪些部分待补充完善、锁定的核心口径与关联文件）。",
    {
        "action": {
            "type": "string",
            "enum": ["upsert", "get", "list"],
            "description": "操作类型：upsert（新建或增量更新项目进度）/ get（按 slug 查询详情）/ list（列出所有在办项目）",
        },
        "title": {"type": "string", "description": "项目、文章或报告标题（upsert 时提供）"},
        "slug": {"type": "string", "description": "项目短标识（可选，省略则根据标题自动生成或匹配）"},
        "kind": {
            "type": "string",
            "enum": list(PROJECT_KINDS.keys()),
            "description": "类型：paper（学术论文）/ official_doc（公文方案）/ report（分析报告）/ code_project（软件工程）/ general",
        },
        "status": {
            "type": "string",
            "enum": ["active", "blocked", "completed", "archived"],
            "description": "项目状态（默认 active）",
        },
        "summary": {"type": "string", "description": "当前文稿或工程的整体进展概述"},
        "completed_items": {
            "type": "array",
            "items": {"type": "string"},
            "description": "已完成的内容模块/章节/实验清单（已完成的事项会自动从 pending_items 中核销移除）",
        },
        "pending_items": {
            "type": "array",
            "items": {"type": "string"},
            "description": "尚未完成、有待补充完善或下一步计划推进的事项清单",
        },
        "key_facts": {
            "type": "array",
            "items": {"type": "string"},
            "description": "跨对话必须保持一致的核心口径、样本区间、实证结论或架构约束",
        },
        "artifacts": {
            "type": "array",
            "items": {"type": "string"},
            "description": "关联的工作区文件路径（如 outputs/fiscal_report.docx）",
        },
        "merge": {
            "type": "boolean",
            "description": "是否与已有同标识项目增量合并（默认 true；设为 false 则完整替换清单）",
        },
    },
    [],
    summary_keys=("action", "title", "slug"),
)
async def project_memory(args: dict[str, Any], ctx: ToolContext) -> ToolResult:
    store = _get_store(ctx)
    action = str(args.get("action") or "upsert")

    if action == "list":
        projs = store.list_projects(include_archived=False, limit=25)
        if not projs:
            return ToolResult("当前暂无登记的在办项目或文稿。")
        out = ["### 在办项目与文稿列表"]
        for p in projs:
            out.append(
                f"- **{p['title']}** (`{p['slug']}` · {p['kind_label']} · 进度 {p['progress_pct']}% · "
                f"已完成 {len(p['completed_items'])} / 待完善 {len(p['pending_items'])})"
            )
        return ToolResult("\n".join(out), data={"projects": projs})

    if action == "get":
        key = str(args.get("slug") or args.get("title") or "").strip()
        if not key:
            raise ToolError("get 操作需要提供 slug 或 title")
        proj = store.get_project(key) or store.find_matching_project(key)
        if not proj:
            raise ToolError(f"未找到匹配的在办项目：{key}")
        lines = [
            f"### {proj['title']} (`{proj['slug']}` · {proj['kind_label']} · {proj['status']} · {proj['progress_pct']}%)",
            f"- **概述**：{proj['summary'] or '（无）'}",
            f"- **已完成（{len(proj['completed_items'])}）**：{'；'.join(proj['completed_items']) or '（暂无）'}",
            f"- **待完善（{len(proj['pending_items'])}）**：{'；'.join(proj['pending_items']) or '（暂无）'}",
            f"- **关键口径**：{'；'.join(proj['key_facts']) or '（暂无）'}",
            f"- **关联文件**：{', '.join(proj['artifacts']) or '（暂无）'}",
        ]
        return ToolResult("\n".join(lines), data={"project": proj})

    title = str(args.get("title") or args.get("slug") or "").strip()
    if not title:
        raise ToolError("upsert 项目进度需要提供 title")
    conv_id = getattr(ctx.agent, "session_id", "") if ctx.agent else ""
    matched = store.find_matching_project(title, conv_id=conv_id) if not args.get("slug") else None
    slug = str(args.get("slug") or (matched["slug"] if matched else "")).strip()
    proj = store.upsert_project(
        title,
        slug=slug,
        kind=str(args.get("kind") or (matched["kind"] if matched else "general")),
        status=str(args.get("status") or "active"),
        summary=str(args.get("summary") or ""),
        completed_items=args.get("completed_items"),
        pending_items=args.get("pending_items"),
        key_facts=args.get("key_facts"),
        artifacts=args.get("artifacts"),
        merge=bool(args.get("merge", True)),
        conv_id=conv_id,
    )
    _record_turn_event(ctx, {
        "kind": "project",
        "slug": proj["slug"],
        "title": proj["title"],
        "completed_count": len(proj["completed_items"]),
        "pending_count": len(proj["pending_items"]),
        "summary": f"已记录项目「{proj['title']}」（已完成 {len(proj['completed_items'])} 项，待完善 {len(proj['pending_items'])} 项）",
    })
    return ToolResult(
        f"已同步在办项目「{proj['title']}」(`{proj['slug']}`，进度 {proj['progress_pct']}%：\n"
        f"- 已完成：{len(proj['completed_items'])} 项\n- 待完善：{len(proj['pending_items'])} 项",
        data={"project": proj},
    )


MEMORY_TOOLS = [memory_upsert, memory_search, memory_delete, portrait_update, project_memory]
