"""学术论文与办公报告质量自检工具：结构完整性、图表连续编号、正文前置引用、嵌入图片有效性、字数与占位符检查。"""
from __future__ import annotations

import asyncio
import io
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .base import ToolContext, ToolError, ToolResult, tool
from .documents import (
    FIG_CAP_RE,
    NOTE_RE,
    REF_HEAD_RE,
    TAB_CAP_RE,
    _strip_md,
    caption_match,
    parse_label,
    parse_markdown_blocks,
)

DOC_TYPES = ("fiscal_paper", "report", "generic")

_W_NS = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
_A_NS = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
_R_NS = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
_V_NS = "{urn:schemas-microsoft-com:vml}"

_PLACEHOLDER_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("英文占位符 (TODO/FIXME/TBD/XXX)", re.compile(r"\b(?:TODO|FIXME|TBD|XXX)\b", re.I)),
    ("中文占位符 (待补充/此处插入等)", re.compile(r"待补充|待完善|待填写|此处插入|在此插入|请在此处|\[图片缺失")),
    ("未替换模板尖括号", re.compile(r"<(?:论文题目|词\d|粘贴|请填写|待填)[^>]{0,60}>")),
]

# 正文文献引用识别：[1]、[1-3]、[1, 2] 或 （作者，2020）/ 作者（2020）/ Author et al. (2020)
_BRACKET_CITE_RE = re.compile(r"\[\s*\d{1,3}(?:\s*[-–—,，]\s*\d{1,3})*\s*\]")
_AUTHOR_YEAR_CITE_RE = re.compile(
    r"(?:[（(][^()（）\n]{1,32}[,，]\s*(?:19|20)\d{2}[a-z]?[)）]"
    r"|[A-Za-z\u4e00-\u9fff]{2,20}(?:\s*等|\s+et\s+al\.)?\s*[（(](?:19|20)\d{2}[a-z]?[)）])"
)

_FISCAL_SECTIONS: list[tuple[str, re.Pattern[str]]] = [
    ("引言/问题提出", re.compile(r"引言|问题提出|问题的提出|研究背景|绪论|导论")),
    ("文献综述/理论分析与研究假说", re.compile(r"文献综述|文献回顾|相关文献|理论分析|理论机制|研究假说|研究假设|制度背景")),
    ("研究设计/模型与数据", re.compile(r"研究设计|模型设定|模型构建|计量模型|变量定义|数据来源|样本与数据|实证设计|模型与数据")),
    ("实证结果分析", re.compile(r"实证结果|实证分析|基准回归|回归结果|经验结果|实证检验")),
    ("稳健性检验", re.compile(r"稳健性|内生性|安慰剂|敏感性")),
    ("异质性或机制分析", re.compile(r"异质性|机制分析|机制检验|传导机制|作用机制|渠道分析|调节效应|中介效应|进一步分析")),
    ("结论与政策建议", re.compile(r"结论|政策建议|政策启示|研究结论|结语|对策建议")),
]

_REPORT_SECTIONS: list[tuple[str, re.Pattern[str]]] = [
    ("摘要/核心结论", re.compile(r"摘要|执行摘要|核心结论|总体情况|概述|概要")),
    ("主体分析", re.compile(r"分析|发现|趋势|结构|对比|归因|现状|结果|表现")),
    ("结论与建议", re.compile(r"结论|建议|对策|举措|下一步|行动计划|总结")),
]


@dataclass
class DocIR:
    path: Path
    title: str = ""
    abstract: str = ""
    keywords: list[str] = field(default_factory=list)
    headings: list[dict[str, Any]] = field(default_factory=list)
    figures: list[dict[str, Any]] = field(default_factory=list)
    tables: list[dict[str, Any]] = field(default_factory=list)
    references: list[str] = field(default_factory=list)
    equations_count: int = 0
    elements: list[dict[str, Any]] = field(default_factory=list)
    body_segments: list[tuple[int, str]] = field(default_factory=list)
    all_texts: list[str] = field(default_factory=list)


def _parse_cap_num(caption: str, kind: str) -> int | None:
    s = _strip_md(caption or "")
    m = (FIG_CAP_RE if kind == "figure" else TAB_CAP_RE).match(s)
    if not m:
        return None
    raw = m.group(1)
    if re.fullmatch(r"\d+", raw):
        return int(raw)
    # 图1-1 等复合编号返回 None 以便提示使用连续单层编号（或按需处理）
    head = re.split(r"[-–.．]", raw)[0]
    return int(head) if head.isdigit() else None


def _split_keywords(text: str) -> list[str]:
    cleaned = re.sub(r"[。.\s]+$", "", text.strip())
    if "；" in cleaned or ";" in cleaned:
        parts = re.split(r"[；;]+", cleaned)
    elif "、" in cleaned or "，" in cleaned or "," in cleaned:
        parts = re.split(r"[、，,]+", cleaned)
    else:
        parts = re.split(r"[\s\u3000]+", cleaned)
    return [p.strip() for p in parts if p.strip()]


def _validate_image_bytes(blob: bytes) -> tuple[bool, int, int]:
    if not blob:
        return False, 0, 0
    try:
        from PIL import Image

        with Image.open(io.BytesIO(blob)) as im:
            w, h = im.size
            return (w > 0 and h > 0), int(w), int(h)
    except Exception:  # noqa: BLE001
        return False, 0, 0


def _validate_image_file(p: Path) -> tuple[bool, int, int, int]:
    if not p.exists() or not p.is_file():
        return False, 0, 0, 0
    try:
        blob = p.read_bytes()
    except OSError:
        return False, 0, 0, 0
    ok, w, h = _validate_image_bytes(blob)
    return ok, len(blob), w, h


def _parse_md_to_ir(path: Path, workspace: Path | None = None) -> DocIR:
    md = path.read_text(encoding="utf-8", errors="replace")
    blocks = parse_markdown_blocks(md)
    ir = DocIR(path=path)
    base_dirs = [d for d in (workspace, path.parent) if d is not None]

    heads = [b for b in blocks if b.kind == "heading"]
    h1s = [b for b in heads if b.level == 1]
    title_block_idx: int | None = None
    if heads and heads[0].level == 1 and len(h1s) == 1:
        ir.title = _strip_md(heads[0].text)
        title_block_idx = blocks.index(heads[0])

    pending_abstract_heading = False
    pos = 0
    for idx, b in enumerate(blocks):
        if idx == title_block_idx:
            ir.all_texts.append(b.text)
            continue
        pos += 1
        kind = b.kind
        if kind == "heading":
            htxt = _strip_md(b.text)
            pending_abstract_heading = bool(re.fullmatch(r"(?:摘\s*要|内容提要|执行摘要)", htxt))
            h_entry = {"level": b.level, "text": htxt, "pos": pos, "line": b.line}
            ir.headings.append(h_entry)
            ir.elements.append({"kind": "heading", "level": b.level, "text": htxt, "pos": pos})
            ir.all_texts.append(htxt)
        elif kind == "abstract":
            ir.abstract = b.text.strip()
            ir.elements.append({"kind": "abstract", "text": ir.abstract, "pos": pos})
            ir.body_segments.append((pos, ir.abstract))
            ir.all_texts.append(ir.abstract)
        elif kind == "keywords":
            ir.keywords = _split_keywords(b.text)
            ir.elements.append({"kind": "keywords", "text": b.text, "pos": pos})
            ir.all_texts.append(b.text)
        elif kind in ("abstract_en", "keywords_en", "meta"):
            ir.elements.append({"kind": kind, "text": b.text, "pos": pos})
            ir.all_texts.append(b.text)
        elif kind == "image":
            img_ok, nbytes, w, h = False, 0, 0, 0
            if not b.src.startswith(("http://", "https://")):
                cand_paths = [Path(b.src).expanduser()] if Path(b.src).expanduser().is_absolute() else [d / b.src for d in base_dirs]
                for cp in cand_paths:
                    img_ok, nbytes, w, h = _validate_image_file(cp)
                    if img_ok or cp.exists():
                        break
            has_note = (idx + 1 < len(blocks) and blocks[idx + 1].kind == "note")
            cap = _strip_md(b.caption)
            fig_entry = {
                "index": len(ir.figures) + 1,
                "pos": pos,
                "caption": cap,
                "num": _parse_cap_num(cap, "figure"),
                "src": b.src,
                "exists": img_ok,
                "bytes": nbytes,
                "width": w,
                "height": h,
                "has_note": has_note,
            }
            ir.figures.append(fig_entry)
            ir.elements.append({"kind": "figure", "pos": pos, "text": cap})
            if cap:
                ir.all_texts.append(cap)
        elif kind == "table":
            has_note = (idx + 1 < len(blocks) and blocks[idx + 1].kind == "note")
            if not has_note and b.rows:
                last_cell = " ".join(b.rows[-1]).strip()
                if NOTE_RE.match(_strip_md(last_cell)):
                    has_note = True
            cap = _strip_md(b.caption)
            tab_entry = {
                "index": len(ir.tables) + 1,
                "pos": pos,
                "caption": cap,
                "num": _parse_cap_num(cap, "table"),
                "rows": len(b.rows),
                "cols": max((len(r) for r in b.rows), default=0),
                "has_note": has_note,
            }
            ir.tables.append(tab_entry)
            ir.elements.append({"kind": "table", "pos": pos, "text": cap})
            if cap:
                ir.all_texts.append(cap)
            for r in b.rows:
                ir.all_texts.append(" ".join(r))
        elif kind == "note":
            ir.elements.append({"kind": "note", "pos": pos, "text": b.text})
            ir.all_texts.append(b.text)
        elif kind == "equation":
            ir.equations_count += 1
            ir.elements.append({"kind": "equation", "pos": pos, "text": b.text})
        elif kind == "ref":
            if b.text.strip():
                ir.references.append(b.text.strip())
                ir.elements.append({"kind": "ref", "pos": pos, "text": b.text.strip()})
                ir.all_texts.append(b.text.strip())
        elif kind in ("para", "bullet", "number", "quote"):
            txt = b.text.strip()
            if pending_abstract_heading and not ir.abstract and kind == "para":
                ir.abstract = txt
                pending_abstract_heading = False
            ir.elements.append({"kind": kind, "pos": pos, "text": txt})
            ir.body_segments.append((pos, txt))
            ir.all_texts.append(txt)
        elif kind == "code":
            ir.elements.append({"kind": "code", "pos": pos, "text": b.text})
            ir.all_texts.append(b.text)
    return ir


def _docx_blip_rids(p_el) -> list[str]:
    rids: list[str] = []
    for blip in p_el.findall(f".//{_A_NS}blip"):
        rid = blip.get(f"{_R_NS}embed")
        if rid:
            rids.append(rid)
    for vimg in p_el.findall(f".//{_V_NS}imagedata"):
        rid = vimg.get(f"{_R_NS}id")
        if rid:
            rids.append(rid)
    return rids


def _parse_docx_to_ir(path: Path) -> DocIR:
    import docx
    from docx.table import Table
    from docx.text.paragraph import Paragraph

    d = docx.Document(str(path))
    ir = DocIR(path=path)
    children = list(d.element.body.iterchildren())
    n_children = len(children)
    in_refs = False
    refs_level = 0
    pending_abstract_heading = False
    pending_table_caption: str | None = None
    pos = 0
    i = 0

    while i < n_children:
        child = children[i]
        tag = child.tag.split("}")[-1]
        if tag == "p":
            para = Paragraph(child, d)
            style_name = (para.style.name if para.style is not None else "") or ""
            raw_text = para.text or ""
            text = raw_text.strip()
            rids = _docx_blip_rids(child)

            # 1. 公式段落（OA Equation 或带公式编号图片的独立段）
            is_eq = style_name == "OA Equation" or (
                bool(rids) and bool(re.fullmatch(r"[（(]\s*[\w.\-]+\s*[)）]", text))
            )
            if is_eq:
                pos += 1
                ir.equations_count += 1
                ir.elements.append({"kind": "equation", "pos": pos, "text": text})
                i += 1
                continue

            # 2. 缺失图片占位段（如 [图片缺失: xxx]）
            if text.startswith("[图片缺失:") or (style_name == "OA Figure" and not rids and "图片缺失" in text):
                pos += 1
                cap = ""
                if i + 1 < n_children and children[i + 1].tag.split("}")[-1] == "p":
                    nxt = Paragraph(children[i + 1], d)
                    nxt_txt = (nxt.text or "").strip()
                    nxt_style = (nxt.style.name if nxt.style is not None else "") or ""
                    if nxt_style == "Caption" or caption_match(nxt_txt, "figure"):
                        cap = _strip_md(nxt_txt)
                        i += 1
                ir.figures.append({
                    "index": len(ir.figures) + 1,
                    "pos": pos,
                    "caption": cap,
                    "num": _parse_cap_num(cap, "figure"),
                    "src": text,
                    "exists": False,
                    "bytes": 0,
                    "width": 0,
                    "height": 0,
                    "has_note": False,
                })
                ir.elements.append({"kind": "figure", "pos": pos, "text": cap})
                ir.all_texts.append(text)
                if cap:
                    ir.all_texts.append(cap)
                i += 1
                continue

            # 3. 嵌入图片段落（排除正文段落内的极小行内数学公式截图）
            if rids:
                first_part = d.part.related_parts.get(rids[0])
                blob = first_part.blob if first_part is not None else b""
                ok, w, h = _validate_image_bytes(blob)
                is_inline_math = (
                    style_name not in ("OA Figure", "Caption")
                    and bool(text)
                    and not caption_match(text, "figure")
                    and h > 0
                    and h < 110
                )
                if not is_inline_math:
                    pos += 1
                    cap = _strip_md(text) if caption_match(text, "figure") else ""
                    if not cap and pending_table_caption and caption_match(pending_table_caption, "figure"):
                        cap = pending_table_caption
                        pending_table_caption = None
                    if not cap and i + 1 < n_children and children[i + 1].tag.split("}")[-1] == "p":
                        nxt = Paragraph(children[i + 1], d)
                        nxt_txt = (nxt.text or "").strip()
                        nxt_style = (nxt.style.name if nxt.style is not None else "") or ""
                        if (nxt_style == "Caption" or caption_match(nxt_txt, "figure")) and not caption_match(nxt_txt, "table"):
                            cap = _strip_md(nxt_txt)
                            i += 1
                    has_note = False
                    if i + 1 < n_children and children[i + 1].tag.split("}")[-1] == "p":
                        nxt2 = Paragraph(children[i + 1], d)
                        nxt2_txt = (nxt2.text or "").strip()
                        nxt2_style = (nxt2.style.name if nxt2.style is not None else "") or ""
                        if nxt2_style == "OA Note" or NOTE_RE.match(_strip_md(nxt2_txt)):
                            has_note = True
                    ir.figures.append({
                        "index": len(ir.figures) + 1,
                        "pos": pos,
                        "caption": cap,
                        "num": _parse_cap_num(cap, "figure"),
                        "src": str(getattr(first_part, "partname", rids[0])),
                        "exists": ok and len(blob) > 0,
                        "bytes": len(blob),
                        "width": w,
                        "height": h,
                        "has_note": has_note,
                    })
                    ir.elements.append({"kind": "figure", "pos": pos, "text": cap})
                    if cap:
                        ir.all_texts.append(cap)
                    i += 1
                    continue

            if not text:
                i += 1
                continue

            # 4. 文档主标题
            if style_name == "Title" and not ir.title:
                ir.title = _strip_md(text)
                ir.all_texts.append(ir.title)
                i += 1
                continue

            # 5. 各级章节标题
            hm = re.match(r"Heading\s*(\d+)", style_name, re.I)
            if hm:
                lvl = int(hm.group(1))
                htxt = _strip_md(text)
                if in_refs and lvl <= refs_level:
                    in_refs = False
                if REF_HEAD_RE.match(htxt):
                    in_refs, refs_level = True, lvl
                pending_abstract_heading = bool(re.fullmatch(r"(?:摘\s*要|内容提要|执行摘要)", htxt))
                pending_table_caption = None
                pos += 1
                ir.headings.append({"level": lvl, "text": htxt, "pos": pos})
                ir.elements.append({"kind": "heading", "level": lvl, "text": htxt, "pos": pos})
                ir.all_texts.append(htxt)
                i += 1
                continue

            # 6. 表题预缓存（紧邻 <w:tbl> 之前的表题段落）
            if (style_name == "Caption" or caption_match(text, "table")) and caption_match(text, "table"):
                pending_table_caption = _strip_md(text)
                i += 1
                continue

            # 7. 摘要 / 关键词等标签段
            lab = parse_label(text)
            if lab:
                lkind, _, lval = lab
                pos += 1
                if lkind == "abstract":
                    ir.abstract = lval.strip()
                    ir.elements.append({"kind": "abstract", "pos": pos, "text": ir.abstract})
                    ir.body_segments.append((pos, ir.abstract))
                elif lkind == "keywords":
                    ir.keywords = _split_keywords(lval)
                    ir.elements.append({"kind": "keywords", "pos": pos, "text": lval})
                else:
                    ir.elements.append({"kind": lkind, "pos": pos, "text": lval})
                ir.all_texts.append(text)
                i += 1
                continue

            # 8. 参考文献条目
            if in_refs or style_name == "OA Reference":
                pos += 1
                ir.references.append(text)
                ir.elements.append({"kind": "ref", "pos": pos, "text": text})
                ir.all_texts.append(text)
                i += 1
                continue

            # 9. 图注/表注
            if style_name == "OA Note" or (
                NOTE_RE.match(_strip_md(text)) and ir.elements and ir.elements[-1]["kind"] in ("table", "figure", "note")
            ):
                pos += 1
                ir.elements.append({"kind": "note", "pos": pos, "text": text})
                ir.all_texts.append(text)
                i += 1
                continue

            # 10. 作者/单位元信息段（不计入正文段落）
            if style_name in ("OA Author", "OA Affiliation"):
                ir.all_texts.append(text)
                i += 1
                continue

            # 11. 普通正文段落
            pos += 1
            if pending_abstract_heading and not ir.abstract:
                ir.abstract = text
                pending_abstract_heading = False
            ir.elements.append({"kind": "para", "pos": pos, "text": text})
            ir.body_segments.append((pos, text))
            ir.all_texts.append(text)
            i += 1

        elif tag == "tbl":
            tbl = Table(child, d)
            rows_txt = [[(c.text or "").strip() for c in r.cells] for r in tbl.rows]
            pos += 1
            cap = pending_table_caption or ""
            pending_table_caption = None
            has_note = False
            if i + 1 < n_children and children[i + 1].tag.split("}")[-1] == "p":
                nxt = Paragraph(children[i + 1], d)
                nxt_txt = (nxt.text or "").strip()
                nxt_style = (nxt.style.name if nxt.style is not None else "") or ""
                if nxt_style == "OA Note" or NOTE_RE.match(_strip_md(nxt_txt)):
                    has_note = True
            if not has_note and rows_txt:
                if NOTE_RE.match(_strip_md(" ".join(rows_txt[-1]))):
                    has_note = True
            ir.tables.append({
                "index": len(ir.tables) + 1,
                "pos": pos,
                "caption": cap,
                "num": _parse_cap_num(cap, "table"),
                "rows": len(rows_txt),
                "cols": max((len(r) for r in rows_txt), default=0),
                "has_note": has_note,
            })
            ir.elements.append({"kind": "table", "pos": pos, "text": cap})
            if cap:
                ir.all_texts.append(cap)
            for r in rows_txt:
                ir.all_texts.append(" ".join(r))
            i += 1
        else:
            i += 1

    return ir


def _infer_doc_type(ir: DocIR) -> str:
    heading_blob = " ".join(h["text"] for h in ir.headings)
    if ir.references or re.search(r"文献综述|实证|稳健性|异质性|研究假设|研究假说|基准回归", heading_blob):
        return "fiscal_paper"
    if re.search(r"执行摘要|分析|建议|趋势|总体情况", heading_blob) or ir.figures or ir.tables:
        return "report"
    return "generic"


def _find_empty_sections(ir: DocIR) -> list[str]:
    """检测空章节（允许父级标题直接跟子级标题，只要子树内有实质内容即可；叶子标题必须有内容）。"""
    empty: list[str] = []
    substantive = {"para", "bullet", "number", "quote", "figure", "table", "equation", "ref", "code", "abstract"}
    heads = ir.headings
    for idx, h in enumerate(heads):
        start_pos = h["pos"]
        lvl = h["level"]
        # 找到下一个同级或更高级标题的位置作为该章节子树终点
        end_pos = max((e["pos"] for e in ir.elements), default=start_pos) + 1
        for nxt in heads[idx + 1:]:
            if nxt["level"] <= lvl:
                end_pos = nxt["pos"]
                break
        next_any_head_pos = heads[idx + 1]["pos"] if idx + 1 < len(heads) else end_pos
        has_child_heading = (idx + 1 < len(heads) and heads[idx + 1]["level"] > lvl and heads[idx + 1]["pos"] < end_pos)
        if has_child_heading:
            has_content = any(
                e["kind"] in substantive and start_pos < e["pos"] < end_pos
                for e in ir.elements
            )
        else:
            has_content = any(
                e["kind"] in substantive and start_pos < e["pos"] < next_any_head_pos
                for e in ir.elements
            )
        if not has_content:
            empty.append(h["text"])
    return empty


def _first_callout_pos(body_segments: list[tuple[int, str]], prefix: str, num: int) -> int | None:
    pat = re.compile(rf"{prefix}\s*{num}(?![0-9])")
    for pos, seg in body_segments:
        if pat.search(seg):
            return pos
    return None


def inspect_document(
    path: str | Path,
    doc_type: str | None = None,
    *,
    workspace: Path | None = None,
) -> dict[str, Any]:
    """对 .docx 或 .md 文档执行结构化质量审查，返回包含 score (0-100)、metrics 与 issues 的字典。"""
    p = Path(path)
    ext = p.suffix.lower()
    if ext == ".md":
        ir = _parse_md_to_ir(p, workspace=workspace)
    elif ext == ".docx":
        ir = _parse_docx_to_ir(p)
    else:
        raise ToolError(f"check_document 仅支持 .docx 或 .md 文件，当前文件为: {p.name}")

    dtype = (doc_type or "").strip().lower()
    if not dtype or dtype == "auto":
        dtype = _infer_doc_type(ir)
    if dtype not in DOC_TYPES:
        raise ToolError(f"未知 doc_type: {doc_type!r}（可选: {', '.join(DOC_TYPES)}）")

    issues: list[dict[str, Any]] = []

    def add_issue(severity: str, code: str, message: str, penalty: int) -> None:
        issues.append({"severity": severity, "code": code, "message": message, "penalty": penalty})

    # 1. 字数统计
    full_joined = "\n".join(ir.all_texts)
    total_chars = len(re.sub(r"\s+", "", full_joined))
    cjk_chars = len(re.findall(r"[\u4e00-\u9fff]", full_joined))
    abstract_chars = len(re.sub(r"\s+", "", ir.abstract))

    if total_chars == 0:
        add_issue("error", "empty_document", "文档内容为空。", 50)

    # 2. 占位符残留检查
    for label, pat in _PLACEHOLDER_PATTERNS:
        matches = pat.findall(full_joined)
        if matches:
            sample = ", ".join(sorted({m.strip() for m in matches})[:4])
            add_issue("error", "placeholder_leftover", f"发现未清理的{label}：{sample}。", 12)

    # 3. 空章节检查
    empty_secs = _find_empty_sections(ir)
    if empty_secs:
        add_issue(
            "error",
            "empty_section",
            f"存在无正文内容的空章节：{', '.join(empty_secs[:5])}。",
            8 * min(len(empty_secs), 3),
        )

    # 4. 按文档类型检查必备章节、摘要字数、文献引用与总篇幅
    heading_texts = [h["text"] for h in ir.headings]
    missing_sections: list[str] = []

    body_blob = "\n".join(seg for _, seg in ir.body_segments)
    bracket_cites = _BRACKET_CITE_RE.findall(body_blob)
    author_cites = _AUTHOR_YEAR_CITE_RE.findall(body_blob)
    citation_count = len(bracket_cites) + len(author_cites)

    if dtype == "fiscal_paper":
        if not ir.abstract and not any(re.search(r"摘要|内容提要", h) for h in heading_texts):
            missing_sections.append("摘要")
        elif abstract_chars > 0 and not (200 <= abstract_chars <= 450):
            add_issue(
                "warning",
                "abstract_length",
                f"中文摘要当前为 {abstract_chars} 字，建议控制在 200—450 字之间。",
                5,
            )

        if len(ir.keywords) < 2 and not any(re.search(r"关键词|关键字", h) for h in heading_texts):
            missing_sections.append("关键词")
        elif ir.keywords and not (3 <= len(ir.keywords) <= 6):
            add_issue(
                "info",
                "keywords_count",
                f"关键词当前为 {len(ir.keywords)} 个，学术论文一般建议 3—5 个。",
                2,
            )

        for sec_name, sec_re in _FISCAL_SECTIONS:
            if not any(sec_re.search(h) for h in heading_texts):
                missing_sections.append(sec_name)

        if not ir.references and not any(REF_HEAD_RE.match(h) for h in heading_texts):
            missing_sections.append("参考文献")

        if missing_sections:
            add_issue(
                "error",
                "missing_sections",
                f"缺少财政学术论文核心章节/要素：{', '.join(missing_sections)}。",
                min(40, 7 * len(missing_sections)),
            )

        if citation_count == 0:
            add_issue(
                "warning",
                "missing_citations",
                "正文中未检测到文献引用标记（如“周黎安（2007）”或“[1]”）。",
                8,
            )
        if 0 < len(ir.references) < 5:
            add_issue(
                "warning",
                "few_references",
                f"参考文献仅 {len(ir.references)} 条，建议补充权威领域文献（通常 ≥ 10 条）。",
                4,
            )
        if total_chars < 3000:
            add_issue(
                "warning",
                "short_paper",
                f"论文总字数仅 {total_chars} 字，低于规范实证论文篇幅要求。",
                8,
            )
        if len(ir.figures) == 0:
            add_issue("warning", "no_figures", "论文未包含任何分析图表。", 6)
        if len(ir.tables) < 3:
            add_issue("warning", "few_tables", f"论文仅包含 {len(ir.tables)} 张表格，实证论文通常需包含描述统计、基准回归与稳健性表。", 6)

    elif dtype == "report":
        for sec_name, sec_re in _REPORT_SECTIONS:
            if sec_name.startswith("摘要") and ir.abstract:
                continue
            if not any(sec_re.search(h) for h in heading_texts):
                missing_sections.append(sec_name)
        if missing_sections:
            add_issue(
                "warning",
                "missing_report_sections",
                f"分析报告建议补齐以下结构模块：{', '.join(missing_sections)}。",
                5 * len(missing_sections),
            )
        if total_chars < 400:
            add_issue("warning", "short_report", f"报告总字数仅 {total_chars} 字，分析内容偏少。", 8)
        if len(ir.figures) == 0 and len(ir.tables) == 0:
            add_issue("warning", "no_visuals", "分析报告未包含任何图表或数据表。", 8)

    else:  # generic
        if not ir.title and not ir.headings:
            add_issue("warning", "no_headings", "文档缺少标题与章节层级结构。", 5)

    # 5. 图检查：图片真实嵌入/存在、图题编号连续性、正文前置引用（in-text callout placement）
    broken_figs = [f for f in ir.figures if not f["exists"]]
    if broken_figs:
        desc = ", ".join(f.get("caption") or f.get("src") or f"第{f['index']}幅图" for f in broken_figs[:5])
        add_issue("error", "missing_or_broken_image", f"发现缺失或损坏的图片（共 {len(broken_figs)} 处）：{desc}。", 12 * min(len(broken_figs), 3))

    uncaptioned_figs = [f for f in ir.figures if not f["caption"] or f["num"] is None]
    if uncaptioned_figs:
        add_issue(
            "warning",
            "figure_caption_missing",
            f"有 {len(uncaptioned_figs)} 幅图片缺少规范编号图题（应为“图1 标题”格式）。",
            5 * min(len(uncaptioned_figs), 3),
        )

    fig_nums = [f["num"] for f in ir.figures if f["num"] is not None]
    if fig_nums:
        expected_figs = list(range(1, len(fig_nums) + 1))
        if fig_nums != expected_figs:
            add_issue(
                "warning",
                "figure_numbering_nonsequential",
                f"图编号不连续或顺序有误：当前为 {['图' + str(n) for n in fig_nums]}，期望为 {['图' + str(n) for n in expected_figs]}。",
                6,
            )

    missing_fig_callouts: list[str] = []
    late_fig_callouts: list[str] = []
    for f in ir.figures:
        num = f["num"]
        if num is None:
            continue
        cpos = _first_callout_pos(ir.body_segments, "图", num)
        f["first_callout_pos"] = cpos
        if cpos is None:
            missing_fig_callouts.append(f"图{num}")
        elif cpos > f["pos"]:
            late_fig_callouts.append(f"图{num}")

    if missing_fig_callouts:
        add_issue(
            "warning",
            "figure_callout_missing",
            f"以下图片未在正文中被提及引用：{', '.join(missing_fig_callouts)}（应在图前写明“如图N所示”）。",
            5 * min(len(missing_fig_callouts), 3),
        )
    if late_fig_callouts:
        add_issue(
            "warning",
            "figure_callout_after_figure",
            f"以下图片的首次正文引用出现在图片之后：{', '.join(late_fig_callouts)}（规范要求“先见文、后见图”，请在紧邻图前的段落引出）。",
            5 * min(len(late_fig_callouts), 3),
        )

    # 6. 表检查：表题编号连续性、正文前置引用、表注（注：/资料来源：）
    uncaptioned_tabs = [t for t in ir.tables if not t["caption"] or t["num"] is None]
    if uncaptioned_tabs:
        add_issue(
            "warning",
            "table_caption_missing",
            f"有 {len(uncaptioned_tabs)} 张表格缺少规范编号表题（应在表格上方单独一行写“表1 标题”）。",
            5 * min(len(uncaptioned_tabs), 3),
        )

    tab_nums = [t["num"] for t in ir.tables if t["num"] is not None]
    if tab_nums:
        expected_tabs = list(range(1, len(tab_nums) + 1))
        if tab_nums != expected_tabs:
            add_issue(
                "warning",
                "table_numbering_nonsequential",
                f"表编号不连续或顺序有误：当前为 {['表' + str(n) for n in tab_nums]}，期望为 {['表' + str(n) for n in expected_tabs]}。",
                6,
            )

    missing_tab_callouts: list[str] = []
    late_tab_callouts: list[str] = []
    tables_without_notes: list[str] = []
    for t in ir.tables:
        num = t["num"]
        label = f"表{num}" if num is not None else f"第{t['index']}张表"
        if not t["has_note"]:
            tables_without_notes.append(label)
        if num is None:
            continue
        cpos = _first_callout_pos(ir.body_segments, "表", num)
        t["first_callout_pos"] = cpos
        if cpos is None:
            missing_tab_callouts.append(label)
        elif cpos > t["pos"]:
            late_tab_callouts.append(label)

    if missing_tab_callouts:
        add_issue(
            "warning",
            "table_callout_missing",
            f"以下表格未在正文中被提及引用：{', '.join(missing_tab_callouts)}（应在表前写明“见表N”或“表N报告了……”）。",
            5 * min(len(missing_tab_callouts), 3),
        )
    if late_tab_callouts:
        add_issue(
            "warning",
            "table_callout_after_table",
            f"以下表格的首次正文引用出现在表格之后：{', '.join(late_tab_callouts)}（规范要求“先见文、后见表”，请在表前段落引出）。",
            5 * min(len(late_tab_callouts), 3),
        )
    if dtype == "fiscal_paper" and tables_without_notes:
        add_issue(
            "info",
            "table_notes_missing",
            f"部分表格缺少表注（`注：` 或 `资料来源：`）：{', '.join(tables_without_notes[:5])}。",
            min(8, 2 * len(tables_without_notes)),
        )

    # 7. 优先级排序与得分计算
    sev_rank = {"error": 0, "warning": 1, "info": 2}
    issues.sort(key=lambda x: (sev_rank.get(x["severity"], 9), -x["penalty"]))
    total_penalty = sum(x["penalty"] for x in issues)
    score = max(0, min(100, 100 - total_penalty))
    critical_count = sum(1 for x in issues if x["severity"] == "error")

    metrics = {
        "total_chars": total_chars,
        "cjk_chars": cjk_chars,
        "abstract_chars": abstract_chars,
        "keywords_count": len(ir.keywords),
        "headings_count": len(ir.headings),
        "figures_count": len(ir.figures),
        "valid_figures_count": sum(1 for f in ir.figures if f["exists"]),
        "tables_count": len(ir.tables),
        "tables_with_notes_count": sum(1 for t in ir.tables if t["has_note"]),
        "equations_count": ir.equations_count,
        "citations_count": citation_count,
        "references_count": len(ir.references),
        "empty_sections_count": len(empty_secs),
        "missing_sections": missing_sections,
    }

    return {
        "score": score,
        "doc_type": dtype,
        "passed": score >= 85 and critical_count == 0,
        "title": ir.title,
        "metrics": metrics,
        "issues": issues,
    }


def _format_report(rel_path: str, result: dict[str, Any]) -> str:
    m = result["metrics"]
    score = result["score"]
    dtype = result["doc_type"]
    badge = "✅ 通过" if result["passed"] else "⚠️ 需修订"
    lines = [
        f"📋 文档质量审查报告：{rel_path}",
        f"- 文档类型：{dtype}  |  综合得分：{score}/100（{badge}）",
        f"- 篇幅指标：总字数 {m['total_chars']:,}（汉字 {m['cjk_chars']:,}）· 摘要 {m['abstract_chars']} 字 · 关键词 {m['keywords_count']} 个 · 章节标题 {m['headings_count']} 个",
        f"- 图表公式：图 {m['valid_figures_count']}/{m['figures_count']} 幅有效 · 表 {m['tables_count']} 张（含表注 {m['tables_with_notes_count']} 张）· 公式 {m['equations_count']} 个 · 正文引用 {m['citations_count']} 处 · 参考文献 {m['references_count']} 条",
    ]
    issues = result["issues"]
    if not issues:
        lines.append("- 检查结果：未发现结构、编号、前置引用或格式问题。")
    else:
        sev_label = {"error": "严重", "warning": "警告", "info": "建议"}
        lines.append(f"- 发现问题（共 {len(issues)} 项，按优先级排列）：")
        for idx, it in enumerate(issues, 1):
            lines.append(f"  {idx}. [{sev_label.get(it['severity'], it['severity'])}] (-{it['penalty']}分) {it['message']}")
    return "\n".join(lines)


@tool(
    "check_document",
    "对生成的 .docx 或 .md 文档进行排版与学术/办公规范审查（0—100 分）。\n"
    "检查项：必备章节结构（fiscal_paper 含摘要/关键词/引言/文献与理论假说/研究设计/实证结果/稳健性/异质性或机制/结论建议/参考文献）、"
    "图表连续编号（图1, 图2… / 表1, 表2…）、正文前置引用位置（每个图N/表N必须在出现位置之前被正文提及）、"
    "Word 内嵌图片或 Markdown 引用图片是否真实存在且非空、表注（注：/资料来源：）、摘要字数（200—450字）、"
    "文献引用标记、残留占位符（TODO/XXX/待补充/此处插入）及空章节。",
    {
        "path": {"type": "string", "description": "待检查的 .docx 或 .md 文件路径（相对工作区或绝对路径）"},
        "doc_type": {
            "type": "string",
            "enum": list(DOC_TYPES),
            "description": "文档类型：fiscal_paper（财政/经济学实证论文）| report（数据分析/商业报告）| generic（通用文档）",
        },
        "paper_type": {
            "type": "string",
            "enum": list(DOC_TYPES),
            "description": "doc_type 的兼容别名（可选）",
        },
    },
    ["path"],
    risk="read",
    summary_keys=("path",),
)
async def check_document(args: dict[str, Any], ctx: ToolContext) -> ToolResult:
    p = ctx.resolve(args.get("path"), must_exist=True, read_only=True)
    if p.is_dir():
        raise ToolError(f"{ctx.rel(p)} 是目录，请指定 .docx 或 .md 文件。")
    doc_type = args.get("doc_type") or args.get("paper_type")
    res = await asyncio.to_thread(inspect_document, p, doc_type, workspace=ctx.workspace)
    rel = ctx.rel(p)
    return ToolResult(_format_report(rel, res), data={"path": rel, **res})


RESEARCH_TOOLS = [check_document]
