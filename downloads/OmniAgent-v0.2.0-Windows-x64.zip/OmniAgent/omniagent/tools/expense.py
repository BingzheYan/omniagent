"""智能报销工具：上传/指定票据路径 → 自动解析 → 材料完整性与金额核对 → 生成报销单与核对报告 → 供网页填报。"""
from __future__ import annotations

import asyncio
import datetime as dt
import shutil
from pathlib import Path
from typing import Any

from omniagent.expense import (
    DEFAULT_POLICY,
    ExpenseLedger,
    analyze_claim,
    collect_files,
    fmt_money,
    load_policy,
    save_policy,
)
from omniagent.expense.engine import SEVERITY_LABEL

from .base import ToolContext, ToolError, ToolResult, tool

INFO_KEYS = ("claimant", "department", "employee_id", "purpose", "project", "cost_center", "destination",
             "trip_start", "trip_end", "approval_no", "company_name", "company_tax_id", "claimed_total")


def _import_paths(paths: list[str], ctx: ToolContext, batch: str) -> tuple[list[Path], list[str]]:
    """工作区内路径直接使用；工作区外的本机路径（如 ~/Downloads/发票）在本机桌面/CLI 模式下复制进工作区再处理。"""
    resolved: list[Path] = []
    notes: list[str] = []
    local_ok = bool(getattr(ctx.settings, "allow_desktop_inspect", True))
    for raw in paths:
        raw = str(raw).strip().strip('"').strip("'")
        if not raw:
            continue
        p = Path(raw).expanduser()
        if not p.is_absolute():
            resolved.append(ctx.resolve(raw, must_exist=True, read_only=True))
            continue
        p = p.resolve()
        try:
            p.relative_to(ctx.workspace)
            if not p.exists():
                raise ToolError(f"路径不存在: {raw}")
            resolved.append(p)
            continue
        except ValueError:
            pass
        if not local_ok:
            raise ToolError(f"多用户服务器模式不允许读取工作区外的路径：{raw}。请先通过界面上传文件。")
        if not p.exists():
            raise ToolError(f"路径不存在: {raw}")
        dst_root = ctx.workspace / "uploads" / "报销材料" / batch
        dst_root.mkdir(parents=True, exist_ok=True)
        if p.is_dir():
            dst = dst_root / p.name
            shutil.copytree(p, dst, dirs_exist_ok=True, ignore=shutil.ignore_patterns(".*", "~$*"))
        else:
            dst = dst_root / p.name
            shutil.copy2(p, dst)
        notes.append(f"已从本机 `{p}` 导入到工作区 `{ctx.rel(dst)}`")
        resolved.append(dst)
    return resolved, notes


@tool(
    "expense_reimburse",
    "智能报销助手（票据→报销单→核对报告）。\n"
    "本工具只负责把票据“读出来、算清楚、查出问题”，结论供你判断：识别置信度低、字段缺失或检查结果与常识不符时，"
    "应亲自用 view_image / read_file 查看原件，再通过 overrides / manual_items / exclude 更正后重新 analyze；"
    "缺少的信息优先从长期记忆与用户画像获取，仍缺失再询问用户。\n"
    "- analyze：传入票据文件或文件夹路径（工作区相对路径，或本机绝对路径如 ~/Downloads/发票），自动识别增值税/全电发票（PDF/OFD/XML/图片 OCR）、"
    "铁路电子客票、航空行程单、网约车行程单、酒店水单、支付凭证、出差审批单与费用清单；检查材料是否齐全（如打车发票必须附行程单、差旅需审批单）、"
    "发票号重复/历史已报销、金额+税额=价税合计、大小写一致、抬头税号、日期与出差期间、住宿/餐饮标准；按类别汇总并计算大写总额与可抵扣进项税；"
    "生成【报销单 Excel】【金额核对报告】【报销内容审核报告】（md+docx）、按序号重命名的附件包，以及供网页自动填报的 portal_fill.json。\n"
    "- show_policy / set_policy：查看或设置单位报销制度（发票抬头、税号、住宿标准、报销网址等，保存在工作区）。\n"
    "- history：查看历史报销批次；mark_submitted：在网页确认提交成功后把批次标记为已提交（用于防重复报销）。",
    {
        "action": {"type": "string", "enum": ["analyze", "show_policy", "set_policy", "history", "mark_submitted"]},
        "paths": {"type": "array", "items": {"type": "string"}, "description": "analyze：票据文件/文件夹路径列表"},
        "claimant": {"type": "string", "description": "报销人姓名"},
        "department": {"type": "string", "description": "所属部门"},
        "employee_id": {"type": "string", "description": "工号"},
        "purpose": {"type": "string", "description": "报销事由（如：赴上海客户现场实施项目差旅费）"},
        "project": {"type": "string", "description": "项目名称/编号"},
        "cost_center": {"type": "string", "description": "成本中心"},
        "destination": {"type": "string", "description": "出差地点"},
        "trip_start": {"type": "string", "description": "出差/费用开始日期 YYYY-MM-DD"},
        "trip_end": {"type": "string", "description": "出差/费用结束日期 YYYY-MM-DD"},
        "approval_no": {"type": "string", "description": "出差/事前审批编号"},
        "company_name": {"type": "string", "description": "单位全称（发票抬头校验用）"},
        "company_tax_id": {"type": "string", "description": "单位统一社会信用代码"},
        "claimed_total": {"type": "number", "description": "报销人自行申报的总金额（用于对账，可选）"},
        "policy": {"type": "object", "description": "set_policy 或本次 analyze 临时覆盖的制度参数，如 "
                   "{company_name, company_tax_id, hotel_cap_per_night, meal_cap_per_invoice, require_hotel_folio, portal_url}"},
        "batch_id": {"type": "string", "description": "mark_submitted 时的批次号（analyze 结果中给出）"},
        "note": {"type": "string", "description": "mark_submitted 备注（如网页返回的单据号）"},
        "output_dir": {"type": "string", "description": "可选：产出目录（默认 outputs/报销/<批次号>）"},
        "overrides": {"type": "object", "description": "复核更正：{文件名: {doc_type?, category?, fields: {total, invoice_no, date, buyer_name, ...}, note}}。"
                      "当识别置信度低/字段缺失/与原件不符时，先用 view_image / read_file 查看原件，再用本参数更正后重新 analyze"},
        "exclude": {"type": "array", "items": {"type": "string"}, "description": "本次不纳入报销的文件名（如用户说明不报的票据、私人消费）"},
        "manual_items": {"type": "array", "items": {"type": "object"}, "description": "手工补录票据：[{doc_type, category, invoice_no, date, total, "
                         "amount_ex_tax, tax, seller_name, buyer_name, file, note}]，用于无法自动识别但已人工读取原件的票据"},
    },
    ["action"],
    risk="write",
    summary_keys=("action", "purpose", "paths", "batch_id"),
)
async def expense_reimburse(args: dict[str, Any], ctx: ToolContext) -> ToolResult:
    act = args["action"]
    ws = ctx.workspace

    if act == "show_policy":
        pol = load_policy(ws)
        lines = ["### 当前报销制度参数（工作区 `.omniagent/expense_policy.yaml`）"]
        lines += [f"- `{k}`: {v!r}" for k, v in pol.items()]
        return ToolResult("\n".join(lines), data={"policy": pol})

    if act == "set_policy":
        upd = dict(args.get("policy") or {})
        for k in ("company_name", "company_tax_id"):
            if args.get(k):
                upd[k] = args[k]
        unknown = [k for k in upd if k not in DEFAULT_POLICY]
        pol = save_policy(ws, upd)
        msg = "✅ 已保存报销制度：" + "，".join(f"{k}={pol[k]!r}" for k in upd if k in pol)
        if unknown:
            msg += f"\n（已忽略未知参数：{', '.join(unknown)}；可用参数：{', '.join(DEFAULT_POLICY)}）"
        return ToolResult(msg, data={"policy": pol, "path": ".omniagent/expense_policy.yaml"})

    if act in ("history", "mark_submitted"):
        led = ExpenseLedger(ws / ".omniagent" / "expense_ledger.db")
        try:
            if act == "mark_submitted":
                bid = str(args.get("batch_id") or "").strip()
                if not bid:
                    raise ToolError("mark_submitted 需要 batch_id")
                n = led.mark(bid, "submitted", str(args.get("note") or ""))
                return ToolResult(f"✅ 批次 `{bid}` 已标记为【已提交】，登记 {n} 张发票，后续再次出现将被判定为重复报销。")
            rows = led.batches()
            if not rows:
                return ToolResult("暂无报销批次记录。")
            lines = ["| 批次 | 报销人 | 金额 | 状态 | 时间 | 目录 |", "|---|---|---:|---|---|---|"]
            for r in rows:
                lines.append(f"| `{r['batch_id']}` | {r['claimant'] or '—'} | {fmt_money(r['total'] or 0)} | "
                             f"{'✅ 已提交' if r['status'] == 'submitted' else '📝 已核对'} | "
                             f"{dt.datetime.fromtimestamp(r['ts']).strftime('%Y-%m-%d %H:%M')} | {r['out_dir']} |")
            return ToolResult("\n".join(lines), data={"batches": rows})
        finally:
            led.close()

    if act != "analyze":
        raise ToolError(f"未知操作 {act}")
    paths = list(args.get("paths") or [])
    if not paths:
        default_dir = ws / "uploads"
        if default_dir.is_dir():
            paths = ["uploads"]
        else:
            raise ToolError("请提供票据文件或文件夹路径（paths），或先在界面上传报销材料。")
    batch = dt.datetime.now().strftime("BX%Y%m%d-%H%M%S")
    resolved, notes = await asyncio.to_thread(_import_paths, paths, ctx, batch)
    files, skipped = collect_files(resolved)
    files = [f for f in files if "outputs/报销" not in f.as_posix() and "/web_ops/" not in f.as_posix()]
    if not files:
        raise ToolError("在给定路径中没有找到可识别的票据（支持 PDF/OFD/XML/图片/Word/Excel/CSV）。"
                        + (f" 已跳过：{', '.join(skipped[:10])}" if skipped else ""))
    out_dir = ctx.resolve(args.get("output_dir")) if args.get("output_dir") else ws / "outputs" / "报销" / batch
    info = {k: args.get(k) for k in INFO_KEYS if args.get(k) not in (None, "")}
    policy = load_policy(ws, args.get("policy"))
    loop = asyncio.get_running_loop()

    def progress(i: int, n: int, name: str):
        asyncio.run_coroutine_threadsafe(ctx.emit({"type": "status", "message": f"🧾 正在识别票据 {i}/{n}：{name}"}), loop)

    res = await asyncio.to_thread(analyze_claim, files, workspace=ws, out_dir=out_dir, info=info, policy=policy,
                                  rel=ctx.rel, progress=progress, overrides=args.get("overrides") or {},
                                  exclude=list(args.get("exclude") or []), manual_items=list(args.get("manual_items") or []))
    o = res["outputs"]
    L = [f"## 🧾 报销核对完成 · 批次 `{res['batch_id']}`", ""]
    L += [f"- {n}" for n in notes]
    L += [f"- 共识别材料 **{len(res['docs'])}** 份，有效票据 **{res['invoice_count']}** 张，附件 **{res['attachment_count']}** 份"
          + (f"；跳过不支持的文件 {len(skipped)} 个" if skipped else ""),
          f"- **核定报销金额：¥{fmt_money(res['grand_total'])}（{res['grand_total_words']}）**，其中税额 ¥{fmt_money(res['tax_total'])}，"
          f"可抵扣进项税 ¥{fmt_money(res['deductible_total'])}",
          f"- **结论：{res['verdict']}**", "", "### 分类汇总", "| 类别 | 张数 | 金额 |", "|---|---:|---:|"]
    for cat, v in res["summary_by_category"].items():
        L.append(f"| {cat} | {v['count']} | {fmt_money(v['total'])} |")
    L += ["", "### 票据识别明细", "| # | 文件 | 类型 | 类别 | 发票号 | 日期 | 金额 | 状态 |", "|---:|---|---|---|---|---|---:|---|"]
    for i, it in enumerate(res["items"], 1):
        L.append(f"| {i} | {it['name']} | {it['doc_label']} | {it['category']} | {it['invoice_no'] or '—'} | {it['date'] or '—'} | "
                 f"{fmt_money(it['total']) if it['total'] is not None else '—'} | {it['status']} |")
    sup = [d for d in res["docs"] if d["doc_type"] not in ("vat_invoice", "train_ticket", "flight_itinerary")]
    from omniagent.expense.reports import _method

    L.append("\n识别方式：" + "；".join(f"{d['name']}→{_method(d.get('method'))}" for d in res["docs"]))
    if sup:
        L.append("\n辅助材料：" + "；".join(f"{d['name']}（{d['doc_label']}"
                                         + (f"，¥{fmt_money(d['fields']['total'])}" if d["fields"].get("total") is not None else "") + "）"
                                         for d in sup))
    if res["issues"]:
        L += ["", "### 审核发现"]
        for x in res["issues"]:
            L.append(f"- {SEVERITY_LABEL[x['severity']]} **{x['title']}**：{x['detail']}" + (f" → {x['fix']}" if x["fix"] else ""))
    low = [d for d in res["docs"] if d["confidence"] in ("low", "none")]
    if low:
        L.append("\n> ⚠️ 以下文件识别不完整，建议用 view_image/read_file 查看原件后通过 overrides 或 manual_items 更正："
                 + "、".join(f"`{d['file']}`" for d in low))
    missing_info = [lab for k, lab in (("claimant", "报销人"), ("department", "部门"), ("purpose", "报销事由")) if not info.get(k)]
    if missing_info:
        L.append(f"\n> 报销单中以下信息待补充：{'、'.join(missing_info)}（可从用户画像/记忆获取或询问用户后重新生成）。")
    L += ["", "### 产出文件",
          f"- 报销单：`{o['expense_form_xlsx']}`",
          f"- 金额核对报告：`{o['amount_report_docx']}`（Markdown 版 `{o['amount_report_md']}`）",
          f"- 报销内容审核报告：`{o['content_report_docx']}`（Markdown 版 `{o['content_report_md']}`）",
          f"- 网页填报数据：`{o['portal_fill_json']}`；附件包：`{o['attachments_dir']}/`",
          "", f"下一步：请用户审阅两份报告；确认无误后可用 `web_automation` 打开报销系统 {policy.get('portal_url')} ，"
          "等待用户登录后按 portal_fill.json 填写表单并上传附件包，最终提交前必须经用户确认；提交成功后调用 "
          f"`expense_reimburse(action='mark_submitted', batch_id='{res['batch_id']}')`。"]
    outputs = [o["expense_form_xlsx"], o["amount_report_docx"], o["content_report_docx"], o["amount_report_md"],
               o["content_report_md"], o["portal_fill_json"]]
    return ToolResult("\n".join(L), data={"path": o["amount_report_md"], "outputs": outputs, "batch_id": res["batch_id"],
                                          "status": res["status"], "grand_total": float(res["grand_total"])})


EXPENSE_TOOLS = [expense_reimburse]

__all__ = ["EXPENSE_TOOLS", "expense_reimburse"]
