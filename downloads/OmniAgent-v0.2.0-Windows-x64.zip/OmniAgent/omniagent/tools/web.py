"""网络工具：网页抓取（转纯文本）与可选的联网搜索（Tavily）。"""
from __future__ import annotations

import re
from html.parser import HTMLParser

import httpx

from .base import ToolContext, ToolError, ToolResult, tool, truncate


class _TextExtractor(HTMLParser):
    SKIP = {"script", "style", "noscript", "svg", "head", "nav", "footer", "iframe"}
    BLOCK = {"p", "div", "br", "li", "tr", "h1", "h2", "h3", "h4", "h5", "h6", "section", "article", "table", "pre"}

    def __init__(self):
        super().__init__()
        self.parts: list[str] = []
        self.skip = 0
        self.title = ""
        self._in_title = False

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self.skip += 1
        if tag == "title":
            self._in_title = True
        if tag in self.BLOCK:
            self.parts.append("\n")
        if tag in ("h1", "h2", "h3"):
            self.parts.append("#" * int(tag[1]) + " ")
        if tag == "li":
            self.parts.append("- ")
        if tag == "a":
            href = dict(attrs).get("href")
            if href and href.startswith("http"):
                self._href = href

    def handle_endtag(self, tag):
        if tag in self.SKIP and self.skip:
            self.skip -= 1
        if tag == "title":
            self._in_title = False
        if tag in self.BLOCK:
            self.parts.append("\n")

    def handle_data(self, data):
        if self._in_title:
            self.title += data
        if not self.skip:
            self.parts.append(data)

    def text(self) -> str:
        t = "".join(self.parts)
        t = re.sub(r"[ \t\r\f\v]+", " ", t)
        t = re.sub(r"\n\s*\n+", "\n\n", t)
        return t.strip()


@tool(
    "web_fetch",
    "抓取网页或在线文件内容（HTML 自动转为纯文本，JSON/文本原样返回）。可用 save_to 把原始内容保存到工作区（如下载数据集）。",
    {
        "url": {"type": "string"},
        "save_to": {"type": "string", "description": "可选：保存原始内容到工作区路径"},
    },
    ["url"],
    summary_keys=("url",),
)
async def web_fetch(args, ctx: ToolContext):
    url = args["url"]
    if not url.startswith(("http://", "https://")):
        raise ToolError("URL 必须以 http:// 或 https:// 开头")
    headers = {"User-Agent": "Mozilla/5.0 (OmniAgent; +https://github.com/) AppleWebKit/537.36 Chrome/124 Safari/537.36"}
    async with httpx.AsyncClient(follow_redirects=True, timeout=45, headers=headers) as client:
        try:
            r = await client.get(url)
        except httpx.HTTPError as e:
            raise ToolError(f"请求失败: {e}") from None
    if args.get("save_to"):
        p = ctx.resolve(args["save_to"])
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(r.content)
        return ToolResult(f"[HTTP {r.status_code}] 已保存 {len(r.content)} 字节到 {ctx.rel(p)}", data={"path": ctx.rel(p)})
    ctype = r.headers.get("content-type", "")
    if "html" in ctype:
        ex = _TextExtractor()
        ex.feed(r.text)
        body = (f"标题: {ex.title.strip()}\n\n" if ex.title.strip() else "") + ex.text()
    elif any(k in ctype for k in ("json", "text", "xml", "csv")):
        body = r.text
    else:
        body = f"(二进制内容 {ctype}，{len(r.content)} 字节；请使用 save_to 保存后处理)"
    return ToolResult(f"[HTTP {r.status_code}] {url}\n\n{truncate(body, 25_000)}", is_error=r.status_code >= 400)


@tool(
    "web_search",
    "联网搜索，返回相关网页标题、链接和摘要。需要获取最新信息、查资料、查文档时使用。",
    {
        "query": {"type": "string"},
        "max_results": {"type": "integer", "description": "默认 6"},
    },
    ["query"],
    summary_keys=("query",),
)
async def web_search(args, ctx: ToolContext):
    key = ctx.settings.tavily_api_key
    if not key:
        raise ToolError("未配置 TAVILY_API_KEY，无法联网搜索。可改用 web_fetch 访问已知网址。")
    async with httpx.AsyncClient(timeout=40) as client:
        r = await client.post(
            "https://api.tavily.com/search",
            json={"api_key": key, "query": args["query"], "max_results": int(args.get("max_results") or 6),
                  "include_answer": True},
        )
    if r.status_code != 200:
        raise ToolError(f"搜索失败 HTTP {r.status_code}: {r.text[:300]}")
    data = r.json()
    lines = []
    if data.get("answer"):
        lines.append(f"摘要回答: {data['answer']}\n")
    for i, item in enumerate(data.get("results", []), 1):
        lines.append(f"{i}. {item.get('title')}\n   {item.get('url')}\n   {(item.get('content') or '')[:500]}")
    return "\n".join(lines) or "无结果"


WEB_TOOLS = [web_fetch, web_search]
