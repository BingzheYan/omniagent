"""图像查看工具：让模型“看到”自己生成的图表、截图等，用于核验可视化效果。"""
from __future__ import annotations

import asyncio
import base64
import io
from pathlib import Path
from typing import Any

from .base import ToolContext, ToolError, ToolResult, tool

MAX_SIDE = 1568  # Claude 推荐的最长边；更大的图片会被等比缩小
MAX_BYTES = 3_500_000  # 编码前字节上限（base64 后约 4.7MB，低于 Anthropic 5MB 限制）
SUPPORTED_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".tif", ".tiff"}


def model_supports_vision(ctx: ToolContext) -> bool:
    agent = ctx.agent
    profile = getattr(getattr(agent, "llm", None), "profile", None)
    if profile is None:
        return bool(ctx.state.get("vision", True))
    return bool(getattr(profile, "vision", False))


def _human_size(n: int) -> str:
    return f"{n}B" if n < 1024 else (f"{n / 1024:.1f}KB" if n < 1 << 20 else f"{n / (1 << 20):.1f}MB")


def inspect_image(path: Path) -> dict[str, Any]:
    from PIL import Image

    with Image.open(path) as im:
        return {"width": im.width, "height": im.height, "mode": im.mode, "format": im.format or path.suffix[1:].upper(),
                "frames": getattr(im, "n_frames", 1)}


def encode_image(path: Path, max_side: int = MAX_SIDE) -> dict[str, Any]:
    """读取并（必要时）缩放、转码图片，返回 {media_type, data(base64), width, height, orig_width, orig_height}。"""
    from PIL import Image

    with Image.open(path) as im:
        im.seek(0)
        orig_w, orig_h = im.size
        fmt = (im.format or "").upper()
        img = im.copy()
    if img.mode in ("P", "LA") or (img.mode == "RGBA" and fmt not in ("PNG", "WEBP")):
        img = img.convert("RGBA")
    elif img.mode not in ("RGB", "RGBA", "L"):
        img = img.convert("RGB")
    resized = max(img.size) > max_side
    if resized:
        img.thumbnail((max_side, max_side), getattr(Image, "Resampling", Image).LANCZOS)
    has_alpha = img.mode == "RGBA"

    def save(kind: str, quality: int = 85) -> bytes:
        buf = io.BytesIO()
        if kind == "JPEG":
            src = img
            if has_alpha:  # JPEG 不支持透明：铺白底
                bg = Image.new("RGB", img.size, (255, 255, 255))
                bg.paste(img, mask=img.split()[-1])
                src = bg
            elif src.mode != "RGB":
                src = src.convert("RGB")
            src.save(buf, "JPEG", quality=quality, optimize=True)
        else:
            img.save(buf, "PNG", optimize=True)
        return buf.getvalue()

    # 原图是 JPEG 且无需缩放：直接使用原始字节，避免二次压缩
    raw = path.read_bytes()
    if fmt == "JPEG" and not resized and len(raw) <= MAX_BYTES:
        data, media = raw, "image/jpeg"
    elif fmt == "JPEG":
        data, media = save("JPEG"), "image/jpeg"
    else:
        data, media = save("PNG"), "image/png"
        if len(data) > MAX_BYTES:  # 图表等 PNG 过大时转 JPEG
            data, media = save("JPEG", 85), "image/jpeg"
    q = 75
    while len(data) > MAX_BYTES and q >= 35:
        data, media = save("JPEG", q), "image/jpeg"
        q -= 15
    return {"media_type": media, "data": base64.b64encode(data).decode("ascii"), "width": img.width,
            "height": img.height, "orig_width": orig_w, "orig_height": orig_h, "bytes": len(data)}


@tool(
    "view_image",
    "查看一张图片（PNG/JPG/GIF/WebP/BMP），图片会作为视觉输入返回给你。用于核验自己生成的图表"
    "（标题、坐标轴、中文是否乱码、图例、数据是否合理、布局是否拥挤）、查看截图或用户上传的图片。"
    "大图会自动缩放到最长边 1568px。SVG/PDF 请先用 python 转为 PNG。",
    {"path": {"type": "string", "description": "图片路径（相对工作区或绝对路径）"}},
    ["path"],
    summary_keys=("path",),
)
async def view_image(args, ctx: ToolContext):
    p = ctx.resolve(args.get("path"), must_exist=True, read_only=True)
    if p.is_dir():
        raise ToolError(f"{ctx.rel(p)} 是目录，请指定图片文件。")
    ext = p.suffix.lower()
    if ext == ".svg":
        raise ToolError("view_image 不支持 SVG。请先用 python 转换为 PNG（如 cairosvg，或直接用 matplotlib 保存为 PNG）。")
    if ext not in SUPPORTED_EXTS:
        raise ToolError(f"不支持的图片格式 {ext or '(无扩展名)'}；支持: {', '.join(sorted(SUPPORTED_EXTS))}")
    rel = ctx.rel(p)
    size = p.stat().st_size
    try:
        info = await asyncio.to_thread(inspect_image, p)
    except Exception as e:  # noqa: BLE001
        raise ToolError(f"无法打开图片 {rel}：{type(e).__name__}: {e}（文件可能已损坏或并非图片）") from None
    desc = f"{info['width']}×{info['height']} 像素，{info['format']}，{info['mode']}，{_human_size(size)}"
    if info.get("frames", 1) > 1:
        desc += f"，{info['frames']} 帧（仅显示第一帧）"

    if not model_supports_vision(ctx):
        return ToolResult(
            f"[图片信息] {rel}：{desc}。\n"
            "注意：当前模型不支持图像输入，无法直接查看图片内容。如需核验图表，请改用文本方式："
            "用 python 检查绘图所用的数据（数值范围、缺失值、排序）、确认标题/坐标轴标签/图例已设置、"
            "确认中文字体已配置（plt.rcParams['font.sans-serif']），并检查文件尺寸是否合理。",
            data={"image": rel, "vision": False, **info},
        )

    try:
        enc = await asyncio.to_thread(encode_image, p)
    except Exception as e:  # noqa: BLE001
        raise ToolError(f"图片编码失败 {rel}：{type(e).__name__}: {e}") from None
    scaled = ""
    if (enc["width"], enc["height"]) != (enc["orig_width"], enc["orig_height"]):
        scaled = f"（已缩放为 {enc['width']}×{enc['height']} 发送）"
    text = (f"[图片] {rel}：{desc}{scaled}。图片内容已附在本结果中，请仔细检查：标题与坐标轴标签是否完整、"
            "中文是否显示为方框、图例/数据标签是否遮挡、数值与分析结论是否一致。")
    return ToolResult(
        text,
        data={"image": rel, "vision": True, "width": info["width"], "height": info["height"]},
        images=[{"media_type": enc["media_type"], "data": enc["data"], "path": rel}],
    )


VISION_TOOLS = [view_image]
