"""Shell 命令执行工具（支持超时与后台进程）。"""
from __future__ import annotations

import asyncio
import os
import platform
import signal
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .base import ToolContext, ToolError, ToolResult, tool, truncate


def _decode_output(data: bytes) -> str:
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        if os.name == "nt":
            return data.decode("gb18030", errors="replace")
        return data.decode("utf-8", errors="replace")


def _kill_proc_tree(proc: asyncio.subprocess.Process, sig: int | None = None) -> None:
    if os.name == "nt":
        try:
            subprocess.run(
                ["taskkill", "/F", "/T", "/PID", str(proc.pid)],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5,
            )
        except Exception:  # noqa: BLE001
            pass
        try:
            proc.kill()
        except ProcessLookupError:
            pass
        return
    kill_sig = sig if sig is not None else getattr(signal, "SIGKILL", signal.SIGTERM)
    try:
        os.killpg(proc.pid, kill_sig)
    except (ProcessLookupError, PermissionError, AttributeError, OSError):
        try:
            proc.send_signal(kill_sig)
        except ProcessLookupError:
            pass


@tool(
    "run_shell",
    "在工作区目录中执行 shell 命令（"
    + ("zsh/bash" if platform.system() != "Windows" else "cmd")
    + "），返回 stdout+stderr 与退出码。用于运行测试、构建、git、安装依赖、执行脚本等。"
    "长期运行的服务（如开发服务器）请设置 background=true，输出会写入日志文件，之后用 process 工具查看输出或停止。"
    "不要用它来读写/搜索文件内容（请用 read_file/write_file/edit_file/grep/glob）。",
    {
        "command": {"type": "string", "description": "要执行的命令"},
        "timeout": {"type": "integer", "description": "超时秒数，默认 180，最大 1800"},
        "background": {"type": "boolean", "description": "是否后台运行（用于启动服务）"},
        "cwd": {"type": "string", "description": "可选：工作区内的子目录"},
    },
    ["command"],
    risk="exec",
    summary_keys=("command",),
)
async def run_shell(args, ctx: ToolContext):
    cmd = args["command"]
    cwd = ctx.resolve(args.get("cwd") or ".", must_exist=True)
    env = {**os.environ, "PYTHONIOENCODING": "utf-8", "PAGER": "cat", "GIT_PAGER": "cat", "TERM": "dumb"}

    if args.get("background"):
        log_dir = ctx.workspace / ".omniagent" / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_path = log_dir / f"bg_{int(time.time() * 1000)}.log"
        f = open(log_path, "wb")
        proc = await asyncio.create_subprocess_shell(
            cmd, cwd=str(cwd), env=env, stdout=f, stderr=asyncio.subprocess.STDOUT,
            stdin=asyncio.subprocess.DEVNULL, start_new_session=True,
        )
        ctx.state.setdefault("bg_procs", {})[proc.pid] = BgProc(proc, f, cmd, log_path, time.time())
        await asyncio.sleep(2.0)
        head = _tail(log_path, 40)
        status = f"已退出（code={proc.returncode}）" if proc.returncode is not None else "运行中"
        return ToolResult(
            f"后台进程已启动 PID={proc.pid}，状态：{status}\n日志：{ctx.rel(log_path)}\n"
            f"用 process 工具管理：process(action='output', pid={proc.pid}) 查看最新输出，"
            f"process(action='kill', pid={proc.pid}) 停止，process(action='list') 列出全部。\n--- 最近输出 ---\n{head}",
            data={"pid": proc.pid, "log": ctx.rel(log_path)},
        )

    timeout = min(int(args.get("timeout") or ctx.settings.shell_timeout), 1800)
    start = time.time()
    proc = await asyncio.create_subprocess_shell(
        cmd, cwd=str(cwd), env=env, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT,
        stdin=asyncio.subprocess.DEVNULL, start_new_session=True,
    )
    try:
        out, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except (asyncio.TimeoutError, asyncio.CancelledError) as e:
        await asyncio.to_thread(_kill_proc_tree, proc)
        if isinstance(e, asyncio.CancelledError):
            raise
        raise ToolError(f"命令超时（{timeout}s）已被终止：{cmd}。如需长时间运行请增大 timeout 或使用 background=true") from None
    text = _decode_output(out)
    elapsed = time.time() - start
    header = f"[exit code: {proc.returncode} | {elapsed:.1f}s]"
    return ToolResult(f"{header}\n{truncate(text) if text.strip() else '(无输出)'}", is_error=proc.returncode != 0)


@dataclass
class BgProc:
    proc: asyncio.subprocess.Process
    file: Any
    cmd: str
    log_path: Path
    started: float

    # 兼容旧代码的三元组解包：proc, f, cmd = entry
    def __iter__(self):
        return iter((self.proc, self.file, self.cmd))

    @property
    def status(self) -> str:
        rc = self.proc.returncode
        return "运行中" if rc is None else f"已退出（code={rc}）"


def _tail(path: Path, lines: int = 50, max_chars: int = 12_000) -> str:
    try:
        with open(path, "rb") as fh:
            fh.seek(0, os.SEEK_END)
            size = fh.tell()
            fh.seek(max(0, size - max_chars * 4))
            text = _decode_output(fh.read())
    except OSError as e:
        return f"(无法读取日志: {e})"
    out = "\n".join(text.splitlines()[-lines:])
    return (out[-max_chars:] if len(out) > max_chars else out) or "(暂无输出)"


def _fmt_elapsed(sec: float) -> str:
    sec = int(sec)
    return f"{sec}s" if sec < 60 else (f"{sec // 60}m{sec % 60:02d}s" if sec < 3600 else f"{sec // 3600}h{sec % 3600 // 60:02d}m")


async def _terminate(entry: BgProc, grace: float = 3.0) -> str:
    proc = entry.proc
    if proc.returncode is not None:
        return f"进程已结束（code={proc.returncode}），无需停止"
    if os.name == "nt":
        await asyncio.to_thread(_kill_proc_tree, proc)
        try:
            await asyncio.wait_for(proc.wait(), timeout=grace)
            return f"已停止（taskkill，code={proc.returncode}）"
        except asyncio.TimeoutError:
            return "已发送终止信号，但进程仍未退出"
    sigkill = getattr(signal, "SIGKILL", signal.SIGTERM)
    for sig in (signal.SIGTERM, sigkill):
        _kill_proc_tree(proc, sig)
        try:
            await asyncio.wait_for(proc.wait(), timeout=grace)
            return f"已停止（{'SIGTERM' if sig == signal.SIGTERM else 'SIGKILL'}，code={proc.returncode}）"
        except asyncio.TimeoutError:
            continue
    return "已发送 SIGKILL，但进程仍未退出"


@tool(
    "process",
    "管理由 run_shell(background=true) 启动的后台进程（开发服务器、长时间任务等）。"
    "action=list 列出全部后台进程及状态；action=output 查看指定进程日志的最新输出（tail）；action=kill 停止进程（含其子进程）。",
    {
        "action": {"type": "string", "enum": ["list", "output", "kill"], "description": "操作类型"},
        "pid": {"type": "integer", "description": "进程 PID（output / kill 必填；只有一个后台进程时可省略）"},
        "lines": {"type": "integer", "description": "output 时返回的最后行数，默认 50"},
    },
    ["action"],
    summary_keys=("action", "pid"),
)
async def process(args, ctx: ToolContext):
    procs: dict[int, BgProc] = ctx.state.get("bg_procs") or {}
    action = (args.get("action") or "list").lower()
    now = time.time()
    if action == "list":
        if not procs:
            return "当前没有后台进程。使用 run_shell(background=true) 启动。"
        rows = []
        for pid, e in procs.items():
            rows.append(f"PID {pid} · {e.status} · 运行 {_fmt_elapsed(now - e.started)} · 日志 {ctx.rel(e.log_path)}\n"
                        f"    $ {e.cmd[:200]}")
        return "\n".join(rows)
    if action not in ("output", "kill"):
        raise ToolError(f"未知 action '{action}'，可选 list / output / kill")
    pid = args.get("pid")
    if pid is None:
        if len(procs) == 1:
            pid = next(iter(procs))
        else:
            raise ToolError("请指定 pid。" + ("当前后台进程: " + ", ".join(map(str, procs)) if procs else "当前没有后台进程。"))
    try:
        pid = int(pid)
    except (TypeError, ValueError):
        raise ToolError(f"pid 必须是整数: {pid!r}") from None
    entry = procs.get(pid)
    if entry is None:
        raise ToolError(f"PID {pid} 不是本会话启动的后台进程。" + (f"可用: {', '.join(map(str, procs))}" if procs else ""))
    if action == "output":
        n = max(1, min(int(args.get("lines") or 50), 500))
        try:
            entry.file.flush()
        except Exception:  # noqa: BLE001
            pass
        return ToolResult(f"PID {pid} · {entry.status} · 运行 {_fmt_elapsed(now - entry.started)}\n$ {entry.cmd[:200]}\n"
                          f"--- 最后 {n} 行输出 ---\n{_tail(entry.log_path, n)}")
    msg = await _terminate(entry)
    try:
        entry.file.close()
    except Exception:  # noqa: BLE001
        pass
    procs.pop(pid, None)
    return ToolResult(f"PID {pid}: {msg}\n--- 最后输出 ---\n{_tail(entry.log_path, 15)}")


async def cleanup_background(state: dict) -> None:
    for _pid, entry in list(state.get("bg_procs", {}).items()):
        proc, f, _cmd = entry
        if proc.returncode is None:
            try:
                await asyncio.to_thread(_kill_proc_tree, proc, signal.SIGTERM)
            except Exception:  # noqa: BLE001
                pass
        try:
            f.close()
        except Exception:  # noqa: BLE001
            pass
    state.pop("bg_procs", None)


SHELL_TOOLS = [run_shell, process]
