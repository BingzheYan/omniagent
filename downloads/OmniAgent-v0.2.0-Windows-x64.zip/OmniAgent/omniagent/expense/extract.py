"""多格式票据文本提取：PDF（文字层 / 扫描件 OCR）、OFD 电子发票、全电发票 XML、图片、Word、Excel/CSV、文本。"""
from __future__ import annotations

import re
import tempfile
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

from .ocr import ocr_image

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp", ".heic", ".gif"}
SHEET_EXTS = {".xlsx", ".xlsm", ".xls", ".csv"}
TEXT_EXTS = {".txt", ".md", ".json"}
SUPPORTED_EXTS = {".pdf", ".ofd", ".xml", ".docx"} | IMAGE_EXTS | SHEET_EXTS | TEXT_EXTS


def _strip_ns(tag: str) -> str:
    return tag.split("}", 1)[-1] if "}" in tag else tag


def _xml_text(data: bytes) -> tuple[str, dict[str, str]]:
    """XML → (按行文本, 叶子节点 {tag: text})。"""
    try:
        root = ET.fromstring(data)
    except ET.ParseError:
        return data.decode("utf-8", "replace"), {}
    leaves: dict[str, str] = {}
    lines: list[str] = []
    for el in root.iter():
        txt = (el.text or "").strip()
        if txt and len(list(el)) == 0:
            tag = _strip_ns(el.tag)
            leaves.setdefault(tag, txt)
            lines.append(f"{tag}: {txt}")
    return "\n".join(lines), leaves


def _extract_ofd(path: Path) -> tuple[str, str, dict[str, str]]:
    texts: list[str] = []
    struct: dict[str, str] = {}
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        # 1) 结构化发票数据（部分 OFD 内嵌 original_invoice.xml / CustomTag）
        for n in names:
            low = n.lower()
            if low.endswith(".xml") and ("invoice" in low or "attach" in low) and "content" not in low:
                _, leaves = _xml_text(z.read(n))
                if len(leaves) > len(struct):
                    struct = leaves
        # 2) 页面文字（TextCode），按页面顺序拼接，并按 Y 坐标排序成行
        pages = sorted([n for n in names if re.search(r"Pages/Page_\d+/Content\.xml$", n, re.I)],
                       key=lambda s: int(re.search(r"Page_(\d+)", s).group(1)))
        tpl = [n for n in names if re.search(r"Tpls/.*Content\.xml$", n, re.I)]
        for n in tpl + pages:
            try:
                root = ET.fromstring(z.read(n))
            except ET.ParseError:
                continue
            frags: list[tuple[float, float, str]] = []
            for to in root.iter():
                if _strip_ns(to.tag) != "TextObject":
                    continue
                box = (to.get("Boundary") or "0 0 0 0").split()
                bx, by = float(box[0]), float(box[1]) if len(box) > 1 else 0.0
                for tc in to:
                    if _strip_ns(tc.tag) == "TextCode" and (tc.text or "").strip():
                        y = by + float(tc.get("Y") or 0)
                        x = bx + float(tc.get("X") or 0)
                        frags.append((round(y / 2.5), x, tc.text.strip()))
            frags.sort()
            rows: dict[float, list[tuple[float, str]]] = {}
            for y, x, t in frags:
                rows.setdefault(y, []).append((x, t))
            for y in sorted(rows):
                texts.append("  ".join(t for _, t in sorted(rows[y])))
    body = "\n".join(texts)
    if struct:
        body += "\n" + "\n".join(f"{k}: {v}" for k, v in struct.items())
    return body, "ofd", struct


def _extract_pdf(path: Path) -> tuple[str, str, int]:
    import fitz  # pymupdf

    doc = fitz.open(str(path))
    parts: list[str] = []
    method = "pdf_text"
    try:
        for page in doc:
            txt = page.get_text("text") or ""
            if len(txt.strip()) < 25:  # 扫描件 → 渲染后 OCR
                pix = page.get_pixmap(dpi=220)
                tf = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
                tf_path = Path(tf.name)
                tf.close()
                try:
                    pix.save(str(tf_path))
                    ocr_txt, m = ocr_image(tf_path)
                finally:
                    tf_path.unlink(missing_ok=True)
                if ocr_txt:
                    txt, method = ocr_txt, f"pdf_ocr_{m}"
            parts.append(txt)
        return "\n".join(parts), method, len(doc)
    finally:
        doc.close()


def _extract_sheet(path: Path) -> tuple[str, list[list[str]]]:
    import pandas as pd

    if path.suffix.lower() == ".csv":
        df = None
        for enc in ("utf-8-sig", "gbk", "utf-8"):
            try:
                df = pd.read_csv(path, dtype=str, encoding=enc)
                break
            except Exception:  # noqa: BLE001
                continue
        if df is None:
            return "", []
    else:
        df = pd.read_excel(path, dtype=str)
    df = df.fillna("")
    rows = [list(map(str, df.columns))] + df.astype(str).values.tolist()
    text = "\n".join(" | ".join(r) for r in rows[:400])
    return text, rows


def extract_text(path: str | Path) -> dict:
    """返回 {text, method, pages, struct, rows}。"""
    p = Path(path)
    ext = p.suffix.lower()
    out = {"text": "", "method": "unsupported", "pages": 1, "struct": {}, "rows": []}
    try:
        if ext == ".pdf":
            out["text"], out["method"], out["pages"] = _extract_pdf(p)
        elif ext == ".ofd":
            out["text"], out["method"], out["struct"] = _extract_ofd(p)
        elif ext == ".xml":
            out["text"], out["struct"] = _xml_text(p.read_bytes())
            out["method"] = "xml"
        elif ext in IMAGE_EXTS:
            src = p
            if ext == ".heic":
                src = p  # macOS Vision 可直接读取 HEIC
            out["text"], m = ocr_image(src)
            out["method"] = f"ocr_{m}"
        elif ext == ".docx":
            import docx

            d = docx.Document(str(p))
            lines = [para.text for para in d.paragraphs if para.text.strip()]
            for t in d.tables:
                for r in t.rows:
                    lines.append("  ".join(c.text.strip() for c in r.cells))
            out["text"], out["method"] = "\n".join(lines), "docx"
        elif ext in SHEET_EXTS:
            out["text"], out["rows"] = _extract_sheet(p)
            out["method"] = "sheet"
        elif ext in TEXT_EXTS:
            out["text"], out["method"] = p.read_text(encoding="utf-8", errors="replace"), "text"
    except Exception as e:  # noqa: BLE001
        out["method"] = f"error: {type(e).__name__}: {e}"
    return out
