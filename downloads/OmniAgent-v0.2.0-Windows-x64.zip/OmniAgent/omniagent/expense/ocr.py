"""离线 OCR：
- macOS 优先使用系统 Vision 框架（支持简体中文，无需联网/无需额外模型）；
- Windows 优先使用系统内置 Windows.Media.Ocr（WinRT 离线中文识别，无需额外依赖）；
- 其他平台或兜底回退到 pytesseract（若已安装）。
"""
from __future__ import annotations

import os
import platform
import re
import shutil
import subprocess
from pathlib import Path

SWIFT_OCR_SOURCE = r'''
import Foundation
import Vision
import AppKit

let args = CommandLine.arguments
if args.count < 2 { FileHandle.standardError.write("usage: OmniOCR <image>\n".data(using: .utf8)!); exit(2) }
let url = URL(fileURLWithPath: args[1])
guard let img = NSImage(contentsOf: url),
      let cg = img.cgImage(forProposedRect: nil, context: nil, hints: nil) else {
    FileHandle.standardError.write("cannot load image\n".data(using: .utf8)!); exit(3)
}
let req = VNRecognizeTextRequest()
req.recognitionLevel = .accurate
req.usesLanguageCorrection = true
if #available(macOS 13.0, *) { req.revision = VNRecognizeTextRequestRevision3 }
req.recognitionLanguages = ["zh-Hans", "en-US"]
let handler = VNImageRequestHandler(cgImage: cg, options: [:])
do { try handler.perform([req]) } catch { FileHandle.standardError.write("ocr failed\n".data(using: .utf8)!); exit(4) }
struct Item { let y: Double; let x: Double; let h: Double; let s: String }
var items: [Item] = []
for obs in (req.results ?? []) {
    if let top = obs.topCandidates(1).first {
        let b = obs.boundingBox
        items.append(Item(y: 1.0 - Double(b.midY), x: Double(b.minX), h: Double(b.height), s: top.string))
    }
}
items.sort { $0.y == $1.y ? $0.x < $1.x : $0.y < $1.y }
var rows: [[Item]] = []
for it in items {
    if var last = rows.last, let ref = last.first, abs(ref.y - it.y) < max(0.008, ref.h * 0.55) {
        last.append(it); rows[rows.count - 1] = last
    } else { rows.append([it]) }
}
for r in rows { print(r.sorted { $0.x < $1.x }.map { $0.s }.joined(separator: "  ")) }
'''


def _bin_dir() -> Path:
    d = Path(os.environ.get("OMNIAGENT_BIN_DIR") or (Path.home() / ".omniagent" / "bin"))
    d.mkdir(parents=True, exist_ok=True)
    return d


def ensure_vision_ocr() -> Path | None:
    if platform.system() != "Darwin":
        return None
    swiftc = shutil.which("swiftc")
    bin_path = _bin_dir() / "OmniOCR"
    src_path = _bin_dir() / "OmniOCR.swift"
    if bin_path.is_file() and src_path.is_file() and src_path.read_text(encoding="utf-8") == SWIFT_OCR_SOURCE:
        return bin_path
    if not swiftc:
        return bin_path if bin_path.is_file() else None
    src_path.write_text(SWIFT_OCR_SOURCE, encoding="utf-8")
    res = subprocess.run([swiftc, "-O", "-framework", "Vision", "-framework", "AppKit", str(src_path), "-o", str(bin_path)],
                         capture_output=True, text=True, timeout=240)
    if res.returncode != 0 or not bin_path.is_file():
        return None
    return bin_path


WIN_OCR_PS1 = r'''
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
})[0]
function Await($WinRtTask, $ResultType) {
    $asTask = $asTaskGeneric.MakeGenericMethod($ResultType)
    $netTask = $asTask.Invoke($null, @($WinRtTask))
    $netTask.Wait(-1) | Out-Null
    return $netTask.Result
}
[Windows.Storage.StorageFile,Windows.Storage,ContentType=WindowsRuntime] | Out-Null
[Windows.Graphics.Imaging.BitmapDecoder,Windows.Graphics,ContentType=WindowsRuntime] | Out-Null
[Windows.Media.Ocr.OcrEngine,Windows.Foundation,ContentType=WindowsRuntime] | Out-Null
[Windows.Globalization.Language,Windows.Foundation,ContentType=WindowsRuntime] | Out-Null

$imgPath = [System.IO.Path]::GetFullPath($env:OMNI_OCR_IMAGE)
$file = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($imgPath)) ([Windows.Storage.StorageFile])
$stream = Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
try {
    $decoder = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
    $bitmap = Await ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
    $engine = $null
    foreach ($tag in @('zh-Hans-CN', 'zh-Hans', 'zh-CN')) {
        try {
            $lang = New-Object Windows.Globalization.Language($tag)
            if ([Windows.Media.Ocr.OcrEngine]::IsLanguageSupported($lang)) {
                $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($lang)
                if ($engine) { break }
            }
        } catch {}
    }
    if (-not $engine) { $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages() }
    if (-not $engine) { exit 5 }
    $res = Await ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])
    foreach ($line in $res.Lines) {
        foreach ($w in $line.Words) {
            $r = $w.BoundingRect
            Write-Output ("{0}`t{1}`t{2}`t{3}`t{4}" -f $r.X, $r.Y, $r.Width, $r.Height, $w.Text)
        }
    }
} finally {
    if ($stream) { $stream.Dispose() }
}
'''


def _format_win_ocr_words(raw: str) -> str:
    words: list[tuple[float, float, float, float, str]] = []
    for ln in raw.splitlines():
        parts = ln.split("\t", 4)
        if len(parts) != 5:
            continue
        try:
            x, y, w, h = float(parts[0]), float(parts[1]), float(parts[2]), float(parts[3])
        except ValueError:
            continue
        txt = parts[4].strip()
        if txt:
            words.append((y + h * 0.5, x, w, max(h, 1.0), txt))
    if not words:
        return ""
    words.sort(key=lambda it: (it[0], it[1]))
    rows: list[list[tuple[float, float, float, float, str]]] = []
    for it in words:
        if rows and abs(rows[-1][0][0] - it[0]) < max(6.0, rows[-1][0][3] * 0.58):
            rows[-1].append(it)
        else:
            rows.append([it])
    out_lines: list[str] = []
    ascii_alnum = re.compile(r"^[A-Za-z0-9]+$")
    for r in rows:
        r.sort(key=lambda it: it[1])
        buf: list[str] = []
        prev_end = None
        prev_txt = ""
        for _cy, x, w, h, txt in r:
            if prev_end is not None:
                gap = x - prev_end
                if gap > h * 1.1:
                    buf.append("  ")
                elif gap > h * 0.35 or (ascii_alnum.match(prev_txt) and ascii_alnum.match(txt)):
                    buf.append(" ")
            buf.append(txt)
            prev_end = x + w
            prev_txt = txt
        out_lines.append("".join(buf))
    return "\n".join(out_lines).strip()


def _windows_ocr(path: Path, timeout: int = 90) -> str:
    if platform.system() != "Windows":
        return ""
    ps = shutil.which("powershell") or shutil.which("powershell.exe")
    if not ps:
        return ""
    script_path = _bin_dir() / "OmniOCR.ps1"
    if not script_path.is_file() or script_path.read_text(encoding="utf-8") != WIN_OCR_PS1:
        script_path.write_text(WIN_OCR_PS1, encoding="utf-8")
    env = {**os.environ, "OMNI_OCR_IMAGE": str(path.resolve())}
    r = subprocess.run(
        [ps, "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", str(script_path)],
        capture_output=True, encoding="utf-8", errors="replace", env=env, timeout=timeout,
    )
    if r.returncode != 0 or not r.stdout.strip():
        return ""
    return _format_win_ocr_words(r.stdout)


def ocr_image(path: str | Path, timeout: int = 90) -> tuple[str, str]:
    """返回 (识别文本, 方法)。方法为 vision / windows / tesseract / unavailable。"""
    p = Path(path)
    try:
        exe = ensure_vision_ocr()
    except Exception:  # noqa: BLE001
        exe = None
    if exe:
        try:
            r = subprocess.run([str(exe), str(p)], capture_output=True, text=True, timeout=timeout)
            if r.returncode == 0 and r.stdout.strip():
                return r.stdout.strip(), "vision"
        except Exception:  # noqa: BLE001
            pass
    if platform.system() == "Windows":
        try:
            win_txt = _windows_ocr(p, timeout=timeout)
            if win_txt:
                return win_txt, "windows"
        except Exception:  # noqa: BLE001
            pass
    try:
        import pytesseract  # type: ignore
        from PIL import Image

        if platform.system() == "Windows" and not shutil.which("tesseract"):
            for cand in (
                r"C:\Program Files\Tesseract-OCR\tesseract.exe",
                r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
                str(Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "Tesseract-OCR" / "tesseract.exe"),
            ):
                if cand and Path(cand).is_file():
                    pytesseract.pytesseract.tesseract_cmd = cand
                    break
        txt = pytesseract.image_to_string(Image.open(p), lang="chi_sim+eng")
        if txt.strip():
            return txt.strip(), "tesseract"
    except Exception:  # noqa: BLE001
        pass
    return "", "unavailable"
