"""票据识别与字段抽取：增值税/全电发票、铁路电子客票、航空行程单、网约车行程单、酒店水单、支付凭证、出差审批单、费用清单。"""
from __future__ import annotations

import datetime as dt
import re
from decimal import Decimal
from typing import Any

from .amounts import D, chinese_to_amount, money

DOC_LABELS = {
    "vat_invoice": "增值税发票",
    "train_ticket": "铁路电子客票",
    "flight_itinerary": "航空运输电子客票行程单",
    "taxi_itinerary": "网约车/出租车行程单",
    "hotel_folio": "酒店住宿水单",
    "payment_record": "支付凭证",
    "approval_form": "出差/事前审批单",
    "expense_list": "费用清单",
    "contract": "合同/协议",
    "other": "其他材料",
}
INVOICE_TYPES = {"vat_invoice", "train_ticket", "flight_itinerary"}

CATEGORY_RULES: list[tuple[str, tuple[str, ...]]] = [
    ("住宿费", ("住宿", "酒店", "宾馆", "客房", "旅馆", "民宿", "公寓")),
    ("城际交通费", ("铁路", "航空", "机票", "客票", "国内航空", "代订机票", "火车")),
    ("市内交通费", ("客运服务", "出租", "网约车", "滴滴", "打车", "出行", "曹操", "高德", "T3", "地铁", "公交")),
    ("通行/燃油费", ("通行费", "成品油", "汽油", "柴油", "停车", "过路", "加油")),
    ("餐饮费", ("餐饮", "餐费", "饮食", "餐厅", "饭店", "酒楼", "食堂", "伙食")),
    ("会议培训费", ("会议", "会务", "培训", "展览", "论坛", "注册费")),
    ("办公用品费", ("办公", "文具", "纸制品", "耗材", "墨盒", "硒鼓", "计算机配套", "打印纸", "电子元件")),
    ("通讯费", ("通信", "电信", "移动", "联通", "话费", "宽带", "流量")),
    ("快递邮寄费", ("快递", "邮寄", "收派", "物流", "速运")),
    ("印刷资料费", ("印刷", "复印", "图书", "资料", "出版", "书刊", "文献")),
    ("软件信息服务费", ("软件", "信息技术服务", "云服务", "技术服务", "数据服务")),
]

_DATE_RE = r"(\d{4})\s*[年\-/.]\s*(\d{1,2})\s*[月\-/.]\s*(\d{1,2})\s*日?"
_AMT = r"([0-9][0-9,]*\.\d{1,2}|[0-9]+)"


def norm_date(y: str, m: str, d: str) -> str | None:
    try:
        return dt.date(int(y), int(m), int(d)).isoformat()
    except ValueError:
        return None


def find_dates(text: str) -> list[str]:
    out = []
    for m in re.finditer(_DATE_RE, text):
        v = norm_date(*m.groups())
        if v and v not in out:
            out.append(v)
    return out


def _first(pattern: str, text: str, flags=re.S) -> str:
    m = re.search(pattern, text, flags)
    return m.group(1).strip() if m else ""


def _yen_amounts(text: str) -> list[Decimal]:
    return [money(x) for x in re.findall(r"[¥￥]\s*(-?[0-9][0-9,]*\.\d{2})", text)]


def guess_category(*texts: str) -> str:
    blob = " ".join(t for t in texts if t)
    for cat, kws in CATEGORY_RULES:
        if any(k in blob for k in kws):
            return cat
    return "其他费用"


def classify(text: str, name: str, has_rows: bool) -> str:
    t = text
    low_name = name.lower()
    if has_rows:
        return "expense_list"
    if re.search(r"航空运输电子客票行程单|电子客票行程单|民航发展基金|燃油附加费", t) and re.search(r"航班|承运|票价|旅客", t):
        return "flight_itinerary"
    if re.search(r"铁路电子客票|电子客票号|12306|中国铁路", t) or (
            "电子客票" in t and re.search(r"[GDCZTKY]\d{1,4}", t) and "站" in t):
        return "train_ticket"
    if re.search(r"发票号码|发票代码|EIid|InvoiceNumber", t) and re.search(r"价税合计|开票日期|IssueTime|TotalTax", t):
        return "vat_invoice"
    if re.search(r"行程单", t) and re.search(r"滴滴|打车|出行|网约车|用车|曹操|T3|高德|首汽|共\s*\d+\s*笔行程|上车|下车", t):
        return "taxi_itinerary"
    if re.search(r"水单|宾客账单|住宿账单|结账单|Folio|FOLIO|入住日期|离店日期|到店日期|Arrival|Departure", t):
        return "hotel_folio"
    if re.search(r"出差申请|出差审批|差旅申请|事前审批|出差单|审批单|出差任务", t):
        return "approval_form"
    if re.search(r"支付成功|交易成功|付款成功|支付凭证|交易详情|账单详情|微信支付|支付宝|转账成功|商户全称", t):
        return "payment_record"
    if re.search(r"合同|协议书|甲方|乙方", t) and len(t) > 300:
        return "contract"
    if any(k in low_name for k in ("发票", "invoice", "fapiao")):
        return "vat_invoice"
    if "行程单" in name:
        return "taxi_itinerary"
    if "水单" in name:
        return "hotel_folio"
    if "审批" in name or "申请" in name:
        return "approval_form"
    return "other"


def _parse_vat(t: str, struct: dict[str, str]) -> dict[str, Any]:
    f: dict[str, Any] = {}
    f["invoice_no"] = _first(r"发票号码\s*[:：]?\s*([0-9]{8,20})", t) or struct.get("EIid") or struct.get("InvoiceNumber", "")
    f["invoice_code"] = _first(r"发票代码\s*[:：]?\s*([0-9]{10,12})", t)
    title = _first(r"((?:电子发票|增值税)[^\n]{0,16}?(?:专用发票|普通发票|发票)[）)]?)", t)
    f["invoice_kind"] = title or ("电子发票" if "电子" in t else "增值税发票")
    f["is_special"] = "专用发票" in (title or t[:200])
    m = re.search(r"开票日期\s*[:：]?\s*" + _DATE_RE, t)
    f["date"] = norm_date(*m.groups()) if m else (struct.get("IssueTime", "")[:10] or (find_dates(t) or [""])[0])
    # 名称与税号：先出现的为购买方，后出现的为销售方
    names = [n.strip() for n in re.findall(r"名\s*称\s*[:：]\s*([^\n:：]{2,60}?)(?=\s{2,}|\n|统一社会|纳税人|$)", t)]
    names = [re.sub(r"\s+", "", n) for n in names if not re.match(r"^[\s:：]*$", n)]
    ids = re.findall(r"(?:统一社会信用代码\s*/?\s*纳税人识别号|纳税人识别号|统一社会信用代码)\s*[:：]?\s*([0-9A-Z]{15,20})", t)
    f["buyer_name"] = names[0] if names else struct.get("BuyerName", "")
    f["seller_name"] = names[1] if len(names) > 1 else struct.get("SellerName", "")
    f["buyer_tax_id"] = ids[0] if ids else struct.get("BuyerIdNum", "")
    f["seller_tax_id"] = ids[1] if len(ids) > 1 else struct.get("SellerIdNum", "")
    items = re.findall(r"(\*[^*\n]{1,20}\*[^\n]{0,40})", t)
    f["items"] = [re.split(r"\s{2,}|\s(?=\d)", it.strip())[0] for it in items][:8]
    rates = re.findall(r"(\d{1,2})\s*%", t)
    f["tax_rate"] = f"{rates[0]}%" if rates else ("免税" if "免税" in t else ("不征税" if "不征税" in t else ""))
    qty = re.search(r"\*住宿[^\n]*?(?:天|间夜|晚|间)\s+(\d+(?:\.\d+)?)", t)
    if qty:
        f["nights"] = float(qty.group(1))
    # 金额
    total_small = _first(r"[（(]\s*小\s*写\s*[)）]\s*[:：]?\s*[¥￥]?\s*" + _AMT, t)
    total_big = _first(r"价税合计\s*[（(]\s*大\s*写\s*[)）]\s*[:：]?\s*[⊗ⓧ×Ⓧ⨂\s]*([零壹贰叁肆伍陆柒捌玖拾佰仟万亿圆元角分整正]+)", t)
    if not total_big:
        total_big = _first(r"[⊗ⓧ×Ⓧ⨂]\s*([零壹贰叁肆伍陆柒捌玖拾佰仟万亿圆元角分整正]{2,})", t)
    f["total_in_words"] = total_big
    big_val = chinese_to_amount(total_big) if total_big else None
    hj = re.search(r"合\s*计\s*[¥￥]\s*" + _AMT + r"\s*[¥￥*]\s*" + _AMT, t)
    if not hj:
        hj = re.search(r"合\s*计[^\n¥￥]{0,6}[¥￥]\s*" + _AMT + r"[^\n¥￥]{0,30}[¥￥]\s*" + _AMT, t)
    amount = money(hj.group(1)) if hj else None
    tax = money(hj.group(2)) if hj else None
    if struct.get("TotalTax-includedAmount") or struct.get("TotalTaxincludedAmount"):
        total_small = total_small or struct.get("TotalTax-includedAmount") or struct.get("TotalTaxincludedAmount")
    if struct.get("TotalAmWithoutTax") and amount is None:
        amount = money(struct["TotalAmWithoutTax"])
    if struct.get("TotalTaxAm") and tax is None:
        tax = money(struct["TotalTaxAm"])
    total = money(total_small) if total_small else (big_val if big_val is not None else None)
    yen = _yen_amounts(t)
    if total is None and yen:
        total = max(yen)
    if (amount is None or tax is None) and total is not None and yen:
        # 在 ¥ 金额中寻找 a + b == total 的组合
        for a in yen:
            for b in yen:
                if a is not b and a >= b and money(a + b) == total:
                    amount, tax = a, b
                    break
            if amount is not None:
                break
    if amount is None and total is not None and tax is None and f["tax_rate"] in ("免税", "不征税", "0%"):
        amount, tax = total, Decimal("0.00")
    f["amount_ex_tax"] = amount
    f["tax"] = tax
    f["total"] = total
    f["total_in_words_value"] = big_val
    f["check_code"] = _first(r"校\s*验\s*码\s*[:：]?\s*([0-9\s]{10,30})", t).replace(" ", "")
    return f


def _parse_train(t: str) -> dict[str, Any]:
    f: dict[str, Any] = {"invoice_kind": "铁路电子客票", "is_special": False}
    f["invoice_no"] = _first(r"发票号码\s*[:：]?\s*([0-9]{8,20})", t) or _first(r"电子客票号\s*[:：]?\s*([0-9A-Z]{10,24})", t)
    fare = _first(r"票\s*价\s*[:：]?\s*[¥￥]?\s*" + _AMT, t) or (str(max(_yen_amounts(t))) if _yen_amounts(t) else "")
    if not fare:
        fare = _first(r"[¥￥]\s*" + _AMT, t)
    f["total"] = money(fare) if fare else None
    m = re.search(_DATE_RE + r"\s*(\d{1,2}:\d{2})?\s*开", t)
    f["travel_date"] = norm_date(*m.groups()[:3]) if m else None
    if m and m.group(4):
        f["depart_time"] = m.group(4)
    mi = re.search(r"开票日期\s*[:：]?\s*" + _DATE_RE, t)
    f["date"] = norm_date(*mi.groups()) if mi else f["travel_date"]
    stations = []
    for s in re.findall(r"([\u4e00-\u9fa5]{2,8}站)", t):
        if s not in stations and s not in ("车站", "售票站", "检票站"):
            stations.append(s)
    f["from_station"], f["to_station"] = (stations + ["", ""])[:2]
    f["train_no"] = _first(r"\b([GDCZTKY]\d{1,4})\b", t)
    f["seat"] = _first(r"(商务座|特等座|一等座|二等座|软卧|硬卧|软座|硬座|无座|动卧)", t)
    f["passenger"] = _first(r"\d{6,10}\*{2,8}\d{2,4}[\dXx]?\s*([\u4e00-\u9fa5·]{2,10})", t) or \
        _first(r"([\u4e00-\u9fa5·]{2,4})\s*\d{6,10}\*{2,8}", t)
    if f["total"] is not None:
        f["amount_ex_tax"] = money(f["total"] / Decimal("1.09"))
        f["tax"] = money(f["total"] - f["amount_ex_tax"])
        f["deductible_tax"] = f["tax"]
    f["items"] = [f"{f['from_station']}→{f['to_station']} {f['train_no']} {f['seat']}".strip()]
    return f


def _parse_flight(t: str) -> dict[str, Any]:
    f: dict[str, Any] = {"invoice_kind": "航空运输电子客票行程单", "is_special": False}
    f["invoice_no"] = _first(r"发票号码\s*[:：]?\s*([0-9]{8,20})", t) or _first(r"(?:电子客票号码|客票号码|票号)\s*[:：]?\s*([0-9\-]{10,20})", t)
    fare = _first(r"票\s*价\s*[:：]?\s*(?:CNY)?\s*" + _AMT, t)
    fuel = _first(r"燃油附加费\s*[:：]?\s*(?:CNY|YQ)?\s*" + _AMT, t)
    fund = _first(r"(?:民航发展基金|机场建设费)\s*[:：]?\s*(?:CNY|CN)?\s*" + _AMT, t)
    total = _first(r"合\s*计\s*[:：]?\s*(?:CNY)?\s*[¥￥]?\s*" + _AMT, t)
    f["fare"], f["fuel"], f["fund"] = (money(x) if x else None for x in (fare, fuel, fund))
    if total:
        f["total"] = money(total)
    else:
        f["total"] = money(sum(x for x in (f["fare"], f["fuel"], f["fund"]) if x is not None)) if fare else None
    dates = find_dates(t)
    mi = re.search(r"(?:开票日期|填开日期)\s*[:：]?\s*" + _DATE_RE, t)
    f["date"] = norm_date(*mi.groups()) if mi else (dates[0] if dates else None)
    f["flight_no"] = _first(r"\b((?:[A-Z]{2}|[A-Z]\d|\d[A-Z])\d{3,4})\b", t)
    f["passenger"] = _first(r"旅客姓名\s*[:：]?\s*([\u4e00-\u9fa5A-Z/·]{2,20})", t)
    if f["fare"] is not None:
        base = f["fare"] + (f["fuel"] or Decimal(0))
        f["deductible_tax"] = money(base / Decimal("1.09") * Decimal("0.09"))
        f["tax"] = f["deductible_tax"]
        f["amount_ex_tax"] = money((f["total"] or base) - f["tax"])
    f["items"] = [f"航班 {f['flight_no']}".strip()]
    return f


def _parse_taxi(t: str) -> dict[str, Any]:
    f: dict[str, Any] = {}
    m = re.search(r"共\s*(\d+)\s*笔行程[，,\s]*合计\s*" + _AMT + r"\s*元", t)
    if m:
        f["trip_count"], f["total"] = int(m.group(1)), money(m.group(2))
    else:
        tot = _first(r"合\s*计\s*[:：]?\s*[¥￥]?\s*" + _AMT + r"\s*元?", t)
        f["total"] = money(tot) if tot else (max(_yen_amounts(t)) if _yen_amounts(t) else None)
    mr = re.search(r"(?:行程)?(?:起止|开始)?(?:日期|时间)\s*[:：]\s*" + _DATE_RE + r".{0,12}?(?:至|~|－|—|-)\s*" + _DATE_RE, t)
    if mr:
        g = mr.groups()
        f["period_start"], f["period_end"] = norm_date(*g[:3]), norm_date(*g[3:6])
    dates = find_dates(t)
    f["date"] = f.get("period_end") or (dates[-1] if dates else None)
    f["platform"] = _first(r"(滴滴出行|滴滴|高德打车|高德|曹操出行|T3出行|首汽约车|美团打车|如祺出行|享道出行)", t)
    return f


def _parse_folio(t: str) -> dict[str, Any]:
    f: dict[str, Any] = {}
    ci = re.search(r"(?:入住|到店|抵店|Arrival)[^\d\n]{0,10}" + _DATE_RE, t)
    co = re.search(r"(?:离店|退房|离开|Departure)[^\d\n]{0,10}" + _DATE_RE, t)
    f["check_in"] = norm_date(*ci.groups()) if ci else None
    f["check_out"] = norm_date(*co.groups()) if co else None
    if f["check_in"] and f["check_out"]:
        f["nights"] = max(1, (dt.date.fromisoformat(f["check_out"]) - dt.date.fromisoformat(f["check_in"])).days)
    tot = _first(r"(?:消费合计|总消费|费用合计|合计|总计|结账金额|应付金额|应收|Total|TOTAL|Balance)[^\d\n]{0,12}" + _AMT, t)
    f["total"] = money(tot) if tot else (max(_yen_amounts(t)) if _yen_amounts(t) else None)
    f["hotel"] = _first(r"([\u4e00-\u9fa5A-Za-z]{2,30}(?:酒店|宾馆|饭店|大厦|Hotel))", t)
    f["guest"] = _first(r"(?:宾客姓名|客人姓名|姓名|Guest Name|Name)\s*[:：]?\s*([\u4e00-\u9fa5A-Za-z·]{2,20})", t)
    f["date"] = f["check_out"] or (find_dates(t) or [None])[-1]
    return f


def _parse_payment(t: str) -> dict[str, Any]:
    f: dict[str, Any] = {}
    amt = _first(r"(?:付款金额|支付金额|实付金额|实付|交易金额|订单金额|消费金额)\s*[:：]?\s*[-−¥￥]?\s*" + _AMT, t) or \
        _first(r"[-−]\s*[¥￥]?\s*([0-9][0-9,]*\.\d{2})", t)
    f["total"] = money(amt) if amt else (max(_yen_amounts(t)) if _yen_amounts(t) else None)
    f["merchant"] = _first(r"(?:商户全称|商户名称|收款方|商家|对方账户|收款人)\s*[:：]?\s*([^\n]{2,40})", t)
    f["pay_channel"] = _first(r"(微信支付|支付宝|云闪付|银行卡|信用卡)", t)
    f["date"] = (find_dates(t) or [None])[0]
    return f


def _parse_approval(t: str) -> dict[str, Any]:
    f: dict[str, Any] = {}
    f["applicant"] = _first(r"(?:出差人|申请人|姓名)\s*[:：]?\s*([\u4e00-\u9fa5·]{2,10})", t)
    f["destination"] = _first(r"(?:出差地点|目的地|出差城市|前往)\s*[:：]?\s*([\u4e00-\u9fa5]{2,20})", t)
    f["purpose"] = _first(r"(?:出差事由|事由|出差目的|目的)\s*[:：]?\s*([^\n]{2,80})", t)
    f["approval_no"] = _first(r"(?:审批编号|单据编号|申请单号|编号)\s*[:：]?\s*([A-Za-z0-9\-]{4,30})", t)
    mr = re.search(_DATE_RE + r".{0,6}?(?:至|到|~|－|—|-)\s*" + _DATE_RE, t)
    if mr:
        g = mr.groups()
        f["period_start"], f["period_end"] = norm_date(*g[:3]), norm_date(*g[3:6])
    budget = _first(r"(?:预算|预计费用|申请金额)\s*[:：]?\s*[¥￥]?\s*" + _AMT, t)
    f["budget"] = money(budget) if budget else None
    f["approved"] = bool(re.search(r"已通过|审批通过|同意|已批准|已审批", t))
    f["date"] = f.get("period_start")
    return f


def _parse_expense_list(rows: list[list[str]]) -> dict[str, Any]:
    f: dict[str, Any] = {"rows": [], "total": None}
    if not rows:
        return f
    head = [str(h) for h in rows[0]]
    amt_idx = next((i for i, h in enumerate(head) if re.search(r"金额|报销额|费用|合计|价税", h)), None)
    cat_idx = next((i for i, h in enumerate(head) if re.search(r"类别|类型|科目|项目", h)), None)
    date_idx = next((i for i, h in enumerate(head) if re.search(r"日期|时间", h)), None)
    desc_idx = next((i for i, h in enumerate(head) if re.search(r"说明|摘要|事由|备注|内容", h)), None)
    total = Decimal(0)
    for r in rows[1:]:
        if amt_idx is None or amt_idx >= len(r):
            continue
        v = D(r[amt_idx])
        if v == 0 and not re.search(r"\d", str(r[amt_idx])):
            continue
        if any(k in " ".join(map(str, r)) for k in ("合计", "总计")):
            continue
        total += v
        f["rows"].append({
            "category": r[cat_idx] if cat_idx is not None and cat_idx < len(r) else "",
            "date": r[date_idx] if date_idx is not None and date_idx < len(r) else "",
            "desc": r[desc_idx] if desc_idx is not None and desc_idx < len(r) else "",
            "amount": money(v),
        })
    f["total"] = money(total) if f["rows"] else None
    return f


def parse_document(name: str, extracted: dict) -> dict[str, Any]:
    text = extracted.get("text") or ""
    struct = extracted.get("struct") or {}
    rows = extracted.get("rows") or []
    doc_type = classify(text, name, bool(rows))
    if doc_type == "vat_invoice":
        fields = _parse_vat(text, struct)
    elif doc_type == "train_ticket":
        fields = _parse_train(text)
    elif doc_type == "flight_itinerary":
        fields = _parse_flight(text)
    elif doc_type == "taxi_itinerary":
        fields = _parse_taxi(text)
    elif doc_type == "hotel_folio":
        fields = _parse_folio(text)
    elif doc_type == "payment_record":
        fields = _parse_payment(text)
    elif doc_type == "approval_form":
        fields = _parse_approval(text)
    elif doc_type == "expense_list":
        fields = _parse_expense_list(rows)
    else:
        fields = {"date": (find_dates(text) or [None])[0],
                  "total": max(_yen_amounts(text)) if _yen_amounts(text) else None}
    if doc_type in ("train_ticket", "flight_itinerary"):
        category = "城际交通费"
    elif doc_type == "taxi_itinerary":
        category = "市内交通费"
    elif doc_type == "hotel_folio":
        category = "住宿费"
    elif doc_type == "vat_invoice":
        category = guess_category(" ".join(fields.get("items") or []), fields.get("seller_name", ""))
    else:
        category = ""
    confidence = "high"
    if not text.strip():
        confidence = "none"
    elif doc_type in INVOICE_TYPES and (fields.get("total") is None or not fields.get("invoice_no")):
        confidence = "low"
    elif doc_type == "other":
        confidence = "low"
    return {
        "doc_type": doc_type,
        "doc_label": DOC_LABELS[doc_type],
        "category": category,
        "fields": fields,
        "confidence": confidence,
        "text_excerpt": text[:1500],
        "method": extracted.get("method"),
        "pages": extracted.get("pages", 1),
    }
