"""报销产出物：报销单 Excel、金额核对报告、报销内容审核报告（Markdown + Word）、网页填报数据 JSON。"""
from __future__ import annotations

import json
from decimal import Decimal
from pathlib import Path
from typing import Any

from .amounts import fmt_money, money
from .engine import SEVERITY_LABEL, to_jsonable


METHOD_LABEL = {
    "pdf_text": "PDF 文字层", "ofd": "OFD 版式文件", "xml": "全电发票 XML", "docx": "Word 文档", "sheet": "表格", "text": "文本",
    "ocr_vision": "图片 OCR（macOS Vision 离线）", "ocr_windows": "图片 OCR（Windows 系统离线）",
    "ocr_tesseract": "图片 OCR（Tesseract）", "ocr_unavailable": "OCR 不可用",
    "pdf_ocr_vision": "扫描 PDF OCR（macOS Vision）", "pdf_ocr_windows": "扫描 PDF OCR（Windows 系统离线）",
    "pdf_ocr_tesseract": "扫描 PDF OCR（Tesseract）", "manual": "人工补录",
}


def _method(m) -> str:
    return METHOD_LABEL.get(str(m), str(m))


def _m(x) -> str:
    return fmt_money(x) if x is not None else "—"


def _info_rows(r: dict[str, Any]) -> list[tuple[str, str]]:
    info = r["info"]
    period = " ~ ".join(p for p in r["period"] if p) or (info.get("trip_start") or "")
    return [
        ("报销人", info.get("claimant") or "（待填写）"),
        ("所属部门", info.get("department") or "（待填写）"),
        ("工号", info.get("employee_id") or ""),
        ("报销事由", info.get("purpose") or "（待填写）"),
        ("项目/成本中心", " / ".join(x for x in (info.get("project"), info.get("cost_center")) if x) or ""),
        ("出差地点", info.get("destination") or ""),
        ("费用期间", period),
        ("审批编号", info.get("approval_no") or ""),
        ("单位（发票抬头）", r["policy"].get("company_name") or info.get("company_name") or "（未配置，仅提示）"),
    ]


def build_portal_fill(r: dict[str, Any]) -> dict[str, Any]:
    info = r["info"]
    active = [it for it in r["items"] if not it.get("excluded")]
    return {
        "portal_url": r["policy"].get("portal_url"),
        "batch_id": r["batch_id"],
        "status": r["status"],
        "verdict": r["verdict"],
        "header": {
            "报销人": info.get("claimant", ""),
            "部门": info.get("department", ""),
            "工号": info.get("employee_id", ""),
            "报销事由": info.get("purpose", ""),
            "项目": info.get("project", ""),
            "成本中心": info.get("cost_center", ""),
            "出差地点": info.get("destination", ""),
            "开始日期": r["period"][0],
            "结束日期": r["period"][1],
            "审批编号": info.get("approval_no", ""),
            "报销总金额": float(r["grand_total"]),
            "大写金额": r["grand_total_words"],
            "发票张数": r["invoice_count"],
            "附件张数": r["attachment_count"],
            "可抵扣进项税额": float(r["deductible_total"]),
        },
        "lines": [
            {
                "序号": i, "费用类型": it["category"], "发生日期": it["date"], "发票号码": it["invoice_no"],
                "票据类型": it["doc_label"], "销售方": it["seller"], "摘要": it["items"],
                "不含税金额": float(it["amount_ex_tax"]) if it["amount_ex_tax"] is not None else None,
                "税额": float(it["tax"]) if it["tax"] is not None else None,
                "金额": float(it["total"]) if it["total"] is not None else None,
                "附件": next((d.get("attachment") for d in r["docs"] if d["file"] == it["file"]), it["file"]),
            }
            for i, it in enumerate(active, 1)
        ],
        "category_totals": {k: float(v["total"]) for k, v in r["summary_by_category"].items()},
        "attachments": r["attachments"],
        "open_issues": [f"[{SEVERITY_LABEL[x['severity']]}] {x['title']}：{x['detail']}" for x in r["issues"]
                        if x["severity"] != "info"],
    }


def _xlsx(r: dict[str, Any], path: Path) -> None:
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

    wb = Workbook()
    thin = Side(style="thin", color="B7BDC8")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    head_fill = PatternFill("solid", fgColor="1F3A5F")
    head_font = Font(bold=True, color="FFFFFF", name="微软雅黑", size=10)
    body_font = Font(name="微软雅黑", size=10)
    center = Alignment(horizontal="center", vertical="center", wrap_text=True)
    left = Alignment(horizontal="left", vertical="center", wrap_text=True)
    money_fmt = "#,##0.00"

    # 报销单
    ws = wb.active
    ws.title = "报销单"
    ws.merge_cells("A1:F1")
    ws["A1"] = "费 用 报 销 单"
    ws["A1"].font = Font(bold=True, size=16, name="微软雅黑")
    ws["A1"].alignment = center
    ws.row_dimensions[1].height = 32
    ws["A2"] = f"批次：{r['batch_id']}    生成时间：{r['generated_at']}"
    ws.merge_cells("A2:F2")
    ws["A2"].font = Font(size=9, color="666666", name="微软雅黑")
    row = 3
    pairs = _info_rows(r)
    for i in range(0, len(pairs), 2):
        for j, (k, v) in enumerate(pairs[i:i + 2]):
            c1 = ws.cell(row=row, column=1 + j * 3, value=k)
            c2 = ws.cell(row=row, column=2 + j * 3, value=v)
            ws.merge_cells(start_row=row, start_column=2 + j * 3, end_row=row, end_column=3 + j * 3)
            c1.font = Font(bold=True, name="微软雅黑", size=10)
            c1.fill = PatternFill("solid", fgColor="EEF2F7")
            for c in (c1, c2):
                c.border = border
                c.alignment = left
            c2.font = body_font
        row += 1
    row += 1
    heads = ["费用类别", "票据张数", "价税合计（元）", "其中税额（元）", "可抵扣进项税（元）", "备注"]
    for j, hname in enumerate(heads, 1):
        c = ws.cell(row=row, column=j, value=hname)
        c.font, c.fill, c.alignment, c.border = head_font, head_fill, center, border
    row += 1
    for cat, v in r["summary_by_category"].items():
        vals = [cat, v["count"], float(v["total"]), float(v["tax"]), float(v["deductible"]), ""]
        for j, val in enumerate(vals, 1):
            c = ws.cell(row=row, column=j, value=val)
            c.border, c.font = border, body_font
            c.alignment = center if j <= 2 else Alignment(horizontal="right")
            if j in (3, 4, 5):
                c.number_format = money_fmt
        row += 1
    tot_vals = ["合计（小写）", r["invoice_count"], float(r["grand_total"]), float(r["tax_total"]), float(r["deductible_total"]), ""]
    for j, val in enumerate(tot_vals, 1):
        c = ws.cell(row=row, column=j, value=val)
        c.font = Font(bold=True, name="微软雅黑", size=10)
        c.fill = PatternFill("solid", fgColor="FFF4D6")
        c.border = border
        if j in (3, 4, 5):
            c.number_format = money_fmt
    row += 1
    ws.cell(row=row, column=1, value="合计（大写）").font = Font(bold=True, name="微软雅黑")
    ws.cell(row=row, column=2, value=r["grand_total_words"]).font = Font(bold=True, color="B42318", name="微软雅黑", size=11)
    ws.merge_cells(start_row=row, start_column=2, end_row=row, end_column=6)
    for j in range(1, 7):
        ws.cell(row=row, column=j).border = border
    row += 2
    ws.cell(row=row, column=1, value="核对结论").font = Font(bold=True, name="微软雅黑")
    ws.cell(row=row, column=2, value=r["verdict"]).font = Font(bold=True, name="微软雅黑",
                                                              color={"pass": "067647", "review": "B54708", "blocked": "B42318"}[r["status"]])
    ws.merge_cells(start_row=row, start_column=2, end_row=row, end_column=6)
    row += 1
    ws.cell(row=row, column=1, value=f"附件 {r['attachment_count']} 张（已按序号整理至「附件」文件夹）").font = Font(size=9, color="666666")
    row += 2
    for j, lab in enumerate(["报销人签字：", "部门负责人：", "财务审核："], 0):
        ws.cell(row=row, column=1 + j * 2, value=lab).font = body_font
    for col, w in zip("ABCDEF", (16, 22, 16, 16, 18, 20)):
        ws.column_dimensions[col].width = w

    # 费用明细
    ws2 = wb.create_sheet("费用明细")
    heads2 = ["序号", "费用类别", "票据类型", "发票号码", "日期", "销售方/承运方", "摘要", "不含税金额", "税率", "税额",
              "价税合计", "可抵扣进项税", "核验状态", "勾稽检查", "源文件"]
    for j, hname in enumerate(heads2, 1):
        c = ws2.cell(row=1, column=j, value=hname)
        c.font, c.fill, c.alignment, c.border = head_font, head_fill, center, border
    for i, it in enumerate(r["items"], 1):
        vals = [i, it["category"], it["doc_label"], it["invoice_no"], it["date"], it["seller"], it["items"],
                float(it["amount_ex_tax"]) if it["amount_ex_tax"] is not None else None, it["tax_rate"],
                float(it["tax"]) if it["tax"] is not None else None,
                float(it["total"]) if it["total"] is not None else None,
                float(it["deductible_tax"]) if it["deductible_tax"] is not None else None,
                it["status"], "；".join(it["checks"]), it["file"]]
        for j, val in enumerate(vals, 1):
            c = ws2.cell(row=i + 1, column=j, value=val)
            c.border, c.font = border, body_font
            if j in (8, 10, 11, 12):
                c.number_format = money_fmt
            if j == 13 and it["status"] != "通过":
                c.font = Font(color="B42318", bold=True, name="微软雅黑", size=10)
            if it.get("excluded"):
                c.fill = PatternFill("solid", fgColor="FDE2E1")
    n = len(r["items"]) + 2
    ws2.cell(row=n, column=1, value="合计").font = Font(bold=True)
    ws2.cell(row=n, column=11, value=f"=SUMIFS(K2:K{n - 1},M2:M{n - 1},\"<>重复剔除\",M2:M{n - 1},\"<>历史已报销\")").number_format = money_fmt
    for col, w in zip("ABCDEFGHIJKLMNO", (6, 12, 18, 24, 12, 28, 30, 13, 8, 12, 13, 13, 12, 46, 36)):
        ws2.column_dimensions[col].width = w
    ws2.freeze_panes = "A2"

    # 核对问题
    ws3 = wb.create_sheet("核对问题")
    for j, hname in enumerate(["级别", "问题", "说明", "涉及文件", "处理建议"], 1):
        c = ws3.cell(row=1, column=j, value=hname)
        c.font, c.fill, c.alignment, c.border = head_font, head_fill, center, border
    for i, x in enumerate(r["issues"], 2):
        for j, val in enumerate([SEVERITY_LABEL[x["severity"]], x["title"], x["detail"], x["file"], x["fix"]], 1):
            c = ws3.cell(row=i, column=j, value=val)
            c.border, c.font, c.alignment = border, body_font, left
    for col, w in zip("ABCDE", (14, 22, 70, 36, 34)):
        ws3.column_dimensions[col].width = w

    # 附件清单
    ws4 = wb.create_sheet("附件清单")
    for j, hname in enumerate(["序号", "附件文件", "识别类型", "识别方式", "识别置信度", "原文件"], 1):
        c = ws4.cell(row=1, column=j, value=hname)
        c.font, c.fill, c.alignment, c.border = head_font, head_fill, center, border
    for i, d in enumerate(r["docs"], 2):
        for j, val in enumerate([i - 1, d.get("attachment", ""), d["doc_label"], _method(d.get("method")), d["confidence"], d["file"]], 1):
            c = ws4.cell(row=i, column=j, value=val)
            c.border, c.font = border, body_font
    for col, w in zip("ABCDEF", (6, 52, 22, 16, 12, 44)):
        ws4.column_dimensions[col].width = w
    wb.save(path)


def _amount_md(r: dict[str, Any]) -> str:
    L = [f"# 报销金额核对报告", "",
         f"- **批次**：`{r['batch_id']}`　**生成时间**：{r['generated_at']}",
         f"- **报销人**：{r['info'].get('claimant') or '（待填写）'}　**事由**：{r['info'].get('purpose') or '（待填写）'}",
         f"- **核对结论**：**{r['verdict']}**", "",
         "## 一、核定金额汇总", "",
         "| 项目 | 金额（元） |", "|---|---:|",
         f"| 票据张数（有效） | {r['invoice_count']} |",
         f"| 价税合计（核定报销金额） | **{_m(r['grand_total'])}** |",
         f"| 其中：税额 | {_m(r['tax_total'])} |",
         f"| 其中：可抵扣进项税额（供财务参考） | {_m(r['deductible_total'])} |",
         f"| 大写金额 | **{r['grand_total_words']}** |", ""]
    if r["reconciliation"]:
        rc = r["reconciliation"]
        L += ["## 二、申报金额对账", "", "| 申报金额 | 票据核定合计 | 差额（申报 − 核定） |", "|---:|---:|---:|",
              f"| {_m(rc['claimed'])} | {_m(rc['computed'])} | **{_m(rc['diff'])}** |", ""]
    L += ["## 三、分类汇总", "", "| 费用类别 | 张数 | 价税合计 | 税额 | 可抵扣进项税 | 占比 |", "|---|---:|---:|---:|---:|---:|"]
    gt = r["grand_total"] or Decimal(1)
    for cat, v in sorted(r["summary_by_category"].items(), key=lambda kv: -kv[1]["total"]):
        pct = (v["total"] / gt * 100) if gt else 0
        L.append(f"| {cat} | {v['count']} | {_m(v['total'])} | {_m(v['tax'])} | {_m(v['deductible'])} | {pct:.1f}% |")
    L.append(f"| **合计** | **{r['invoice_count']}** | **{_m(r['grand_total'])}** | {_m(r['tax_total'])} | {_m(r['deductible_total'])} | 100% |")
    L += ["", "## 四、逐张票据金额勾稽", "",
          "| # | 类别 | 票据 | 发票号码 | 日期 | 不含税 | 税额 | 价税合计 | 勾稽检查 | 状态 |", "|---:|---|---|---|---|---:|---:|---:|---|---|"]
    for i, it in enumerate(r["items"], 1):
        L.append(f"| {i} | {it['category']} | {it['doc_label']} | {it['invoice_no'] or '—'} | {it['date'] or '—'} | "
                 f"{_m(it['amount_ex_tax'])} | {_m(it['tax'])} | {_m(it['total'])} | {'；'.join(it['checks']) or '—'} | {it['status']} |")
    money_issues = [x for x in r["issues"] if any(k in x["title"] for k in ("金额", "重复", "大小写", "已报销", "申报"))]
    L += ["", "## 五、金额相关异常", ""]
    if money_issues:
        for x in money_issues:
            L.append(f"- {SEVERITY_LABEL[x['severity']]} **{x['title']}**：{x['detail']}" + (f"（建议：{x['fix']}）" if x["fix"] else ""))
    else:
        L.append("- 未发现金额勾稽异常：每张票据「不含税金额 + 税额 = 价税合计」且大小写一致，无重复发票。")
    L += ["", "## 六、计算口径说明", "",
          "1. 核定报销金额 = 各有效票据价税合计之和（剔除重复上传、重复发票号与历史已报销票据）；",
          "2. 铁路电子客票可抵扣进项税 = 票面金额 ÷ (1 + 9%) × 9%；航空客票 = (票价 + 燃油附加费) ÷ (1 + 9%) × 9%（民航发展基金不抵扣）；",
          "3. 增值税专用发票及注明旅客身份信息的客运服务电子普通发票按票面税额列示；",
          "4. 全部金额以 Decimal 精确计算并四舍五入至分，大写金额按《会计基础工作规范》书写。", ""]
    return "\n".join(L)


def _content_md(r: dict[str, Any]) -> str:
    L = ["# 报销内容审核报告", "",
         f"- **批次**：`{r['batch_id']}`　**生成时间**：{r['generated_at']}",
         f"- **审核结论**：**{r['verdict']}**", "",
         "## 一、报销基本信息", "", "| 字段 | 内容 |", "|---|---|"]
    L += [f"| {k} | {v or '—'} |" for k, v in _info_rows(r)]
    L += ["", "## 二、材料完整性清单", "", "| # | 文件 | 识别类型 | 费用类别 | 金额 | 日期 | 识别方式 | 置信度 |",
          "|---:|---|---|---|---:|---|---|---|"]
    for i, d in enumerate(r["docs"], 1):
        f = d["fields"]
        L.append(f"| {i} | {d['name']} | {d['doc_label']} | {d.get('category') or '—'} | {_m(f.get('total'))} | "
                 f"{f.get('travel_date') or f.get('date') or '—'} | {_method(d.get('method'))} | {d['confidence']} |")
    cats = {it["category"] for it in r["items"] if not it.get("excluded")}
    types = {d["doc_type"] for d in r["docs"]}
    L += ["", "## 三、按费用类型的必备材料核查", "", "| 费用类型 | 必备材料 | 是否齐全 |", "|---|---|---|"]
    if "市内交通费" in cats:
        L.append(f"| 市内交通（网约车/出租车） | 发票 + 行程单 | {'✅ 已附行程单' if 'taxi_itinerary' in types else '❌ 缺少行程单'} |")
    if "住宿费" in cats:
        L.append(f"| 住宿费 | 发票 + 水单（建议） | {'✅ 已附水单' if 'hotel_folio' in types else '⚠️ 未附水单'} |")
    if cats & {"住宿费", "城际交通费"}:
        ok = "approval_form" in types or r["info"].get("approval_no")
        L.append(f"| 差旅费 | 出差审批单/审批编号 | {'✅ 已提供' if ok else '⚠️ 未提供'} |")
    if "餐饮费" in cats:
        L.append("| 餐饮/业务招待 | 发票 + 招待事由、对象、人数 | ⚠️ 需报销人补充说明 |")
    if "会议培训费" in cats:
        L.append("| 会议/培训 | 发票 + 通知/议程 + 签到表 | ⚠️ 请确认是否已附 |")
    if not cats:
        L.append("| — | 未识别到有效票据 | ❌ |")
    L += ["", "## 四、审核发现（按严重程度）", ""]
    for sev in ("error", "warning", "info"):
        group = [x for x in r["issues"] if x["severity"] == sev]
        if not group:
            continue
        L.append(f"### {SEVERITY_LABEL[sev]}（{len(group)} 项）")
        for x in group:
            L.append(f"- **{x['title']}**：{x['detail']}" + (f"  \n  → 处理建议：{x['fix']}" if x["fix"] else ""))
        L.append("")
    if not r["issues"]:
        L += ["- 未发现问题。", ""]
    pol = r["policy"]
    L += ["## 五、适用的报销标准", "",
          f"- 住宿标准：{pol.get('hotel_cap_per_night')} 元/晚；餐饮单张提示阈值：{pol.get('meal_cap_per_invoice')} 元；大额票据阈值：{pol.get('large_amount_threshold')} 元；",
          f"- 票据时效：{pol.get('max_invoice_age_days')} 天；出差期间日期容差：±{pol.get('date_tolerance_days')} 天；",
          f"- 网约车必附行程单：{'是' if pol.get('require_taxi_itinerary') else '否'}；住宿必附水单：{'是' if pol.get('require_hotel_folio') else '否'}；差旅需审批：{'是' if pol.get('require_travel_approval') else '否'}。",
          "（可通过 `expense_reimburse(action='set_policy')` 或编辑工作区 `.omniagent/expense_policy.yaml` 调整为本单位制度。）", "",
          "## 六、提交前人工确认事项", "",
          "1. 核对「金额核对报告」中的核定金额与大写金额；",
          "2. 逐项处理上方 ❌ 问题，并确认 ⚠️ 事项；",
          "3. 确认网页填报内容与报销单一致后，再授权智能体点击最终「提交」。", ""]
    return "\n".join(L)


def _md_to_docx(md: str, path: Path, title: str) -> None:
    import re

    import docx
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml.ns import qn
    from docx.shared import Pt, RGBColor

    d = docx.Document()
    st = d.styles["Normal"]
    st.font.name = "宋体"
    st.font.size = Pt(10.5)
    st.element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")

    def add_runs(par, text):
        for k, seg in enumerate(re.split(r"\*\*", text)):
            run = par.add_run(seg.replace("`", ""))
            run.bold = k % 2 == 1
            run.font.name = "宋体"
            run._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")

    lines = md.splitlines()
    i = 0
    while i < len(lines):
        ln = lines[i]
        if ln.startswith("# "):
            p = d.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            r = p.add_run(ln[2:].strip())
            r.bold, r.font.size = True, Pt(18)
            r.font.name = "黑体"
            r._element.rPr.rFonts.set(qn("w:eastAsia"), "黑体")
        elif ln.startswith("## ") or ln.startswith("### "):
            lvl = 1 if ln.startswith("## ") else 2
            hd = d.add_heading(level=lvl)
            r = hd.add_run(ln.lstrip("#").strip())
            r.font.color.rgb = RGBColor(0x1F, 0x3A, 0x5F)
            r.font.name = "黑体"
            r._element.rPr.rFonts.set(qn("w:eastAsia"), "黑体")
        elif ln.startswith("|"):
            block = []
            while i < len(lines) and lines[i].startswith("|"):
                block.append(lines[i])
                i += 1
            rows = [[c.strip() for c in b.strip("|").split("|")] for b in block if not re.match(r"^\|[\s:\-|]+\|$", b)]
            if rows:
                t = d.add_table(rows=len(rows), cols=len(rows[0]))
                t.style = "Table Grid"
                for ri, row in enumerate(rows):
                    for ci, val in enumerate(row[:len(rows[0])]):
                        cell = t.cell(ri, ci)
                        cell.text = ""
                        add_runs(cell.paragraphs[0], val)
                        for run in cell.paragraphs[0].runs:
                            run.font.size = Pt(9)
                            if ri == 0:
                                run.bold = True
            continue
        elif ln.strip().startswith(("- ", "1.", "2.", "3.", "4.", "5.", "6.")):
            p = d.add_paragraph(style="List Bullet" if ln.strip().startswith("- ") else "List Number")
            add_runs(p, re.sub(r"^\s*(?:-|\d+\.)\s*", "", ln))
        elif ln.strip():
            add_runs(d.add_paragraph(), ln.strip())
        i += 1
    d.core_properties.title = title
    d.save(path)


def write_outputs(r: dict[str, Any], out_dir: Path, rel) -> dict[str, str]:
    claimant = (r["info"].get("claimant") or "报销").strip()
    xlsx = out_dir / f"报销单_{claimant}_{r['batch_id']}.xlsx"
    _xlsx(r, xlsx)
    amount_md = _amount_md(r)
    content_md = _content_md(r)
    p_amd = out_dir / "金额核对报告.md"
    p_cmd = out_dir / "报销内容审核报告.md"
    p_amd.write_text(amount_md, encoding="utf-8")
    p_cmd.write_text(content_md, encoding="utf-8")
    p_adocx = out_dir / "金额核对报告.docx"
    p_cdocx = out_dir / "报销内容审核报告.docx"
    _md_to_docx(amount_md, p_adocx, "报销金额核对报告")
    _md_to_docx(content_md, p_cdocx, "报销内容审核报告")
    p_json = out_dir / "portal_fill.json"
    p_json.write_text(json.dumps(to_jsonable(build_portal_fill(r)), ensure_ascii=False, indent=2), encoding="utf-8")
    p_full = out_dir / "analysis.json"
    slim = {k: v for k, v in r.items() if k != "docs"}
    slim["docs"] = [{k: v for k, v in d.items() if k != "text_excerpt"} for d in r["docs"]]
    p_full.write_text(json.dumps(to_jsonable(slim), ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    return {
        "expense_form_xlsx": rel(xlsx),
        "amount_report_md": rel(p_amd),
        "amount_report_docx": rel(p_adocx),
        "content_report_md": rel(p_cmd),
        "content_report_docx": rel(p_cdocx),
        "portal_fill_json": rel(p_json),
        "analysis_json": rel(p_full),
        "attachments_dir": rel(out_dir / "附件"),
    }


__all__ = ["write_outputs", "build_portal_fill", "money"]
