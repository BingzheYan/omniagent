"""金额工具：精确十进制运算、千分位格式化、人民币大写金额互转。"""
from __future__ import annotations

import re
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation

CN_DIGITS = "零壹贰叁肆伍陆柒捌玖"
_DIGIT_MAP = {c: i for i, c in enumerate(CN_DIGITS)}
_DIGIT_MAP.update({"〇": 0, "两": 2, "貮": 2, "参": 3, "陸": 6})
_SMALL_UNITS = {"拾": 10, "佰": 100, "仟": 1000, "十": 10, "百": 100, "千": 1000}
_BIG_UNITS = ["", "万", "亿", "万亿"]
CENT = Decimal("0.01")


def D(x) -> Decimal:
    """把任意数字/字符串安全转为 Decimal（去掉千分位、货币符号）。无法解析返回 Decimal(0)。"""
    if isinstance(x, Decimal):
        return x
    if x is None:
        return Decimal(0)
    if isinstance(x, (int, float)):
        return Decimal(str(x))
    s = re.sub(r"[,\s¥￥元CNY]", "", str(x))
    s = s.replace("，", "")
    try:
        return Decimal(s) if s else Decimal(0)
    except InvalidOperation:
        return Decimal(0)


def money(x) -> Decimal:
    return D(x).quantize(CENT, rounding=ROUND_HALF_UP)


def fmt_money(x) -> str:
    return f"{money(x):,.2f}"


def _group_to_cn(g: int) -> str:
    out, zero = "", False
    for base, unit in ((1000, "仟"), (100, "佰"), (10, "拾"), (1, "")):
        d = g // base % 10
        if d == 0:
            zero = bool(out)
            continue
        if zero:
            out += "零"
            zero = False
        out += CN_DIGITS[d] + unit
    return out


def _int_to_cn(n: int) -> str:
    if n == 0:
        return "零"
    groups: list[int] = []
    while n > 0:
        groups.append(n % 10000)
        n //= 10000
    res, need_zero = "", False
    for gi in range(len(groups) - 1, -1, -1):
        g = groups[gi]
        if g == 0:
            need_zero = bool(res)
            continue
        if res and (need_zero or g < 1000):
            res += "零"
        res += _group_to_cn(g) + _BIG_UNITS[gi]
        need_zero = False
    return res


def amount_to_chinese(x, unit: str = "元") -> str:
    """人民币大写金额（财会规范）：1234.5 → 壹仟贰佰叁拾肆元伍角整；1000 → 壹仟元整；0.05 → 伍分。"""
    v = money(x)
    neg = v < 0
    v = abs(v)
    cents = int((v * 100).to_integral_value())
    yuan, jiao, fen = cents // 100, cents // 10 % 10, cents % 10
    parts = []
    if yuan:
        parts.append(_int_to_cn(yuan) + unit)
    if jiao:
        parts.append(CN_DIGITS[jiao] + "角")
    elif yuan and fen:
        parts.append("零")
    if fen:
        parts.append(CN_DIGITS[fen] + "分")
    if not parts:
        return "零" + unit + "整"
    s = "".join(parts)
    if not fen:
        s += "整"
    return ("负" if neg else "") + s


def _cn_int(s: str) -> int:
    total, section, num = 0, 0, 0
    for ch in s:
        if ch in _DIGIT_MAP:
            num = _DIGIT_MAP[ch]
        elif ch in _SMALL_UNITS:
            section += (num or 1) * _SMALL_UNITS[ch]
            num = 0
        elif ch == "万":
            section += num
            total += section * 10000
            section = num = 0
        elif ch == "亿":
            section += num
            total = (total + section) * 100_000_000
            section = num = 0
    return total + section + num


def chinese_to_amount(s: str) -> Decimal | None:
    """解析人民币大写金额（兼容 ⊗/ⓧ 前缀、圆/元、整/正）。无法解析返回 None。"""
    if not s:
        return None
    s = re.sub(r"[\s⊗ⓧ×Ⓧ⨂人民币:：]", "", str(s))
    if not re.search(r"[壹贰叁肆伍陆柒捌玖零拾佰仟万亿]", s):
        return None
    sep = re.search(r"[圆元]", s)
    if sep:
        yuan_part, rest = s[:sep.start()], s[sep.end():]
    elif re.search(r"[角分]", s):
        yuan_part, rest = "", s
    else:
        yuan_part, rest = re.sub(r"[整正]", "", s), ""
    yuan = _cn_int(yuan_part) if yuan_part else 0
    jiao = fen = 0
    mj = re.search(r"([零壹贰叁肆伍陆柒捌玖])角", rest)
    mf = re.search(r"([零壹贰叁肆伍陆柒捌玖])分", rest)
    if mj:
        jiao = _DIGIT_MAP[mj.group(1)]
    if mf:
        fen = _DIGIT_MAP[mf.group(1)]
    return money(Decimal(yuan) + Decimal(jiao) / 10 + Decimal(fen) / 100)
