"""报销核对引擎：批量解析 → 去重 → 金额勾稽 → 完整性检查 → 制度标准校验 → 分类汇总 → 生成报销单与核对报告。"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import re
import shutil
import sqlite3
import time
from decimal import Decimal
from pathlib import Path
from typing import Any

import yaml

from .amounts import amount_to_chinese, fmt_money, money
from .extract import SUPPORTED_EXTS, extract_text
from .parse import INVOICE_TYPES, parse_document

DEFAULT_PORTAL_URL = "https://znfti.lczyun.com/lczPortal/home"

DEFAULT_POLICY: dict[str, Any] = {
    "company_name": "",            # 发票抬头应为的单位全称（为空则只做提示不做强校验）
    "company_tax_id": "",          # 单位统一社会信用代码
    "portal_url": DEFAULT_PORTAL_URL,
    "hotel_cap_per_night": 500,    # 住宿标准（元/晚）
    "meal_cap_per_invoice": 800,   # 单张餐饮发票提示阈值
    "large_amount_threshold": 5000,  # 单张大额发票阈值（需附合同/审批）
    "max_invoice_age_days": 365,   # 发票时效
    "date_tolerance_days": 3,      # 票据日期相对出差期间允许的偏差天数
    "require_taxi_itinerary": True,  # 网约车/出租车发票必须附行程单
    "require_hotel_folio": False,    # 住宿发票是否必须附水单
    "require_travel_approval": True,  # 差旅费是否需要出差审批单
}

SEVERITY_LABEL = {"error": "❌ 必须处理", "warning": "⚠️ 需人工确认", "info": "ℹ️ 提示"}


def load_policy(workspace: Path, overrides: dict[str, Any] | None = None) -> dict[str, Any]:
    pol = dict(DEFAULT_POLICY)
    p = workspace / ".omniagent" / "expense_policy.yaml"
    if p.is_file():
        try:
            pol.update(yaml.safe_load(p.read_text(encoding="utf-8")) or {})
        except yaml.YAMLError:
            pass
    for k, v in (overrides or {}).items():
        if v not in (None, ""):
            pol[k] = v
    return pol


def save_policy(workspace: Path, updates: dict[str, Any]) -> dict[str, Any]:
    pol = load_policy(workspace)
    for k, v in updates.items():
        if k in DEFAULT_POLICY and v is not None:
            pol[k] = v
    p = workspace / ".omniagent" / "expense_policy.yaml"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(yaml.safe_dump(pol, allow_unicode=True, sort_keys=False), encoding="utf-8")
    return pol


# ------------------------------------------------------------------ 防重复报销台账
class ExpenseLedger:
    def __init__(self, db_path: Path):
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(db_path))
        self.conn.execute("""CREATE TABLE IF NOT EXISTS invoices(
            invoice_no TEXT, batch_id TEXT, amount TEXT, file TEXT, status TEXT, ts REAL,
            PRIMARY KEY(invoice_no, batch_id))""")
        self.conn.execute("""CREATE TABLE IF NOT EXISTS batches(
            batch_id TEXT PRIMARY KEY, claimant TEXT, total TEXT, status TEXT, out_dir TEXT, ts REAL, note TEXT)""")
        self.conn.commit()

    def history(self, invoice_no: str, exclude_batch: str) -> list[dict[str, Any]]:
        cur = self.conn.execute(
            "SELECT batch_id, status, ts, file FROM invoices WHERE invoice_no=? AND batch_id<>? ORDER BY ts",
            (invoice_no, exclude_batch))
        return [{"batch_id": r[0], "status": r[1], "ts": r[2], "file": r[3]} for r in cur.fetchall()]

    def record_batch(self, batch_id: str, claimant: str, total: str, out_dir: str, items: list[dict[str, Any]]) -> None:
        now = time.time()
        self.conn.execute("INSERT OR REPLACE INTO batches VALUES(?,?,?,?,?,?,?)",
                          (batch_id, claimant, total, "analyzed", out_dir, now, ""))
        for it in items:
            if it.get("invoice_no"):
                self.conn.execute("INSERT OR REPLACE INTO invoices VALUES(?,?,?,?,?,?)",
                                  (it["invoice_no"], batch_id, str(it.get("total") or ""), it["file"], "analyzed", now))
        self.conn.commit()

    def mark(self, batch_id: str, status: str, note: str = "") -> int:
        self.conn.execute("UPDATE batches SET status=?, note=? WHERE batch_id=?", (status, note, batch_id))
        n = self.conn.execute("UPDATE invoices SET status=? WHERE batch_id=?", (status, batch_id)).rowcount
        self.conn.commit()
        return n

    def batches(self, limit: int = 20) -> list[dict[str, Any]]:
        cur = self.conn.execute("SELECT batch_id, claimant, total, status, out_dir, ts, note FROM batches ORDER BY ts DESC LIMIT ?",
                                (limit,))
        keys = ["batch_id", "claimant", "total", "status", "out_dir", "ts", "note"]
        return [dict(zip(keys, r)) for r in cur.fetchall()]

    def close(self) -> None:
        self.conn.close()


# ------------------------------------------------------------------ 主流程
def collect_files(paths: list[Path]) -> tuple[list[Path], list[str]]:
    files: list[Path] = []
    skipped: list[str] = []
    for p in paths:
        if p.is_dir():
            for f in sorted(p.rglob("*")):
                if f.is_file() and not f.name.startswith((".", "~$")):
                    if f.suffix.lower() in SUPPORTED_EXTS:
                        files.append(f)
                    else:
                        skipped.append(f.name)
        elif p.is_file():
            if p.suffix.lower() in SUPPORTED_EXTS:
                files.append(p)
            else:
                skipped.append(p.name)
        else:
            skipped.append(f"{p}（不存在）")
    uniq: list[Path] = []
    seen: set[str] = set()
    for f in files:
        k = str(f.resolve())
        if k not in seen:
            seen.add(k)
            uniq.append(f)
    return uniq, skipped


def _sha1(p: Path) -> str:
    h = hashlib.sha1()
    with p.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def _d(s: str | None) -> dt.date | None:
    try:
        return dt.date.fromisoformat(str(s)[:10]) if s else None
    except ValueError:
        return None


def _norm_name(s: str) -> str:
    return re.sub(r"[\s（）()·\-]", "", s or "")


def _apply_override(doc: dict[str, Any], ov: dict[str, Any]) -> None:
    """智能体人工复核后的更正：可改票据类型、费用类别、任意字段（如 total / invoice_no / date / buyer_name）。"""
    from .amounts import money as _money
    from .parse import DOC_LABELS

    if ov.get("doc_type") in DOC_LABELS:
        doc["doc_type"] = ov["doc_type"]
        doc["doc_label"] = DOC_LABELS[ov["doc_type"]]
    if ov.get("category"):
        doc["category"] = str(ov["category"])
    for k, v in (ov.get("fields") or {}).items():
        if k in ("total", "amount_ex_tax", "tax", "deductible_tax", "total_in_words_value", "fare", "fuel", "fund", "budget"):
            doc["fields"][k] = _money(v) if v not in (None, "") else None
        else:
            doc["fields"][k] = v
    doc["confidence"] = "manual"
    doc["corrected"] = True
    doc["correction_note"] = str(ov.get("note") or "智能体复核原件后更正")


def _match_override(name: str, file_rel: str, overrides: dict[str, Any]) -> dict[str, Any] | None:
    for key, ov in (overrides or {}).items():
        k = str(key).strip()
        if k and (k == name or k == file_rel or file_rel.endswith("/" + k) or Path(k).name == name):
            return ov if isinstance(ov, dict) else None
    return None


def analyze_claim(files: list[Path], *, workspace: Path, out_dir: Path, info: dict[str, Any] | None = None,
                  policy: dict[str, Any] | None = None, rel=lambda p: str(p), progress=None,
                  overrides: dict[str, Any] | None = None, exclude: list[str] | None = None,
                  manual_items: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    info = dict(info or {})
    exclude_set = {str(x).strip() for x in (exclude or []) if str(x).strip()}
    policy = dict(policy or DEFAULT_POLICY)
    out_dir.mkdir(parents=True, exist_ok=True)
    batch_id = out_dir.name
    issues: list[dict[str, Any]] = []

    def issue(sev: str, title: str, detail: str, file: str = "", fix: str = ""):
        issues.append({"severity": sev, "title": title, "detail": detail, "file": file, "fix": fix})

    # 1) 逐个解析
    docs: list[dict[str, Any]] = []
    hashes: dict[str, str] = {}
    for i, f in enumerate(files, 1):
        if f.name in exclude_set or rel(f) in exclude_set:
            continue
        if progress:
            progress(i, len(files), f.name)
        ex = extract_text(f)
        doc = parse_document(f.name, ex)
        doc["file"] = rel(f)
        doc["name"] = f.name
        ov = _match_override(f.name, doc["file"], overrides or {})
        if ov:
            _apply_override(doc, ov)
        h = _sha1(f)
        if h in hashes:
            issue("warning", "重复上传同一文件", f"`{f.name}` 与 `{hashes[h]}` 内容完全相同，已从合计中剔除。", rel(f), "删除重复文件")
            doc["duplicate_of"] = hashes[h]
        else:
            hashes[h] = f.name
        if doc["confidence"] == "none":
            hint = "（未能读取到任何文字：可能是加密 PDF、损坏文件或 OCR 不可用）"
            issue("error", "票据无法识别", f"`{f.name}` 无法提取文字{hint}。", rel(f), "请上传清晰的电子原件（PDF/OFD/XML）或高清照片")
        elif doc["confidence"] == "low":
            issue("warning", "关键字段识别不完整", f"`{f.name}` 被识别为「{doc['doc_label']}」，但发票号码或金额未完整识别，请人工核对。",
                  rel(f), "可由智能体用 view_image 查看原件后手工补录")
        docs.append(doc)
    # 智能体手工补录（如：OCR 失败后用 view_image 阅读原件、纸质票据照片、用户口述的无票费用）
    for j, mi in enumerate(manual_items or [], 1):
        from .parse import DOC_LABELS

        dtp = mi.get("doc_type") if mi.get("doc_type") in DOC_LABELS else "vat_invoice"
        fields = {k: v for k, v in mi.items() if k not in ("doc_type", "category", "file", "note")}
        doc = {"doc_type": dtp, "doc_label": DOC_LABELS[dtp], "category": str(mi.get("category") or ""),
               "fields": {}, "confidence": "manual", "text_excerpt": "", "method": "manual", "pages": 1,
               "file": str(mi.get("file") or f"(手工补录#{j})"), "name": Path(str(mi.get("file") or f"手工补录{j}")).name,
               "corrected": True, "correction_note": str(mi.get("note") or "智能体手工补录")}
        _apply_override(doc, {"fields": fields})
        doc["confidence"] = "manual"
        docs.append(doc)
        issue("info", "手工补录票据", f"`{doc['name']}`：{doc['correction_note']}（{DOC_LABELS[dtp]}，金额 {fields.get('total')}）。", doc["file"],
              "请人工核对原件")
    for d in docs:
        if d.get("corrected") and d["method"] != "manual":
            issue("info", "已按复核结果更正识别字段", f"`{d['name']}`：{d.get('correction_note')}", d["file"])

    invoices = [d for d in docs if d["doc_type"] in INVOICE_TYPES and not d.get("duplicate_of")]
    supports = [d for d in docs if d["doc_type"] not in INVOICE_TYPES and not d.get("duplicate_of")]

    # 2) 发票级勾稽与合规检查
    company = _norm_name(policy.get("company_name") or info.get("company_name") or "")
    company_tax = (policy.get("company_tax_id") or info.get("company_tax_id") or "").strip().upper()
    seen_no: dict[str, str] = {}
    today = dt.date.today()
    ledger = ExpenseLedger(workspace / ".omniagent" / "expense_ledger.db")
    items: list[dict[str, Any]] = []
    try:
        for d in invoices:
            f = d["fields"]
            no = str(f.get("invoice_no") or "")
            total = f.get("total")
            item = {
                "file": d["file"], "name": d["name"], "doc_type": d["doc_type"], "doc_label": d["doc_label"],
                "category": d["category"] or "其他费用", "invoice_no": no, "invoice_kind": f.get("invoice_kind", ""),
                "date": f.get("travel_date") or f.get("date") or "", "seller": f.get("seller_name", ""),
                "buyer": f.get("buyer_name", ""), "items": "、".join(f.get("items") or [])[:80],
                "amount_ex_tax": f.get("amount_ex_tax"), "tax": f.get("tax"), "total": total,
                "tax_rate": f.get("tax_rate", ""), "deductible_tax": f.get("deductible_tax"),
                "checks": [], "status": "通过",
            }
            if d["doc_type"] == "vat_invoice" and f.get("is_special") and f.get("tax") is not None:
                item["deductible_tax"] = f["tax"]
            if item["deductible_tax"] is None and d["doc_type"] == "vat_invoice" and item["category"] == "市内交通费" \
                    and f.get("tax") is not None:
                item["deductible_tax"] = f["tax"]  # 旅客运输服务普票可按规定抵扣
            # 重复发票号
            if no:
                if no in seen_no:
                    issue("error", "发票号码重复", f"发票号码 {no} 同时出现在 `{seen_no[no]}` 与 `{d['name']}`，存在重复报销风险，已剔除后者。",
                          d["file"], "删除重复票据")
                    item["status"] = "重复剔除"
                    item["excluded"] = True
                else:
                    seen_no[no] = d["name"]
                    for hrec in ledger.history(no, batch_id):
                        when = dt.datetime.fromtimestamp(hrec["ts"]).strftime("%Y-%m-%d")
                        if hrec["status"] == "submitted":
                            issue("error", "发票已报销过", f"发票号码 {no} 已于 {when} 在报销批次 `{hrec['batch_id']}` 中提交，禁止重复报销。",
                                  d["file"], "剔除该发票")
                            item["status"] = "历史已报销"
                            item["excluded"] = True
                        else:
                            issue("info", "发票曾被核对过", f"发票号码 {no} 曾在 {when} 的批次 `{hrec['batch_id']}` 中核对（未标记提交）。", d["file"])
            # 金额勾稽
            if total is None:
                item["checks"].append("未识别价税合计")
                item["status"] = "待人工核对"
            else:
                if f.get("amount_ex_tax") is not None and f.get("tax") is not None:
                    calc = money(f["amount_ex_tax"] + f["tax"])
                    ok = abs(calc - money(total)) <= Decimal("0.01")
                    item["checks"].append(f"金额 {fmt_money(f['amount_ex_tax'])} + 税额 {fmt_money(f['tax'])} = {fmt_money(calc)}"
                                          + (" ✓" if ok else f" ≠ 价税合计 {fmt_money(total)} ✗"))
                    if not ok and d["doc_type"] == "vat_invoice":
                        issue("error", "金额与税额勾稽不符", f"`{d['name']}`：不含税金额 + 税额 = {fmt_money(calc)}，与价税合计 {fmt_money(total)} 不一致。",
                              d["file"], "核对发票真伪或重新识别")
                        item["status"] = "金额异常"
                if f.get("total_in_words_value") is not None:
                    okw = money(f["total_in_words_value"]) == money(total)
                    item["checks"].append(f"大写「{f.get('total_in_words')}」{'= 小写 ✓' if okw else '≠ 小写 ✗'}")
                    if not okw:
                        issue("error", "大小写金额不一致", f"`{d['name']}`：大写金额 {fmt_money(f['total_in_words_value'])} 与小写 {fmt_money(total)} 不一致。",
                              d["file"], "疑似票据异常，请核验")
                        item["status"] = "金额异常"
                if money(total) <= 0:
                    issue("error", "金额为零或负数", f"`{d['name']}` 价税合计为 {fmt_money(total)}（红字发票？）。", d["file"])
                if money(total) >= Decimal(str(policy.get("large_amount_threshold") or 5000)):
                    issue("info", "单张大额票据", f"`{d['name']}` 金额 {fmt_money(total)} 元，超过大额阈值，建议附合同/审批/验收单。", d["file"])
            # 抬头与税号
            if d["doc_type"] == "vat_invoice":
                buyer = _norm_name(f.get("buyer_name", ""))
                if company and buyer and company != buyer:
                    issue("error", "发票抬头不符", f"`{d['name']}` 购买方为「{f.get('buyer_name')}」，与单位名称「{policy.get('company_name') or info.get('company_name')}」不一致。",
                          d["file"], "联系商家重开发票")
                    item["status"] = "抬头不符"
                elif not buyer:
                    item["checks"].append("未识别购买方名称")
                if company_tax and f.get("buyer_tax_id") and f["buyer_tax_id"].upper() != company_tax:
                    issue("error", "购买方税号不符", f"`{d['name']}` 购买方税号 {f['buyer_tax_id']} ≠ 单位税号 {company_tax}。", d["file"], "联系商家重开发票")
                    item["status"] = "税号不符"
                if not company and buyer:
                    item["checks"].append(f"抬头：{f.get('buyer_name')}")
            # 日期
            idate = _d(item["date"])
            if idate:
                if idate > today:
                    issue("error", "票据日期晚于今天", f"`{d['name']}` 日期为 {idate}。", d["file"])
                elif (today - idate).days > int(policy.get("max_invoice_age_days") or 365):
                    issue("warning", "票据超过报销时效", f"`{d['name']}` 开具于 {idate}，已超过 {policy.get('max_invoice_age_days')} 天。", d["file"],
                          "按单位制度确认是否可报")
            else:
                item["checks"].append("未识别日期")
            # 制度标准
            if item["category"] == "餐饮费" and total is not None and money(total) > Decimal(str(policy.get("meal_cap_per_invoice") or 800)):
                issue("warning", "餐饮费超提示阈值", f"`{d['name']}` 餐饮费 {fmt_money(total)} 元，需补充招待事由、人数与审批。", d["file"])
            if item["category"] == "餐饮费":
                item["checks"].append("需补充招待对象/人数/事由")
            items.append(item)

        # 3) 差旅期间
        period_s = _d(info.get("trip_start"))
        period_e = _d(info.get("trip_end"))
        approvals = [s for s in supports if s["doc_type"] == "approval_form"]
        for a in approvals:
            af = a["fields"]
            period_s = period_s or _d(af.get("period_start"))
            period_e = period_e or _d(af.get("period_end"))
            if not af.get("approved"):
                issue("warning", "审批单未显示审批通过", f"`{a['name']}` 中未找到“已通过/同意”等审批结论。", a["file"])
        tol = dt.timedelta(days=int(policy.get("date_tolerance_days") or 3))
        if period_s and period_e:
            for it in items:
                idate = _d(it["date"])
                if idate and it["category"] in ("住宿费", "城际交通费", "市内交通费", "餐饮费") and \
                        not (period_s - tol <= idate <= period_e + tol):
                    issue("warning", "票据日期不在出差期间", f"`{it['name']}` 日期 {idate} 不在出差期间 {period_s} ~ {period_e}（±{tol.days} 天）内。",
                          it["file"], "确认是否属于本次出差")

        active = [it for it in items if not it.get("excluded")]
        cats = {it["category"] for it in active}
        travel = bool(cats & {"住宿费", "城际交通费"})
        if travel and policy.get("require_travel_approval") and not approvals and not info.get("approval_no"):
            issue("warning", "缺少出差审批单", "本次包含差旅费用（住宿/城际交通），但未提供出差审批单或审批编号。", "",
                  "上传审批单截图/PDF，或在报销信息中填写审批编号")

        # 4) 附件完整性：网约车/出租车
        taxi_inv = [it for it in active if it["category"] == "市内交通费" and it["doc_type"] == "vat_invoice"]
        taxi_iti = [s for s in supports if s["doc_type"] == "taxi_itinerary"]
        if taxi_inv:
            inv_sum = money(sum((it["total"] or 0) for it in taxi_inv))
            iti_sum = money(sum((s["fields"].get("total") or 0) for s in taxi_iti))
            if not taxi_iti and policy.get("require_taxi_itinerary", True):
                issue("error", "缺少打车行程单", f"有 {len(taxi_inv)} 张网约车/出租车发票（合计 {fmt_money(inv_sum)} 元），但未附行程单。", "",
                      "在打车平台导出与发票对应的行程单 PDF 一并上传")
            elif taxi_iti and inv_sum != iti_sum:
                issue("warning", "发票与行程单金额不一致", f"网约车发票合计 {fmt_money(inv_sum)} 元，行程单合计 {fmt_money(iti_sum)} 元，差额 {fmt_money(inv_sum - iti_sum)} 元。",
                      "", "核对是否漏传或多传行程单/发票")
        # 5) 住宿：水单与标准
        hotel_inv = [it for it in active if it["category"] == "住宿费"]
        folios = [s for s in supports if s["doc_type"] == "hotel_folio"]
        cap = Decimal(str(policy.get("hotel_cap_per_night") or 0))
        if hotel_inv and not folios:
            issue("error" if policy.get("require_hotel_folio") else "info", "未附酒店水单",
                  f"有 {len(hotel_inv)} 张住宿发票，但未附酒店结账水单（入住/离店明细）。", "", "向酒店索取水单")
        nights_folio = sum(int(s["fields"].get("nights") or 0) for s in folios)
        hotel_sum = money(sum((it["total"] or 0) for it in hotel_inv))
        nights_inv = 0.0
        for d in invoices:
            if d["category"] == "住宿费" and d["fields"].get("nights"):
                nights_inv += float(d["fields"]["nights"])
        nights = nights_folio or nights_inv
        if not nights and period_s and period_e and hotel_inv:
            nights = max(1, (period_e - period_s).days)
        if hotel_inv and nights and cap:
            per = money(hotel_sum / Decimal(str(nights)))
            if per > cap:
                issue("warning", "住宿费超标准", f"住宿 {fmt_money(hotel_sum)} 元 / {nights:g} 晚 = {fmt_money(per)} 元/晚，超过标准 {fmt_money(cap)} 元/晚。",
                      "", "超标部分需自理或补充特批说明")
        if folios and hotel_inv:
            folio_sum = money(sum((s["fields"].get("total") or 0) for s in folios))
            if folio_sum and folio_sum != hotel_sum:
                issue("warning", "水单与住宿发票金额不一致", f"水单合计 {fmt_money(folio_sum)} 元，住宿发票合计 {fmt_money(hotel_sum)} 元。", "",
                      "核对是否含押金、迷你吧等非报销项目")
        # 6) 支付凭证匹配
        pays = [s for s in supports if s["doc_type"] == "payment_record"]
        for p in pays:
            amt = p["fields"].get("total")
            if amt is not None and not any(it["total"] is not None and money(it["total"]) == money(amt) for it in active):
                issue("info", "支付凭证未匹配到发票", f"`{p['name']}` 支付金额 {fmt_money(amt)} 元，未找到金额相同的发票。", p["file"])
        # 7) 用户申报金额对账
        claimed = None
        lists = [s for s in supports if s["doc_type"] == "expense_list" and s["fields"].get("total") is not None]
        if info.get("claimed_total") not in (None, ""):
            claimed = money(info["claimed_total"])
        elif lists:
            claimed = money(sum(s["fields"]["total"] for s in lists))
        for o in supports:
            if o["doc_type"] == "other":
                issue("info", "未识别类型的材料", f"`{o['name']}` 未能识别为票据或常见附件，将作为其他附件随单提交。", o["file"])

        # 8) 汇总
        summary_by_cat: dict[str, dict[str, Any]] = {}
        for it in active:
            c = summary_by_cat.setdefault(it["category"], {"count": 0, "total": Decimal(0), "tax": Decimal(0), "deductible": Decimal(0)})
            c["count"] += 1
            c["total"] += money(it["total"] or 0)
            c["tax"] += money(it["tax"] or 0)
            c["deductible"] += money(it["deductible_tax"] or 0)
        grand = money(sum(c["total"] for c in summary_by_cat.values()))
        tax_sum = money(sum(c["tax"] for c in summary_by_cat.values()))
        deductible = money(sum(c["deductible"] for c in summary_by_cat.values()))
        recon = None
        if claimed is not None:
            diff = money(claimed - grand)
            recon = {"claimed": claimed, "computed": grand, "diff": diff}
            if diff != 0:
                issue("warning" if abs(diff) < Decimal("1") else "error", "申报金额与票据合计不符",
                      f"申报金额 {fmt_money(claimed)} 元，票据核定合计 {fmt_money(grand)} 元，差额 {fmt_money(diff)} 元。", "",
                      "以票据核定金额为准，或补充缺失票据")
        n_err = sum(1 for x in issues if x["severity"] == "error")
        n_warn = sum(1 for x in issues if x["severity"] == "warning")
        if n_err:
            verdict = f"暂不可提交：存在 {n_err} 项必须处理的问题" + (f"、{n_warn} 项需人工确认" if n_warn else "")
            status = "blocked"
        elif n_warn:
            verdict = f"可提交，但需人工确认 {n_warn} 项"
            status = "review"
        else:
            verdict = "核对通过，材料齐全、金额勾稽一致，可以提交"
            status = "pass"

        # 9) 附件整理（按序号重命名）
        att_dir = out_dir / "附件"
        att_dir.mkdir(exist_ok=True)
        attachments: list[str] = []
        order = sorted([d for d in docs if not d.get("duplicate_of")],
                       key=lambda d: (0 if d["doc_type"] in INVOICE_TYPES else 1, d.get("category") or "", d["name"]))
        for idx, d in enumerate(order, 1):
            src = workspace / d["file"] if not Path(d["file"]).is_absolute() else Path(d["file"])
            amt = d["fields"].get("total")
            amt_s = f"_{fmt_money(amt).replace(',', '')}元" if amt is not None else ""
            cat = d.get("category") or d["doc_label"]
            no = d["fields"].get("invoice_no")
            stem = re.sub(r"[\\/:*?\"<>|\s]+", "", f"{idx:02d}_{cat}{amt_s}_{d['doc_label']}{'_' + str(no)[-8:] if no else ''}")
            dst = att_dir / f"{stem}{Path(d['name']).suffix.lower()}"
            try:
                shutil.copy2(src, dst)
                attachments.append(rel(dst))
                d["attachment"] = rel(dst)
            except OSError:
                pass

        result: dict[str, Any] = {
            "batch_id": batch_id,
            "generated_at": dt.datetime.now().strftime("%Y-%m-%d %H:%M"),
            "info": info,
            "policy": policy,
            "docs": docs,
            "items": items,
            "summary_by_category": summary_by_cat,
            "grand_total": grand,
            "grand_total_words": amount_to_chinese(grand),
            "tax_total": tax_sum,
            "deductible_total": deductible,
            "invoice_count": len(active),
            "attachment_count": len(attachments),
            "reconciliation": recon,
            "issues": issues,
            "verdict": verdict,
            "status": status,
            "period": [period_s.isoformat() if period_s else "", period_e.isoformat() if period_e else ""],
            "attachments": attachments,
        }
        ledger.record_batch(batch_id, str(info.get("claimant") or ""), str(grand), rel(out_dir), active)
    finally:
        ledger.close()

    from .reports import write_outputs

    result["outputs"] = write_outputs(result, out_dir, rel)
    return result


def to_jsonable(o: Any) -> Any:
    if isinstance(o, Decimal):
        return float(o)
    if isinstance(o, dict):
        return {k: to_jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [to_jsonable(v) for v in o]
    return o


def dump_json(o: Any) -> str:
    return json.dumps(to_jsonable(o), ensure_ascii=False, indent=2)
