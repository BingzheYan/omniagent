"""OmniAgent 电脑桌面端（Native Desktop App）。

架构：
1. 在后台线程启动内嵌的本地 FastAPI/Uvicorn 服务（自动分配空闲端口 + 一次性本机安全令牌免密登录）；
2. 在 macOS 上优先使用原生编译的 Cocoa + WKWebView 桌面窗口（支持原生菜单栏、快捷键复制粘贴、原生 Finder 文件选择框、深色标题栏）；
   在其他系统（Windows/Linux）自动依次回退到 pywebview 原生窗口 → Chrome/Edge 独立 App 窗口 (--app=) → 系统窗口；
3. 支持 `omni desktop --build-app` 一键生成可双击运行的 macOS `dist/OmniAgent.app` 应用包。
"""
from __future__ import annotations

import json
import os
import platform
import secrets
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.request
from pathlib import Path

from omniagent import __version__
from omniagent.config import Settings

SWIFT_WEBVIEW_SOURCE = r'''
import Cocoa
import WebKit

class AppDelegate: NSObject, NSApplicationDelegate, WKUIDelegate, WKNavigationDelegate {
    var window: NSWindow!
    var webView: WKWebView!
    let startURL: String

    init(url: String) {
        self.startURL = url
    }

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.appearance = NSAppearance(named: .darkAqua)
        setupMenu()

        let cfg = WKWebViewConfiguration()
        cfg.preferences.setValue(true, forKey: "developerExtrasEnabled")

        let rect = NSRect(x: 0, y: 0, width: 1440, height: 920)
        window = NSWindow(
            contentRect: rect,
            styleMask: [.titled, .closable, .miniaturizable, .resizable, .fullSizeContentView],
            backing: .buffered,
            defer: false
        )
        window.title = "OmniAgent · 自主执行型 AI 智能体工作台"
        window.titlebarAppearsTransparent = false
        window.minSize = NSSize(width: 960, height: 640)
        window.center()

        webView = WKWebView(frame: rect, configuration: cfg)
        webView.autoresizingMask = [.width, .height]
        webView.uiDelegate = self
        webView.navigationDelegate = self
        window.contentView = webView
        window.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)

        if let u = URL(string: startURL) {
            webView.load(URLRequest(url: u))
        }
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        return true
    }

    // 支持 HTML <input type="file"> 调起 macOS 原生文件选择器
    func webView(_ webView: WKWebView,
                 runOpenPanelWith parameters: WKOpenPanelParameters,
                 initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping ([URL]?) -> Void) {
        let panel = NSOpenPanel()
        panel.canChooseFiles = true
        panel.canChooseDirectories = parameters.allowsDirectories
        panel.allowsMultipleSelection = parameters.allowsMultipleSelection
        panel.beginSheetModal(for: window) { result in
            completionHandler(result == .OK ? panel.urls : nil)
        }
    }

    func webView(_ webView: WKWebView,
                 runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping () -> Void) {
        let alert = NSAlert()
        alert.messageText = "OmniAgent"
        alert.informativeText = message
        alert.runModal()
        completionHandler()
    }

    func webView(_ webView: WKWebView,
                 runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping (Bool) -> Void) {
        let alert = NSAlert()
        alert.messageText = "确认操作"
        alert.informativeText = message
        alert.addButton(withTitle: "确定")
        alert.addButton(withTitle: "取消")
        completionHandler(alert.runModal() == .alertFirstButtonReturn)
    }

    private func setupMenu() {
        let mainMenu = NSMenu()
        NSApp.mainMenu = mainMenu

        let appItem = NSMenuItem()
        mainMenu.addItem(appItem)
        let appMenu = NSMenu()
        appItem.submenu = appMenu
        appMenu.addItem(withTitle: "关于 OmniAgent", action: #selector(NSApplication.orderFrontStandardAboutPanel(_:)), keyEquivalent: "")
        appMenu.addItem(NSMenuItem.separator())
        appMenu.addItem(withTitle: "刷新页面", action: #selector(reloadPage), keyEquivalent: "r")
        appMenu.addItem(NSMenuItem.separator())
        appMenu.addItem(withTitle: "退出 OmniAgent", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")

        let editItem = NSMenuItem()
        mainMenu.addItem(editItem)
        let editMenu = NSMenu(title: "编辑")
        editItem.submenu = editMenu
        editMenu.addItem(withTitle: "撤销", action: Selector(("undo:")), keyEquivalent: "z")
        editMenu.addItem(withTitle: "重做", action: Selector(("redo:")), keyEquivalent: "Z")
        editMenu.addItem(NSMenuItem.separator())
        editMenu.addItem(withTitle: "剪切", action: #selector(NSText.cut(_:)), keyEquivalent: "x")
        editMenu.addItem(withTitle: "复制", action: #selector(NSText.copy(_:)), keyEquivalent: "c")
        editMenu.addItem(withTitle: "粘贴", action: #selector(NSText.paste(_:)), keyEquivalent: "v")
        editMenu.addItem(withTitle: "全选", action: #selector(NSText.selectAll(_:)), keyEquivalent: "a")
    }

    @objc func reloadPage() {
        webView.reload()
    }
}

let urlArg = CommandLine.arguments.count > 1 ? CommandLine.arguments[1] : "http://127.0.0.1:8765"
let app = NSApplication.shared
app.setActivationPolicy(.regular)
let delegate = AppDelegate(url: urlArg)
app.delegate = delegate
app.run()
'''


def _free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return int(s.getsockname()[1])


def ensure_macos_native_shell(cache_dir: Path | None = None, *, universal: bool = False) -> Path | None:
    """在 macOS 上编译轻量原生 WKWebView 桌面壳（仅首次编译约 2 秒，后续直接复用二进制）。"""
    if platform.system() != "Darwin":
        return None
    swiftc = shutil.which("swiftc")
    if not swiftc:
        return None
    target_dir = cache_dir or (Path.home() / ".omniagent" / "bin")
    target_dir.mkdir(parents=True, exist_ok=True)
    bin_path = target_dir / "OmniAgentDesktopShell"
    src_path = target_dir / "OmniAgentDesktopShell.swift"
    if not universal and bin_path.is_file() and src_path.is_file() and src_path.read_text(encoding="utf-8") == SWIFT_WEBVIEW_SOURCE:
        return bin_path
    src_path.write_text(SWIFT_WEBVIEW_SOURCE, encoding="utf-8")
    lipo = shutil.which("lipo")
    if universal and lipo:
        arm_bin = target_dir / "OmniAgentDesktopShell.arm64"
        x64_bin = target_dir / "OmniAgentDesktopShell.x86_64"
        r1 = subprocess.run(
            [swiftc, "-O", "-target", "arm64-apple-macos12.0", "-framework", "Cocoa", "-framework", "WebKit", str(src_path), "-o", str(arm_bin)],
            capture_output=True, text=True,
        )
        r2 = subprocess.run(
            [swiftc, "-O", "-target", "x86_64-apple-macos12.0", "-framework", "Cocoa", "-framework", "WebKit", str(src_path), "-o", str(x64_bin)],
            capture_output=True, text=True,
        )
        if r1.returncode == 0 and r2.returncode == 0:
            r3 = subprocess.run([lipo, "-create", str(arm_bin), str(x64_bin), "-output", str(bin_path)], capture_output=True, text=True)
            arm_bin.unlink(missing_ok=True)
            x64_bin.unlink(missing_ok=True)
            if r3.returncode == 0 and bin_path.is_file():
                src_path.unlink(missing_ok=True)
                return bin_path
        arm_bin.unlink(missing_ok=True)
        x64_bin.unlink(missing_ok=True)
    res = subprocess.run(
        [swiftc, "-O", "-framework", "Cocoa", "-framework", "WebKit", str(src_path), "-o", str(bin_path)],
        capture_output=True, text=True,
    )
    if res.returncode != 0 or not bin_path.is_file():
        return None
    return bin_path


def build_macos_app_bundle(output_dir: Path | str = "dist", *, portable: bool = False) -> Path:
    """构建标准 macOS 双击应用包 `OmniAgent.app`。"""
    out_root = Path(output_dir).expanduser().resolve()
    app_dir = out_root / "OmniAgent.app"
    contents = app_dir / "Contents"
    macos_dir = contents / "MacOS"
    res_dir = contents / "Resources"
    macos_dir.mkdir(parents=True, exist_ok=True)
    res_dir.mkdir(parents=True, exist_ok=True)

    # 编译原生窗口二进制进入 App Bundle（优先构建 Apple Silicon + Intel 通用二进制）
    shell_bin = ensure_macos_native_shell(macos_dir, universal=True)

    project_root = Path(__file__).resolve().parent.parent
    fallback_root = "$HOME/Applications/OmniAgent" if portable else str(project_root)
    launcher = macos_dir / "OmniAgent"
    launcher.write_text(
        f"""#!/bin/bash
set -e
export PATH="/opt/homebrew/bin:/usr/local/bin:$HOME/.local/bin:$PATH"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
APP_DIR="${{SCRIPT_DIR%/Contents/MacOS}}"
APP_PARENT="${{APP_DIR%/*}}"
ROOT=""
for cand in "$APP_PARENT" "${{APP_PARENT%/*}}"; do
  if [ -n "$cand" ] && [ "$cand" != "/" ]; then
    if [ -d "$cand/omniagent" ] 2>/dev/null || [ -f "$cand/启动桌面端.command" ] 2>/dev/null || [ -f "$cand/scripts/mac_bootstrap.sh" ] 2>/dev/null; then
      ROOT="$cand"
      break
    fi
  fi
done
if [ -z "$ROOT" ]; then
  if [ "$(basename "$APP_PARENT")" = "dist" ]; then
    ROOT="${{APP_PARENT%/*}}"
  elif [ "$APP_PARENT" != "/Applications" ] && [ "$APP_PARENT" != "$HOME/Applications" ]; then
    ROOT="$APP_PARENT"
  else
    ROOT="{fallback_root}"
  fi
fi
unset ANTHROPIC_AUTH_TOKEN ANTHROPIC_API_KEY ANTHROPIC_BASE_URL
export PYTHONUTF8=1
export PYTHONIOENCODING=utf-8
export OMNIAGENT_NATIVE_SHELL="$SCRIPT_DIR/OmniAgentDesktopShell"

# 检测当前进程是否拥有 ROOT 目录的实际文件读取权限（macOS 桌面/下载/文稿目录受 TCC 保护）
CAN_DIRECT=0
if [ -x "$ROOT/.venv/bin/python" ] && [ -w "$ROOT" ] 2>/dev/null; then
  if PYTHONPATH="$ROOT" "$ROOT/.venv/bin/python" -c "import omniagent" >/dev/null 2>&1; then
    CAN_DIRECT=1
  fi
fi

if [ "$CAN_DIRECT" -eq 1 ]; then
  cd "$ROOT"
  export PYTHONPATH="$ROOT${{PYTHONPATH:+:$PYTHONPATH}}"
  if [ -d "$ROOT/demo_data" ]; then
    exec "$ROOT/.venv/bin/python" -m omniagent desktop -m deepseek --data-dir "$ROOT/demo_data"
  else
    exec "$ROOT/.venv/bin/python" -m omniagent desktop -m deepseek
  fi
fi

osascript - "$ROOT" <<'APPLESCRIPT'
on run argv
  set rootPath to item 1 of argv
  set shCmd to "cd " & quoted form of rootPath & " && if [ -f ./启动桌面端.command ]; then bash ./启动桌面端.command; elif [ -f ./scripts/mac_bootstrap.sh ]; then bash ./scripts/mac_bootstrap.sh desktop --detach; fi"
  tell application "Terminal"
    activate
    do script shCmd
  end tell
end run
APPLESCRIPT
exit 0
""",
        encoding="utf-8",
    )
    os.chmod(launcher, 0o755)

    plist = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleName</key><string>OmniAgent</string>
    <key>CFBundleDisplayName</key><string>OmniAgent</string>
    <key>CFBundleIdentifier</key><string>ai.omniagent.desktop</string>
    <key>CFBundleVersion</key><string>{__version__}</string>
    <key>CFBundleShortVersionString</key><string>{__version__}</string>
    <key>CFBundlePackageType</key><string>APPL</string>
    <key>CFBundleExecutable</key><string>OmniAgent</string>
    <key>NSHighResolutionCapable</key><true/>
    <key>NSDesktopFolderUsageDescription</key><string>OmniAgent 需要访问桌面目录以加载运行环境与工作区文件。</string>
    <key>NSDocumentsFolderUsageDescription</key><string>OmniAgent 需要访问文稿目录以读写工作区文件。</string>
    <key>NSDownloadsFolderUsageDescription</key><string>OmniAgent 需要访问下载目录以加载运行环境与工作区文件。</string>
    <key>NSAppTransportSecurity</key>
    <dict><key>NSAllowsLocalNetworking</key><true/></dict>
</dict>
</plist>
"""
    (contents / "Info.plist").write_text(plist, encoding="utf-8")
    if shell_bin:
        os.chmod(shell_bin, 0o755)
    codesign = shutil.which("codesign")
    if platform.system() == "Darwin" and codesign:
        subprocess.run([codesign, "--force", "--deep", "--sign", "-", str(app_dir)], capture_output=True, text=True)
    return app_dir


def build_windows_app_bundle(output_dir: Path | str = "dist", *, portable: bool = False) -> Path:
    """构建 Windows 可双击无黑框启动的桌面应用启动器（OmniAgent.vbs + OmniAgent.bat）。"""
    out_root = Path(output_dir).expanduser().resolve()
    out_root.mkdir(parents=True, exist_ok=True)
    project_root = Path(__file__).resolve().parent.parent
    fallback_win_root = r"%USERPROFILE%\Desktop\OmniAgent" if portable else str(project_root)

    bat_path = out_root / "OmniAgent.bat"
    bat_content = (
        "@echo off\r\n"
        "chcp 65001 >nul\r\n"
        "setlocal\r\n"
        "set \"SCRIPT_DIR=%~dp0\"\r\n"
        "set \"ROOT=%SCRIPT_DIR%..\"\r\n"
        "if not exist \"%ROOT%\\omniagent\\__init__.py\" set \"ROOT=" + fallback_win_root + "\"\r\n"
        "cd /d \"%ROOT%\"\r\n"
        "set ANTHROPIC_AUTH_TOKEN=\r\n"
        "set ANTHROPIC_API_KEY=\r\n"
        "set ANTHROPIC_BASE_URL=\r\n"
        "set PYTHONUTF8=1\r\n"
        "set PYTHONIOENCODING=utf-8\r\n"
        "if exist \"%ROOT%\\.venv\\Scripts\\python.exe\" (\r\n"
        "  set \"PY=%ROOT%\\.venv\\Scripts\\python.exe\"\r\n"
        ") else (\r\n"
        "  set \"PY=python\"\r\n"
        ")\r\n"
        "if exist \"%ROOT%\\demo_data\" (\r\n"
        "  \"%PY%\" -m omniagent desktop -m deepseek --data-dir \"%ROOT%\\demo_data\"\r\n"
        ") else (\r\n"
        "  \"%PY%\" -m omniagent desktop -m deepseek\r\n"
        ")\r\n"
    )
    bat_path.write_bytes(bat_content.encode("utf-8"))

    vbs_path = out_root / "OmniAgent.vbs"
    vbs_content = (
        'Set fso = CreateObject("Scripting.FileSystemObject")\r\n'
        'Set sh = CreateObject("WScript.Shell")\r\n'
        'dir = fso.GetParentFolderName(WScript.ScriptFullName)\r\n'
        'sh.Run """" & dir & "\\OmniAgent.bat""", 0, False\r\n'
    )
    vbs_path.write_bytes(vbs_content.encode("ascii"))
    return vbs_path


def build_desktop_app(output_dir: Path | str = "dist") -> Path:
    """按当前操作系统构建可双击运行的桌面启动包（macOS `.app` / Windows `.vbs`+`.bat`）。"""
    if platform.system() == "Windows":
        return build_windows_app_bundle(output_dir)
    return build_macos_app_bundle(output_dir)


def _wait_server(url: str, timeout: float = 15.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=1.0) as r:
                if r.status == 200:
                    return True
        except Exception:  # noqa: BLE001
            time.sleep(0.1)
    return False


def _find_chromium_app_browser() -> str | None:
    pf = os.environ.get("ProgramFiles", r"C:\Program Files")
    pfx86 = os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")
    local_app = os.environ.get("LOCALAPPDATA", "")
    for cand in (
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
        "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser",
        str(Path(pf) / "Google" / "Chrome" / "Application" / "chrome.exe"),
        str(Path(pfx86) / "Google" / "Chrome" / "Application" / "chrome.exe"),
        str(Path(local_app) / "Google" / "Chrome" / "Application" / "chrome.exe") if local_app else None,
        str(Path(pfx86) / "Microsoft" / "Edge" / "Application" / "msedge.exe"),
        str(Path(pf) / "Microsoft" / "Edge" / "Application" / "msedge.exe"),
        str(Path(pf) / "BraveSoftware" / "Brave-Browser" / "Application" / "brave.exe"),
        shutil.which("google-chrome"),
        shutil.which("chrome"),
        shutil.which("chromium"),
        shutil.which("msedge"),
    ):
        if cand and Path(cand).exists():
            return cand
    return None


def _resolve_macos_native_shell() -> Path | None:
    if platform.system() != "Darwin":
        return None
    project_root = Path(__file__).resolve().parent.parent
    env_shell = os.environ.get("OMNIAGENT_NATIVE_SHELL")
    candidates = [
        Path(env_shell) if env_shell else None,
        project_root / "OmniAgent.app" / "Contents" / "MacOS" / "OmniAgentDesktopShell",
        project_root / "dist" / "OmniAgent.app" / "Contents" / "MacOS" / "OmniAgentDesktopShell",
        Path(sys.executable).resolve().parent / "OmniAgentDesktopShell",
    ]
    for cand in candidates:
        if cand and cand.is_file():
            return cand
    return ensure_macos_native_shell()


def _write_ready_signal(url: str) -> None:
    ready_path = os.environ.get("OMNIAGENT_READY_FILE")
    if not ready_path:
        return
    try:
        p = Path(ready_path)
        tmp = p.with_suffix(".tmp")
        tmp.write_text(json.dumps({"ok": True, "url": url, "pid": os.getpid()}), encoding="utf-8")
        os.replace(tmp, p)
    except OSError:
        pass


def _spawn_detached_desktop(
    *,
    port: int,
    data_dir: str | Path | None,
    default_model: str | None,
    auto_login: bool,
) -> int:
    from rich.console import Console

    console = Console()
    log_dir = Path.home() / ".omniagent" / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "desktop.log"
    ready_file = log_dir / f"ready_{os.getpid()}_{secrets.token_hex(4)}.json"

    project_root = Path(__file__).resolve().parent.parent
    cmd = [sys.executable, "-m", "omniagent", "desktop"]
    if default_model:
        cmd += ["-m", str(default_model)]
    if port:
        cmd += ["--port", str(port)]
    if data_dir:
        cmd += ["--data-dir", str(Path(data_dir).expanduser().resolve())]
    if not auto_login:
        cmd.append("--no-auto-login")

    env = os.environ.copy()
    env["OMNIAGENT_DETACHED_CHILD"] = "1"
    env["OMNIAGENT_READY_FILE"] = str(ready_file)
    cur_pp = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = f"{project_root}{os.pathsep}{cur_pp}" if cur_pp else str(project_root)

    start_offset = log_file.stat().st_size if log_file.exists() else 0
    with open(log_file, "a", encoding="utf-8") as log_fh:
        proc = subprocess.Popen(
            cmd,
            cwd=os.getcwd(),
            env=env,
            stdin=subprocess.DEVNULL,
            stdout=log_fh,
            stderr=log_fh,
            start_new_session=True,
        )

    deadline = time.time() + 18.0
    while time.time() < deadline:
        if ready_file.is_file():
            try:
                info = json.loads(ready_file.read_text(encoding="utf-8"))
            except Exception:  # noqa: BLE001
                info = {"url": "http://127.0.0.1"}
            ready_file.unlink(missing_ok=True)
            console.print(
                f"[bold green]✔ OmniAgent 桌面端窗口已打开[/bold green] · 本地服务 {info.get('url', '')}\n"
                "[dim]（桌面端已在独立进程运行，此终端窗口可直接关闭）[/dim]"
            )
            return 0
        rc = proc.poll()
        if rc is not None:
            ready_file.unlink(missing_ok=True)
            err_tail = ""
            if log_file.exists():
                with open(log_file, "r", encoding="utf-8", errors="replace") as rf:
                    rf.seek(start_offset)
                    err_tail = rf.read().strip()
            console.print(f"[bold red]✖ OmniAgent 桌面端启动失败（退出码 {rc}）[/bold red]")
            if err_tail:
                console.print(err_tail)
            return rc or 1
        time.sleep(0.1)

    ready_file.unlink(missing_ok=True)
    console.print("[yellow]OmniAgent 桌面端正在后台继续初始化，请稍候查看应用窗口。[/yellow]")
    return 0


def launch_desktop(
    settings: Settings,
    *,
    port: int = 0,
    data_dir: str | Path | None = None,
    default_model: str | None = None,
    auto_login: bool = True,
    detach: bool = False,
) -> int:
    if detach and os.environ.get("OMNIAGENT_DETACHED_CHILD") != "1":
        return _spawn_detached_desktop(
            port=port,
            data_dir=data_dir,
            default_model=default_model,
            auto_login=auto_login,
        )

    import uvicorn
    from rich.console import Console

    from omniagent.web.server import create_app, default_data_dir

    # Windows pythonw.exe 无控制台模式下 stdout/stderr 可能为 None，重定向到日志避免 uvicorn/rich 报错
    if sys.stdout is None or sys.stderr is None:
        log_dir = Path.home() / ".omniagent" / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        fh = open(log_dir / "desktop.log", "a", encoding="utf-8")
        if sys.stdout is None:
            sys.stdout = fh
        if sys.stderr is None:
            sys.stderr = fh

    console = Console()
    actual_port = port or _free_port()
    d_dir = Path(data_dir) if data_dir else default_data_dir()
    desk_token = secrets.token_urlsafe(24) if auto_login else None
    app = create_app(d_dir, settings, default_model=default_model, desktop_token=desk_token)

    cfg = uvicorn.Config(app, host="127.0.0.1", port=actual_port, log_level="warning", log_config=None)
    server = uvicorn.Server(cfg)
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()

    base_url = f"http://127.0.0.1:{actual_port}"
    if not _wait_server(f"{base_url}/api/health"):
        console.print("[red]启动本地桌面后端服务超时[/red]")
        return 1

    entry_url = f"{base_url}/api/auth/desktop-login?token={desk_token}" if desk_token else base_url
    console.print(f"[bold cyan]OmniAgent 桌面端已启动[/bold cyan] · 本地服务 {base_url} · 数据目录 {d_dir}")

    # 1) macOS 原生 Cocoa WKWebView 桌面窗口
    native_shell = _resolve_macos_native_shell()
    if native_shell:
        try:
            proc = subprocess.Popen([str(native_shell), entry_url])
            _write_ready_signal(base_url)
            proc.wait()
            server.should_exit = True
            return 0
        except KeyboardInterrupt:
            server.should_exit = True
            return 0

    # 2) pywebview（跨平台原生窗口）
    try:
        import webview  # type: ignore

        _write_ready_signal(base_url)
        webview.create_window("OmniAgent", entry_url, width=1440, height=920, min_size=(960, 640))
        webview.start()
        server.should_exit = True
        return 0
    except ImportError:
        pass

    # 3) Chrome / Edge 独立 App 窗口模式（无地址栏）
    browser = _find_chromium_app_browser()
    if browser:
        profile_dir = d_dir / "desktop_window_profile"
        proc = subprocess.Popen([
            browser,
            f"--app={entry_url}",
            f"--user-data-dir={profile_dir}",
            "--window-size=1440,920",
            "--no-first-run",
            "--no-default-browser-check",
            "--disable-background-mode",
            "--disable-features=msEdgeSidebarV2,TranslateUI",
        ])
        _write_ready_signal(base_url)
        try:
            proc.wait()
        except KeyboardInterrupt:
            proc.terminate()
        server.should_exit = True
        return 0

    # 4) 兜底：系统默认浏览器打开并保持服务运行
    import webbrowser

    webbrowser.open(entry_url)
    _write_ready_signal(base_url)
    console.print("已在默认窗口打开，按 Ctrl+C 退出服务。")
    try:
        while thread.is_alive():
            time.sleep(0.5)
    except KeyboardInterrupt:
        server.should_exit = True
    return 0
