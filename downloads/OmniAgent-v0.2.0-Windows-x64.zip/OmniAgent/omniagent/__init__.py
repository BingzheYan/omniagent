"""OmniAgent - 自主执行型 AI 智能体系统。"""

__version__ = "0.2.0"
