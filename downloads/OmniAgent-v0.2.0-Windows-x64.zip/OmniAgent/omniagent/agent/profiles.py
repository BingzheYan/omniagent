"""智能体与子智能体（Agents & Subagents）注册表。

内置专业角色覆盖软件工程、代码调研、数据与计量分析、学术与办公写作、质量审查、外部应用连接；
同时支持从 ~/.omniagent/agents/*.md、<workspace>/.omniagent/agents/*.md 以及用户数据库加载自定义智能体。
"""
from __future__ import annotations

import re
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

import yaml


@dataclass
class AgentProfile:
    name: str
    title: str
    description: str
    icon: str = "🤖"
    mode: str = "auto"  # auto | code | office
    system_prompt: str = ""
    allowed_tools: list[str] | None = None  # None = 全部可用工具
    excluded_tools: list[str] = field(default_factory=list)
    max_steps: int = 50
    builtin: bool = True
    source: str = "builtin"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


BUILTIN_AGENTS: dict[str, AgentProfile] = {
    "general": AgentProfile(
        name="general",
        title="全能主控智能体",
        description="默认自主主控智能体：理解复杂目标、拆解计划、编排子智能体、调用全套编程与办公工具直到任务交付。",
        icon="◆",
        mode="auto",
        max_steps=80,
        system_prompt=(
            "你是全能主控智能体（Orchestrator）。面对跨领域或大规模任务时，先制定清晰计划，"
            "可将独立模块通过 delegate_task 或 delegate_parallel 委派给 researcher / coder / analyst / writer / "
            "connector / reviewer 等专业子智能体协同完成，并对最终交付物做整体核验。"
        ),
    ),
    "coder": AgentProfile(
        name="coder",
        title="软件架构与开发工程师",
        description="专注复杂编程、Bug 根因定位、重构、架构设计与自动化测试验证（Claude Code / Codex 标准）。",
        icon="💻",
        mode="code",
        max_steps=70,
        system_prompt=(
            "你是资深软件架构与开发工程师。严格遵循：先阅读上下文与现有约定 → 先用测试或最小脚本复现问题 → "
            "最小化、精准修改（edit_file）→ 运行完整测试套件与边界检查 → 确保零遗留 TODO 与零破坏性回归。"
        ),
    ),
    "researcher": AgentProfile(
        name="researcher",
        title="代码库与资料调研专家",
        description="快速只读探索代码库结构、检索跨文件调用链、抓取网页资料或探查外部连接器数据，不修改任何文件。",
        icon="🔎",
        mode="auto",
        allowed_tools=[
            "read_file", "list_dir", "glob", "grep", "web_fetch", "web_search",
            "load_skill", "view_image", "list_connectors", "connector_query", "browser_inspect", "desktop_inspect",
            "memory_search",
        ],
        max_steps=35,
        system_prompt=(
            "你是只读调研子智能体。高效并行使用 grep / glob / read_file / browser_inspect / connector_query 收集事实证据，"
            "输出结构化调研报告（关键文件路径与行号、核心逻辑、数据字段与结论），绝不臆测未读取的内容。"
        ),
    ),
    "analyst": AgentProfile(
        name="analyst",
        title="数据科学与计量经济分析师",
        description="精通 Python 数据清洗、统计检验、面板固定效应/DID/工具变量计量建模及高水准学术/商业图表绘制。",
        icon="📊",
        mode="office",
        excluded_tools=["delegate_task", "delegate_parallel"],
        max_steps=50,
        system_prompt=(
            "你是数据科学与计量经济分析专家。使用 python 工具（pandas / numpy / scipy / statsmodels / linearmodels / "
            "omniagent.research）完成严谨的数据核查、缺失与异常值处理、回归建模（双向固定效应、稳健标准误、稳健性与异质性检验）"
            "及高分辨率图表绘制，并用 view_image 逐张检查图表排版、中文标签与图例无遮挡。所有统计数字必须来自真实计算输出。"
        ),
    ),
    "writer": AgentProfile(
        name="writer",
        title="学术论文与公文报告主笔",
        description="撰写《财政研究》等期刊级实证论文、GB/T 9704 党政公文、商业分析报告、演示文稿，并执行排版与规范核验。",
        icon="🖋",
        mode="office",
        excluded_tools=["delegate_task", "delegate_parallel"],
        max_steps=50,
        system_prompt=(
            "你是学术论文与公文报告主笔。写作前先调用 load_skill 加载对应领域技能（fiscal-paper / data-analysis-report / "
            "official-document / presentation）。严格遵循“先文字引出（如图1所示 / 表2汇报了…）→ 紧跟插入图表 → 深入解读机制与政策含义”"
            "的学术规范，使用 create_document(style='academic' 或 'report') 输出文档，并用 check_document 逐项自检修正至高分通过。"
        ),
    ),
    "connector": AgentProfile(
        name="connector",
        title="外部应用与业务自动化专家",
        description="自主连接外部 API、邮箱（IMAP/SMTP）、日历（CalDAV/.ics）、报销/OA/CRM/招聘等需登录的网页系统、数据库与 MCP，执行双向读写与持续追踪。",
        icon="🔌",
        mode="auto",
        excluded_tools=["delegate_task", "delegate_parallel"],
        max_steps=55,
        system_prompt=(
            "你是外部应用与业务自动化专家。熟练运用 connector_manage 自动探测接入外部接口，用 email_ops 读取/回复邮件并维护线程，"
            "用 calendar_ops 检测冲突并安排日程提醒，用 browser_session 在招聘/OA/CRM 网页中有状态填表上传简历并提交，"
            "用 tracker_manage 建立持续跟进台账，并将采集数据落地工作区供深度分析。"
            "需要登录的网页业务系统（报销、OA、ERP 等）用 web_automation 真实浏览器操作：遇到登录页先 wait_login 提示用户亲自登录，"
            "登录后再观察页面、自主决定如何完成任务；不可逆的最终提交必须经用户确认。"
        ),
    ),
    "reviewer": AgentProfile(
        name="reviewer",
        title="质量与实测审查员",
        description="独立审阅代码变更、调用 verify_deliverable 拉起服务实测验收、核对统计数据、用 check_document 与 view_image 检验文档图表。",
        icon="🛡",
        mode="auto",
        excluded_tools=["delegate_task", "delegate_parallel", "write_file", "edit_file"],
        max_steps=35,
        system_prompt=(
            "你是独立的质量与实测审查员（Reviewer）。你不直接修改业务文件，而是通过 verify_deliverable（实测语法/单测/Web服务启动/Office文档）、"
            "read_file、grep、run_shell、python、check_document 与 view_image 严格挑刺，输出清晰的通过/不通过结论及按优先级排列的问题清单。"
        ),
    ),
}

_FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n?(.*)", re.DOTALL)


def _parse_agent_md(path: Path, source: str) -> AgentProfile | None:
    try:
        raw = path.read_text(encoding="utf-8")
    except OSError:
        return None
    meta: dict[str, Any] = {}
    body = raw
    m = _FRONTMATTER_RE.match(raw)
    if m:
        meta = yaml.safe_load(m.group(1)) or {}
        body = m.group(2).strip()
    name = str(meta.get("name") or path.stem).strip().lower()
    if not name:
        return None
    tools = meta.get("allowed_tools") or meta.get("tools")
    if isinstance(tools, str):
        tools = [t.strip() for t in tools.split(",") if t.strip()]
    excluded = meta.get("excluded_tools") or []
    if isinstance(excluded, str):
        excluded = [t.strip() for t in excluded.split(",") if t.strip()]
    return AgentProfile(
        name=name,
        title=str(meta.get("title") or name),
        description=str(meta.get("description") or body.splitlines()[0][:100] if body else name),
        icon=str(meta.get("icon") or "🤖"),
        mode=str(meta.get("mode") or "auto"),
        system_prompt=body,
        allowed_tools=list(tools) if tools else None,
        excluded_tools=list(excluded),
        max_steps=int(meta.get("max_steps") or 45),
        builtin=False,
        source=source,
    )


def discover_agents(workspace: Path | None = None, extra_profiles: list[dict[str, Any]] | None = None
                    ) -> dict[str, AgentProfile]:
    """返回所有可用的智能体档案（内置 + ~/.omniagent/agents + <workspace>/.omniagent/agents + 用户自定义）。"""
    out: dict[str, AgentProfile] = dict(BUILTIN_AGENTS)
    roots: list[tuple[Path, str]] = [(Path.home() / ".omniagent" / "agents", "user")]
    if workspace:
        roots.append((Path(workspace) / ".omniagent" / "agents", "workspace"))
    for folder, src in roots:
        if folder.is_dir():
            for p in sorted(folder.glob("*.md")):
                prof = _parse_agent_md(p, src)
                if prof:
                    out[prof.name] = prof
    for spec in extra_profiles or []:
        name = str(spec.get("name") or "").strip()
        if not name:
            continue
        out[name] = AgentProfile(
            name=name,
            title=str(spec.get("title") or name),
            description=str(spec.get("description") or ""),
            icon=str(spec.get("icon") or "🤖"),
            mode=str(spec.get("mode") or "auto"),
            system_prompt=str(spec.get("system_prompt") or ""),
            allowed_tools=spec.get("allowed_tools") or None,
            excluded_tools=list(spec.get("excluded_tools") or []),
            max_steps=int(spec.get("max_steps") or 45),
            builtin=False,
            source="custom",
        )
    return out
