"""Agent 内核：理解 → 规划 → 执行工具 → 观察 → 自检 → 迭代，直到任务完成。

CLI、Web 工作台与桌面端共用此内核，通过事件回调 (on_event) 获取实时进度（含思维链、文件变更、子智能体状态），
通过 approver / ask_user 回调实现人机协作。
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
import time
import uuid
from pathlib import Path
from typing import Any, Awaitable, Callable

from omniagent.config import Settings
from omniagent.llm.types import LLMProvider, LLMResponse, Message, ToolCall, Usage
from omniagent.memory import MemoryStore, consolidate_turn_memory
from omniagent.safety import approval_reason, check_blocked
from omniagent.tools import ToolContext, ToolError, ToolRegistry, ToolResult, build_default_registry
from omniagent.tools.base import truncate
from omniagent.tools.planning import render_todos
from omniagent.tools.python_exec import shutdown_kernel
from omniagent.tools.shell import cleanup_background

from .context import compact_history, drop_old_images, history_tokens, slim_old_tool_outputs, workspace_snapshot
from .profiles import AgentProfile, discover_agents
from .prompts import DOOM_LOOP_PROMPT, REVIEW_PROMPT, build_system_prompt
from .session import load_session, save_session

log = logging.getLogger(__name__)

EventHandler = Callable[[dict[str, Any]], Awaitable[None]]
Approver = Callable[[dict[str, Any]], Awaitable[bool]]
AskUser = Callable[[str], Awaitable[str | None]]

PARALLEL_SAFE = {"read_file", "list_dir", "glob", "grep", "web_fetch", "web_search", "view_image", "load_skill",
                 "list_connectors", "memory_search"}
MODIFYING_RISKS = {"write", "exec"}
MAX_IMAGES_IN_HISTORY = 6
# 接入外部系统 / 应用的工具：执行步骤会同步到工作台右侧「操作」栏
EXTERNAL_OP_TOOLS = {
    "web_automation": ("🌐", "网页业务系统"), "browser_session": ("🌐", "网页会话"), "browser_inspect": ("🔎", "网页读取"),
    "email_ops": ("✉️", "邮箱"), "calendar_ops": ("📅", "日历"), "connector_query": ("🔌", "外部连接器"),
    "connector_manage": ("🧩", "连接器管理"), "desktop_inspect": ("🖥", "本机应用"), "desktop_action": ("🖥", "本机应用"),
    "tracker_manage": ("📡", "事项追踪"), "expense_reimburse": ("🧾", "智能报销"), "web_fetch": ("🌐", "网页抓取"),
}
MAX_EXTERNAL_OPS = 300


class LoopDetector:
    """检测“死循环”：同一工具+参数连续失败 N 次，或完全相同的调用连续重复 M 次。"""

    def __init__(self, fail_threshold: int = 3, repeat_threshold: int = 4):
        self.fail_threshold = fail_threshold
        self.repeat_threshold = repeat_threshold
        self.history: list[tuple[str, bool, str]] = []

    @staticmethod
    def fingerprint(tc: ToolCall) -> str:
        try:
            args = json.dumps(tc.arguments, sort_keys=True, ensure_ascii=False)
        except (TypeError, ValueError):
            args = str(tc.arguments)
        return f"{tc.name}:{args}"

    def observe(self, calls: list[ToolCall], results: list[Message]) -> str | None:
        for tc, res in zip(calls, results):
            self.history.append((self.fingerprint(tc), bool(res.is_error), tc.name))
        self.history = self.history[-30:]
        if not self.history:
            return None
        last_key, _, name = self.history[-1]
        streak = 0
        for key, _err, _n in reversed(self.history):
            if key != last_key:
                break
            streak += 1
        tail = self.history[-self.fail_threshold:]
        reason = None
        if len(tail) == self.fail_threshold and all(k == last_key and err for k, err, _ in tail):
            reason = f"同一个 {name} 调用（参数完全相同）已连续失败 {self.fail_threshold} 次。"
        elif streak >= self.repeat_threshold:
            reason = f"完全相同的 {name} 调用已连续重复 {streak} 次，结果不会因重复而改变。"
        if reason:
            self.history.clear()
        return reason

    def reset(self) -> None:
        self.history.clear()


def _filter_registry_by_profile(base: ToolRegistry, prof: AgentProfile | None, extra_exclude: set[str] | None = None
                                ) -> ToolRegistry:
    exclude = set(extra_exclude or ())
    if prof:
        exclude.update(prof.excluded_tools or [])
    reg = base.subset(exclude)
    if prof and prof.allowed_tools is not None:
        allowed = set(prof.allowed_tools)
        reg = ToolRegistry([reg.get(n) for n in reg.names() if n in allowed and reg.get(n) is not None])
    return reg


def _compact_tool_data(data: dict[str, Any] | None) -> dict[str, Any]:
    if not data:
        return {}
    out: dict[str, Any] = {}
    for k in ("path", "added", "removed", "status", "fuzzy", "image", "images", "score"):
        if k in data and data[k] is not None:
            out[k] = data[k]
    if data.get("diff"):
        out["diff"] = str(data["diff"])[:12_000]
    return out


class Agent:
    def __init__(
        self,
        llm: LLMProvider,
        settings: Settings,
        workspace: str | Path,
        *,
        tools: ToolRegistry | None = None,
        mode: str = "auto",
        approval: str | None = None,
        on_event: EventHandler | None = None,
        approver: Approver | None = None,
        ask_user: AskUser | None = None,
        session_id: str | None = None,
        max_steps: int | None = None,
        depth: int = 0,
        role: str | None = None,
        persist: bool = True,
        custom_instructions: str | None = None,
        on_saved: Callable[["Agent"], None] | None = None,
        agent_profile: str = "general",
        extra_agents: list[dict[str, Any]] | None = None,
        extra_connectors: list[dict[str, Any]] | None = None,
        memory_enabled: bool | None = None,
        memory_store: MemoryStore | None = None,
    ):
        self.llm = llm
        self.custom_instructions = custom_instructions
        self.on_saved = on_saved
        self.settings = settings
        self.workspace = Path(workspace).resolve()
        self.workspace.mkdir(parents=True, exist_ok=True)
        self.extra_agents = list(extra_agents or [])
        self.extra_connectors = list(extra_connectors or [])
        self.agent_profile_name = agent_profile or "general"
        all_agents = discover_agents(self.workspace, self.extra_agents)
        prof = all_agents.get(self.agent_profile_name)
        base_tools = tools or build_default_registry(settings)
        self.tools = _filter_registry_by_profile(base_tools, prof if tools is None else None)
        self._full_tools = base_tools
        self.mode = mode if mode != "auto" or not prof else (prof.mode or "auto")
        self.approval = approval or settings.approval
        self.on_event = on_event
        self.approver = approver
        self.depth = depth
        self.role = role
        self.max_steps = max_steps or (prof.max_steps if prof and depth > 0 else settings.max_steps)
        self.persist = persist and depth == 0
        self.memory_enabled = bool(self.persist if memory_enabled is None else memory_enabled)
        if memory_store is not None:
            self.memory_store: MemoryStore | None = memory_store
            self._owns_memory_store = False
        elif self.memory_enabled:
            self.memory_store = MemoryStore(self.workspace / ".omniagent" / "memory.db")
            self._owns_memory_store = True
        else:
            self.memory_store = None
            self._owns_memory_store = False
        self.session_id = session_id or uuid.uuid4().hex[:12]
        self.title = ""
        self.created = time.time()
        self.messages: list[Message] = []
        self.state: dict[str, Any] = {
            "extra_connectors": self.extra_connectors,
            "file_changes": {},
            "memory_store": self.memory_store,
        }
        self.usage = Usage()
        self.last_context_tokens = 0
        self.running = False
        self._system_prompt_cache: str | None = None
        self._turn_start_idx: int = 0
        self._turn_task: str = ""
        self._turn_changes: dict[str, dict[str, Any]] = {}
        self._turn_subagents: list[dict[str, Any]] = []
        self._live_step: int = 0
        self._live_thinking_buf: str = ""
        self._live_text_buf: str = ""
        self._live_tools: dict[str, dict[str, Any]] = {}
        self.loop_detector = LoopDetector()
        self.ctx = ToolContext(self.workspace, settings, self.emit, ask_user, self.state, self)
        if depth > 0:
            self.ctx.ask_user = None

    # ------------------------------------------------------------------ 基础设施
    def set_agent_profile(self, name: str, extra_agents: list[dict[str, Any]] | None = None) -> None:
        if extra_agents is not None:
            self.extra_agents = list(extra_agents)
        all_agents = discover_agents(self.workspace, self.extra_agents)
        prof = all_agents.get(name) or all_agents["general"]
        self.agent_profile_name = prof.name
        self.tools = _filter_registry_by_profile(self._full_tools, prof)

    @property
    def system_prompt(self) -> str:
        if self._system_prompt_cache is not None:
            return self._system_prompt_cache
        return self.build_system_prompt(snapshot=False)

    def build_system_prompt(self, snapshot: bool = True, current_task: str = "") -> str:
        names = self.tools.names()
        skills = None
        if "load_skill" in names:
            try:
                from omniagent.tools.skills import discover_skills

                skills = discover_skills(self.workspace)
            except Exception as e:  # noqa: BLE001
                log.warning("扫描技能失败: %s", e)
        agents_map = discover_agents(self.workspace, self.extra_agents)
        prof = agents_map.get(self.agent_profile_name)
        connectors = None
        if "connector_query" in names:
            try:
                from omniagent.tools.integrations import get_available_connectors

                connectors = get_available_connectors(self.ctx)
            except Exception:  # noqa: BLE001
                connectors = None
        ws_ctx = None
        if snapshot:
            try:
                ws_ctx = workspace_snapshot(self.workspace)
            except Exception as e:  # noqa: BLE001
                log.debug("workspace snapshot failed: %s", e)
        prompt = build_system_prompt(
            self.workspace, self.mode, names, self.role if self.depth else None,
            skills=skills, workspace_context=ws_ctx, agents=agents_map if self.depth == 0 else None,
            connectors=connectors, profile_prompt=prof.system_prompt if prof else "",
        )
        if self.custom_instructions and self.custom_instructions.strip():
            prompt += f"\n# 用户的自定义指令（请始终遵守）\n{self.custom_instructions.strip()[:8000]}\n"
        if self.memory_enabled and self.memory_store is not None:
            try:
                mem_ctx = self.memory_store.build_prompt_context(
                    current_task or self._turn_task, conv_id=self.session_id
                )
                if mem_ctx:
                    prompt += mem_ctx
            except Exception as e:  # noqa: BLE001
                log.debug("memory prompt build failed: %s", e)
        return prompt

    async def emit(self, event: dict[str, Any]) -> None:
        event.setdefault("depth", self.depth)
        event.setdefault("session_id", self.session_id)
        if self.depth == 0:
            et = event.get("type")
            if et == "task_start":
                self._live_step = 0
                self._live_thinking_buf = ""
                self._live_text_buf = ""
                self._live_tools.clear()
            elif et == "step":
                self._live_step = int(event.get("step") or (self._live_step + 1))
                self._live_thinking_buf = ""
                self._live_text_buf = ""
            elif et == "thinking_delta":
                self._live_thinking_buf = (self._live_thinking_buf + str(event.get("text") or ""))[-24_000:]
            elif et == "text_delta":
                self._live_text_buf = (self._live_text_buf + str(event.get("text") or ""))[-40_000:]
            elif et == "assistant_message":
                self._live_thinking_buf = ""
                self._live_text_buf = ""
            elif et == "tool_start" and event.get("id"):
                self._live_tools[event["id"]] = {
                    "id": event["id"], "name": event.get("name"),
                    "arguments": event.get("arguments") or {}, "summary": event.get("summary") or "",
                }
            elif et == "tool_end" and event.get("id"):
                self._live_tools.pop(event["id"], None)
            elif et in ("done", "cancelled", "error"):
                self._live_thinking_buf = ""
                self._live_text_buf = ""
                self._live_tools.clear()
        if self.on_event:
            try:
                await self.on_event(event)
            except Exception as e:  # noqa: BLE001
                log.debug("event handler error: %s", e)

    def get_live_state(self) -> dict[str, Any]:
        """获取当前正在执行的实时中间态，支持前端在多个并发对话间来回切换时无缝衔接。"""
        return {
            "step": self._live_step,
            "thinking": self._live_thinking_buf,
            "text": self._live_text_buf,
            "active_tools": list(self._live_tools.values()),
            "login_pending": self.state.get("_login_pending"),
        }

    def save(self) -> None:
        if not self.persist:
            return
        save_session(self.workspace, self.session_id, {
            "id": self.session_id, "title": self.title, "created": self.created, "mode": self.mode,
            "agent_profile": self.agent_profile_name, "model": self.llm.profile.name,
            "messages": self.messages, "todos": self.state.get("todos", []),
            "file_changes": list((self.state.get("file_changes") or {}).values()),
            "external_ops": list(self.state.get("external_ops") or [])[-MAX_EXTERNAL_OPS:],
            "usage": self.usage.__dict__,
        })
        if self.on_saved:
            try:
                self.on_saved(self)
            except Exception as e:  # noqa: BLE001
                log.warning("on_saved hook failed: %s", e)

    def load(self, session_id: str) -> bool:
        data = load_session(self.workspace, session_id)
        if not data:
            return False
        self.session_id = session_id
        self.messages = data["messages"]
        self.title = data.get("title", "")
        self.created = data.get("created", time.time())
        self.state["todos"] = data.get("todos", [])
        fc_list = data.get("file_changes") or []
        self.state["file_changes"] = {f["path"]: f for f in fc_list if isinstance(f, dict) and f.get("path")}
        self.state["external_ops"] = [o for o in (data.get("external_ops") or []) if isinstance(o, dict)]
        if data.get("agent_profile"):
            self.set_agent_profile(data["agent_profile"])
        self._repair_history()
        return True

    def reset(self) -> None:
        self.messages.clear()
        self.state.pop("todos", None)
        self.state["file_changes"] = {}
        self.state["external_ops"] = []
        self.session_id = uuid.uuid4().hex[:12]
        self.title = ""
        self.created = time.time()

    async def close(self) -> None:
        await shutdown_kernel(self.state)
        await cleanup_background(self.state)
        if self.depth == 0 and self.state.get("_pw_sessions"):
            try:
                from omniagent.tools.web_automation import close_web_sessions

                await close_web_sessions(self.state)
            except Exception:  # noqa: BLE001
                pass
        for ws_sess in list((self.state.get("_web_sessions") or {}).values()):
            try:
                await ws_sess.close()
            except Exception:  # noqa: BLE001
                pass
        if self.state.get("_tracker_store") is not None:
            try:
                self.state["_tracker_store"].close()
            except Exception:  # noqa: BLE001
                pass
        if self._owns_memory_store and self.memory_store is not None:
            try:
                self.memory_store.close()
            except Exception:  # noqa: BLE001
                pass
        elif self.state.get("_owned_memory_store") and isinstance(self.state.get("memory_store"), MemoryStore):
            try:
                self.state["memory_store"].close()
            except Exception:  # noqa: BLE001
                pass

    def _repair_history(self) -> None:
        fixed: list[Message] = []
        i = 0
        msgs = self.messages
        while i < len(msgs):
            m = msgs[i]
            fixed.append(m)
            i += 1
            if m.role == "assistant" and m.tool_calls:
                answered = set()
                while i < len(msgs) and msgs[i].role == "tool":
                    answered.add(msgs[i].tool_call_id)
                    fixed.append(msgs[i])
                    i += 1
                for tc in m.tool_calls:
                    if tc.id not in answered:
                        fixed.append(Message("tool", "(操作被用户中断，未执行)", tool_call_id=tc.id, name=tc.name,
                                             is_error=True))
        self.messages = fixed

    def _record_file_change(self, tool_name: str, data: dict[str, Any]) -> list[dict[str, Any]]:
        """记录本轮及会话累计的文件变更（支持文本 diff 行数累加与二进制产物登记）。"""
        paths: list[str] = []
        if data.get("path"):
            paths.append(str(data["path"]))
        for img in data.get("images") or []:
            if tool_name in ("python", "browser_inspect"):
                paths.append(str(img))
        for extra in data.get("outputs") or []:
            if extra and str(extra) not in paths:
                paths.append(str(extra))
        if not paths:
            return []
        updated: list[dict[str, Any]] = []
        sess_fc = self.state.setdefault("file_changes", {})
        for rel in paths:
            is_primary = rel == data.get("path")
            added = int(data.get("added") or 0) if is_primary else 0
            removed = int(data.get("removed") or 0) if is_primary else 0
            diff = str(data.get("diff") or "")[:12_000] if is_primary else ""
            status = data.get("status") or "added"
            binary = not bool(diff) and added == 0 and removed == 0 and tool_name not in ("write_file", "edit_file")
            prev = self._turn_changes.get(rel)
            entry = {
                "path": rel,
                "status": prev["status"] if (prev and prev["status"] == "added") else status,
                "added": (prev["added"] if prev else 0) + added,
                "removed": (prev["removed"] if prev else 0) + removed,
                "diff": diff or (prev.get("diff", "") if prev else ""),
                "binary": binary,
                "updated": time.time(),
            }
            self._turn_changes[rel] = entry
            sess_fc[rel] = dict(entry)
            updated.append(entry)
        return updated

    # ------------------------------------------------------------------ 主循环
    async def run(self, task: str) -> str:
        if self.running:
            raise RuntimeError("Agent 正在执行任务")
        self.running = True
        self._turn_changes = {}
        self._turn_subagents = []
        self.state["_turn_memory_events"] = []
        self._repair_history()
        if not self.title:
            self.title = task.strip().splitlines()[0][:60] if task.strip() else "新任务"
        self._turn_start_idx = len(self.messages)
        self._turn_task = task
        self.messages.append(Message("user", task))
        await self.emit({"type": "task_start", "task": task, "title": self.title,
                         "agent_profile": self.agent_profile_name})
        self._system_prompt_cache = None
        try:
            self._system_prompt_cache = await asyncio.to_thread(self.build_system_prompt, True, task)
        except Exception as e:  # noqa: BLE001
            log.warning("构建系统提示词失败，使用简化版本: %s", e)
        self.loop_detector.reset()
        reviews = 0
        modified_since_review = False
        started = time.time()
        try:
            for step in range(1, self.max_steps + 1):
                await self._maybe_compact()
                await self.emit({"type": "step", "step": step})
                resp = await self._call_llm()
                meta: dict[str, Any] = {}
                if resp.thinking:
                    meta["thinking"] = resp.thinking
                self.messages.append(Message("assistant", resp.content, resp.tool_calls, meta=meta))
                await self.emit({
                    "type": "assistant_message", "content": resp.content, "thinking": resp.thinking,
                    "tool_calls": [{"id": t.id, "name": t.name, "arguments": t.arguments} for t in resp.tool_calls],
                })

                if not resp.tool_calls:
                    if resp.stop_reason in ("length", "max_tokens"):
                        self.messages.append(Message("user", "<system-reminder>你的输出因长度限制被截断，请继续。"
                                                     "</system-reminder>", meta={"system": True}))
                        continue
                    if modified_since_review and reviews < self.settings.max_reviews:
                        reviews += 1
                        modified_since_review = False
                        todos = self.state.get("todos") or []
                        pending = [t for t in todos if t.get("status") not in ("completed", "cancelled")]
                        note = ""
                        if pending:
                            note = "4. 计划中仍有未完成项：\n" + render_todos(pending) + "\n   请完成它们，或在确认不再需要时更新计划。"
                        self.messages.append(Message("user", REVIEW_PROMPT.format(todo_note=note), meta={"system": True}))
                        await self.emit({"type": "review", "round": reviews})
                        continue
                    return await self._finish(resp.content, step, started)

                results = await self._run_tools(resp.tool_calls)
                self.messages.extend(results)
                for tc, res in zip(resp.tool_calls, results):
                    t = self.tools.get(tc.name)
                    if t and t.risk in MODIFYING_RISKS and not res.is_error:
                        modified_since_review = True
                loop_reason = self.loop_detector.observe(resp.tool_calls, results)
                if loop_reason:
                    self.messages.append(Message("user", DOOM_LOOP_PROMPT.format(reason=loop_reason),
                                                 meta={"system": True, "loop_warning": True}))
                    await self.emit({"type": "loop_warning", "reason": loop_reason})
                self.save()

            self.messages.append(Message(
                "user", "<system-reminder>已达到最大执行步数。请不要再调用工具，直接总结已完成的工作、产出文件、"
                        "未完成部分以及建议的后续步骤。</system-reminder>", meta={"system": True}))
            resp = await self._call_llm()
            text = resp.content or "已达到最大步数，任务未完全完成。"
            self.messages.append(Message("assistant", text, meta={"thinking": resp.thinking} if resp.thinking else {}))
            if resp.tool_calls:
                self.messages[-1].tool_calls = []
            return await self._finish(text, self.max_steps, started, incomplete=True)
        except asyncio.CancelledError:
            self._repair_history()
            self.messages.append(Message("user", "<system-reminder>用户中断了上一个任务。</system-reminder>",
                                         meta={"system": True}))
            self.save()
            await self.emit({"type": "cancelled"})
            raise
        except Exception as e:
            self._repair_history()
            self.save()
            await self.emit({"type": "error", "message": f"{type(e).__name__}: {e}"})
            raise
        finally:
            self.running = False
            self._system_prompt_cache = None

    async def _finish(self, text: str, steps: int, started: float, incomplete: bool = False) -> str:
        changes_list = list(self._turn_changes.values())
        mem_events: list[dict[str, Any]] = list(self.state.get("_turn_memory_events") or [])
        if self.depth == 0 and self.memory_enabled and self.memory_store is not None:
            try:
                turn_msgs = self.messages[self._turn_start_idx:]
                cons = await consolidate_turn_memory(
                    self.memory_store,
                    conv_id=self.session_id,
                    conv_title=self.title,
                    user_task=self._turn_task,
                    final_text=text,
                    turn_messages=turn_msgs,
                    todos=list(self.state.get("todos") or []),
                    turn_changes=changes_list,
                    mode=self.mode,
                    agent_profile=self.agent_profile_name,
                    incomplete=incomplete,
                    llm=self.llm,
                    enable_llm_pass=False,
                )
                seen_summaries = {e.get("summary") for e in mem_events}
                for ev in cons.get("events") or []:
                    if ev.get("summary") not in seen_summaries:
                        mem_events.append(ev)
                        seen_summaries.add(ev.get("summary"))
            except Exception as e:  # noqa: BLE001
                log.warning("post-turn memory consolidation failed: %s", e)

        if self.messages and self.messages[-1].role == "assistant":
            if changes_list:
                self.messages[-1].meta["turn_changes"] = changes_list
            if self._turn_subagents:
                self.messages[-1].meta["subagents"] = list(self._turn_subagents)
            if mem_events:
                self.messages[-1].meta["memories_learned"] = mem_events
        self.save()
        if changes_list and self.depth == 0:
            await self.emit({"type": "file_changes", "files": changes_list, "final": True})
        if mem_events and self.depth == 0:
            stats = self.memory_store.overview()["stats"] if self.memory_store else {}
            await self.emit({"type": "memory_updated", "events": mem_events, "stats": stats})
        await self.emit({
            "type": "done", "final": text, "steps": steps, "elapsed": round(time.time() - started, 1),
            "incomplete": incomplete, "usage": self.usage.__dict__, "files_changed": changes_list,
            "memories_learned": mem_events,
        })
        return text

    async def _call_llm(self) -> LLMResponse:
        async def on_delta(kind: str, text: str):
            await self.emit({"type": "text_delta" if kind == "text" else "thinking_delta", "text": text})

        resp = await self.llm.complete(self.system_prompt, self.messages, self.tools.schemas(), on_delta)
        self.usage.add(resp.usage)
        self.last_context_tokens = resp.usage.input_tokens or history_tokens(self.system_prompt, self.messages)
        await self.emit({"type": "usage", **self.usage.__dict__, "context_tokens": self.last_context_tokens,
                         "context_window": self.llm.profile.context_window})
        return resp

    # ------------------------------------------------------------------ 工具执行
    async def _run_tools(self, calls: list[ToolCall]) -> list[Message]:
        if len(calls) > 1 and all(c.name in PARALLEL_SAFE for c in calls):
            return list(await asyncio.gather(*(self._execute_tool(c) for c in calls)))
        out = []
        for c in calls:
            out.append(await self._execute_tool(c))
        return out

    async def _execute_tool(self, tc: ToolCall) -> Message:
        tool = self.tools.get(tc.name)
        summary = tool.summarize(tc.arguments) if tool else ""
        await self.emit({"type": "tool_start", "id": tc.id, "name": tc.name, "arguments": tc.arguments,
                         "summary": summary})
        started = time.time()
        ext = EXTERNAL_OP_TOOLS.get(tc.name)
        if ext:
            await self._external_op(tc, "running", summary)
        result: ToolResult
        if tool is None:
            result = ToolResult(f"未知工具 '{tc.name}'。可用工具: {', '.join(self.tools.names())}", is_error=True)
        elif tc.parse_error:
            result = ToolResult(tc.parse_error + "\n请重新调用并提供合法的 JSON 参数（内容过长时可分多次写入）。", is_error=True)
        elif blocked := check_blocked(tc.name, tc.arguments):
            result = ToolResult(blocked + "。请使用更安全的替代方案。", is_error=True)
        else:
            reason = approval_reason(tc.name, tool.risk, tc.arguments, self.approval)
            approved = True
            if reason:
                approved = await self._request_approval(tc, reason, summary)
            if not approved:
                result = ToolResult("用户拒绝了此操作。请考虑其他方案，或在必要时用 ask_user 询问用户意图。", is_error=True)
            else:
                try:
                    self.state["_active_tool_id"] = tc.id
                    result = await tool.run(tc.arguments, self.ctx)
                except ToolError as e:
                    result = ToolResult(f"错误: {e}", is_error=True)
                except asyncio.CancelledError:
                    raise
                except Exception as e:  # noqa: BLE001
                    log.exception("tool %s failed", tc.name)
                    result = ToolResult(f"工具内部异常 {type(e).__name__}: {e}", is_error=True)
        content = truncate(result.content)
        images = list(getattr(result, "images", None) or [])
        # 只把真正产生/修改文件的工具结果计入「变更/产出」（读取原件、加载技能等只读操作不计入）
        if not result.is_error and result.data and tool is not None and (
                tool.risk in MODIFYING_RISKS or tc.name in ("python", "browser_inspect")):
            changed = self._record_file_change(tc.name, result.data)
            if changed and self.depth == 0:
                await self.emit({"type": "file_changes", "files": list(self._turn_changes.values()), "final": False})
        if ext:
            await self._external_op(tc, "error" if result.is_error else "done", summary, result=result,
                                    duration=round(time.time() - started, 2))
        await self.emit({
            "type": "tool_end", "id": tc.id, "name": tc.name, "content": content[:6000], "is_error": result.is_error,
            "data": result.data, "duration": round(time.time() - started, 2), "images_attached": len(images),
        })
        meta: dict[str, Any] = {}
        if images:
            meta["images"] = images
        compact_d = _compact_tool_data(result.data)
        if compact_d:
            meta["data"] = compact_d
        return Message("tool", content, tool_call_id=tc.id, name=tc.name, is_error=result.is_error, meta=meta)

    async def _external_op(self, tc: ToolCall, status: str, summary: str, result: ToolResult | None = None,
                           duration: float | None = None) -> None:
        """把外部系统操作步骤记录到会话并推送到工作台「操作」栏（含页面截图、网址与执行结果）。"""
        icon, system = EXTERNAL_OP_TOOLS.get(tc.name, ("🔌", tc.name))
        args = tc.arguments or {}
        ops: list[dict[str, Any]] = self.state.setdefault("external_ops", [])
        op = next((o for o in reversed(ops) if o.get("id") == tc.id), None)
        if op is None:
            safe_args = {k: ("******" if re.search(r"pass|密码|token|secret", str(k), re.I) else v)
                         for k, v in args.items() if k not in ("fields", "body", "config", "headers")}
            raw_args = json.dumps(safe_args, ensure_ascii=False, default=str)
            op = {
                "id": tc.id, "tool": tc.name, "icon": icon, "system": system,
                "action": str(args.get("action") or ""), "title": str(args.get("note") or summary or tc.name)[:120],
                "args": json.loads(raw_args) if len(raw_args) <= 1500 else {},
                "session": str(args.get("session") or args.get("session_name") or args.get("connector") or ""),
                "url": str(args.get("url") or ""), "status": status, "started": time.time(), "depth": self.depth,
            }
            if isinstance(args.get("fields"), dict):
                op["fields"] = [str(k) for k in list(args["fields"])[:30]]
            ops.append(op)
            del ops[:-MAX_EXTERNAL_OPS]
        op["status"] = status
        if result is not None:
            data = result.data or {}
            first = next((ln.strip() for ln in (result.content or "").splitlines() if ln.strip()), "")
            op["detail"] = first[:300]
            if data.get("op_title") and not args.get("note"):
                op["title"] = str(data["op_title"])[:120]
            if data.get("screenshot"):
                op["screenshot"] = data["screenshot"]
            elif data.get("images"):
                op["screenshot"] = str((data.get("images") or [""])[0])
            if data.get("url"):
                op["url"] = data["url"]
            if data.get("title"):
                op["page_title"] = str(data["title"])[:120]
            op["duration"] = duration
        await self.emit({"type": "external_op", **op})

    async def _request_approval(self, tc: ToolCall, reason: str, summary: str) -> bool:
        if self.approver is None:
            return False
        req = {"id": uuid.uuid4().hex[:8], "tool": tc.name, "arguments": tc.arguments, "reason": reason,
               "summary": summary}
        await self.emit({"type": "approval_request", **req})
        ok = await self.approver(req)
        await self.emit({"type": "approval_result", "id": req["id"], "approved": ok})
        return ok

    # ------------------------------------------------------------------ 上下文压缩
    async def _maybe_compact(self, force: bool = False) -> None:
        drop_old_images(self.messages, keep_recent=MAX_IMAGES_IN_HISTORY)
        window = self.llm.profile.context_window
        current = max(self.last_context_tokens, history_tokens(self.system_prompt, self.messages))
        if not force and current < window * 0.5:
            return
        if not force:
            slim_old_tool_outputs(self.messages)
            current = history_tokens(self.system_prompt, self.messages)
            if current < window * 0.7:
                return
        await self.emit({"type": "status", "message": "上下文较长，正在压缩历史…"})
        res = await compact_history(self.llm, self.messages, keep_tokens=int(window * 0.2),
                                    max_summary_input_chars=int(window * 1.5))
        if res:
            before = current
            self.messages, _ = res
            self.last_context_tokens = history_tokens(self.system_prompt, self.messages)
            await self.emit({"type": "compact", "before": before, "after": self.last_context_tokens})
            self.save()

    async def compact(self) -> None:
        await self._maybe_compact(force=True)

    # ------------------------------------------------------------------ 子智能体（单个与并行）
    async def spawn_subagent(self, task: str, role: str, max_steps: int | None = None,
                             agent_type: str | None = None) -> str:
        agents_map = discover_agents(self.workspace, self.extra_agents)
        prof = agents_map.get(agent_type or "") or agents_map.get(role.lower() if role else "")
        exclude = {"ask_user"}
        if self.depth + 1 >= 2:
            exclude.update({"delegate_task", "delegate_parallel"})
        child_tools = _filter_registry_by_profile(self._full_tools, prof, extra_exclude=exclude)
        role_label = role or (prof.title if prof else "专业子智能体")
        sub_id = f"sub_{uuid.uuid4().hex[:6]}"
        child = Agent(
            self.llm, self.settings, self.workspace, tools=child_tools,
            mode=prof.mode if prof else self.mode, approval=self.approval,
            on_event=self.on_event, approver=self.approver,
            max_steps=max_steps or (prof.max_steps if prof else 40),
            depth=self.depth + 1, role=role_label,
            session_id=f"{self.session_id}-{sub_id}",
            agent_profile=prof.name if prof else "general",
            extra_agents=self.extra_agents, extra_connectors=self.extra_connectors,
            memory_enabled=self.memory_enabled, memory_store=self.memory_store,
        )
        # 子智能体与主智能体共享浏览器会话与外部操作记录（登录态不丢失、操作栏统一展示）
        child.state["_pw_sessions"] = self.state.setdefault("_pw_sessions", {})
        child.state["external_ops"] = self.state.setdefault("external_ops", [])
        child.ctx.state = child.state
        t0 = time.time()
        sub_meta = {
            "subagent_id": sub_id, "agent_type": prof.name if prof else "general",
            "icon": prof.icon if prof else "🤖", "role": role_label, "task": task[:500],
        }
        await self.emit({"type": "subagent_start", **sub_meta})
        try:
            report = await child.run(task)
            for rel, fc in child._turn_changes.items():
                self._turn_changes[rel] = fc
                self.state.setdefault("file_changes", {})[rel] = dict(fc)
            if child._turn_changes and self.depth == 0:
                await self.emit({"type": "file_changes", "files": list(self._turn_changes.values()), "final": False})
        finally:
            self.usage.add(child.usage)
            await child.close()
        elapsed = round(time.time() - t0, 1)
        done_meta = {**sub_meta, "elapsed": elapsed, "report": report[:3000]}
        self._turn_subagents.append(done_meta)
        await self.emit({"type": "subagent_end", **done_meta})
        return report

    async def spawn_subagents_parallel(self, specs: list[dict[str, Any]]) -> list[tuple[str, str]]:
        async def _one(sp: dict[str, Any]) -> tuple[str, str]:
            atype = sp.get("agent_type")
            role = sp.get("role") or atype or "助手"
            rep = await self.spawn_subagent(sp["task"], role, sp.get("max_steps"), agent_type=atype)
            return role, rep

        return list(await asyncio.gather(*(_one(sp) for sp in specs)))


def summarize_args(args: dict[str, Any], limit: int = 300) -> str:
    s = json.dumps(args, ensure_ascii=False)
    return s if len(s) <= limit else s[:limit] + "…"
