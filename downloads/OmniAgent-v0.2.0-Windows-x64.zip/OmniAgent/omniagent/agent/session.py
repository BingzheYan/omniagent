"""会话持久化：保存/恢复对话历史、计划与用量。"""
from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

from omniagent.llm.types import Message


def sessions_dir(workspace: Path) -> Path:
    d = workspace / ".omniagent" / "sessions"
    d.mkdir(parents=True, exist_ok=True)
    return d


def save_session(workspace: Path, session_id: str, data: dict[str, Any]) -> None:
    data = dict(data)
    data["updated"] = time.time()
    data["messages"] = [m.to_dict() if isinstance(m, Message) else m for m in data.get("messages", [])]
    path = sessions_dir(workspace) / f"{session_id}.json"
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, default=str), encoding="utf-8")
    tmp.replace(path)


def load_session(workspace: Path, session_id: str) -> dict[str, Any] | None:
    path = sessions_dir(workspace) / f"{session_id}.json"
    if not path.exists():
        return None
    data = json.loads(path.read_text(encoding="utf-8"))
    data["messages"] = [Message.from_dict(m) for m in data.get("messages", [])]
    return data


def list_sessions(workspace: Path, limit: int = 50) -> list[dict[str, Any]]:
    out = []
    for p in sessions_dir(workspace).glob("*.json"):
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
            out.append({"id": d.get("id", p.stem), "title": d.get("title", ""), "updated": d.get("updated", 0),
                        "model": d.get("model"), "mode": d.get("mode")})
        except Exception:  # noqa: BLE001
            continue
    out.sort(key=lambda x: x["updated"], reverse=True)
    return out[:limit]


def delete_session(workspace: Path, session_id: str) -> bool:
    p = sessions_dir(workspace) / f"{session_id}.json"
    if p.exists():
        p.unlink()
        return True
    return False
