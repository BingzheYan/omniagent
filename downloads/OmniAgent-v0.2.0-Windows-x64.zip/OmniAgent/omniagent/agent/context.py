"""上下文管理：token 估算、旧工具输出瘦身、自动摘要压缩、工作区快照。"""
from __future__ import annotations

import os
import subprocess
from pathlib import Path

from omniagent.llm.types import LLMProvider, Message, message_images

from .prompts import COMPACT_PROMPT

IMAGE_TOKENS = 1600  # 一张 ≤1568px 图片约 1.6k tokens（粗略）


def estimate_tokens(text: str) -> int:
    # 粗略估算：ASCII 约 4 字符/token，中日韩字符约 1.5 字符/token
    if not text:
        return 0
    cjk = sum(1 for ch in text if ord(ch) > 0x2E80)
    return int((len(text) - cjk) / 4 + cjk / 1.5) + 4


def message_tokens(m: Message) -> int:
    n = estimate_tokens(m.content)
    for tc in m.tool_calls:
        n += estimate_tokens(str(tc.arguments)) + 10
    n += IMAGE_TOKENS * len(message_images(m))
    return n


def history_tokens(system: str, messages: list[Message]) -> int:
    return estimate_tokens(system) + sum(message_tokens(m) for m in messages)


def drop_old_images(messages: list[Message], keep_recent: int = 3) -> int:
    """只保留最近 keep_recent 条消息中的图片，更早的图片替换为文字说明。返回移除的图片数。"""
    idx = [i for i, m in enumerate(messages) if message_images(m)]
    removed = 0
    for i in idx[:-keep_recent] if keep_recent > 0 else idx:
        m = messages[i]
        imgs = message_images(m)
        paths = ", ".join(img.get("path") or "?" for img in imgs)
        m.meta = {k: v for k, v in m.meta.items() if k != "images"}
        m.content += f"\n[为节省上下文，较早附带的 {len(imgs)} 张图片已移除：{paths}；如需再看请重新调用 view_image]"
        removed += len(imgs)
    return removed


def slim_old_tool_outputs(messages: list[Message], keep_recent: int = 12, max_chars: int = 3000) -> int:
    """截短较早的工具输出（保留最近 keep_recent 条完整），并移除较早的图片，返回节省的字符数（图片按 token 折算）。"""
    tool_idx = [i for i, m in enumerate(messages) if m.role == "tool"]
    saved = drop_old_images(messages) * IMAGE_TOKENS * 4
    for i in tool_idx[:-keep_recent] if len(tool_idx) > keep_recent else []:
        m = messages[i]
        if len(m.content) > max_chars and not m.meta.get("slimmed"):
            before = len(m.content)
            m.content = m.content[: max_chars // 2] + "\n...[较早的输出已截短以节省上下文]...\n" + m.content[-max_chars // 3:]
            m.meta["slimmed"] = True
            saved += before - len(m.content)
    return saved


def _transcript(messages: list[Message], per_msg: int = 2500) -> str:
    out = []
    for m in messages:
        if m.role == "user":
            out.append(f"[用户]{'(系统提醒)' if m.meta.get('system') else ''}: {m.content[:per_msg * 2]}")
        elif m.role == "assistant":
            s = f"[智能体]: {m.content[:per_msg]}"
            for tc in m.tool_calls:
                s += f"\n  -> 调用 {tc.name}({str(tc.arguments)[:600]})"
            out.append(s)
        elif m.role == "tool":
            c = m.content
            if len(c) > per_msg:
                c = c[: per_msg // 2] + " ...[略]... " + c[-per_msg // 3:]
            out.append(f"[工具结果 {m.name}{' 错误' if m.is_error else ''}]: {c}")
    return "\n\n".join(out)


async def compact_history(llm: LLMProvider, messages: list[Message], keep_tokens: int, max_summary_input_chars: int
                          ) -> tuple[list[Message], str] | None:
    """把较早的历史压缩成摘要，保留最近约 keep_tokens 的消息原文。"""
    if len(messages) < 6:
        return None
    acc, cut = 0, len(messages)
    for i in range(len(messages) - 1, 0, -1):
        acc += message_tokens(messages[i])
        if acc > keep_tokens:
            break
        cut = i
    # 保留段不能以 tool 消息开头（否则会与其 tool_call 分离）
    while cut < len(messages) and messages[cut].role == "tool":
        cut += 1
    if cut <= 2:
        return None
    old, kept = messages[:cut], messages[cut:]
    text = _transcript(old)
    if len(text) > max_summary_input_chars:
        text = _transcript(old, per_msg=600)
        if len(text) > max_summary_input_chars:
            text = text[: max_summary_input_chars // 3] + "\n...[中间部分省略]...\n" + text[-max_summary_input_chars * 2 // 3:]
    resp = await llm.complete(COMPACT_PROMPT, [Message("user", f"以下是需要压缩的工作历史：\n\n{text}")], tools=None)
    summary = resp.content.strip()
    header = Message(
        "user",
        "<system-reminder>为节省上下文，之前的对话已被压缩为以下摘要。请基于它继续完成任务。</system-reminder>\n\n" + summary,
        meta={"system": True, "compacted": True},
    )
    return [header] + kept, summary


# ---------------------------------------------------------------- 工作区快照
STACK_FILES = [
    "pyproject.toml", "setup.py", "setup.cfg", "requirements.txt", "Pipfile", "poetry.lock", "uv.lock", "environment.yml",
    "package.json", "pnpm-lock.yaml", "yarn.lock", "tsconfig.json", "deno.json", "go.mod", "Cargo.toml", "pom.xml",
    "build.gradle", "build.gradle.kts", "Gemfile", "composer.json", "CMakeLists.txt", "Makefile", "Dockerfile",
    "docker-compose.yml", "compose.yaml", ".pre-commit-config.yaml", "tox.ini", "pytest.ini", "noxfile.py",
    "AGENTS.md", "CLAUDE.md", "OMNI.md", "README.md",
]
_SKIP_TOP = {".git", ".DS_Store", "__pycache__", ".omniagent", ".venv", "venv", "node_modules",
             ".mypy_cache", ".pytest_cache", ".ruff_cache", ".idea",
             ".vscode", ".tox", ".next"}


def _git(workspace: Path, *args: str, timeout: float = 3.0) -> str | None:
    try:
        r = subprocess.run(["git", *args], cwd=str(workspace), capture_output=True, text=True, timeout=timeout,
                           env={**os.environ, "GIT_PAGER": "cat", "PAGER": "cat", "GIT_OPTIONAL_LOCKS": "0",
                                "GIT_TERMINAL_PROMPT": "0"})
    except (OSError, subprocess.SubprocessError):
        return None
    return r.stdout.rstrip("\n") if r.returncode == 0 else None


def workspace_snapshot(workspace: Path, max_status: int = 30, max_commits: int = 5, max_entries: int = 40) -> str:
    """采集工作区概况（git 分支/状态/最近提交、顶层目录、技术栈文件），用于系统提示词。

    每次 run() 只采集一次，保持系统提示词在多步之间稳定以利于提示缓存。
    """
    workspace = Path(workspace)
    parts: list[str] = []
    if _git(workspace, "rev-parse", "--is-inside-work-tree") == "true":
        branch = _git(workspace, "rev-parse", "--abbrev-ref", "HEAD") or "?"
        git_lines = [f"- Git 分支: {branch}"]
        status = _git(workspace, "status", "--short", "--untracked-files=normal")
        if status is not None:
            lines = [l for l in status.splitlines() if l.strip()]
            if lines:
                shown = lines[:max_status]
                git_lines.append(f"- git status --short（{len(lines)} 项变更）:")
                git_lines += [f"    {l}" for l in shown]
                if len(lines) > max_status:
                    git_lines.append(f"    …（另有 {len(lines) - max_status} 项未列出）")
            else:
                git_lines.append("- 工作树干净（无未提交修改）")
        log = _git(workspace, "log", f"-{max_commits}", "--date=short", "--pretty=format:%h %ad %s")
        if log:
            git_lines.append("- 最近提交:")
            git_lines += [f"    {l[:150]}" for l in log.splitlines()]
        elif log is None:
            git_lines.append("- 尚无提交")
        parts += git_lines
    try:
        entries = sorted((e for e in workspace.iterdir() if e.name not in _SKIP_TOP),
                         key=lambda e: (not e.is_dir(), e.name.lower()))
    except OSError:
        entries = []
    if entries:
        names = [e.name + ("/" if e.is_dir() else "") for e in entries[:max_entries]]
        more = f" …（共 {len(entries)} 项）" if len(entries) > max_entries else ""
        parts.append(f"- 顶层目录: {'  '.join(names)}{more}")
    else:
        parts.append("- 顶层目录: （空）")
    stack = [f for f in STACK_FILES if (workspace / f).exists()]
    if stack:
        parts.append(f"- 项目/技术栈文件: {', '.join(stack)}")
    return "\n".join(parts)
