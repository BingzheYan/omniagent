"""OmniAgent 自动化评测套件运行器（支持编程评测 + 办公/学术科研评测 + --oracle 离线轨迹验证）。"""
from __future__ import annotations

import argparse
import asyncio
import dataclasses
import hashlib
import importlib.util
import os
import shutil
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Sequence

import yaml
from rich.console import Console
from rich.table import Table

from omniagent.agent import Agent
from omniagent.config import ModelProfile, Settings, load_settings
from omniagent.llm import create_provider
from omniagent.llm.mock_provider import MockProvider

TASKS_ROOT = Path(__file__).resolve().parent / "tasks"
console = Console(highlight=False)


@dataclass
class TaskSpec:
    id: str
    category: str
    title: str
    prompt: str
    path: Path
    mode: str = "auto"
    max_steps: int = 40
    timeout: int = 600
    check: dict[str, Any] = field(default_factory=dict)


@dataclass
class EvalTaskResult:
    id: str
    category: str
    title: str
    passed: bool
    score: float
    steps: int
    elapsed: float
    details: str
    metrics: dict[str, Any] = field(default_factory=dict)
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return dataclasses.asdict(self)


@dataclass
class EvalSuiteResult:
    results: list[EvalTaskResult]
    oracle: bool = False
    model: str = "mock"
    elapsed: float = 0.0

    @property
    def total(self) -> int:
        return len(self.results)

    @property
    def passed(self) -> int:
        return sum(1 for r in self.results if r.passed)

    @property
    def pass_rate(self) -> float:
        return (self.passed / self.total) if self.total else 0.0

    @property
    def average_score(self) -> float:
        return (sum(r.score for r in self.results) / self.total) if self.total else 0.0

    def by_category(self) -> dict[str, dict[str, Any]]:
        cats: dict[str, list[EvalTaskResult]] = {}
        for r in self.results:
            cats.setdefault(r.category, []).append(r)
        out: dict[str, dict[str, Any]] = {}
        for c, items in cats.items():
            p = sum(1 for x in items if x.passed)
            out[c] = {
                "total": len(items),
                "passed": p,
                "pass_rate": p / len(items) if items else 0.0,
            }
        return out

    def to_dict(self) -> dict[str, Any]:
        return {
            "total": self.total,
            "passed": self.passed,
            "pass_rate": round(self.pass_rate, 4),
            "average_score": round(self.average_score, 4),
            "oracle": self.oracle,
            "model": self.model,
            "elapsed": round(self.elapsed, 2),
            "by_category": self.by_category(),
            "results": [r.to_dict() for r in self.results],
        }

    def to_markdown(self) -> str:
        mode_tag = "Oracle 脚本轨迹 (MockProvider)" if self.oracle else f"模型 `{self.model}`"
        lines = [
            "# OmniAgent 评测报告",
            "",
            f"- **运行模式**：{mode_tag}",
            f"- **总体通过率**：**{self.passed}/{self.total} ({self.pass_rate * 100:.1f}%)**",
            f"- **平均得分**：{self.average_score * 100:.1f}/100",
            f"- **总耗时**：{self.elapsed:.1f}s",
            "",
            "## 分类汇总",
            "",
            "| 类别 | 通过数 / 总数 | 通过率 |",
            "| :--- | :---: | :---: |",
        ]
        for cat, info in self.by_category().items():
            lines.append(f"| {cat} | {info['passed']}/{info['total']} | {info['pass_rate'] * 100:.1f}% |")

        lines += [
            "",
            "## 任务明细",
            "",
            "| 任务 ID | 类别 | 状态 | 得分 | 步数 | 耗时 | 核验说明 |",
            "| :--- | :---: | :---: | :---: | :---: | :---: | :--- |",
        ]
        for r in self.results:
            st = "PASS" if r.passed else "FAIL"
            detail = (r.error or r.details).replace("\n", " ").replace("|", "\\|")
            lines.append(
                f"| `{r.id}` | {r.category} | {st} | {r.score * 100:.1f} | {r.steps} | {r.elapsed:.1f}s | {detail[:180]} |"
            )
        lines.append("")
        return "\n".join(lines)


def _load_python_module(py_path: Path, mod_name: str):
    spec = importlib.util.spec_from_file_location(mod_name, str(py_path))
    if spec is None or spec.loader is None:
        raise RuntimeError(f"无法加载模块: {py_path}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def discover_tasks(tasks_dir: Path | None = None) -> list[TaskSpec]:
    root = Path(tasks_dir or TASKS_ROOT)
    specs: list[TaskSpec] = []
    if not root.is_dir():
        return specs
    for d in sorted(root.iterdir()):
        yml = d / "task.yaml"
        if not d.is_dir() or not yml.is_file():
            continue
        raw = yaml.safe_load(yml.read_text(encoding="utf-8")) or {}
        specs.append(
            TaskSpec(
                id=str(raw.get("id") or d.name),
                category=str(raw.get("category") or "coding"),
                title=str(raw.get("title") or d.name),
                prompt=str(raw["prompt"]),
                path=d,
                mode=str(raw.get("mode") or "auto"),
                max_steps=int(raw.get("max_steps") or 40),
                timeout=int(raw.get("timeout") or 600),
                check=dict(raw.get("check") or {}),
            )
        )
    cat_order = {"coding": 0, "office": 1}
    specs.sort(key=lambda s: (cat_order.get(s.category, 9), s.id))
    return specs


def select_tasks(all_specs: Sequence[TaskSpec], selector: str | Sequence[str] | None) -> list[TaskSpec]:
    if selector is None or selector == "all" or selector == ["all"]:
        return list(all_specs)
    if isinstance(selector, str):
        tokens = [t.strip() for t in selector.split(",") if t.strip()]
    else:
        tokens = [t.strip() for part in selector for t in str(part).split(",") if t.strip()]
    if not tokens or "all" in tokens:
        return list(all_specs)

    selected: list[TaskSpec] = []
    by_id = {s.id: s for s in all_specs}
    cat_aliases = {"coding": "coding", "code": "coding", "office": "office", "research": "office"}
    for tok in tokens:
        if tok in cat_aliases:
            target_cat = cat_aliases[tok]
            for s in all_specs:
                if s.category == target_cat and s not in selected:
                    selected.append(s)
        elif tok in by_id:
            if by_id[tok] not in selected:
                selected.append(by_id[tok])
        else:
            avail = ", ".join(sorted(by_id))
            raise ValueError(f"未知评测任务或类别 {tok!r}。可选类别: all, coding, office；可选任务: {avail}")
    return selected


def _hash_file(p: Path) -> str | None:
    if not p.exists() or not p.is_file():
        return None
    return hashlib.sha256(p.read_bytes()).hexdigest()


def _run_pytest_check(spec: TaskSpec, ws: Path) -> dict[str, Any]:
    chk = spec.check
    hidden_rel = chk.get("hidden")
    dest_rel = chk.get("dest", "tests_hidden")
    if hidden_rel:
        hidden_src = spec.path / hidden_rel
        hidden_dst = ws / dest_rel
        if hidden_dst.exists():
            shutil.rmtree(hidden_dst)
        shutil.copytree(hidden_src, hidden_dst)

    test_targets = [t for t in ("tests", dest_rel) if (ws / t).exists()]
    cmd = [sys.executable, "-m", "pytest", "-q", "-W", "ignore::pytest.PytestDeprecationWarning", f"--rootdir={ws}", *test_targets]
    env = os.environ.copy()
    venv_bin = str(Path(sys.executable).resolve().parent)
    env["PATH"] = venv_bin + os.pathsep + env.get("PATH", "")
    env["PYTHONPATH"] = str(ws) + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")

    proc = subprocess.run(
        cmd,
        cwd=str(ws),
        env=env,
        capture_output=True,
        text=True,
        timeout=int(chk.get("timeout") or 180),
    )
    stdout_clean = proc.stdout.strip()
    out = (stdout_clean + "\n" + proc.stderr.strip()).strip()
    summary_line = stdout_clean.splitlines()[-1] if stdout_clean.splitlines() else f"exit={proc.returncode}"
    passed = proc.returncode == 0
    return {
        "passed": passed,
        "score": 1.0 if passed else 0.0,
        "details": summary_line if passed else (stdout_clean[-600:] or out[-600:]),
        "metrics": {"returncode": proc.returncode},
    }


def _run_python_check(spec: TaskSpec, ws: Path, agent_result: str, events: list[dict[str, Any]]) -> dict[str, Any]:
    checker_file = spec.path / (spec.check.get("script") or "checker.py")
    mod = _load_python_module(checker_file, f"omni_eval_checker_{spec.id}")
    res = mod.check(ws, agent_result, events, spec.path)
    if isinstance(res, tuple):
        ok, msg = res
        return {"passed": bool(ok), "score": 1.0 if ok else 0.0, "details": str(msg), "metrics": {}}
    return {
        "passed": bool(res.get("passed", False)),
        "score": float(res.get("score", 1.0 if res.get("passed") else 0.0)),
        "details": str(res.get("details") or ""),
        "metrics": dict(res.get("metrics") or {}),
    }


async def run_single_task(
    spec: TaskSpec,
    *,
    oracle: bool = False,
    model: str | None = None,
    keep_workspace: bool = False,
) -> EvalTaskResult:
    ws_parent = Path(tempfile.mkdtemp(prefix=f"omni_eval_{spec.id}_"))
    ws = ws_parent / "workspace"
    src_ws = spec.path / "workspace"
    if src_ws.is_dir():
        shutil.copytree(src_ws, ws)
    else:
        ws.mkdir(parents=True, exist_ok=True)

    protected_rels = list(spec.check.get("protected") or [])
    protected_before = {rel: _hash_file(ws / rel) for rel in protected_rels}

    # 确保子进程 shell 中的 `python` 指向当前虚拟环境解释器
    venv_bin = str(Path(sys.executable).resolve().parent)
    old_path = os.environ.get("PATH", "")
    if not old_path.startswith(venv_bin + os.pathsep):
        os.environ["PATH"] = venv_bin + os.pathsep + old_path

    events: list[dict[str, Any]] = []

    async def on_event(e: dict[str, Any]) -> None:
        events.append(e)

    started = time.time()
    steps_used = 0
    try:
        if oracle:
            oracle_path = spec.path / "oracle.py"
            if not oracle_path.is_file():
                raise FileNotFoundError(f"任务 {spec.id} 缺少 oracle.py")
            oracle_mod = _load_python_module(oracle_path, f"omni_eval_oracle_{spec.id}")
            script = oracle_mod.build_script(ws)
            provider = MockProvider(ModelProfile("mock", "mock", "mock", vision=True), script)
            settings = Settings(
                default_model="mock",
                approval="auto",
                max_steps=spec.max_steps,
                python_executable=sys.executable,
            )
        else:
            settings = load_settings(ws)
            settings.approval = "auto"
            settings.python_executable = sys.executable
            prof = settings.get_model(model or "mock")
            provider = create_provider(prof)

        agent = Agent(
            provider,
            settings,
            ws,
            mode=spec.mode,
            approval="auto",
            on_event=on_event,
            max_steps=spec.max_steps,
            persist=False,
        )
        try:
            agent_result = await asyncio.wait_for(agent.run(spec.prompt), timeout=spec.timeout)
        finally:
            await agent.close()

        done_ev = next((e for e in reversed(events) if e.get("type") == "done" and e.get("depth", 0) == 0), None)
        steps_used = int(done_ev["steps"]) if done_ev else sum(1 for e in events if e.get("type") == "step")

        # 校验受保护文件未被篡改
        tampered = [rel for rel, h0 in protected_before.items() if _hash_file(ws / rel) != h0]
        if tampered:
            return EvalTaskResult(
                id=spec.id,
                category=spec.category,
                title=spec.title,
                passed=False,
                score=0.0,
                steps=steps_used,
                elapsed=round(time.time() - started, 2),
                details=f"受保护文件被修改或删除: {', '.join(tampered)}",
            )

        chk_type = (spec.check.get("type") or "pytest").lower()
        if chk_type == "pytest":
            verdict = await asyncio.to_thread(_run_pytest_check, spec, ws)
        elif chk_type == "python":
            verdict = await asyncio.to_thread(_run_python_check, spec, ws, agent_result, events)
        else:
            raise ValueError(f"未知 check.type: {chk_type!r}")

        return EvalTaskResult(
            id=spec.id,
            category=spec.category,
            title=spec.title,
            passed=verdict["passed"],
            score=verdict["score"],
            steps=steps_used,
            elapsed=round(time.time() - started, 2),
            details=verdict["details"],
            metrics=verdict["metrics"],
        )
    except Exception as exc:  # noqa: BLE001
        return EvalTaskResult(
            id=spec.id,
            category=spec.category,
            title=spec.title,
            passed=False,
            score=0.0,
            steps=steps_used,
            elapsed=round(time.time() - started, 2),
            details="",
            error=f"{type(exc).__name__}: {exc}",
        )
    finally:
        if not keep_workspace:
            shutil.rmtree(ws_parent, ignore_errors=True)


async def run_eval_suite(
    tasks: str | Sequence[str] | None = "all",
    *,
    oracle: bool = False,
    model: str | None = None,
    out: str | Path | None = None,
    tasks_dir: Path | None = None,
    keep_workspaces: bool = False,
    quiet: bool = False,
) -> EvalSuiteResult:
    """异步运行评测套件并返回结构化汇总结果（可选写出 Markdown 报告）。"""
    all_specs = discover_tasks(tasks_dir)
    selected = select_tasks(all_specs, tasks)
    suite_start = time.time()
    results: list[EvalTaskResult] = []

    for idx, spec in enumerate(selected, 1):
        if not quiet:
            console.print(f"[cyan]({idx}/{len(selected)})[/cyan] 运行 [bold]{spec.id}[/bold] · {spec.title} …")
        res = await run_single_task(spec, oracle=oracle, model=model, keep_workspace=keep_workspaces)
        results.append(res)
        if not quiet:
            badge = "[bold green]PASS[/bold green]" if res.passed else "[bold red]FAIL[/bold red]"
            msg = res.error or res.details
            console.print(f"    {badge}  ({res.steps} 步, {res.elapsed:.1f}s)  {msg[:160]}")

    suite = EvalSuiteResult(
        results=results,
        oracle=oracle,
        model="oracle-mock" if oracle else (model or "mock"),
        elapsed=round(time.time() - suite_start, 2),
    )

    if out is not None:
        out_path = Path(out)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(suite.to_markdown(), encoding="utf-8")
        if not quiet:
            console.print(f"\n📄 评测报告已保存至: [bold]{out_path}[/bold]")

    if not quiet:
        tbl = Table(title=f"OmniAgent 评测汇总（通过 {suite.passed}/{suite.total} · {suite.pass_rate * 100:.1f}%）")
        for col in ("任务 ID", "类别", "结果", "得分", "步数", "耗时"):
            tbl.add_column(col)
        for r in suite.results:
            tbl.add_row(
                r.id,
                r.category,
                "[green]PASS[/green]" if r.passed else "[red]FAIL[/red]",
                f"{r.score * 100:.1f}",
                str(r.steps),
                f"{r.elapsed:.1f}s",
            )
        console.print(tbl)

    return suite


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="python -m omniagent.evals",
        description="OmniAgent 编程与办公科研自动化评测套件",
    )
    parser.add_argument(
        "--oracle",
        action="store_true",
        help="使用每个任务内置的 oracle 脚本化轨迹在离线 MockProvider 上运行验证（不调用真实大模型 API）",
    )
    parser.add_argument(
        "--tasks",
        default="all",
        help="要运行的任务范围：all | coding | office | 单个或多个逗号分隔的任务 ID（默认 all）",
    )
    parser.add_argument(
        "--model",
        default=None,
        help="非 --oracle 模式下的模型档案名称（默认 mock）",
    )
    parser.add_argument(
        "--out",
        default=None,
        help="输出 Markdown 评测报告路径（例如 report.md）",
    )
    parser.add_argument(
        "--keep-workspaces",
        action="store_true",
        help="保留临时评测工作区目录以便调试",
    )
    parser.add_argument(
        "-q",
        "--quiet",
        action="store_true",
        help="静默模式，仅返回退出码",
    )
    argv_list = list(argv) if argv is not None else None
    if argv_list and argv_list[0] == "--":
        argv_list = argv_list[1:]
    args = parser.parse_args(argv_list)
    suite = asyncio.run(
        run_eval_suite(
            tasks=args.tasks,
            oracle=args.oracle,
            model=args.model,
            out=args.out,
            keep_workspaces=args.keep_workspaces,
            quiet=args.quiet,
        )
    )
    return 0 if suite.passed == suite.total else 1
