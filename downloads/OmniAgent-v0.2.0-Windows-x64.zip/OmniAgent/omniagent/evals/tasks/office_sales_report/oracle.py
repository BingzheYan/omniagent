"""Scripted oracle trajectory for office_sales_report."""
from __future__ import annotations

from pathlib import Path

from omniagent.llm.types import LLMResponse, ToolCall

_ANALYZE_AND_PLOT = r'''
import json
from pathlib import Path
import matplotlib.pyplot as plt
import pandas as pd
from omniagent.research import academic_style, df_to_markdown, savefig

df = pd.read_csv("data/sales_2025.csv")
missing_qty = int(df["销量"].isna().sum())
missing_rows = df[df["销量"].isna()][["月份", "地区", "产品", "单价", "销售额"]].to_dict(orient="records")

# 用销售额/单价回推或分组中位数校验缺失销量（不修改原始 CSV）
clean = df.copy()
clean["销量_填补"] = clean["销量"].fillna((clean["销售额"] / clean["单价"]).round(0))

total_rev = float(clean["销售额"].sum())
reg = (
    clean.groupby("地区", as_index=False)
    .agg(销售额_万元=("销售额", lambda s: s.sum() / 1e4), 订单记录数=("销售额", "count"), 月均销售额_万元=("销售额", lambda s: s.sum() / 12 / 1e4))
    .sort_values("销售额_万元", ascending=False)
)
reg["占比_%"] = (reg["销售额_万元"] / (total_rev / 1e4) * 100).round(2)

prod = (
    clean.groupby("产品", as_index=False)
    .agg(销售额_万元=("销售额", lambda s: s.sum() / 1e4), 总销量=("销量_填补", "sum"), 单价_元=("单价", "first"))
    .sort_values("销售额_万元", ascending=False)
)
prod["占比_%"] = (prod["销售额_万元"] / (total_rev / 1e4) * 100).round(2)

monthly = clean.groupby("月份", as_index=False)["销售额"].sum().sort_values("月份")
monthly["销售额_万元"] = monthly["销售额"] / 1e4
monthly["环比_%"] = (monthly["销售额_万元"].pct_change() * 100).round(2)

academic_style(dpi=300)
Path("outputs/figures").mkdir(parents=True, exist_ok=True)

# 图1：区域与产品结构横向对比图
fig1, (ax1, ax2) = plt.subplots(1, 2, figsize=(8.8, 3.8))
r_plot = reg.sort_values("销售额_万元", ascending=True)
cols1 = ["#1F4E79" if x == reg.iloc[0]["地区"] else "#94A3B8" for x in r_plot["地区"]]
ax1.barh(r_plot["地区"], r_plot["销售额_万元"], color=cols1)
for i, v in enumerate(r_plot["销售额_万元"]):
    ax1.text(v + 8, i, f"{v:.1f}", va="center", fontsize=9)
ax1.set_xlim(0, r_plot["销售额_万元"].max() * 1.22)
ax1.set_xlabel("销售额（万元）")
ax1.text(0.02, 0.93, "(a) 各区域销售额对比", transform=ax1.transAxes, fontweight="bold")

p_plot = prod.sort_values("销售额_万元", ascending=True)
cols2 = ["#B22222" if x == prod.iloc[0]["产品"] else "#94A3B8" for x in p_plot["产品"]]
ax2.barh(p_plot["产品"], p_plot["销售额_万元"], color=cols2)
for i, v in enumerate(p_plot["销售额_万元"]):
    ax2.text(v + 20, i, f"{v:.1f}", va="center", fontsize=9)
ax2.set_xlim(0, p_plot["销售额_万元"].max() * 1.24)
ax2.set_xlabel("销售额（万元）")
ax2.text(0.02, 0.93, "(b) 各品类销售额对比", transform=ax2.transAxes, fontweight="bold")
fig1.tight_layout()
savefig(fig1, "outputs/figures/fig1_structure.png", dpi=300)

# 图2：2025年1—12月销售额趋势折线图
fig2, ax = plt.subplots(figsize=(7.2, 3.9))
x_labels = [m.split("-")[1] + "月" for m in monthly["月份"]]
ax.plot(x_labels, monthly["销售额_万元"], marker="o", linewidth=1.8, color="#1F4E79", label="月度销售额")
ax.axhline(monthly["销售额_万元"].mean(), linestyle="--", color="#64748B", linewidth=1.0, label=f"月均水平 ({monthly['销售额_万元'].mean():.1f}万元)")
peak_idx = int(monthly["销售额_万元"].idxmax())
ax.annotate(
    f"峰值: {monthly.loc[peak_idx, '销售额_万元']:.2f}万元",
    xy=(peak_idx, monthly.loc[peak_idx, "销售额_万元"]),
    xytext=(max(0, peak_idx - 3), monthly.loc[peak_idx, "销售额_万元"] - 18),
    arrowprops={"arrowstyle": "->", "color": "#B22222"},
    fontsize=9,
    color="#B22222",
)
ax.set_xlabel("月份（2025年）")
ax.set_ylabel("销售额（万元）")
ax.legend(loc="upper left", frameon=False)
fig2.tight_layout()
savefig(fig2, "outputs/figures/fig2_monthly_trend.png", dpi=300)

# 生成报告 Markdown
peak_row = monthly.loc[monthly["销售额_万元"].idxmax()]
min_row = monthly.loc[monthly["销售额_万元"].idxmin()]
growth_full = (peak_row["销售额_万元"] / min_row["销售额_万元"] - 1) * 100

reg_md = df_to_markdown(
    reg.rename(columns={"销售额_万元": "销售额（万元）", "订单记录数": "记录数", "月均销售额_万元": "月均销售额（万元）", "占比_%": "占比（%）"}),
    digits=2,
)
prod_md = df_to_markdown(
    prod.rename(columns={"销售额_万元": "销售额（万元）", "总销量": "估算总销量（件）", "单价_元": "单价（元）", "占比_%": "占比（%）"}),
    digits=2,
)

md = f"""# 2025年度全渠道区域与产品销售经营分析报告

## 一、执行摘要与核心结论

2025年全年公司三大主力智能硬件产品在四大销售大区合计实现总销售额 **{total_rev / 1e4:,.2f}万元**（精确值 {total_rev:,.2f}元），全年经营呈现“头部区域领跑、高客单旗舰驱动、下半年稳步走高”的鲜明特征：

1. **区域格局一超三强**：**{reg.iloc[0]['地区']}**大区全年实现销售额 **{reg.iloc[0]['销售额_万元']:.2f}万元**，占全公司总营收的 **{reg.iloc[0]['占比_%']:.2f}%**，稳居第一；西南、华南、华北大区体量接近，分别贡献 {reg.iloc[1]['占比_%']:.2f}%、{reg.iloc[2]['占比_%']:.2f}% 与 {reg.iloc[3]['占比_%']:.2f}%。
2. **平板电脑贡献近七成营收**：**{prod.iloc[0]['产品']}**全年销售额达 **{prod.iloc[0]['销售额_万元']:.2f}万元**（占比 **{prod.iloc[0]['占比_%']:.2f}%**），是绝对营收支柱；智能手表与蓝牙耳机分别实现 {prod.iloc[1]['销售额_万元']:.2f}万元（{prod.iloc[1]['占比_%']:.2f}%）和 {prod.iloc[2]['销售额_万元']:.2f}万元（{prod.iloc[2]['占比_%']:.2f}%）。
3. **月度走势逐季攀升**：全年最低点出现在 **{min_row['月份']}**（{min_row['销售额_万元']:.2f}万元），年末旺季 **{peak_row['月份']}** 创下全年峰值 **{peak_row['销售额_万元']:.2f}万元**，较年初低点增长 **{growth_full:.1f}%**。

## 二、数据体检与清洗说明

本次分析基于 `data/sales_2025.csv` 原始台账（共 {len(df)} 条“月份×地区×产品”汇总记录，覆盖 2025-01 至 2025-12 共 12 个自然月、4 个大区、3 类产品）。经数据健康检查：

- **完整性核查**：`销售额`、`单价`、`月份`、`地区`、`产品` 字段完整无缺失；`销量` 字段存在 **{missing_qty} 处缺失值**（位于 2025-02 华南区平板电脑记录，当月销售额为 316,319.60元、单价 2,500元）。
- **清洗规则**：严格保持原始 `data/sales_2025.csv` 只读不改；销售额统计直接汇总精确实收金额字段，销量辅助测算采用 `销售额 / 单价` 合理回推（约 127 台），无重复行与合计混入行。

## 三、区域与产品结构分析

从区域与产品两个维度拆解全年营收构成。如图1所示，华东大区在区域维度优势突出，而平板电脑在产品维度占据主导地位。

![图1 2025年各区域与各产品品类销售额结构对比](outputs/figures/fig1_structure.png)

资料来源：基于 `data/sales_2025.csv` 全年销售数据统计绘制。

各大区具体销售额、月均规模及占比明细见表1。

表1 2025年各区域销售业绩汇总表

{reg_md}

注：销售额按原始台账精确金额折算为万元，占比保留两位小数。

表1数据显示，华东大区全年贡献 {reg.iloc[0]['销售额_万元']:.2f}万元（{reg.iloc[0]['占比_%']:.2f}%），领先第二名西南大区（{reg.iloc[1]['销售额_万元']:.2f}万元）达 {(reg.iloc[0]['销售额_万元'] - reg.iloc[1]['销售额_万元']):.2f}万元；西南、华南（{reg.iloc[2]['销售额_万元']:.2f}万元）与华北（{reg.iloc[3]['销售额_万元']:.2f}万元）三大区域差距在 15 万元以内，梯队竞争均衡。各产品品类的营收表现见表2。

表2 2025年各产品品类销售表现汇总表

{prod_md}

注：2025-02华南平板电脑缺失的1条销量已按销售额除以单价估算填补，不影响销售额精确统计。

结合表2可知，高单价的平板电脑（单价 2,500元）贡献了 {prod.iloc[0]['占比_%']:.2f}% 的销售额；蓝牙耳机虽销量基数可观，但受限于 300 元客单价，销售额占比仅为 {prod.iloc[2]['占比_%']:.2f}%，具备捆绑搭售提效空间。

## 四、月度销售趋势分析

为刻画全年增长节奏与季节性波动特征，如图2所示，2025年1—12月公司月度销售额整体围绕 {monthly['销售额_万元'].mean():.2f}万元的月均水平稳步上行。

![图2 2025年1—12月公司月度销售额演变趋势](outputs/figures/fig2_monthly_trend.png)

资料来源：基于 `data/sales_2025.csv` 月度汇总计算。

从图2走势来看，一季度受年初淡季影响，1月销售额为全年最低值 {min_row['销售额_万元']:.2f}万元；二季度起随着新品促销放量，5月突破 225 万元；下半年进入暑期返校季与年末大促周期后持续攀升，12月达到全年最高峰 {peak_row['销售额_万元']:.2f}万元，全年增长韧性充足。

## 五、经营建议与行动举措

1. **巩固华东标杆经验并深耕西南增量市场**：总结华东大区高客单平板渠道打法，向增速居前的西南大区复制政企集采与教育渠道方案，力争非华东区域单区年营收突破 750 万元。
2. **推行“平板+耳机/手表”场景化套餐联售**：针对平板电脑占比偏高、配件单品营收贡献偏低的结构特征，面向购机用户推出蓝牙耳机与智能手表组合折扣券，提升连带购买率与综合客单价。
3. **完善华南等大区ERP销量字段强校验机制**：针对体检发现的 2025-02 华南区销量漏填问题，在月度结账入库环节增加“销量—单价—销售额”勾稽校验规则，保障源头数据100%完整。
"""

Path("outputs/sales_report.md").write_text(md, encoding="utf-8")
print(json.dumps({"total_rev": round(total_rev, 2), "missing_qty": missing_qty, "peak_month": peak_row["月份"]}, ensure_ascii=False))
'''


def _todos(statuses: list[str], tag: str) -> ToolCall:
    items = [
        "加载数据分析技能并对 sales_2025.csv 做体检与图表绘制",
        "使用 view_image 核验图表并生成 Word 报告",
        "调用 check_document 自检确认得分达标",
    ]
    return ToolCall(
        f"todo_{tag}",
        "todo_write",
        {"todos": [{"content": c, "status": s} for c, s in zip(items, statuses)]},
    )


def build_script(ws: Path) -> list:
    return [
        LLMResponse("先加载 data-analysis-report 技能并建立分析计划。", [
            _todos(["in_progress", "pending", "pending"], "1"),
            ToolCall("sk1", "load_skill", {"name": "data-analysis-report"}),
            ToolCall("ls1", "list_dir", {"path": "data"}),
        ]),
        LLMResponse("运行 Python 完成数据体检、区域/品类/月度聚合统计，并绘制 2 幅高清图表与报告草稿。", [
            ToolCall("py1", "python", {"code": _ANALYZE_AND_PLOT}),
        ]),
        LLMResponse("用 view_image 逐张查看生成的图表，确认中文显示与标签排版正常。", [
            _todos(["completed", "in_progress", "pending"], "2"),
            ToolCall("vi1", "view_image", {"path": "outputs/figures/fig1_structure.png"}),
            ToolCall("vi2", "view_image", {"path": "outputs/figures/fig2_monthly_trend.png"}),
        ]),
        LLMResponse("图表清晰无遮挡，调用 create_document 生成正式 Word 报告 outputs/sales_report.docx。", [
            ToolCall("cd1", "create_document", {
                "source_path": "outputs/sales_report.md",
                "output_path": "outputs/sales_report.docx",
                "style": "report",
                "author": "经营分析组",
                "date": "2026年1月",
            }),
        ]),
        LLMResponse("调用 check_document 对 outputs/sales_report.docx 做结构与图表引用质量检查。", [
            _todos(["completed", "completed", "in_progress"], "3"),
            ToolCall("chk1", "check_document", {"path": "outputs/sales_report.docx", "doc_type": "report"}),
            _todos(["completed", "completed", "completed"], "4"),
        ]),
        LLMResponse("报告与自检已完成。", []),
        LLMResponse("最终核对生成的 docx 文本摘要。", [
            ToolCall("rv1", "read_file", {"path": "outputs/sales_report.docx"}),
        ]),
        LLMResponse(
            "已完成 `data/sales_2025.csv` 全年销售数据分析并交付 `outputs/sales_report.docx`：\n"
            "- 全年总销售额 **2,920.82万元**（29,208,152.39元），定位并说明 2025-02 华南平板电脑销量缺失 1 处；\n"
            "- 地区第一名为**华东**（877.00万元，占比 30.03%），核心品类为**平板电脑**（2,031.54万元，占比 69.55%），峰值月份为 **2025-12**（305.09万元）；\n"
            "- 内嵌 2 幅 300dpi 统计图与 2 张汇总表，`check_document` 审查高分通过。",
            [],
        ),
    ]
