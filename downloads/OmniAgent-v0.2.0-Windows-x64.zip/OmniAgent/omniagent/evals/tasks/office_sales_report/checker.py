"""Automated ground-truth checker for office_sales_report."""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any

import pandas as pd

from omniagent.tools.documents import extract_text
from omniagent.tools.research import inspect_document


def _contains_number(text: str, target: float, tol_rel: float = 0.015) -> bool:
    """Match a number expressed either in raw yuan (e.g. 29,208,152.39) or wan-yuan (e.g. 2920.82 / 2,920.8)."""
    candidates = [target, target / 1e4]
    raw_nums = re.findall(r"\d[\d,]*\.?\d*", text)
    for token in raw_nums:
        try:
            val = float(token.replace(",", ""))
        except ValueError:
            continue
        for c in candidates:
            if abs(c) > 0 and abs(val - c) / abs(c) <= tol_rel:
                return True
    return False


def check(ws: Path, agent_result: str, events: list[dict[str, Any]], task_dir: Path) -> dict[str, Any]:
    docx_candidates = [
        ws / "outputs" / "sales_report.docx",
        *(sorted((ws / "outputs").glob("*.docx")) if (ws / "outputs").exists() else []),
        *sorted(ws.glob("*.docx")),
    ]
    report_path = next((p for p in docx_candidates if p.exists()), None)
    if report_path is None:
        return {"passed": False, "score": 0.0, "details": "未找到生成的 Word 报告 (.docx)", "metrics": {}}

    doc_check = inspect_document(report_path, doc_type="report", workspace=ws)
    doc_score = int(doc_check["score"])
    valid_figs = int(doc_check["metrics"]["valid_figures_count"])
    tables_cnt = int(doc_check["metrics"]["tables_count"])

    # Ground truth computed directly from data/sales_2025.csv
    df = pd.read_csv(ws / "data" / "sales_2025.csv")
    total_rev = float(df["销售额"].sum())
    by_region = df.groupby("地区")["销售额"].sum().sort_values(ascending=False)
    top_region = str(by_region.index[0])
    top_region_rev = float(by_region.iloc[0])
    top_region_share = float(top_region_rev / total_rev * 100.0)

    by_prod = df.groupby("产品")["销售额"].sum().sort_values(ascending=False)
    top_prod = str(by_prod.index[0])
    top_prod_rev = float(by_prod.iloc[0])

    by_month = df.groupby("月份")["销售额"].sum().sort_index()
    peak_month = str(by_month.idxmax())  # 2025-12

    text = extract_text(report_path)
    failures: list[str] = []

    if valid_figs < 2:
        failures.append(f"Word 内嵌有效图片不足 2 幅（当前 {valid_figs} 幅）")
    if doc_score < 85:
        failures.append(f"check_document 得分 {doc_score} < 85（问题：{doc_check['issues']}）")
    if top_region not in text:
        failures.append(f"报告未提及销售额最高地区 {top_region}")
    if top_prod not in text:
        failures.append(f"报告未提及核心贡献品类 {top_prod}")
    if not _contains_number(text, total_rev):
        failures.append(f"未匹配到正确的全年总销售额真值（{total_rev:,.2f} 元 / {total_rev/1e4:.2f} 万元）")
    if not _contains_number(text, top_region_rev):
        failures.append(f"未匹配到 {top_region} 销售额真值（{top_region_rev:,.2f} 元 / {top_region_rev/1e4:.2f} 万元）")
    if not _contains_number(text, top_prod_rev):
        failures.append(f"未匹配到 {top_prod} 销售额真值（{top_prod_rev:,.2f} 元 / {top_prod_rev/1e4:.2f} 万元）")
    if not re.search(r"30\.0|30\.03", text):
        failures.append(f"未匹配到 {top_region} 销售占比（{top_region_share:.1f}%）")
    if "12" not in text and peak_month not in text:
        failures.append(f"未提及峰值月份 {peak_month}")

    passed = len(failures) == 0
    return {
        "passed": passed,
        "score": doc_score / 100.0 if passed else max(0.0, (doc_score - 20 * len(failures)) / 100.0),
        "details": (
            f"报告核验通过：check_document={doc_score}/100，内嵌图 {valid_figs} 幅，表 {tables_cnt} 张，核心指标与真值一致。"
            if passed
            else "；".join(failures)
        ),
        "metrics": {
            "check_document_score": doc_score,
            "embedded_figures": valid_figs,
            "tables": tables_cnt,
        },
    }
