"""Scripted oracle trajectory for office_fiscal_paper."""
from __future__ import annotations

from pathlib import Path

from omniagent.llm.types import LLMResponse, ToolCall

_RUN_ECONOMETRICS = r'''
import json
from pathlib import Path
import pandas as pd
from omniagent.research.fiscal_pipeline import build_fiscal_figures_and_markdown

df = pd.read_csv("data/fiscal_panel_2012_2023.csv")
Path("outputs/figures").mkdir(parents=True, exist_ok=True)
paper_md, gt, figs = build_fiscal_figures_and_markdown(
    df,
    Path("outputs/figures"),
    rel_fig_dir="outputs/figures",
)
Path("outputs/fiscal_paper.md").write_text(paper_md, encoding="utf-8")
summary = {
    "nobs": gt["nobs"],
    "baseline_beta": round(gt["baseline_beta"], 4),
    "baseline_se": round(gt["baseline_se"], 4),
    "did_beta": round(gt["did_beta"], 4),
    "iv_beta": round(gt["iv_beta"], 4),
    "iv_kp_f": round(gt["iv_kp_f"], 2),
    "pre_wald_p": round(gt["pre_wald_p"], 3),
    "figures": [str(p) for p in figs],
}
print(json.dumps(summary, ensure_ascii=False, indent=2))
'''


def _todos(statuses: list[str], tag: str) -> ToolCall:
    items = [
        "加载 fiscal-paper 技能并检查省级面板数据",
        "运行 PanelOLS/DID/IV/事件研究与稳健性、异质性、机制回归并生成 4 幅学术图",
        "调用 view_image 检查全部图表并以 academic 版式生成 Word 论文",
        "调用 check_document(doc_type='fiscal_paper') 完成规范审查",
    ]
    return ToolCall(
        f"todo_{tag}",
        "todo_write",
        {"todos": [{"content": c, "status": s} for c, s in zip(items, statuses)]},
    )


def build_script(ws: Path) -> list:
    return [
        LLMResponse("先加载 fiscal-paper 技能并查看工作区数据文件。", [
            _todos(["in_progress", "pending", "pending", "pending"], "1"),
            ToolCall("sk_fp", "load_skill", {"name": "fiscal-paper"}),
            ToolCall("ls_data", "list_dir", {"path": "data"}),
        ]),
        LLMResponse("在 Python 中执行完整的面板双向固定效应、交错DID、IV-2SLS、事件研究平行趋势、五项稳健性、区域与财力异质性及双渠道机制回归，生成 4 幅 300dpi 学术图与 6 张三线表并组装论文草稿。", [
            _todos(["completed", "in_progress", "pending", "pending"], "2"),
            ToolCall("py_econ", "python", {"code": _RUN_ECONOMETRICS}),
        ]),
        LLMResponse("使用 view_image 逐幅检查生成的 4 张学术图，确认中文正常显示、误差棒与图例无遮挡。", [
            _todos(["completed", "completed", "in_progress", "pending"], "3"),
            ToolCall("vi_f1", "view_image", {"path": "outputs/figures/fig1_regional_trends.png"}),
            ToolCall("vi_f2", "view_image", {"path": "outputs/figures/fig2_binscatter_fe.png"}),
            ToolCall("vi_f3", "view_image", {"path": "outputs/figures/fig3_event_study.png"}),
            ToolCall("vi_f4", "view_image", {"path": "outputs/figures/fig4_heterogeneity_forest.png"}),
        ]),
        LLMResponse("调用 create_document(style='academic') 生成《财政研究》版式的 Word 论文 outputs/fiscal_paper.docx。", [
            ToolCall("cd_paper", "create_document", {
                "source_path": "outputs/fiscal_paper.md",
                "output_path": "outputs/fiscal_paper.docx",
                "style": "academic",
                "author": "财政经济研究课题组",
                "affiliation": "（模拟面板实证研究示例，2026）",
            }),
        ]),
        LLMResponse("运行 check_document(doc_type='fiscal_paper') 进行学术结构与图表前置引用审查。", [
            _todos(["completed", "completed", "completed", "in_progress"], "4"),
            ToolCall("chk_paper", "check_document", {
                "path": "outputs/fiscal_paper.docx",
                "doc_type": "fiscal_paper",
            }),
            _todos(["completed", "completed", "completed", "completed"], "5"),
        ]),
        LLMResponse("论文排版与质量审查已完成，进入最终确认。", []),
        LLMResponse("抽查生成的 Word 文档首页与实证表格内容。", [
            ToolCall("rv_docx", "read_file", {"path": "outputs/fiscal_paper.docx", "limit": 120}),
        ]),
        LLMResponse(
            "已完成省级财政面板实证计量分析与《财政研究》风格论文撰写，交付文件 `outputs/fiscal_paper.docx`：\n"
            "- **数据与识别**：基于 2012—2023 年 30 省份模拟平衡面板（N=360），双向固定效应基准回归中 `DigSup` 系数为 **0.343***（聚类稳健标准误 0.039）；交错 DID（0.035***）、工具变量 2SLS（0.356***，KP-F=32.12）与事前平行趋势联合检验（p=0.640）均支持因果识别；\n"
            "- **异质性与机制**：中西部与低财政自给率省份治理效应更强；通过提升财政支出透明度（0.460***）与降低专项资金闲置偏离率（-0.119***）两条渠道发挥作用；\n"
            "- **规范自检**：共内嵌 4 幅学术图与 6 张三线表，`check_document(doc_type='fiscal_paper')` 得分 100/100。",
            [],
        ),
    ]
