"""Automated ground-truth checker for office_fiscal_paper."""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any

import pandas as pd

from omniagent.research.fiscal_pipeline import compute_ground_truth
from omniagent.tools.documents import extract_text
from omniagent.tools.research import inspect_document


def _has_close_float(text: str, target: float, tol_abs: float = 0.008) -> bool:
    for raw in re.findall(r"[-−]?\d+\.\d+", text):
        try:
            val = float(raw.replace("−", "-"))
        except ValueError:
            continue
        if abs(val - target) <= tol_abs:
            return True
    return False


def check(ws: Path, agent_result: str, events: list[dict[str, Any]], task_dir: Path) -> dict[str, Any]:
    docx_candidates = [
        ws / "outputs" / "fiscal_paper.docx",
        *(sorted((ws / "outputs").glob("*.docx")) if (ws / "outputs").exists() else []),
        *sorted(ws.glob("*.docx")),
    ]
    paper_path = next((p for p in docx_candidates if p.exists()), None)
    if paper_path is None:
        return {"passed": False, "score": 0.0, "details": "未找到生成的学术论文 .docx 文件", "metrics": {}}

    doc_check = inspect_document(paper_path, doc_type="fiscal_paper", workspace=ws)
    doc_score = int(doc_check["score"])
    m = doc_check["metrics"]
    issues = doc_check["issues"]
    issue_codes = {it["code"] for it in issues}

    df = pd.read_csv(ws / "data" / "fiscal_panel_2012_2023.csv")
    gt = compute_ground_truth(df)
    text = extract_text(paper_path)

    failures: list[str] = []
    if doc_score < 90:
        failures.append(f"check_document 得分 {doc_score} < 90（问题：{issues}）")
    if m["valid_figures_count"] < 4:
        failures.append(f"有效内嵌图数量 {m['valid_figures_count']} < 4")
    if m["tables_count"] < 5:
        failures.append(f"表格数量 {m['tables_count']} < 5")
    for callout_err in (
        "figure_callout_missing",
        "figure_callout_after_figure",
        "table_callout_missing",
        "table_callout_after_table",
        "figure_numbering_nonsequential",
        "table_numbering_nonsequential",
    ):
        if callout_err in issue_codes:
            failures.append(f"存在图表编号或正文前置引用违规: {callout_err}")

    # Verify required table topics exist in document text
    for topic, pat in [
        ("变量定义表", r"变量定义|变量名称|变量符号"),
        ("描述性统计表", r"描述性统计|标准差|最小值"),
        ("基准回归表", r"基准回归|双向FE|省份固定效应"),
        ("稳健性检验表", r"稳健性|剔除直辖市|缩尾"),
        ("异质性或机制表", r"异质性|中西部|机制"),
    ]:
        if not re.search(pat, text):
            failures.append(f"缺少必需的实证表格模块：{topic}")

    # Verify econometric numbers match ground truth computed on panel CSV
    if str(gt["nobs"]) not in text:
        failures.append(f"未报告正确的面板观测值总数 N={gt['nobs']}")
    if not _has_close_float(text, gt["pub_eff_mean"], tol_abs=0.005):
        failures.append(f"被解释变量 pub_eff 均值与真值 ({gt['pub_eff_mean']:.3f}) 不符")
    if not _has_close_float(text, gt["dig_sup_mean"], tol_abs=0.005):
        failures.append(f"核心解释变量 dig_sup 均值与真值 ({gt['dig_sup_mean']:.3f}) 不符")
    if not _has_close_float(text, gt["baseline_beta"], tol_abs=0.012):
        failures.append(f"双向固定效应基准回归系数与真值 ({gt['baseline_beta']:.3f}) 不符")
    if not _has_close_float(text, gt["het_mw_beta"], tol_abs=0.015):
        failures.append(f"异质性回归系数与真值 ({gt['het_mw_beta']:.3f}) 不符")

    # Verify agent invoked academic create_document, view_image, and check_document
    tool_starts = [e for e in events if e.get("type") == "tool_start"]
    called_names = {e.get("name") for e in tool_starts}
    if "view_image" not in called_names:
        failures.append("执行过程中未调用 view_image 核验生成的图表")
    if "check_document" not in called_names:
        failures.append("执行过程中未调用 check_document 进行论文质量自检")
    used_academic = any(
        e.get("name") == "create_document" and (e.get("arguments") or {}).get("style") == "academic"
        for e in tool_starts
    )
    if not used_academic:
        failures.append("未以 style='academic' 调用 create_document")

    passed = len(failures) == 0
    return {
        "passed": passed,
        "score": doc_score / 100.0 if passed else max(0.0, (doc_score - 15 * len(failures)) / 100.0),
        "details": (
            f"财政论文核验通过：check_document={doc_score}/100，图 {m['valid_figures_count']} 幅，表 {m['tables_count']} 张，"
            f"基准双向FE系数={gt['baseline_beta']:.3f}*** 与面板真值完全吻合。"
            if passed
            else "；".join(failures)
        ),
        "metrics": {
            "check_document_score": doc_score,
            "figures": m["valid_figures_count"],
            "tables": m["tables_count"],
            "total_chars": m["total_chars"],
        },
    }
