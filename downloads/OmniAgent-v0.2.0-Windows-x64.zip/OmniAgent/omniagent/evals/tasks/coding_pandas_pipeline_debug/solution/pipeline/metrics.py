"""Order & refund reconciliation metrics (reference solution)."""
from __future__ import annotations

from pathlib import Path

import pandas as pd


def _parse_money_series(s: pd.Series) -> pd.Series:
    cleaned = s.fillna("0").astype(str).str.replace(",", "", regex=False).str.strip()
    return pd.to_numeric(cleaned, errors="raise").astype(float)


def _normalize_region(val: object) -> str:
    if val is None or pd.isna(val):
        return "Unknown"
    s = str(val).strip()
    return s.title() if s else "Unknown"


def load_clean_orders(data_dir: str | Path) -> pd.DataFrame:
    data_dir = Path(data_dir)
    customers = pd.read_csv(data_dir / "customers.csv")
    orders = pd.read_csv(data_dir / "orders.csv")
    refunds = pd.read_csv(data_dir / "refunds.csv")

    # Keep latest customer record by updated_at (stable sort preserves file order on ties)
    customers["updated_at"] = pd.to_datetime(customers["updated_at"], format="ISO8601")
    customers = (
        customers.sort_values("updated_at", kind="mergesort")
        .drop_duplicates(subset=["customer_id"], keep="last")
        .copy()
    )
    customers["region"] = customers["region"].map(_normalize_region)

    # Completed orders only (case-insensitive, whitespace-tolerant)
    status_norm = orders["status"].fillna("").astype(str).str.strip().str.lower()
    completed = orders[status_norm == "completed"].copy()
    completed["order_date"] = pd.to_datetime(completed["order_date"].astype(str).str.strip(), dayfirst=True)
    completed["month"] = completed["order_date"].dt.strftime("%Y-%m")
    completed["gross_amount"] = _parse_money_series(completed["amount"]).round(2)

    # Aggregate multiple partial refunds per order_id BEFORE joining
    if len(refunds):
        refunds = refunds.copy()
        refunds["refund_amount"] = _parse_money_series(refunds["amount"])
        refund_totals = (
            refunds.groupby("order_id", as_index=False)["refund_amount"]
            .sum()
        )
        refund_totals["refund_amount"] = refund_totals["refund_amount"].round(2)
    else:
        refund_totals = pd.DataFrame(columns=["order_id", "refund_amount"])

    merged = completed.merge(customers[["customer_id", "region"]], on="customer_id", how="left")
    merged["region"] = merged["region"].fillna("Unknown")
    merged = merged.merge(refund_totals, on="order_id", how="left")
    merged["refund_amount"] = merged["refund_amount"].fillna(0.0).round(2)
    merged["net_amount"] = (merged["gross_amount"] - merged["refund_amount"]).round(2)

    cols = [
        "order_id",
        "customer_id",
        "region",
        "order_date",
        "month",
        "gross_amount",
        "refund_amount",
        "net_amount",
    ]
    return merged[cols].sort_values("order_id").reset_index(drop=True)


def monthly_region_revenue(data_dir: str | Path) -> pd.DataFrame:
    df = load_clean_orders(data_dir)
    grouped = (
        df.groupby(["month", "region"], as_index=False)
        .agg(
            order_count=("order_id", "count"),
            gross_revenue=("gross_amount", "sum"),
            refund_total=("refund_amount", "sum"),
            net_revenue=("net_amount", "sum"),
        )
        .sort_values(["month", "region"])
        .reset_index(drop=True)
    )
    for col in ("gross_revenue", "refund_total", "net_revenue"):
        grouped[col] = grouped[col].round(2)
    grouped["order_count"] = grouped["order_count"].astype(int)
    return grouped


def top_customers(data_dir: str | Path, n: int = 5) -> list[tuple[str, float]]:
    if n <= 0:
        return []
    df = load_clean_orders(data_dir)
    if df.empty:
        return []
    agg = df.groupby("customer_id", as_index=False)["net_amount"].sum()
    agg["net_amount"] = agg["net_amount"].round(2)
    agg = agg.sort_values(["net_amount", "customer_id"], ascending=[False, True]).head(n)
    return [(str(r.customer_id), round(float(r.net_amount), 2)) for r in agg.itertuples(index=False)]
