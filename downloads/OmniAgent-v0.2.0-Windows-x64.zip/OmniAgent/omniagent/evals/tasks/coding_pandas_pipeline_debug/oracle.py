"""Scripted oracle trajectory for coding_pandas_pipeline_debug."""
from __future__ import annotations

from pathlib import Path

from omniagent.llm.types import LLMResponse, ToolCall

SOLUTION_FILE = Path(__file__).resolve().parent / "solution" / "pipeline" / "metrics.py"

_DIAG = """
import pandas as pd
for name in ["customers.csv", "orders.csv", "refunds.csv"]:
    df = pd.read_csv(f"data/{name}")
    print("===", name, df.shape)
    print(df.head(5))
orders = pd.read_csv("data/orders.csv")
print("status values:", orders["status"].unique())
print("comma amounts:", orders["amount"].astype(str).str.contains(",").sum())
refunds = pd.read_csv("data/refunds.csv")
print("duplicate refund order_ids:", (refunds["order_id"].value_counts() > 1).sum())
"""

_EXTRA_TESTS = '''from pathlib import Path
import pytest
from pipeline import load_clean_orders, monthly_region_revenue, top_customers

DATA_DIR = Path(__file__).resolve().parent.parent / "data"


def test_schema_and_reconciliation():
    df = load_clean_orders(DATA_DIR)
    assert len(df) == 211
    assert df["order_id"].is_unique
    assert sorted(df["month"].unique().tolist()) == [
        "2024-01", "2024-02", "2024-03", "2024-04", "2024-05", "2024-06"
    ]
    assert sorted(df["region"].unique().tolist()) == ["East", "North", "South", "Unknown", "West"]
    by_id = df.set_index("order_id")
    assert by_id.loc["O0076", "refund_amount"] == pytest.approx(1134.78)
    assert by_id.loc["O0061", "region"] == "Unknown"

    rep = monthly_region_revenue(DATA_DIR)
    assert int(rep["order_count"].sum()) == 211
    assert round(float(rep["net_revenue"].sum()), 2) == pytest.approx(248900.75)
    assert top_customers(DATA_DIR, n=2)[0] == ("C038", 20030.02)
'''


def _todos(statuses: list[str], tag: str) -> ToolCall:
    items = [
        "阅读口径文档并探查三张 CSV 的脏数据特征",
        "修复 pipeline/metrics.py 中的 5 处清洗与关联 bug",
        "补充对账回归测试并运行 pytest",
    ]
    return ToolCall(
        f"todo_{tag}",
        "todo_write",
        {"todos": [{"content": c, "status": s} for c, s in zip(items, statuses)]},
    )


def build_script(ws: Path) -> list:
    sol_src = SOLUTION_FILE.read_text(encoding="utf-8")
    return [
        LLMResponse("先制定排查计划，阅读 README 与 pipeline/metrics.py。", [
            _todos(["in_progress", "pending", "pending"], "1"),
            ToolCall("rd_doc", "read_file", {"path": "README.md"}),
            ToolCall("rd_src", "read_file", {"path": "pipeline/metrics.py"}),
            ToolCall("rd_tst", "read_file", {"path": "tests/test_metrics.py"}),
        ]),
        LLMResponse("用 python 检查三张 CSV 的字段格式、重复键和异常字符。", [
            ToolCall("py_diag", "python", {"code": _DIAG}),
        ]),
        LLMResponse("已定位全部 5 个根因：千分位逗号变 NaN、status 空白与大小写、DD/MM/YYYY 日期误解析、客户未按最新 updated_at 去重及 inner join 丢单、退款未先按 order_id 汇总导致多笔退款翻倍。写入修复代码。", [
            _todos(["completed", "in_progress", "pending"], "2"),
            ToolCall("wr_fix", "write_file", {"path": "pipeline/metrics.py", "content": sol_src}),
        ]),
        LLMResponse("补充对账单元测试并执行 pytest。", [
            _todos(["completed", "completed", "in_progress"], "3"),
            ToolCall("wr_tst", "write_file", {"path": "tests/test_metrics.py", "content": _EXTRA_TESTS}),
            ToolCall("sh_tst", "run_shell", {"command": "python -m pytest -q"}),
        ]),
        LLMResponse("更新全部计划项为完成。", [
            _todos(["completed", "completed", "completed"], "4"),
        ]),
        LLMResponse("修复与验证已完成，准备最终自检。", []),
        LLMResponse("复核 pipeline/metrics.py。", [
            ToolCall("rv_src", "read_file", {"path": "pipeline/metrics.py"}),
        ]),
        LLMResponse(
            "已修复 `pipeline/metrics.py` 中的全部 5 处数据对账 bug：\n"
            "1. 金额解析去除千分位逗号 `,`，恢复所有千元以上大额订单与退款；\n"
            "2. `status` 去空白并忽略大小写匹配 `completed`（共 211 笔有效订单）；\n"
            "3. `order_date` 按 `dayfirst=True` 解析 `DD/MM/YYYY`，消除 7—12 月错位月份；\n"
            "4. `customers` 按 `updated_at` 升序保留最新记录，清洗空白/大小写地区名，并改用 `left` join 保留未登记客户（归为 `Unknown`）；\n"
            "5. `refunds` 先按 `order_id` 聚合求和再关联订单，避免一单多退重复计入营收。\n"
            "全部单元测试运行通过。",
            [],
        ),
    ]
