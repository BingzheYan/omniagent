# Order & Refund Revenue Pipeline (`pipeline`)

`pipeline.metrics` computes monthly regional net revenue and top customer rankings from three CSV exports in `data/`:

- `customers.csv`: `customer_id, name, region, updated_at` (`YYYY-MM-DD`)
- `orders.csv`: `order_id, customer_id, order_date, amount, status`
- `refunds.csv`: `refund_id, order_id, refund_date, amount`

## Business Specification

1. **Customers (`customers.csv`)**:
   - The export is an append-only change log: a `customer_id` may appear multiple times. Keep the record with the **latest `updated_at`** date (if tied, keep the last row in file order).
   - Normalize `region`: strip whitespace; if empty/blank or missing, use `"Unknown"`, otherwise title-case (`"North"`, `"South"`, `"East"`, `"West"`).
   - Orders whose `customer_id` is absent from `customers.csv` must still be retained with `region = "Unknown"`.

2. **Orders (`orders.csv`)**:
   - `status`: strip surrounding whitespace and match case-insensitively. Include **only** `"completed"` orders (exclude `"pending"` and `"cancelled"`).
   - `order_date`: formatted as European **`DD/MM/YYYY`** (e.g. `08/03/2024` is **2024-03-08**, March 8). Derive `month` as `"YYYY-MM"` based on `order_date`.
   - `amount`: strings may contain thousands separators (e.g. `"3,153.75"`). Parse as float rounded to 2 decimal places (`gross_amount`).

3. **Refunds (`refunds.csv`)**:
   - `amount` may also contain thousands separators (e.g. `"1,009.98"`).
   - An order may have **zero, one, or multiple partial refunds** across time. Sum all refund amounts per `order_id` (`refund_amount`, default `0.0` when no refund exists), attributed to the original order regardless of `refund_date`.
   - Refunds for non-completed orders must not introduce extra rows into completed orders.
   - `net_amount = round(gross_amount - refund_amount, 2)`.

4. **Public API (`pipeline.metrics`)**:
   - `load_clean_orders(data_dir) -> pd.DataFrame`:
     Sorted by `order_id` ascending (reset index), with exact columns:
     `["order_id", "customer_id", "region", "order_date", "month", "gross_amount", "refund_amount", "net_amount"]`
     (`order_date` as `datetime64[ns]`).
   - `monthly_region_revenue(data_dir) -> pd.DataFrame`:
     Grouped by `["month", "region"]`, sorted by `["month", "region"]` ascending (reset index), with exact columns:
     `["month", "region", "order_count", "gross_revenue", "refund_total", "net_revenue"]`
     (monetary columns rounded to 2 decimals, `order_count` as int).
   - `top_customers(data_dir, n=5) -> list[tuple[str, float]]`:
     Top `n` `(customer_id, net_revenue)` pairs across completed orders, sorted by `(-net_revenue, customer_id)` with `net_revenue` rounded to 2 decimals.
