"""Order & refund reconciliation metrics (contains bugs reported by Finance)."""
from __future__ import annotations

from pathlib import Path

import pandas as pd


def load_clean_orders(data_dir: str | Path) -> pd.DataFrame:
    data_dir = Path(data_dir)
    customers = pd.read_csv(data_dir / "customers.csv")
    orders = pd.read_csv(data_dir / "orders.csv")
    refunds = pd.read_csv(data_dir / "refunds.csv")

    # Deduplicate customers
    customers = customers.drop_duplicates(subset=["customer_id"], keep="first").copy()
    customers["region"] = customers["region"].fillna("Unknown")

    # Filter completed orders and parse fields
    completed = orders[orders["status"] == "completed"].copy()
    completed["order_date"] = pd.to_datetime(completed["order_date"], format="mixed")
    completed["month"] = completed["order_date"].dt.strftime("%Y-%m")
    completed["gross_amount"] = pd.to_numeric(completed["amount"], errors="coerce").fillna(0.0).round(2)

    refunds["refund_amount"] = pd.to_numeric(refunds["amount"], errors="coerce").fillna(0.0)

    merged = completed.merge(customers[["customer_id", "region"]], on="customer_id", how="inner")
    merged = merged.merge(refunds[["order_id", "refund_amount"]], on="order_id", how="left")
    merged["refund_amount"] = merged["refund_amount"].fillna(0.0).round(2)
    merged["net_amount"] = (merged["gross_amount"] - merged["refund_amount"]).round(2)

    cols = [
        "order_id",
        "customer_id",
        "region",
        "order_date",
        "month",
        "gross_amount",
        "refund_amount",
        "net_amount",
    ]
    return merged[cols].sort_values("order_id").reset_index(drop=True)


def monthly_region_revenue(data_dir: str | Path) -> pd.DataFrame:
    df = load_clean_orders(data_dir)
    grouped = (
        df.groupby(["month", "region"], as_index=False)
        .agg(
            order_count=("order_id", "count"),
            gross_revenue=("gross_amount", "sum"),
            refund_total=("refund_amount", "sum"),
            net_revenue=("net_amount", "sum"),
        )
        .sort_values(["month", "region"])
        .reset_index(drop=True)
    )
    for col in ("gross_revenue", "refund_total", "net_revenue"):
        grouped[col] = grouped[col].round(2)
    grouped["order_count"] = grouped["order_count"].astype(int)
    return grouped


def top_customers(data_dir: str | Path, n: int = 5) -> list[tuple[str, float]]:
    df = load_clean_orders(data_dir)
    agg = df.groupby("customer_id", as_index=False)["net_amount"].sum()
    agg["net_amount"] = agg["net_amount"].round(2)
    agg = agg.sort_values(["net_amount", "customer_id"], ascending=[False, True]).head(n)
    return [(str(r.customer_id), float(r.net_amount)) for r in agg.itertuples(index=False)]
