from pathlib import Path

from pipeline import load_clean_orders, monthly_region_revenue, top_customers

DATA_DIR = Path(__file__).resolve().parent.parent / "data"


def test_schema_and_non_empty():
    df = load_clean_orders(DATA_DIR)
    assert list(df.columns) == [
        "order_id",
        "customer_id",
        "region",
        "order_date",
        "month",
        "gross_amount",
        "refund_amount",
        "net_amount",
    ]
    assert len(df) > 100

    rep = monthly_region_revenue(DATA_DIR)
    assert list(rep.columns) == [
        "month",
        "region",
        "order_count",
        "gross_revenue",
        "refund_total",
        "net_revenue",
    ]
    top = top_customers(DATA_DIR, n=3)
    assert len(top) == 3
