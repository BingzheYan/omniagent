"""Hidden acceptance suite for coding_pandas_pipeline_debug."""
from __future__ import annotations

from pathlib import Path

import pandas as pd
import pytest

from pipeline import load_clean_orders, monthly_region_revenue, top_customers

DATA_DIR = Path(__file__).resolve().parent.parent / "data"


def test_real_dataset_exact_totals():
    df = load_clean_orders(DATA_DIR)
    assert len(df) == 211
    assert df["order_id"].is_unique
    assert list(df["order_id"]) == sorted(df["order_id"])
    assert sorted(df["region"].unique().tolist()) == ["East", "North", "South", "Unknown", "West"]
    assert sorted(df["month"].unique().tolist()) == [
        "2024-01", "2024-02", "2024-03", "2024-04", "2024-05", "2024-06"
    ]
    assert round(float(df["gross_amount"].sum()), 2) == pytest.approx(260584.69, abs=0.01)
    assert round(float(df["refund_amount"].sum()), 2) == pytest.approx(11683.94, abs=0.01)
    assert round(float(df["net_amount"].sum()), 2) == pytest.approx(248900.75, abs=0.01)


def test_comma_formatted_amounts_and_multi_refunds():
    df = load_clean_orders(DATA_DIR).set_index("order_id")
    # O0076 had amount "3,026.10" and TWO partial refunds: 756.52 + 378.26 = 1134.78
    row = df.loc["O0076"]
    assert row["gross_amount"] == pytest.approx(3026.10)
    assert row["refund_amount"] == pytest.approx(1134.78)
    assert row["net_amount"] == pytest.approx(1891.32)

    # O0151 had status " COMPLETED ", amount "4,039.92", refund "1,009.98", and C014 moved west -> SOUTH
    r151 = df.loc["O0151"]
    assert r151["region"] == "South"
    assert r151["month"] == "2024-04"  # 12/04/2024 -> April 12, NOT Dec 4!
    assert r151["gross_amount"] == pytest.approx(4039.92)
    assert r151["refund_amount"] == pytest.approx(1009.98)
    assert r151["net_amount"] == pytest.approx(3029.94)


def test_unlisted_customer_and_blank_region_preserved():
    df = load_clean_orders(DATA_DIR).set_index("order_id")
    # C099 is not in customers.csv at all
    assert df.loc["O0061", "region"] == "Unknown"
    assert df.loc["O0061", "gross_amount"] == pytest.approx(4347.82)
    # C012 has whitespace-only region "  "
    assert df.loc["O0003", "region"] == "Unknown"
    # Pending order O0155 (which has a refund R034) must NOT appear
    assert "O0155" not in df.index


def test_monthly_region_and_top_customers():
    rep = monthly_region_revenue(DATA_DIR)
    assert int(rep["order_count"].sum()) == 211
    assert round(float(rep["net_revenue"].sum()), 2) == pytest.approx(248900.75, abs=0.01)

    top5 = top_customers(DATA_DIR, n=5)
    assert top5 == [
        ("C038", 20030.02),
        ("C020", 17493.17),
        ("C022", 15019.57),
        ("C033", 12417.40),
        ("C001", 12114.86),
    ]


def test_synthetic_edge_cases(tmp_path: Path):
    (tmp_path / "customers.csv").write_text(
        "customer_id,name,region,updated_at\n"
        "C1,Alice, north ,2024-01-01\n"
        "C1,Alice,WEST,2024-05-01\n"
        "C2,Bob,   ,2024-02-01\n",
        encoding="utf-8",
    )
    (tmp_path / "orders.csv").write_text(
        "order_id,customer_id,order_date,amount,status\n"
        'O1,C1,02/05/2024,"1,200.50", Completed \n'
        "O2,C2,15/05/2024,100.00,completed\n"
        "O3,C9,20/05/2024,50.00,COMPLETED\n"
        "O4,C1,21/05/2024,999.00,pending\n",
        encoding="utf-8",
    )
    (tmp_path / "refunds.csv").write_text(
        "refund_id,order_id,refund_date,amount\n"
        'R1,O1,2024-06-01,"1,000.00"\n'
        "R2,O1,2024-06-10,50.25\n"
        "R3,O4,2024-05-25,100.00\n",
        encoding="utf-8",
    )
    clean = load_clean_orders(tmp_path).set_index("order_id")
    assert list(clean.index) == ["O1", "O2", "O3"]
    assert clean.loc["O1", "region"] == "West"
    assert clean.loc["O1", "month"] == "2024-05"
    assert clean.loc["O1", "net_amount"] == pytest.approx(150.25)
    assert clean.loc["O2", "region"] == "Unknown"
    assert clean.loc["O3", "region"] == "Unknown"
