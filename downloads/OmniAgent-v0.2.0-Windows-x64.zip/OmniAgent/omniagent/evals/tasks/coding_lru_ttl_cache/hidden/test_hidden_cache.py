"""Hidden acceptance tests for the LRU+TTL cache specification."""
import threading

import pytest

from ttlcache import CacheStats, TTLCache, cached


class FakeClock:
    def __init__(self, now: float = 1000.0) -> None:
        self.now = now

    def __call__(self) -> float:
        return self.now

    def advance(self, seconds: float) -> None:
        self.now += seconds


@pytest.fixture
def clock():
    return FakeClock()


# --------------------------------------------------------------------------- construction
@pytest.mark.parametrize("kwargs", [{"maxsize": 0}, {"maxsize": -1}, {"maxsize": 2.5}, {"maxsize": True},
                                    {"ttl": 0}, {"ttl": -3}])
def test_invalid_constructor_args(kwargs):
    with pytest.raises(ValueError):
        TTLCache(**kwargs)


def test_set_rejects_non_positive_ttl(clock):
    cache = TTLCache(4, clock=clock)
    with pytest.raises(ValueError):
        cache.set("a", 1, ttl=0)


# --------------------------------------------------------------------------- LRU behaviour
def test_get_refreshes_recency_and_eviction_counts(clock):
    cache = TTLCache(3, clock=clock)
    for k in "abc":
        cache[k] = k.upper()
    assert cache.get("a") == "A"
    cache["d"] = "D"
    assert cache.keys() == ["c", "a", "d"]
    assert cache.stats.evictions == 1


def test_replacing_existing_key_moves_to_end_without_eviction(clock):
    cache = TTLCache(2, clock=clock)
    cache["a"] = 1
    cache["b"] = 2
    cache["a"] = 10
    assert cache.keys() == ["b", "a"]
    assert cache.stats.evictions == 0
    cache["c"] = 3
    assert cache.keys() == ["a", "c"]
    assert cache["a"] == 10


def test_contains_and_peek_do_not_touch_recency_or_stats(clock):
    cache = TTLCache(2, clock=clock)
    cache["a"] = 1
    cache["b"] = 2
    assert "a" in cache
    assert cache.peek("a") == 1
    assert cache.peek("zzz", "d") == "d"
    cache["c"] = 3  # "a" is still LRU and must be evicted
    assert "a" not in cache
    assert cache.stats.hits == 0 and cache.stats.misses == 0


def test_getitem_and_delitem_raise_keyerror(clock):
    cache = TTLCache(2, clock=clock)
    with pytest.raises(KeyError):
        cache["nope"]
    with pytest.raises(KeyError):
        del cache["nope"]
    assert cache.stats.misses == 1


def test_none_values_are_real_values(clock):
    cache = TTLCache(2, clock=clock)
    cache["a"] = None
    assert "a" in cache
    assert cache["a"] is None
    assert cache.stats.hits == 1


# --------------------------------------------------------------------------- TTL
def test_expiry_boundary_is_inclusive(clock):
    cache = TTLCache(4, ttl=10, clock=clock)
    cache["a"] = 1
    clock.advance(9.5)
    assert "a" in cache
    clock.advance(0.5)  # exactly t + ttl
    assert "a" not in cache
    assert cache.stats.expirations == 1


def test_expired_get_counts_miss_and_expiration_once(clock):
    cache = TTLCache(4, ttl=5, clock=clock)
    cache["a"] = 1
    clock.advance(5)
    assert cache.get("a", "gone") == "gone"
    assert cache.get("a", "gone") == "gone"
    assert cache.stats == CacheStats(hits=0, misses=2, evictions=0, expirations=1)


def test_per_entry_ttl_overrides_default_and_none_means_forever(clock):
    cache = TTLCache(4, ttl=5, clock=clock)
    cache.set("short", 1, ttl=1)
    cache.set("forever", 2, ttl=None)
    cache.set("default", 3)
    clock.advance(2)
    assert cache.keys() == ["forever", "default"]
    clock.advance(10_000)
    assert cache.keys() == ["forever"]


def test_overwrite_restarts_ttl(clock):
    cache = TTLCache(4, ttl=10, clock=clock)
    cache["a"] = 1
    clock.advance(8)
    cache["a"] = 2
    clock.advance(8)
    assert cache.get("a") == 2


def test_insert_into_full_cache_purges_expired_before_evicting(clock):
    cache = TTLCache(3, clock=clock)
    cache.set("old", 0, ttl=1)
    cache.set("b", 1)
    cache.set("c", 2)
    clock.advance(5)
    cache.set("d", 3)
    assert cache.keys() == ["b", "c", "d"]
    assert cache.stats.evictions == 0
    assert cache.stats.expirations == 1


def test_len_and_purge_expired(clock):
    cache = TTLCache(10, ttl=3, clock=clock)
    for i in range(5):
        cache[i] = i
        clock.advance(1)
    # inserted at t=0..4, now t=5: keys 0,1,2 expired (expire at 3,4,5)
    assert cache.purge_expired() == 3
    assert len(cache) == 2
    assert cache.purge_expired() == 0
    assert cache.stats.expirations == 3


def test_delete_returns_false_for_expired_entry(clock):
    cache = TTLCache(4, ttl=1, clock=clock)
    cache["a"] = 1
    cache["b"] = 2
    assert cache.delete("a") is True
    assert cache.delete("a") is False
    clock.advance(1)
    assert cache.delete("b") is False
    assert cache.stats.expirations == 1


def test_stats_hit_rate_and_reset(clock):
    cache = TTLCache(4, clock=clock)
    assert cache.stats.hit_rate == 0.0
    cache["a"] = 1
    cache.get("a")
    cache.get("a")
    cache.get("x")
    assert cache.stats.hit_rate == pytest.approx(2 / 3)
    snapshot = cache.stats
    cache.reset_stats()
    assert cache.stats == CacheStats()
    assert snapshot.hits == 2  # snapshot is immutable
    with pytest.raises(Exception):
        snapshot.hits = 5  # type: ignore[misc]


def test_clear_keeps_stats(clock):
    cache = TTLCache(4, clock=clock)
    cache["a"] = 1
    cache.get("a")
    cache.clear()
    assert len(cache) == 0
    assert cache.stats.hits == 1


def test_thread_safety_under_contention():
    cache = TTLCache(50)
    errors = []
    n_threads, n_ops = 8, 2000

    def worker(tid: int) -> None:
        try:
            for i in range(n_ops):
                key = (tid * 7 + i) % 120
                cache.set(key, i)
                cache.get((key + 3) % 120)
                if i % 10 == 0:
                    cache.delete((key + 5) % 120)
        except Exception as e:  # pragma: no cover - reported below
            errors.append(e)

    threads = [threading.Thread(target=worker, args=(t,)) for t in range(n_threads)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert not errors
    assert len(cache) <= 50
    s = cache.stats
    assert s.hits + s.misses == n_threads * n_ops


# --------------------------------------------------------------------------- decorator
def test_cached_kwargs_order_insensitive_but_positional_distinct():
    calls = []

    @cached(maxsize=16)
    def f(a=0, b=0):
        calls.append((a, b))
        return a * 10 + b

    assert f(a=1, b=2) == 12
    assert f(b=2, a=1) == 12
    assert len(calls) == 1
    f(1, 2)
    assert len(calls) == 2
    info = f.cache_info()
    assert info.hits == 1 and info.misses == 2


def test_cached_caches_none_and_falsy_results():
    calls = []

    @cached()
    def lookup(x):
        calls.append(x)
        return None if x == "none" else 0

    lookup("none")
    lookup("none")
    lookup("zero")
    lookup("zero")
    assert calls == ["none", "zero"]


def test_cached_does_not_cache_exceptions():
    calls = []

    @cached()
    def flaky(x):
        calls.append(x)
        if len(calls) == 1:
            raise RuntimeError("boom")
        return x

    with pytest.raises(RuntimeError):
        flaky(1)
    assert flaky(1) == 1
    assert flaky(1) == 1
    assert calls == [1, 1]


def test_cached_unhashable_arguments_bypass_cache():
    calls = []

    @cached()
    def total(xs, scale=1):
        calls.append(1)
        return sum(xs) * scale

    assert total([1, 2, 3]) == 6
    assert total([1, 2, 3]) == 6
    assert total((1, 2), scale=[2][0]) == 6
    assert len(calls) == 3
    info = total.cache_info()
    assert info.hits == 0 and info.misses == 1


def test_cached_ttl_with_clock_and_metadata(clock):
    calls = []

    @cached(maxsize=4, ttl=30, clock=clock)
    def fetch(user_id: int) -> dict:
        """Fetch a user."""
        calls.append(user_id)
        return {"id": user_id}

    assert fetch.__name__ == "fetch"
    assert fetch.__doc__ == "Fetch a user."
    assert callable(fetch.__wrapped__)
    fetch(1)
    clock.advance(29)
    fetch(1)
    clock.advance(1)
    fetch(1)
    assert calls == [1, 1]
    assert isinstance(fetch.cache, TTLCache)


def test_cached_maxsize_eviction_and_cache_clear():
    calls = []

    @cached(maxsize=2)
    def ident(x):
        calls.append(x)
        return x

    ident(1)
    ident(2)
    ident(1)
    ident(3)  # evicts 2
    ident(2)
    assert calls == [1, 2, 3, 2]
    ident.cache_clear()
    assert ident.cache_info() == CacheStats()
    ident(1)
    assert calls[-1] == 1 and len(calls) == 5
