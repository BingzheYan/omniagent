"""``@cached`` memoization decorator built on :class:`TTLCache`."""
from __future__ import annotations

import functools
import threading
import time
from typing import Any, Callable, Hashable, TypeVar

from .cache import MISSING, CacheStats, Clock, TTLCache

F = TypeVar("F", bound=Callable[..., Any])

_KWMARK = object()  # separates positional from keyword arguments in cache keys


def make_key(args: tuple[Any, ...], kwargs: dict[str, Any]) -> Hashable:
    """Build a hashable cache key; keyword order is irrelevant.

    Raises ``TypeError`` if any argument is unhashable.
    """
    key: tuple[Any, ...] = args
    if kwargs:
        key = args + (_KWMARK,) + tuple(sorted(kwargs.items()))
    hash(key)
    return key


def cached(maxsize: int = 128, ttl: float | None = None, *, clock: Clock = time.monotonic) -> Callable[[F], F]:
    """Memoize a function in a :class:`TTLCache` (see README.md)."""

    def decorator(func: F) -> F:
        cache: TTLCache[Hashable, Any] = TTLCache(maxsize, ttl, clock=clock)
        lock = threading.Lock()

        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            try:
                key = make_key(args, kwargs)
            except TypeError:
                return func(*args, **kwargs)
            value = cache.get(key, MISSING)
            if value is not MISSING:
                return value
            value = func(*args, **kwargs)
            with lock:
                cache.set(key, value)
            return value

        def cache_info() -> CacheStats:
            return cache.stats

        def cache_clear() -> None:
            cache.clear()
            cache.reset_stats()

        wrapper.cache = cache  # type: ignore[attr-defined]
        wrapper.cache_info = cache_info  # type: ignore[attr-defined]
        wrapper.cache_clear = cache_clear  # type: ignore[attr-defined]
        return wrapper  # type: ignore[return-value]

    return decorator
