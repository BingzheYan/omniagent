"""Thread-safe LRU cache with per-entry TTL.  See README.md for the full specification."""
from __future__ import annotations

import threading
import time
from collections import OrderedDict
from dataclasses import dataclass
from typing import Any, Callable, Generic, Hashable, Iterator, TypeVar

K = TypeVar("K", bound=Hashable)
V = TypeVar("V")

Clock = Callable[[], float]


class _Missing:
    """Sentinel type used to distinguish "argument not given" from ``None``."""

    _instance: "_Missing | None" = None

    def __new__(cls) -> "_Missing":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __repr__(self) -> str:
        return "<MISSING>"


MISSING: Any = _Missing()


@dataclass(frozen=True)
class CacheStats:
    """Immutable snapshot of cache counters."""

    hits: int = 0
    misses: int = 0
    evictions: int = 0
    expirations: int = 0

    @property
    def hit_rate(self) -> float:
        lookups = self.hits + self.misses
        return self.hits / lookups if lookups else 0.0


@dataclass
class _Entry(Generic[V]):
    value: V
    expires_at: float | None  # absolute clock time, None = never


def _validate_ttl(ttl: float | None) -> None:
    if ttl is None:
        return
    if isinstance(ttl, bool) or not isinstance(ttl, (int, float)) or not ttl > 0:
        raise ValueError(f"ttl must be a positive number or None, got {ttl!r}")


class TTLCache(Generic[K, V]):
    """LRU cache whose entries additionally expire after a time-to-live."""

    def __init__(self, maxsize: int = 128, ttl: float | None = None, *, clock: Clock = time.monotonic) -> None:
        if isinstance(maxsize, bool) or not isinstance(maxsize, int) or maxsize < 1:
            raise ValueError(f"maxsize must be an int >= 1, got {maxsize!r}")
        _validate_ttl(ttl)
        self.maxsize = maxsize
        self.ttl = ttl
        self._clock = clock
        self._data: OrderedDict[K, _Entry[V]] = OrderedDict()
        self._lock = threading.RLock()
        self._hits = self._misses = self._evictions = self._expirations = 0

    # ------------------------------------------------------------------ internals
    def _is_expired(self, entry: _Entry[V], now: float) -> bool:
        return entry.expires_at is not None and now >= entry.expires_at

    def _live_entry(self, key: K) -> _Entry[V] | None:
        """Return the live entry for ``key``, removing it (and counting) if expired. Lock must be held."""
        entry = self._data.get(key)
        if entry is None:
            return None
        if self._is_expired(entry, self._clock()):
            del self._data[key]
            self._expirations += 1
            return None
        return entry

    def _purge_locked(self) -> int:
        now = self._clock()
        expired = [k for k, e in self._data.items() if self._is_expired(e, now)]
        for k in expired:
            del self._data[k]
        self._expirations += len(expired)
        return len(expired)

    # ------------------------------------------------------------------ lookups
    def get(self, key: K, default: Any = None) -> V | Any:
        with self._lock:
            entry = self._live_entry(key)
            if entry is None:
                self._misses += 1
                return default
            self._data.move_to_end(key)
            self._hits += 1
            return entry.value

    def __getitem__(self, key: K) -> V:
        value = self.get(key, MISSING)
        if value is MISSING:
            raise KeyError(key)
        return value

    def peek(self, key: K, default: Any = None) -> V | Any:
        with self._lock:
            entry = self._live_entry(key)
            return default if entry is None else entry.value

    def __contains__(self, key: object) -> bool:
        with self._lock:
            return self._live_entry(key) is not None  # type: ignore[arg-type]

    # ------------------------------------------------------------------ mutation
    def set(self, key: K, value: V, ttl: float | None = MISSING) -> None:
        if ttl is MISSING:
            ttl = self.ttl
        else:
            _validate_ttl(ttl)
        with self._lock:
            now = self._clock()
            entry = _Entry(value, None if ttl is None else now + ttl)
            if key in self._data:
                self._data[key] = entry
                self._data.move_to_end(key)
                return
            if len(self._data) >= self.maxsize:
                self._purge_locked()
                if len(self._data) >= self.maxsize:
                    self._data.popitem(last=False)
                    self._evictions += 1
            self._data[key] = entry

    def __setitem__(self, key: K, value: V) -> None:
        self.set(key, value)

    def delete(self, key: K) -> bool:
        with self._lock:
            entry = self._live_entry(key)
            if entry is None:
                return False
            del self._data[key]
            return True

    def __delitem__(self, key: K) -> None:
        if not self.delete(key):
            raise KeyError(key)

    def purge_expired(self) -> int:
        with self._lock:
            return self._purge_locked()

    def clear(self) -> None:
        with self._lock:
            self._data.clear()

    # ------------------------------------------------------------------ introspection
    def __len__(self) -> int:
        with self._lock:
            self._purge_locked()
            return len(self._data)

    def keys(self) -> list[K]:
        with self._lock:
            self._purge_locked()
            return list(self._data)

    def __iter__(self) -> Iterator[K]:
        return iter(self.keys())

    @property
    def stats(self) -> CacheStats:
        with self._lock:
            return CacheStats(self._hits, self._misses, self._evictions, self._expirations)

    def reset_stats(self) -> None:
        with self._lock:
            self._hits = self._misses = self._evictions = self._expirations = 0

    def __repr__(self) -> str:
        return f"TTLCache(maxsize={self.maxsize}, ttl={self.ttl}, size={len(self._data)})"
