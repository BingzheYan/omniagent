"""Scripted oracle trajectory for coding_lru_ttl_cache."""
from __future__ import annotations

from pathlib import Path

from omniagent.llm.types import LLMResponse, ToolCall

SOLUTION_DIR = Path(__file__).resolve().parent / "solution" / "ttlcache"


def _todos(statuses: list[str], tag: str) -> ToolCall:
    items = [
        "阅读 README 规格与起步测试",
        "实现线程安全 TTLCache 与 CacheStats",
        "实现 @cached 装饰器并运行测试验证",
    ]
    return ToolCall(
        f"todo_{tag}",
        "todo_write",
        {"todos": [{"content": c, "status": s} for c, s in zip(items, statuses)]},
    )


def build_script(ws: Path) -> list:
    cache_src = (SOLUTION_DIR / "cache.py").read_text(encoding="utf-8")
    deco_src = (SOLUTION_DIR / "decorators.py").read_text(encoding="utf-8")
    return [
        LLMResponse("先制定实施计划，阅读规格说明与现有代码骨架。", [
            _todos(["in_progress", "pending", "pending"], "1"),
            ToolCall("rd_readme", "read_file", {"path": "README.md"}),
            ToolCall("rd_cache", "read_file", {"path": "ttlcache/cache.py"}),
            ToolCall("rd_deco", "read_file", {"path": "ttlcache/decorators.py"}),
            ToolCall("rd_test", "read_file", {"path": "tests/test_cache.py"}),
        ]),
        LLMResponse("规格已明确，开始实现 TTLCache（LRU + 独立条目 TTL + 惰性过期 + 满容量先清理过期再淘汰 + RLock 线程安全）。", [
            _todos(["completed", "in_progress", "pending"], "2"),
            ToolCall("wr_cache", "write_file", {"path": "ttlcache/cache.py", "content": cache_src}),
        ]),
        LLMResponse("实现 @cached 装饰器（参数规范化、不可哈希参数旁路、cache_info / cache_clear）。", [
            _todos(["completed", "completed", "in_progress"], "3"),
            ToolCall("wr_deco", "write_file", {"path": "ttlcache/decorators.py", "content": deco_src}),
        ]),
        LLMResponse("运行 pytest 验证全部行为与边界条件。", [
            ToolCall("run_pytest", "run_shell", {"command": "python -m pytest -q"}),
        ]),
        LLMResponse("更新计划状态。", [
            _todos(["completed", "completed", "completed"], "4"),
        ]),
        LLMResponse("代码与测试已完成，进入自检。", []),
        LLMResponse("核对已写入的缓存与装饰器模块。", [
            ToolCall("rv_deco", "read_file", {"path": "ttlcache/decorators.py"}),
        ]),
        LLMResponse(
            "已严格按 README 规格完成实现并通过 pytest 测试：\n"
            "- `ttlcache/cache.py`：实现 `CacheStats.hit_rate` 与基于 `OrderedDict + RLock` 的 `TTLCache`，支持每条目独立 TTL、"
            "`now >= expires_at` 惰性过期、满容量插入前自动 `purge_expired`、`peek`/`__contains__` 不污染统计、`None` 值缓存。\n"
            "- `ttlcache/decorators.py`：实现 `@cached` 装饰器，支持关键字顺序无关缓存键、不可哈希参数自动降级直调，以及 `cache_info()` / `cache_clear()`。",
            [],
        ),
    ]
