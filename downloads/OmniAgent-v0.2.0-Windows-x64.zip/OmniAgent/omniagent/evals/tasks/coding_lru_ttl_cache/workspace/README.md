# ttlcache

An in-process **LRU cache with per-entry TTL**, used by our API gateway to cache
upstream lookups.  This document is the specification — the implementation in
`ttlcache/cache.py` and `ttlcache/decorators.py` must follow it exactly.

## `TTLCache(maxsize=128, ttl=None, *, clock=time.monotonic)`

| argument  | meaning |
|-----------|---------|
| `maxsize` | maximum number of entries; must be an `int >= 1`, otherwise `ValueError` (note: `bool` is not accepted). |
| `ttl`     | default time-to-live in seconds for new entries. `None` = entries never expire. Must be `> 0` if given, otherwise `ValueError`. |
| `clock`   | zero-argument callable returning the current time in seconds (injectable for tests). |

### Expiry

* An entry stored at time `t` with ttl `d` is **expired once `clock() >= t + d`**.
* Expiration is **lazy**: expired entries are removed when they are touched by
  `get`, `[]`, `peek`, `in`, `delete`, `set` of a new key into a full cache, `len()`, `keys()`,
  or by an explicit `purge_expired()` call.
* Every expired entry that is removed counts **exactly once** in `stats.expirations`.

### Operations

* `get(key, default=None)` — return the value of a live entry and mark it most-recently used
  (counts a **hit**). If the key is missing or expired, return `default` (counts a **miss**;
  an expired entry is removed and counted as an expiration).
* `cache[key]` — like `get` but raises `KeyError` on a miss (stats are updated the same way).
* `set(key, value, ttl=<default>)` — insert or replace. `ttl` overrides the cache default for this
  entry; passing `ttl=None` explicitly means *this entry never expires*. A `ttl` that is not `None`
  must be `> 0` (`ValueError`). Replacing an existing key updates its value, restarts its TTL and
  marks it most-recently used; it never evicts anything.
  When a **new** key is inserted into a full cache, all expired entries are purged first; only if the
  cache is still full is the **least-recently-used** entry evicted (counts an **eviction**).
* `cache[key] = value` — `set` with the default ttl.
* `delete(key) -> bool` — remove the entry; returns `True` if a *live* entry was removed, `False` if the key
  was missing or already expired.
* `del cache[key]` — like `delete` but raises `KeyError` if there was no live entry.
* `key in cache` — `True` iff a live entry exists. Does **not** change recency and does **not** count hits/misses.
* `peek(key, default=None)` — return the value without changing recency or hit/miss stats.
* `len(cache)` — number of live entries.
* `keys()` — list of live keys ordered from least- to most-recently used.
* `purge_expired() -> int` — remove all expired entries, return how many were removed.
* `clear()` — remove everything (stats are kept).
* `stats` — a frozen `CacheStats(hits, misses, evictions, expirations)` snapshot with a `hit_rate`
  property (`hits / (hits + misses)`, `0.0` when there were no lookups).
* `reset_stats()` — zero all counters.

All public methods must be **thread-safe** (one internal lock is fine).

## `@cached(maxsize=128, ttl=None, *, clock=time.monotonic)`

Memoizes a function in a `TTLCache`.

* The cache key is built from the positional arguments and the keyword arguments;
  keyword argument **order does not matter** (`f(a=1, b=2)` and `f(b=2, a=1)` share an entry).
  Positional and keyword spellings are *not* unified (`f(1)` and `f(x=1)` are different keys).
* Return values are cached even when they are `None` or other falsy values.
* Exceptions raised by the function are propagated and **not** cached.
* If any argument is unhashable, the function is simply called (no caching, no hit/miss counted).
* The wrapper keeps the wrapped function's metadata (`functools.wraps`) and exposes
  `wrapper.cache` (the `TTLCache`), `wrapper.cache_info()` (returns `cache.stats`) and
  `wrapper.cache_clear()` (clears entries **and** resets stats).

## Development

```bash
python -m pytest -q
```
