"""``@cached`` memoization decorator built on :class:`TTLCache`."""
from __future__ import annotations

import time
from typing import Any, Callable, TypeVar

from .cache import Clock

F = TypeVar("F", bound=Callable[..., Any])


def cached(maxsize: int = 128, ttl: float | None = None, *, clock: Clock = time.monotonic) -> Callable[[F], F]:
    """Memoize a function in a :class:`TTLCache` (see README.md for the exact semantics)."""
    raise NotImplementedError
