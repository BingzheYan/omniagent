"""Thread-safe LRU cache with per-entry TTL.  See README.md for the full specification."""
from __future__ import annotations

import threading
import time
from collections import OrderedDict
from dataclasses import dataclass
from typing import Any, Callable, Generic, Hashable, Iterator, TypeVar

K = TypeVar("K", bound=Hashable)
V = TypeVar("V")

Clock = Callable[[], float]


class _Missing:
    """Sentinel type used to distinguish "argument not given" from ``None``."""

    _instance: "_Missing | None" = None

    def __new__(cls) -> "_Missing":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __repr__(self) -> str:
        return "<MISSING>"


MISSING: Any = _Missing()


@dataclass(frozen=True)
class CacheStats:
    """Immutable snapshot of cache counters."""

    hits: int = 0
    misses: int = 0
    evictions: int = 0
    expirations: int = 0

    @property
    def hit_rate(self) -> float:
        """``hits / (hits + misses)``, or ``0.0`` if there were no lookups."""
        raise NotImplementedError


class TTLCache(Generic[K, V]):
    """LRU cache whose entries additionally expire after a time-to-live.

    TODO(gateway-team): implement according to README.md.  ``OrderedDict`` +
    ``threading.RLock`` are the suggested building blocks.
    """

    def __init__(self, maxsize: int = 128, ttl: float | None = None, *, clock: Clock = time.monotonic) -> None:
        raise NotImplementedError

    # ------------------------------------------------------------------ lookups
    def get(self, key: K, default: Any = None) -> V | Any:
        """Return the live value for ``key`` (a hit) or ``default`` (a miss)."""
        raise NotImplementedError

    def __getitem__(self, key: K) -> V:
        raise NotImplementedError

    def peek(self, key: K, default: Any = None) -> V | Any:
        """Return the value without touching recency or hit/miss counters."""
        raise NotImplementedError

    def __contains__(self, key: object) -> bool:
        raise NotImplementedError

    # ------------------------------------------------------------------ mutation
    def set(self, key: K, value: V, ttl: float | None = MISSING) -> None:
        """Insert or replace ``key``. ``ttl`` overrides the default; ``None`` = never expires."""
        raise NotImplementedError

    def __setitem__(self, key: K, value: V) -> None:
        raise NotImplementedError

    def delete(self, key: K) -> bool:
        """Remove ``key``; return ``True`` if a live entry was removed."""
        raise NotImplementedError

    def __delitem__(self, key: K) -> None:
        raise NotImplementedError

    def purge_expired(self) -> int:
        """Remove all expired entries and return how many were removed."""
        raise NotImplementedError

    def clear(self) -> None:
        raise NotImplementedError

    # ------------------------------------------------------------------ introspection
    def __len__(self) -> int:
        raise NotImplementedError

    def keys(self) -> list[K]:
        """Live keys, least- to most-recently used."""
        raise NotImplementedError

    def __iter__(self) -> Iterator[K]:
        return iter(self.keys())

    @property
    def stats(self) -> CacheStats:
        raise NotImplementedError

    def reset_stats(self) -> None:
        raise NotImplementedError
