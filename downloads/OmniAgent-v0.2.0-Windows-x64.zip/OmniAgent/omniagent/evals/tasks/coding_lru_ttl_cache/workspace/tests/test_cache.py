"""Starter tests — extend as you implement the cache."""
from ttlcache import TTLCache, cached


class FakeClock:
    """Manually advanced clock for deterministic TTL tests."""

    def __init__(self, now: float = 0.0) -> None:
        self.now = now

    def __call__(self) -> float:
        return self.now

    def advance(self, seconds: float) -> None:
        self.now += seconds


def test_set_and_get():
    cache = TTLCache(maxsize=2)
    cache.set("a", 1)
    assert cache.get("a") == 1
    assert cache.get("missing", "dflt") == "dflt"


def test_lru_eviction():
    cache = TTLCache(maxsize=2)
    cache["a"] = 1
    cache["b"] = 2
    cache.get("a")
    cache["c"] = 3
    assert "b" not in cache
    assert cache.keys() == ["a", "c"]


def test_ttl_expiry():
    clock = FakeClock()
    cache = TTLCache(maxsize=10, ttl=5, clock=clock)
    cache["a"] = 1
    clock.advance(4.9)
    assert cache.get("a") == 1
    clock.advance(1)
    assert cache.get("a") is None


def test_cached_decorator_basic():
    calls = []

    @cached(maxsize=8)
    def square(x):
        calls.append(x)
        return x * x

    assert square(3) == 9
    assert square(3) == 9
    assert calls == [3]
