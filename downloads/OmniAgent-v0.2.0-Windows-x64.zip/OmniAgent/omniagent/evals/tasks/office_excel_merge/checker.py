"""Automated ground-truth checker for office_excel_merge."""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any

import openpyxl
import pandas as pd


def _parse_money(val: Any) -> float:
    s = re.sub(r"[¥￥,\s元]", "", str(val or ""))
    return round(float(s), 2)


def _compute_ground_truth(data_dir: Path) -> dict[str, Any]:
    records: list[dict[str, Any]] = []

    specs = [
        ("华东区_订单台账.xlsx", "华东", "订单号", "下单日期", "客户名称", "产品类别", "订单金额", "状态", None),
        ("华南区_销售明细.xlsx", "华南", "单号", "交易日期", "客户", "品类", "销售额(元)", "订单状态", None),
        ("北方及西南_导出表.xlsx", None, "OrderID", "日期", "客户名称", "品类", "成交金额", "状态", "区域"),
    ]
    for fname, fixed_reg, c_id, c_dt, c_cust, c_cat, c_amt, c_st, c_reg in specs:
        raw = pd.read_excel(data_dir / fname)
        for _, r in raw.iterrows():
            oid = str(r.get(c_id) or "").strip()
            if not oid or any(k in oid for k in ("合计", "小计", "总计", "nan")):
                continue
            status = str(r.get(c_st) or "").strip()
            if status != "已完成":
                continue
            reg = fixed_reg if fixed_reg else str(r.get(c_reg) or "").strip()
            records.append({
                "订单号": oid,
                "日期": pd.to_datetime(r[c_dt]).strftime("%Y-%m-%d"),
                "区域": reg,
                "客户名称": str(r[c_cust]).strip(),
                "产品类别": str(r[c_cat]).strip(),
                "金额": _parse_money(r[c_amt]),
            })

    df = pd.DataFrame(records).drop_duplicates(subset=["订单号"], keep="first").sort_values("订单号").reset_index(drop=True)
    return {
        "count": len(df),
        "grand_total": round(float(df["金额"].sum()), 2),
        "by_region": {k: round(float(v), 2) for k, v in df.groupby("区域")["金额"].sum().items()},
        "by_category": {k: round(float(v), 2) for k, v in df.groupby("产品类别")["金额"].sum().items()},
    }


def check(ws: Path, agent_result: str, events: list[dict[str, Any]], task_dir: Path) -> dict[str, Any]:
    out_candidates = [
        ws / "outputs" / "区域销售合并汇总.xlsx",
        *(sorted((ws / "outputs").glob("*.xlsx")) if (ws / "outputs").exists() else []),
        *sorted(ws.glob("*.xlsx")),
    ]
    xlsx_path = next((p for p in out_candidates if p.exists()), None)
    if xlsx_path is None:
        return {"passed": False, "score": 0.0, "details": "未找到生成的汇总 Excel 文件 (.xlsx)", "metrics": {}}

    gt = _compute_ground_truth(ws / "data")
    wb = openpyxl.load_workbook(xlsx_path, data_only=True)
    sheet_names = wb.sheetnames
    failures: list[str] = []

    if len(sheet_names) < 2:
        failures.append(f"工作簿至少需包含明细与汇总 2 个工作表，当前仅 {sheet_names}")

    # Check header styling on first sheet
    ws0 = wb[sheet_names[0]]
    header_bold = any(cell.font and cell.font.bold for cell in ws0[1])
    if not header_bold:
        failures.append("首行表头未设置加粗格式")

    sheets_df = pd.read_excel(xlsx_path, sheet_name=None)
    detail_name = next((n for n in sheet_names if "明细" in n or "订单" in n), sheet_names[0])
    detail_df = sheets_df[detail_name].dropna(how="all")
    # Exclude optional bottom total row if present in detail sheet
    first_col = detail_df.columns[0]
    detail_rows = detail_df[~detail_df[first_col].astype(str).str.contains("合计|总计|小计", na=False)]

    amt_col = next((c for c in detail_rows.columns if "金额" in str(c) or "销售" in str(c)), None)
    if amt_col is None:
        failures.append(f"明细表未找到金额列：{list(detail_rows.columns)}")
    else:
        actual_count = len(detail_rows)
        actual_total = round(float(pd.to_numeric(detail_rows[amt_col], errors="coerce").sum()), 2)
        if actual_count != gt["count"]:
            failures.append(f"清洗去重后有效订单数应为 {gt['count']}，实际为 {actual_count}")
        if abs(actual_total - gt["grand_total"]) > 0.05:
            failures.append(f"清洗后总销售额应为 {gt['grand_total']:,.2f}，实际为 {actual_total:,.2f}")

        reg_col = next((c for c in detail_rows.columns if "区域" in str(c) or "地区" in str(c)), None)
        if reg_col is not None:
            actual_by_reg = {
                str(k).strip(): round(float(v), 2)
                for k, v in detail_rows.groupby(reg_col)[amt_col].sum().items()
            }
            for rk, rv in gt["by_region"].items():
                if abs(actual_by_reg.get(rk, -1.0) - rv) > 0.05:
                    failures.append(f"区域 {rk} 汇总金额不符：期望 {rv:,.2f}，实际 {actual_by_reg.get(rk)}")

        cat_col = next((c for c in detail_rows.columns if "类" in str(c) or "品" in str(c)), None)
        if cat_col is not None:
            actual_by_cat = {
                str(k).strip(): round(float(v), 2)
                for k, v in detail_rows.groupby(cat_col)[amt_col].sum().items()
            }
            for ck, cv in gt["by_category"].items():
                if abs(actual_by_cat.get(ck, -1.0) - cv) > 0.05:
                    failures.append(f"品类 {ck} 汇总金额不符：期望 {cv:,.2f}，实际 {actual_by_cat.get(ck)}")

    passed = len(failures) == 0
    return {
        "passed": passed,
        "score": 1.0 if passed else max(0.0, 1.0 - 0.25 * len(failures)),
        "details": (
            f"Excel 清洗合并核验通过：共 {len(sheet_names)} 个工作表，唯一有效订单 {gt['count']} 笔，"
            f"销售总额 {gt['grand_total']:,.2f} 元与真值完全一致。"
            if passed
            else "；".join(failures)
        ),
        "metrics": {
            "sheets": len(sheet_names),
            "valid_orders": gt["count"],
            "grand_total": gt["grand_total"],
        },
    }
