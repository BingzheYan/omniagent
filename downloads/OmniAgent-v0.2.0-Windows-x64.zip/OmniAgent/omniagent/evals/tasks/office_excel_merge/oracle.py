"""Scripted oracle trajectory for office_excel_merge."""
from __future__ import annotations

from pathlib import Path

from omniagent.llm.types import LLMResponse, ToolCall

_CLEAN_AND_EXPORT = r'''
import json, re
from pathlib import Path
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

def clean_money(v):
    s = re.sub(r"[¥￥,\s元]", "", str(v or ""))
    return round(float(s), 2)

specs = [
    ("data/华东区_订单台账.xlsx", "华东", "订单号", "下单日期", "客户名称", "产品类别", "订单金额", "状态", None),
    ("data/华南区_销售明细.xlsx", "华南", "单号", "交易日期", "客户", "品类", "销售额(元)", "订单状态", None),
    ("data/北方及西南_导出表.xlsx", None, "OrderID", "日期", "客户名称", "品类", "成交金额", "状态", "区域"),
]

raw_total_rows = 0
summary_dropped = 0
invalid_status_dropped = 0
records = []

for path, fixed_reg, c_id, c_dt, c_cust, c_cat, c_amt, c_st, c_reg in specs:
    df_raw = pd.read_excel(path)
    raw_total_rows += len(df_raw)
    for _, r in df_raw.iterrows():
        oid = str(r.get(c_id) or "").strip()
        if not oid or oid.lower() == "nan" or any(k in oid for k in ("合计", "小计", "总计")):
            summary_dropped += 1
            continue
        st = str(r.get(c_st) or "").strip()
        if st != "已完成":
            invalid_status_dropped += 1
            continue
        reg = fixed_reg if fixed_reg else str(r.get(c_reg) or "").strip()
        records.append({
            "订单号": oid,
            "日期": pd.to_datetime(r[c_dt]).strftime("%Y-%m-%d"),
            "区域": reg,
            "客户名称": str(r[c_cust]).strip(),
            "产品类别": str(r[c_cat]).strip(),
            "金额": clean_money(r[c_amt]),
        })

before_dedup = len(records)
df = pd.DataFrame(records).drop_duplicates(subset=["订单号"], keep="first").sort_values("订单号").reset_index(drop=True)
dup_dropped = before_dedup - len(df)
grand_total = round(float(df["金额"].sum()), 2)

reg_sum = (
    df.groupby("区域", as_index=False)
    .agg(有效订单数=("订单号", "count"), 销售总额=("金额", "sum"))
    .sort_values("销售总额", ascending=False)
)
reg_sum["销售总额"] = reg_sum["销售总额"].round(2)
reg_sum["占比(%)"] = (reg_sum["销售总额"] / grand_total * 100).round(2)

cat_sum = (
    df.groupby("产品类别", as_index=False)
    .agg(有效订单数=("订单号", "count"), 销售总额=("金额", "sum"))
    .sort_values("销售总额", ascending=False)
)
cat_sum["销售总额"] = cat_sum["销售总额"].round(2)
cat_sum["占比(%)"] = (cat_sum["销售总额"] / grand_total * 100).round(2)

Path("outputs").mkdir(parents=True, exist_ok=True)
wb = Workbook()
wb.remove(wb.active)

header_fill = PatternFill("solid", fgColor="1F4E79")
header_font = Font(bold=True, color="FFFFFF", size=11)
total_fill = PatternFill("solid", fgColor="EEF3FA")
total_font = Font(bold=True, color="1F3864")
thin_border = Border(bottom=Side(style="thin", color="D0D7DE"))

def add_styled_sheet(title: str, frame: pd.DataFrame, money_cols: set[str], add_total: bool = False):
    ws = wb.create_sheet(title)
    cols = list(frame.columns)
    ws.append(cols)
    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center")
    for _, row in frame.iterrows():
        ws.append([row[c] for c in cols])
    if add_total:
        t_row = []
        for idx, c in enumerate(cols):
            if idx == 0:
                t_row.append("合计")
            elif c == "有效订单数":
                t_row.append(int(frame[c].sum()))
            elif c in money_cols:
                t_row.append(round(float(frame[c].sum()), 2))
            elif c == "占比(%)":
                t_row.append(100.0)
            else:
                t_row.append("")
        ws.append(t_row)
        for cell in ws[ws.max_row]:
            cell.fill = total_fill
            cell.font = total_font
    for r_idx in range(2, ws.max_row + 1):
        for c_idx, c_name in enumerate(cols, 1):
            cell = ws.cell(r_idx, c_idx)
            cell.border = thin_border
            if c_name in money_cols:
                cell.number_format = "#,##0.00"
                cell.alignment = Alignment(horizontal="right")
            elif c_name in ("占比(%)",):
                cell.number_format = "0.00"
                cell.alignment = Alignment(horizontal="right")
    ws.freeze_panes = "A2"
    for col in ws.columns:
        max_w = max(
            (sum(2 if "\u4e00" <= ch <= "\u9fff" else 1 for ch in str(c.value)) for c in col if c.value is not None),
            default=10,
        )
        ws.column_dimensions[get_column_letter(col[0].column)].width = min(max(max_w + 4, 12), 42)

add_styled_sheet("清洗后明细", df, {"金额"}, add_total=False)
add_styled_sheet("区域汇总", reg_sum, {"销售总额"}, add_total=True)
add_styled_sheet("品类汇总", cat_sum, {"销售总额"}, add_total=True)

out_file = "outputs/区域销售合并汇总.xlsx"
wb.save(out_file)

print(json.dumps({
    "raw_total_rows": raw_total_rows,
    "summary_dropped": summary_dropped,
    "invalid_status_dropped": invalid_status_dropped,
    "dup_dropped": dup_dropped,
    "valid_orders": len(df),
    "grand_total": grand_total,
    "by_region": reg_sum.to_dict(orient="records"),
    "by_category": cat_sum.to_dict(orient="records"),
}, ensure_ascii=False, indent=2))
'''


def _todos(statuses: list[str], tag: str) -> ToolCall:
    items = [
        "检查三份大区 Excel 台账的表头差异与脏数据情况",
        "使用 Python 清洗、去重、合并并导出多工作表格式化 Excel",
        "重新读取生成的汇总工作簿核对各项合计勾稽关系",
    ]
    return ToolCall(
        f"todo_{tag}",
        "todo_write",
        {"todos": [{"content": c, "status": s} for c, s in zip(items, statuses)]},
    )


def build_script(ws: Path) -> list:
    return [
        LLMResponse("先制定清洗合并计划，并用 read_file 查看三份原始 Excel 文件的表头与数据样本。", [
            _todos(["in_progress", "pending", "pending"], "1"),
            ToolCall("rd_e1", "read_file", {"path": "data/华东区_订单台账.xlsx"}),
            ToolCall("rd_e2", "read_file", {"path": "data/华南区_销售明细.xlsx"}),
            ToolCall("rd_e3", "read_file", {"path": "data/北方及西南_导出表.xlsx"}),
        ]),
        LLMResponse("已摸清全部脏数据特征：不同列名、¥与千分位字符串、3条合计/小计/总计行、3条已作废/已取消行、以及同表/跨表重复单号（含 ORD-1002、ORD-1003、ORD-3004）。执行 Python 清洗去重并生成格式化多表 Excel。", [
            _todos(["completed", "in_progress", "pending"], "2"),
            ToolCall("py_merge", "python", {"code": _CLEAN_AND_EXPORT}),
        ]),
        LLMResponse("用 read_file 打开生成的 outputs/区域销售合并汇总.xlsx 复核三张工作表与勾稽总额。", [
            _todos(["completed", "completed", "in_progress"], "3"),
            ToolCall("rd_out", "read_file", {"path": "outputs/区域销售合并汇总.xlsx"}),
            _todos(["completed", "completed", "completed"], "4"),
        ]),
        LLMResponse("全部清洗与对账核验已完成。", []),
        LLMResponse("确认原始数据目录完好。", [
            ToolCall("ls_d", "list_dir", {"path": "data"}),
        ]),
        LLMResponse(
            "已完成三份大区销售台账的清洗、去重与合并，结果保存至 `outputs/区域销售合并汇总.xlsx`（原始文件保持未动）：\n"
            "- **数据清洗留痕**：原始共 20 行记录，剔除“本页合计/总计/小计”汇总行 **3 行**、剔除“已作废/已取消”无效订单 **3 行**、剔除同表及跨表重复订单号 **3 行**（`ORD-1002`、`ORD-1003`、`ORD-3004`），最终保留唯一有效已完成订单 **11 笔**；\n"
            "- **核对总销售额**：**669,900.50 元**（其中华东 225,700.50 元、华南 205,200.00 元、华北 130,500.00 元、西南 108,500.00 元；数据分析平台 310,400.00 元、安全网关 190,100.50 元、云计算服务 169,400.00 元）；\n"
            "- **工作簿结构**：包含 `清洗后明细`、`区域汇总`、`品类汇总` 三个工作表，已统一设置深蓝加粗表头、千分位两位小数金额格式、首行冻结与自适应列宽。",
            [],
        ),
    ]
