"""Safe recursive-descent mathematical expression parser & evaluator."""
from __future__ import annotations

import math
import re
from dataclasses import dataclass
from typing import Callable, Mapping


class ExprError(ValueError):
    """Base error for expression parsing and evaluation."""


class ExprSyntaxError(ExprError):
    """Raised when an expression cannot be lexed or parsed."""


class UnknownIdentifierError(ExprError):
    """Raised when a variable or function name is not defined."""


class ExprEvalError(ExprError):
    """Raised on arithmetic/domain/arity evaluation errors."""


Number = int | float


def _fn_round(x: Number, ndigits: Number | None = None) -> Number:
    if ndigits is None:
        return round(x)
    if isinstance(ndigits, float) and not ndigits.is_integer():
        raise ExprEvalError("round() ndigits must be an integer")
    return round(x, int(ndigits))


def _fn_min(*args: Number) -> Number:
    if not args:
        raise ExprEvalError("min() requires at least 1 argument")
    return min(args)


def _fn_max(*args: Number) -> Number:
    if not args:
        raise ExprEvalError("max() requires at least 1 argument")
    return max(args)


def _fn_sum(*args: Number) -> Number:
    if not args:
        raise ExprEvalError("sum() requires at least 1 argument")
    return sum(args)


def _fn_log(x: Number, base: Number | None = None) -> float:
    return math.log(x) if base is None else math.log(x, base)


BUILTIN_CONSTANTS: dict[str, Number] = {
    "pi": math.pi,
    "e": math.e,
    "tau": math.tau,
}

BUILTIN_FUNCTIONS: dict[str, Callable[..., Number]] = {
    "abs": abs,
    "round": _fn_round,
    "min": _fn_min,
    "max": _fn_max,
    "sum": _fn_sum,
    "sqrt": math.sqrt,
    "sin": math.sin,
    "cos": math.cos,
    "tan": math.tan,
    "log": _fn_log,
    "exp": math.exp,
    "floor": math.floor,
    "ceil": math.ceil,
    "pow": pow,
}

_TOKEN_SPEC = re.compile(
    r"""
    (?P<WS>\s+)
    |(?P<NUM>(?:\d+\.\d*|\.\d+|\d+)(?:[eE][+-]?\d+)?)
    |(?P<OP>\*\*|//|[+\-*/%(),=])
    |(?P<IDENT>[A-Za-z_][A-Za-z0-9_]*)
    """,
    re.VERBOSE,
)


@dataclass(frozen=True)
class Token:
    kind: str  # NUM | OP | IDENT | EOF
    value: str
    pos: int


def tokenize(text: str) -> list[Token]:
    if not isinstance(text, str):
        raise ExprSyntaxError("expression must be a string")
    tokens: list[Token] = []
    idx = 0
    n = len(text)
    while idx < n:
        m = _TOKEN_SPEC.match(text, idx)
        if not m:
            raise ExprSyntaxError(f"unexpected character {text[idx]!r} at position {idx}")
        idx = m.end()
        if m.lastgroup == "WS":
            continue
        tokens.append(Token(m.lastgroup or "OP", m.group(0), m.start()))
    tokens.append(Token("EOF", "", n))
    return tokens


def _check_number(val: object) -> Number:
    if isinstance(val, bool) or not isinstance(val, (int, float)):
        raise ExprEvalError(f"non-numeric value {val!r}")
    if isinstance(val, float) and not math.isfinite(val):
        raise ExprEvalError(f"non-finite numeric result: {val}")
    return val


class _Parser:
    def __init__(
        self,
        tokens: list[Token],
        vars_map: Mapping[str, Number],
        funcs_map: Mapping[str, Callable[..., Number]],
    ) -> None:
        self.tokens = tokens
        self.pos = 0
        self.vars_map = vars_map
        self.funcs_map = funcs_map

    def peek(self) -> Token:
        return self.tokens[self.pos]

    def advance(self) -> Token:
        tok = self.tokens[self.pos]
        self.pos += 1
        return tok

    def match_op(self, *ops: str) -> Token | None:
        tok = self.peek()
        if tok.kind == "OP" and tok.value in ops:
            self.pos += 1
            return tok
        return None

    def expect_op(self, op: str) -> Token:
        tok = self.match_op(op)
        if tok is None:
            got = self.peek()
            raise ExprSyntaxError(f"expected {op!r} at position {got.pos}, got {got.value or 'EOF'!r}")
        return tok

    def parse_top(self, *, allow_assign: bool) -> tuple[str | None, Number]:
        if self.peek().kind == "EOF":
            raise ExprSyntaxError("empty expression")
        if not allow_assign:
            eq_tok = next((t for t in self.tokens if t.kind == "OP" and t.value == "="), None)
            if eq_tok is not None:
                raise ExprSyntaxError(f"assignment '=' is not allowed at position {eq_tok.pos}")
        if (
            allow_assign
            and self.peek().kind == "IDENT"
            and self.pos + 1 < len(self.tokens)
            and self.tokens[self.pos + 1].kind == "OP"
            and self.tokens[self.pos + 1].value == "="
        ):
            ident = self.advance().value
            self.advance()  # consume '='
            val = self.parse_expr()
            if self.peek().kind != "EOF":
                bad = self.peek()
                raise ExprSyntaxError(f"unexpected token {bad.value!r} at position {bad.pos}")
            return ident, val

        val = self.parse_expr()
        if self.peek().kind != "EOF":
            bad = self.peek()
            raise ExprSyntaxError(f"unexpected token {bad.value!r} at position {bad.pos}")
        return None, val

    def parse_expr(self) -> Number:
        left = self.parse_term()
        while tok := self.match_op("+", "-"):
            right = self.parse_term()
            left = _check_number(left + right if tok.value == "+" else left - right)
        return left

    def parse_term(self) -> Number:
        left = self.parse_unary()
        while tok := self.match_op("*", "/", "//", "%"):
            right = self.parse_unary()
            op = tok.value
            if op == "*":
                left = _check_number(left * right)
            else:
                if right == 0:
                    raise ExprEvalError(f"division or modulo by zero ({op})")
                if op == "/":
                    left = _check_number(left / right)
                elif op == "//":
                    left = _check_number(left // right)
                else:
                    left = _check_number(left % right)
        return left

    def parse_unary(self) -> Number:
        if tok := self.match_op("+", "-"):
            operand = self.parse_unary()
            return _check_number(+operand if tok.value == "+" else -operand)
        return self.parse_power()

    def parse_power(self) -> Number:
        base = self.parse_atom()
        if self.match_op("**"):
            # Right-associative; exponent allows unary prefix (e.g. 2 ** -3)
            exp = self.parse_unary()
            try:
                res = base ** exp
            except (ZeroDivisionError, ValueError, OverflowError) as exc:
                raise ExprEvalError(str(exc)) from None
            if isinstance(res, complex):
                raise ExprEvalError("complex result is not supported")
            return _check_number(res)
        return base

    def parse_atom(self) -> Number:
        tok = self.peek()
        if tok.kind == "NUM":
            self.advance()
            raw = tok.value
            if "." in raw or "e" in raw or "E" in raw:
                return _check_number(float(raw))
            return int(raw)

        if tok.kind == "OP" and tok.value == "(":
            self.advance()
            if self.peek().kind == "OP" and self.peek().value == ")":
                raise ExprSyntaxError(f"empty parentheses at position {tok.pos}")
            val = self.parse_expr()
            self.expect_op(")")
            return val

        if tok.kind == "IDENT":
            self.advance()
            name = tok.value
            if self.match_op("("):
                args: list[Number] = []
                if not self.match_op(")"):
                    while True:
                        args.append(self.parse_expr())
                        if self.match_op(","):
                            if self.peek().kind == "OP" and self.peek().value == ")":
                                raise ExprSyntaxError(f"trailing comma in call to {name}()")
                            continue
                        self.expect_op(")")
                        break
                fn = self.funcs_map.get(name)
                if fn is None:
                    raise UnknownIdentifierError(f"unknown function: {name!r}")
                try:
                    out = fn(*args)
                except ExprError:
                    raise
                except (ValueError, TypeError, ZeroDivisionError, OverflowError) as exc:
                    raise ExprEvalError(f"error in {name}(): {exc}") from None
                return _check_number(out)

            if name in self.vars_map:
                return _check_number(self.vars_map[name])
            raise UnknownIdentifierError(f"undefined variable: {name!r}")

        raise ExprSyntaxError(f"unexpected token {tok.value or 'EOF'!r} at position {tok.pos}")


class Evaluator:
    """Stateful expression evaluator supporting ``name = expr`` assignments."""

    def __init__(
        self,
        variables: Mapping[str, Number] | None = None,
        functions: Mapping[str, Callable[..., Number]] | None = None,
    ) -> None:
        self.variables: dict[str, Number] = {}
        if variables:
            for k, v in variables.items():
                self.variables[str(k)] = _check_number(v)
        self.functions: dict[str, Callable[..., Number]] = {**BUILTIN_FUNCTIONS, **(dict(functions) if functions else {})}

    def eval(self, expr: str) -> Number:
        tokens = tokenize(expr)
        merged_vars = {**BUILTIN_CONSTANTS, **self.variables}
        target, val = _Parser(tokens, merged_vars, self.functions).parse_top(allow_assign=True)
        if target is not None:
            self.variables[target] = val
        return val


def evaluate(
    expr: str,
    variables: Mapping[str, Number] | None = None,
    functions: Mapping[str, Callable[..., Number]] | None = None,
) -> Number:
    """Stateless evaluation of a single expression (assignments disallowed)."""
    merged_vars: dict[str, Number] = dict(BUILTIN_CONSTANTS)
    if variables:
        for k, v in variables.items():
            merged_vars[str(k)] = _check_number(v)
    merged_funcs: dict[str, Callable[..., Number]] = {**BUILTIN_FUNCTIONS, **(dict(functions) if functions else {})}
    tokens = tokenize(expr)
    _, val = _Parser(tokens, merged_vars, merged_funcs).parse_top(allow_assign=False)
    return val
