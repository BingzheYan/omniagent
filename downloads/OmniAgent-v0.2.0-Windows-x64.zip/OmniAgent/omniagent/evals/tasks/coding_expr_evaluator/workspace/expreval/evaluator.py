"""Expression parser & evaluator skeleton. See README.md for full specification."""
from __future__ import annotations

from typing import Callable, Mapping


class ExprError(ValueError):
    """Base error for expression parsing and evaluation."""


class ExprSyntaxError(ExprError):
    """Raised when an expression cannot be lexed or parsed."""


class UnknownIdentifierError(ExprError):
    """Raised when a variable or function name is not defined."""


class ExprEvalError(ExprError):
    """Raised on arithmetic/domain/arity evaluation errors."""


Number = int | float


class Evaluator:
    """Stateful expression evaluator supporting ``name = expr`` assignments."""

    def __init__(
        self,
        variables: Mapping[str, Number] | None = None,
        functions: Mapping[str, Callable[..., Number]] | None = None,
    ) -> None:
        raise NotImplementedError

    def eval(self, expr: str) -> Number:
        raise NotImplementedError


def evaluate(
    expr: str,
    variables: Mapping[str, Number] | None = None,
    functions: Mapping[str, Callable[..., Number]] | None = None,
) -> Number:
    """Stateless evaluation of a single expression (assignments disallowed)."""
    raise NotImplementedError
