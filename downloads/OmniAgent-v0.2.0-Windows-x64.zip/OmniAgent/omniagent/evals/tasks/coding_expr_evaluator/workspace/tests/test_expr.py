import math
import pytest

from expreval import Evaluator, ExprEvalError, ExprSyntaxError, UnknownIdentifierError, evaluate


def test_basic_precedence():
    assert evaluate("1 + 2 * 3") == 7
    assert evaluate("(1 + 2) * 3") == 9
    assert evaluate("2 ** 3 ** 2") == 512
    assert evaluate("-2 ** 2") == -4


def test_variables_and_functions():
    assert evaluate("sqrt(x ** 2 + y ** 2)", {"x": 3, "y": 4}) == pytest.approx(5.0)
    assert evaluate("sin(pi / 2)") == pytest.approx(1.0)


def test_errors():
    with pytest.raises(ExprSyntaxError):
        evaluate("1 + * 2")
    with pytest.raises(UnknownIdentifierError):
        evaluate("unknown_var + 1")
    with pytest.raises(ExprEvalError):
        evaluate("1 / 0")
