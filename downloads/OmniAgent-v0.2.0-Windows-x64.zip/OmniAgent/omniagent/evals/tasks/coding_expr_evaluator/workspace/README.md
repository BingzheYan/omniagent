# Safe Expression Parser & Evaluator (`expreval`)

Implement a standalone mathematical expression parser and evaluator **without** calling Python's `eval()` or `exec()`.

## Public API (`expreval`)

- Exceptions (all subclassing `ExprError(ValueError)`):
  - `ExprSyntaxError(ExprError)` — empty input, unexpected character/token, unbalanced parentheses, trailing tokens, invalid assignment target, etc.
  - `UnknownIdentifierError(ExprError)` — undefined variable or unknown function name.
  - `ExprEvalError(ExprError)` — division/modulo by zero, math domain error (e.g. `sqrt(-1)`, `log(0)`), wrong function argument count, or runtime `ValueError`/`TypeError` from a function call.
- `evaluate(expr: str, variables: Mapping[str, float | int] | None = None, functions: Mapping[str, Callable] | None = None) -> float | int`
- `class Evaluator`:
  - `Evaluator(variables=None, functions=None)`
  - `.variables`: mutable `dict[str, float | int]` of user variables (overrides built-in constants when same name is set).
  - `.eval(expr: str) -> float | int`: evaluates either a pure expression OR a single assignment `ident = expr` (storing the result in `self.variables[ident]` and returning it; note `evaluate(...)` rejects `=` with `ExprSyntaxError` unless evaluated through `Evaluator.eval`).

## Grammar & Semantics

1. **Numbers**: integers (`42`), decimals (`3.14`, `.5`, `5.`), scientific notation (`1.25e-4`, `2E3`). Keep exact `int` when both operands are `int` for `+`, `-`, `*`, `//`, `%`, and non-negative integer `**`; `/` always returns `float`.
2. **Precedence (lowest to highest)**:
   1. `+`, `-` (binary, left-associative)
   2. `*`, `/`, `//`, `%` (binary, left-associative; zero divisor raises `ExprEvalError`)
   3. Unary prefix `+x`, `-x` (right-associative: `--3 == 3`; binds **looser** than `**`, so `-2 ** 2 == -4`, while `2 ** -3 == 0.125`)
   4. `**` (exponentiation, **right-associative**: `2 ** 3 ** 2 == 512`)
   5. Atoms: numbers, identifiers, parenthesized `(expr)`, function calls `fn(a, b, ...)`
3. **Constants & Functions**:
   - Built-in constants: `pi`, `e`, `tau` (from `math`), overridable via `variables`.
   - Built-in functions: `abs(x)`, `round(x[, ndigits])`, `min(x, ...)`, `max(x, ...)`, `sum(x, ...)`, `sqrt(x)`, `sin(x)`, `cos(x)`, `tan(x)`, `log(x[, base])`, `exp(x)`, `floor(x)`, `ceil(x)`, `pow(x, y)`. Custom `functions` override built-ins of the same name.
   - Calling `min()`, `max()`, or `sum()` with 0 arguments raises `ExprEvalError`. Any non-finite result (`inf` / `nan`) raises `ExprEvalError`.
