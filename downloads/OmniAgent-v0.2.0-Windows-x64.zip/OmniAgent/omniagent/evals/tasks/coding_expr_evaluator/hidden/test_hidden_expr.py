"""Hidden acceptance tests for coding_expr_evaluator."""
from __future__ import annotations

import inspect
import math
import pytest

import expreval.evaluator as ev_mod
from expreval import (
    Evaluator,
    ExprError,
    ExprEvalError,
    ExprSyntaxError,
    UnknownIdentifierError,
    evaluate,
)


def test_precedence_and_associativity():
    assert evaluate("10 - 4 - 2") == 4
    assert evaluate("24 / 4 / 2") == pytest.approx(3.0)
    assert evaluate("17 // 5") == 3
    assert evaluate("17 % 5") == 2
    assert evaluate("2 ** 3 ** 2") == 512
    assert evaluate("(2 ** 3) ** 2") == 64
    assert evaluate("-2 ** 2") == -4
    assert evaluate("(-2) ** 2") == 4
    assert evaluate("2 ** -3") == pytest.approx(0.125)
    assert evaluate("--++--5") == 5
    assert isinstance(evaluate("3 + 4 * 5"), int)


def test_float_formats_and_scientific_notation():
    assert evaluate(".5 + .25") == pytest.approx(0.75)
    assert evaluate("5. * 2") == pytest.approx(10.0)
    assert evaluate("1.5e3 + 2.5E-1") == pytest.approx(1500.25)


def test_constants_variables_and_override():
    assert evaluate("cos(0) + sin(pi / 2)") == pytest.approx(2.0)
    assert evaluate("tau / pi") == pytest.approx(2.0)
    assert evaluate("log(e ** 3)") == pytest.approx(3.0)
    # User variable overrides builtin constant
    assert evaluate("pi * 2", {"pi": 3}) == 6


def test_builtin_and_custom_functions():
    assert evaluate("min(5, 2, 8, -3)") == -3
    assert evaluate("max(5, 2, 8, -3)") == 8
    assert evaluate("sum(1, 2, 3, 4)") == 10
    assert evaluate("round(3.14159, 2)") == pytest.approx(3.14)
    assert evaluate("round(3.6)") == 4
    assert evaluate("floor(3.9) + ceil(3.1)") == 7
    assert evaluate("log(8, 2)") == pytest.approx(3.0)
    assert evaluate("pow(3, 4)") == 81
    assert evaluate("hypot(3, 4) + clamp(15, 0, 10)", functions={
        "hypot": math.hypot,
        "clamp": lambda x, lo, hi: max(lo, min(hi, x)),
    }) == pytest.approx(15.0)


def test_stateful_evaluator_assignments():
    calc = Evaluator({"tax": 0.1})
    assert calc.eval("subtotal = 120 * 3") == 360
    assert calc.eval("total = subtotal * (1 + tax)") == pytest.approx(396.0)
    assert calc.variables["subtotal"] == 360
    assert calc.variables["total"] == pytest.approx(396.0)
    # Stateless evaluate() must reject assignment
    with pytest.raises(ExprSyntaxError):
        evaluate("x = 5")


@pytest.mark.parametrize("bad_expr", [
    "",
    "   ",
    "1 +",
    "* 3",
    "1 + (2 * 3",
    "1 + 2)",
    "()",
    "1 2",
    "2 ^ 3",
    "sin(1, )",
    "1 = 2",
    "__import__('os')",
    "(1).__class__",
])
def test_syntax_errors(bad_expr: str):
    with pytest.raises((ExprSyntaxError, UnknownIdentifierError)):
        evaluate(bad_expr)


def test_unknown_identifiers():
    with pytest.raises(UnknownIdentifierError):
        evaluate("foo + 1")
    with pytest.raises(UnknownIdentifierError):
        evaluate("bar(1, 2)")


@pytest.mark.parametrize("err_expr", [
    "10 / 0",
    "10 // 0",
    "10 % 0",
    "sqrt(-1)",
    "log(0)",
    "log(-5)",
    "min()",
    "max()",
    "sum()",
    "sin(1, 2)",
    "10.0 ** 10000",
    "(-2) ** 0.5",
])
def test_eval_errors(err_expr: str):
    with pytest.raises(ExprEvalError):
        evaluate(err_expr)
    with pytest.raises(ExprError):
        evaluate(err_expr)


def test_no_python_eval_or_exec_used():
    src = inspect.getsource(ev_mod)
    assert "eval(" not in src.replace("def eval(", "").replace(".eval(", "")
    assert "exec(" not in src
