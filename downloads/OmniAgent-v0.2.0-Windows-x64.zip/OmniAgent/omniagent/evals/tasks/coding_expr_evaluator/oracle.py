"""Scripted oracle trajectory for coding_expr_evaluator."""
from __future__ import annotations

from pathlib import Path

from omniagent.llm.types import LLMResponse, ToolCall

SOLUTION_FILE = Path(__file__).resolve().parent / "solution" / "expreval" / "evaluator.py"

_EXTRA_TESTS = '''import math
import pytest
from expreval import Evaluator, ExprEvalError, ExprSyntaxError, UnknownIdentifierError, evaluate


def test_precedence_associativity_and_unary():
    assert evaluate("1 + 2 * 3") == 7
    assert evaluate("(1 + 2) * 3") == 9
    assert evaluate("2 ** 3 ** 2") == 512
    assert evaluate("-2 ** 2") == -4
    assert evaluate("2 ** -3") == pytest.approx(0.125)
    assert evaluate("17 // 5 + 17 % 5") == 5


def test_functions_constants_and_state():
    calc = Evaluator({"r": 5})
    area = calc.eval("area = pi * r ** 2")
    assert area == pytest.approx(math.pi * 25)
    assert calc.eval("round(sqrt(area / pi), 4)") == 5
    assert evaluate("min(4, -2, 9) + max(1, 7) + log(8, 2)") == pytest.approx(8.0)


def test_error_classes():
    for s in ["", "1 +", "(1 + 2", "x = 1", "2 ^ 3"]:
        with pytest.raises(ExprSyntaxError):
            evaluate(s)
    for s in ["missing_x", "unknown_fn(1)"]:
        with pytest.raises(UnknownIdentifierError):
            evaluate(s)
    for s in ["1 / 0", "1 % 0", "sqrt(-4)", "log(0)", "min()"]:
        with pytest.raises(ExprEvalError):
            evaluate(s)
'''


def _todos(statuses: list[str], tag: str) -> ToolCall:
    items = [
        "阅读 README 语法规格与现有代码框架",
        "实现无 eval 的词法分析器与递归下降求值器",
        "扩充边界测试并运行 pytest 验证",
    ]
    return ToolCall(
        f"todo_{tag}",
        "todo_write",
        {"todos": [{"content": c, "status": s} for c, s in zip(items, statuses)]},
    )


def build_script(ws: Path) -> list:
    sol_src = SOLUTION_FILE.read_text(encoding="utf-8")
    return [
        LLMResponse("先制定实现计划，阅读 README.md 与 expreval 骨架。", [
            _todos(["in_progress", "pending", "pending"], "1"),
            ToolCall("rd_doc", "read_file", {"path": "README.md"}),
            ToolCall("rd_init", "read_file", {"path": "expreval/__init__.py"}),
            ToolCall("rd_eval", "read_file", {"path": "expreval/evaluator.py"}),
            ToolCall("rd_tst", "read_file", {"path": "tests/test_expr.py"}),
        ]),
        LLMResponse("编写递归下降解析器与求值器（严格区分一元负号与右结合幂运算优先级，支持内置常量/函数与状态化赋值）。", [
            _todos(["completed", "in_progress", "pending"], "2"),
            ToolCall("wr_eval", "write_file", {"path": "expreval/evaluator.py", "content": sol_src}),
        ]),
        LLMResponse("扩充单元测试并运行 pytest 验证全部运算符、函数与异常分支。", [
            _todos(["completed", "completed", "in_progress"], "3"),
            ToolCall("wr_tst", "write_file", {"path": "tests/test_expr.py", "content": _EXTRA_TESTS}),
            ToolCall("sh_tst", "run_shell", {"command": "python -m pytest -q"}),
        ]),
        LLMResponse("标记计划全部完成。", [
            _todos(["completed", "completed", "completed"], "4"),
        ]),
        LLMResponse("实现与测试已完成，进入自检。", []),
        LLMResponse("核对 evaluator.py 源码。", [
            ToolCall("rv_eval", "read_file", {"path": "expreval/evaluator.py"}),
        ]),
        LLMResponse(
            "已完成 `expreval` 安全表达式解析与求值器实现：\n"
            "- 纯手工正则词法分析 + 递归下降语法分析，零 `eval`/`exec` 调用；\n"
            "- 完整支持四则/整除/取模、一元正负号、右结合幂运算 `**`、内置常量与数学函数、自定义函数注入及 `Evaluator` 变量赋值；\n"
            "- 精确抛出 `ExprSyntaxError`、`UnknownIdentifierError` 与 `ExprEvalError` 异常并全部通过 pytest 验证。",
            [],
        ),
    ]
