"""Hidden tests: API of the new shared money module."""
from decimal import Decimal

import pytest

try:
    from pricing import Money, format_amount, parse_amount, round_money
except ImportError:  # module not created yet -> every test fails individually
    Money = format_amount = parse_amount = round_money = None  # type: ignore[assignment]


@pytest.mark.parametrize(
    "text,expected",
    [
        ("$1,234.5", "1234.50"),
        ("1234.5", "1234.50"),
        ("-$3", "-3.00"),
        ("$-3.00", "-3.00"),
        ("($3.00)", "-3.00"),
        ("  12 ", "12.00"),
        ("2.675", "2.68"),
        ("-2.675", "-2.68"),
        (".5", "0.50"),
        ("1,000,000", "1000000.00"),
    ],
)
def test_parse_amount_valid(text, expected):
    value = parse_amount(text)
    assert isinstance(value, Decimal)
    assert str(value) == expected


@pytest.mark.parametrize("text", ["", "   ", "abc", "1.2.3", "$", "--1", "(3", "(-3)", "12a", "1 000"])
def test_parse_amount_invalid(text):
    with pytest.raises(ValueError):
        parse_amount(text)


@pytest.mark.parametrize(
    "value,kwargs,expected",
    [
        (Decimal("1234.5"), {}, "$1,234.50"),
        (-3, {}, "-$3.00"),
        (Decimal("-3"), {"negative": "parens"}, "($3.00)"),
        (Decimal("1234.5"), {"symbol": "", "grouping": False}, "1234.50"),
        (Decimal("2.675"), {}, "$2.68"),
        (Decimal("-0.001"), {}, "$0.00"),
        ("1000000", {}, "$1,000,000.00"),
        (Decimal("-1234567.891"), {"symbol": "€", "negative": "parens"}, "(€1,234,567.89)"),
    ],
)
def test_format_amount(value, kwargs, expected):
    assert format_amount(value, **kwargs) == expected


def test_format_amount_accepts_money_and_rejects_bad_input():
    assert format_amount(Money("-12.5"), negative="parens") == "($12.50)"
    with pytest.raises(ValueError):
        format_amount(Decimal("1"), negative="red")
    with pytest.raises(TypeError):
        format_amount(1.5)


def test_round_money_half_up():
    assert round_money(Decimal("0.125")) == Decimal("0.13")
    assert round_money(Decimal("-0.125")) == Decimal("-0.13")
    assert str(round_money(Decimal("7"))) == "7.00"


def test_money_construction_and_rounding():
    assert Money("1.005") == Money("1.01")
    assert Money(5).amount == Decimal("5.00")
    assert str(Money(5).amount) == "5.00"
    assert Money(Decimal("19.999")).amount == Decimal("20.00")
    assert len({Money("1.0"), Money("1.00"), Money(1)}) == 1
    with pytest.raises(TypeError):
        Money(0.1)


def test_money_arithmetic():
    assert Money("19.99") * 3 == Money("59.97")
    assert sum([Money("0.10")] * 3, Money(0)) == Money("0.30")
    assert sum([Money("0.10"), Money("0.20")]) == Money("0.30")
    assert Money("10.00") - Money("0.01") == Money("9.99")
    assert -Money("2.50") == Money("-2.50")
    assert Money("2.00") * Decimal("0.0725") == Money("0.15")
    assert Money("1.00") < Money("1.01")
    assert max(Money("3"), Money("12")) == Money("12")


def test_money_str_and_format():
    assert str(Money("1234.5")) == "$1,234.50"
    assert Money("-1234.5").format(negative="parens") == "($1,234.50)"
