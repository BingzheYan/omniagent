"""Hidden tests: the duplicated helpers are gone and every module uses pricing.money."""
import ast
import re
from pathlib import Path

import pytest

import pricing
from pricing import Invoice, LineItem, load_catalog

try:
    from pricing import Money
except ImportError:  # module not created yet -> every test fails individually
    Money = None  # type: ignore[assignment]
from pricing.cli import main
from pricing.discounts import coupon_discount, percent_off
from pricing.report import revenue_by_customer, summarize

PKG = Path(pricing.__file__).parent
CONSUMERS = ["catalog.py", "discounts.py", "invoice.py", "report.py", "cli.py"]
OLD_HELPERS = {
    "invoice.py": "_fmt",
    "report.py": "money",
    "cli.py": "_parse_price",
    "catalog.py": "_to_cents",
    "discounts.py": "_round2",
}


def _tree(name: str) -> ast.Module:
    return ast.parse((PKG / name).read_text(encoding="utf-8"))


def _imports_money(tree: ast.Module) -> bool:
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            mod = node.module or ""
            if mod in ("money", "pricing.money") or (mod == "" and any(a.name == "money" for a in node.names)) \
                    or (mod == "pricing" and any(a.name == "money" for a in node.names)):
                return True
        if isinstance(node, ast.Import) and any(a.name == "pricing.money" for a in node.names):
            return True
    return False


def test_money_module_exists():
    tree = _tree("money.py")
    names = {n.name for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
    assert {"Money", "parse_amount", "format_amount", "round_money"} <= names


@pytest.mark.parametrize("module", CONSUMERS)
def test_module_uses_shared_money(module):
    assert _imports_money(_tree(module)), f"{module} should import from pricing.money"


@pytest.mark.parametrize("module,helper", sorted(OLD_HELPERS.items()))
def test_old_helper_removed(module, helper):
    defined = {n.name for n in ast.walk(_tree(module)) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}
    assert helper not in defined
    assert "_fmt_money" not in defined


@pytest.mark.parametrize("module", CONSUMERS)
def test_no_float_money_or_adhoc_formatting(module):
    source = (PKG / module).read_text(encoding="utf-8")
    calls = [n for n in ast.walk(ast.parse(source))
             if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == "float"]
    assert not calls, f"{module} still calls float()"
    assert not re.search(r"\.2f", source), f"{module} still formats money by hand"


# --------------------------------------------------------------------------- behaviour after refactor
def test_invoice_amounts_are_money_with_half_up_rounding():
    inv = Invoice("T1", "Test", tax_rate="0.0725")
    inv.add(LineItem("A", "Apple", "1.00", 2))
    assert isinstance(inv.subtotal, Money)
    assert isinstance(inv.total, Money)
    assert inv.tax_amount == Money("0.15")
    assert inv.total == Money("2.15")
    assert inv.render().splitlines()[-2].endswith("$0.15")


def test_invoice_total_exact_decimal():
    inv = Invoice("T2", "Test", tax_rate="0.05")
    inv.add(LineItem("B", "Banana", "2.05", 2))
    assert inv.total == Money("4.31")
    assert isinstance(inv.items[0].total, Money)


def test_catalog_prices_are_money_rounded_half_up():
    cat = load_catalog([{"sku": "X", "name": " Thing ", "price": " $1,249.005 "},
                        {"sku": "Y", "name": "Other", "price": "1.005"}])
    assert cat["X"].unit_price == Money("1249.01")
    assert cat["Y"].unit_price == Money("1.01")
    assert isinstance(cat["Y"].unit_price, Money)


def test_discounts_return_money():
    assert coupon_discount(Money("10.00"), "FLAT20") == Money("10.00")
    assert coupon_discount(Money("33.33"), "save15") == Money("5.00")
    assert isinstance(percent_off(Money("1.45"), 15), Money)
    assert coupon_discount(Money("10.00"), None) == Money("0")


def test_report_revenue_is_money_and_accepts_money_adjustments():
    inv = Invoice("R1", "Zed", tax_rate="0.05")
    inv.add(LineItem("B", "Banana", "2.05", 2))
    assert revenue_by_customer([inv, inv]) == {"Zed": Money("8.62")}
    assert summarize([], adjustments=[Money("-5")]).splitlines()[-1].endswith("($5.00)")


def test_cli_uses_shared_parsing(capsys):
    assert main(["normalize", "($3.00)", "2.675", "$-1"]) == 0
    assert capsys.readouterr().out == "-3.00\n2.68\n-1.00\n"
    assert main(["sum", "0.10", "0.20", "(0.05)"]) == 0
    assert capsys.readouterr().out == "0.25\n"
