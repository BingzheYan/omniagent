"""Product catalog loading."""
from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Mapping

from .money import Money, parse_amount


@dataclass(frozen=True)
class Product:
    sku: str
    name: str
    unit_price: Money


def load_catalog(rows: Iterable[Mapping[str, str]]) -> dict[str, Product]:
    """Build a ``sku -> Product`` mapping from rows with ``sku``, ``name`` and ``price`` keys."""
    catalog: dict[str, Product] = {}
    for row in rows:
        sku = row["sku"].strip()
        if sku in catalog:
            raise ValueError(f"duplicate sku {sku!r}")
        catalog[sku] = Product(sku, row["name"].strip(), Money(parse_amount(row["price"])))
    return catalog


def load_catalog_csv(path: str | Path) -> dict[str, Product]:
    with open(path, newline="", encoding="utf-8") as fh:
        return load_catalog(csv.DictReader(fh))
