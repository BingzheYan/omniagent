"""Shared money handling: exact ``Decimal`` arithmetic, parsing and formatting.

Every amount is kept as a ``Decimal`` rounded to whole cents with
``ROUND_HALF_UP``.  Floats are rejected on purpose — they cannot represent most
cent values exactly.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation
from typing import Union

CENT = Decimal("0.01")

_AMOUNT_RE = re.compile(r"^(?P<neg1>-)?\$?(?P<neg2>-)?(?P<num>(?:\d[\d,]*)?(?:\.\d+)?)$")

AmountLike = Union["Money", Decimal, int, str]


def _to_decimal(value: AmountLike) -> Decimal:
    if isinstance(value, Money):
        return value.amount
    if isinstance(value, bool) or isinstance(value, float):
        raise TypeError(f"refusing to treat {type(value).__name__} {value!r} as money; use Decimal or str")
    if isinstance(value, Decimal):
        return value
    if isinstance(value, int):
        return Decimal(value)
    if isinstance(value, str):
        return parse_amount(value)
    raise TypeError(f"unsupported amount type: {type(value).__name__}")


def round_money(value: AmountLike) -> Decimal:
    """Round to cents using ``ROUND_HALF_UP`` (``Decimal("2.675") -> Decimal("2.68")``)."""
    result = _to_decimal(value).quantize(CENT, rounding=ROUND_HALF_UP)
    return result + Decimal("0.00") if result == 0 else result  # normalise -0.00 to 0.00


def parse_amount(text: str) -> Decimal:
    """Parse a human-entered amount into a cent-rounded ``Decimal``.

    Accepts surrounding whitespace, an optional ``$``, thousands separators
    (``,``), a leading ``-`` (before or after the ``$``) or accounting-style
    parentheses for negatives: ``"$1,234.5"``, ``"-$3"``, ``"$-3"``, ``"($3.00)"``.
    Raises ``ValueError`` for anything else.
    """
    if not isinstance(text, str):
        raise TypeError("parse_amount expects a string")
    s = text.strip()
    negative = False
    if s.startswith("(") and s.endswith(")"):
        negative, s = True, s[1:-1].strip()
    m = _AMOUNT_RE.match(s)
    if not m or not m.group("num") or not any(ch.isdigit() for ch in m.group("num")):
        raise ValueError(f"invalid amount: {text!r}")
    if m.group("neg1") and m.group("neg2"):
        raise ValueError(f"invalid amount: {text!r}")
    if (m.group("neg1") or m.group("neg2")) and negative:
        raise ValueError(f"invalid amount: {text!r}")
    negative = negative or bool(m.group("neg1") or m.group("neg2"))
    try:
        value = Decimal(m.group("num").replace(",", ""))
    except InvalidOperation:  # pragma: no cover - regex already guards this
        raise ValueError(f"invalid amount: {text!r}") from None
    return round_money(-value if negative else value)


def format_amount(
    value: AmountLike,
    *,
    symbol: str = "$",
    grouping: bool = True,
    negative: str = "minus",
) -> str:
    """Format an amount.

    * ``format_amount(Decimal("1234.5"))`` -> ``"$1,234.50"``
    * ``negative="minus"`` -> ``"-$3.00"``; ``negative="parens"`` -> ``"($3.00)"``
    * ``symbol=""`` / ``grouping=False`` -> ``"1234.50"``
    """
    if negative not in ("minus", "parens"):
        raise ValueError(f"negative must be 'minus' or 'parens', got {negative!r}")
    amount = round_money(value)
    body = f"{symbol}{abs(amount):{',' if grouping else ''}.2f}"
    if amount < 0:
        return f"({body})" if negative == "parens" else f"-{body}"
    return body


@dataclass(frozen=True, order=True)
class Money:
    """An exact, cent-rounded amount of money (single currency)."""

    amount: Decimal

    def __init__(self, amount: AmountLike = 0) -> None:
        object.__setattr__(self, "amount", round_money(amount))

    @classmethod
    def zero(cls) -> "Money":
        return cls(0)

    def _coerce(self, other: object) -> "Money":
        if isinstance(other, Money):
            return other
        if isinstance(other, (Decimal, int)) and not isinstance(other, bool):
            return Money(other)
        return NotImplemented  # type: ignore[return-value]

    def __add__(self, other: object) -> "Money":
        o = self._coerce(other)
        return NotImplemented if o is NotImplemented else Money(self.amount + o.amount)

    def __radd__(self, other: object) -> "Money":  # supports sum()
        return self.__add__(other)

    def __sub__(self, other: object) -> "Money":
        o = self._coerce(other)
        return NotImplemented if o is NotImplemented else Money(self.amount - o.amount)

    def __rsub__(self, other: object) -> "Money":
        o = self._coerce(other)
        return NotImplemented if o is NotImplemented else Money(o.amount - self.amount)

    def __mul__(self, factor: object) -> "Money":
        if isinstance(factor, bool) or not isinstance(factor, (int, Decimal)):
            return NotImplemented
        return Money(self.amount * factor)

    __rmul__ = __mul__

    def __neg__(self) -> "Money":
        return Money(-self.amount)

    def __abs__(self) -> "Money":
        return Money(abs(self.amount))

    def __bool__(self) -> bool:
        return self.amount != 0

    def format(self, **options: object) -> str:
        """Shortcut for :func:`format_amount` (same keyword options)."""
        return format_amount(self, **options)  # type: ignore[arg-type]

    def __str__(self) -> str:
        return format_amount(self)

    def __repr__(self) -> str:
        return f"Money('{self.amount}')"
