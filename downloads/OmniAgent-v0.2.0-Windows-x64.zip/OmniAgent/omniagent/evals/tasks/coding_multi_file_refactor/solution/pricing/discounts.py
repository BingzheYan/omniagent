"""Coupon and percentage discounts."""
from __future__ import annotations

from decimal import Decimal

from .money import Money

COUPONS: dict[str, tuple[str, Decimal]] = {
    "SAVE10": ("percent", Decimal("10")),
    "SAVE15": ("percent", Decimal("15")),
    "FLAT5": ("flat", Decimal("5")),
    "FLAT20": ("flat", Decimal("20")),
}


def percent_off(amount: Money, pct: Decimal | int | str) -> Money:
    """Return the discount for ``pct`` percent of ``amount`` (rounded half-up to cents)."""
    pct = Decimal(pct)
    if not 0 <= pct <= 100:
        raise ValueError(f"percentage out of range: {pct}")
    return Money(amount) * (pct / 100)


def coupon_discount(subtotal: Money, code: str | None) -> Money:
    """Discount granted by ``code`` on ``subtotal``; never more than the subtotal itself."""
    subtotal = Money(subtotal)
    if not code:
        return Money.zero()
    try:
        kind, value = COUPONS[code.strip().upper()]
    except KeyError:
        raise ValueError(f"unknown coupon {code!r}") from None
    discount = percent_off(subtotal, value) if kind == "percent" else Money(value)
    return min(discount, subtotal)
