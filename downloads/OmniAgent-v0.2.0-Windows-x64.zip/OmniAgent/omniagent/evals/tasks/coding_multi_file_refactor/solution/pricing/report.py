"""Management reports across many invoices (accounting style: negatives in parentheses)."""
from __future__ import annotations

from collections import defaultdict
from typing import Iterable

from .invoice import Invoice
from .money import AmountLike, Money, format_amount


def revenue_by_customer(invoices: Iterable[Invoice]) -> dict[str, Money]:
    """Total invoiced amount per customer, sorted by customer name."""
    totals: dict[str, Money] = defaultdict(Money.zero)
    for inv in invoices:
        totals[inv.customer] += inv.total
    return {k: totals[k] for k in sorted(totals)}


def summarize(invoices: Iterable[Invoice], adjustments: Iterable[AmountLike] = ()) -> str:
    """Render a revenue summary table.

    ``adjustments`` are manual corrections (credit notes are negative).
    """
    invoices = list(invoices)
    rows = [f"{'Invoice':<10}{'Customer':<20}{'Total':>14}"]
    for inv in invoices:
        rows.append(f"{inv.number:<10}{inv.customer[:19]:<20}{format_amount(inv.total, negative='parens'):>14}")
    adj = [Money(a) for a in adjustments]
    for a in adj:
        rows.append(f"{'ADJ':<10}{'':<20}{format_amount(a, negative='parens'):>14}")
    grand = sum((inv.total for inv in invoices), Money.zero()) + sum(adj, Money.zero())
    rows.append(f"{'TOTAL':<30}{format_amount(grand, negative='parens'):>14}")
    return "\n".join(rows)
