"""Invoices: line items, totals and plain-text rendering."""
from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal

from .discounts import coupon_discount
from .money import AmountLike, Money, format_amount

WIDTH = 46


@dataclass
class LineItem:
    sku: str
    description: str
    unit_price: Money
    quantity: int = 1

    def __post_init__(self) -> None:
        if self.quantity <= 0:
            raise ValueError("quantity must be positive")
        self.unit_price = Money(self.unit_price)

    @property
    def total(self) -> Money:
        return self.unit_price * self.quantity


@dataclass
class Invoice:
    number: str
    customer: str
    items: list[LineItem] = field(default_factory=list)
    tax_rate: Decimal | int | str = Decimal("0")
    coupon: str | None = None

    def __post_init__(self) -> None:
        if isinstance(self.tax_rate, float):
            raise TypeError("tax_rate must be a Decimal, int or str, not float")
        self.tax_rate = Decimal(self.tax_rate)

    def add(self, item: LineItem) -> None:
        self.items.append(item)

    @property
    def subtotal(self) -> Money:
        return sum((i.total for i in self.items), Money.zero())

    @property
    def discount(self) -> Money:
        return coupon_discount(self.subtotal, self.coupon)

    @property
    def tax_amount(self) -> Money:
        return (self.subtotal - self.discount) * self.tax_rate

    @property
    def total(self) -> Money:
        return self.subtotal - self.discount + self.tax_amount

    def render(self) -> str:
        """Plain-text invoice used in e-mails and the CLI."""
        rule = "-" * WIDTH
        lines = [f"INVOICE #{self.number}", f"Customer: {self.customer}", rule]
        for item in self.items:
            lines.append(f"{item.description[:18]:<18}{item.quantity:>4} x "
                         f"{format_amount(item.unit_price):>10}{format_amount(item.total):>11}")
        lines.append(rule)
        lines.append(f"{'Subtotal:':<30}{format_amount(self.subtotal):>16}")
        if self.coupon:
            lines.append(f"{f'Discount ({self.coupon.upper()}):':<30}{format_amount(-self.discount):>16}")
        if self.tax_rate:
            pct = f"{(self.tax_rate * 100).normalize():f}"
            lines.append(f"{f'Tax ({pct}%):':<30}{format_amount(self.tax_amount):>16}")
        lines.append(f"{'Total:':<30}{format_amount(self.total):>16}")
        return "\n".join(lines)


__all__ = ["AmountLike", "Invoice", "LineItem"]
