"""Scripted oracle trajectory for coding_multi_file_refactor."""
from __future__ import annotations

from pathlib import Path

from omniagent.llm.types import LLMResponse, ToolCall

SOLUTION_DIR = Path(__file__).resolve().parent / "solution" / "pricing"
MODULES = ["money.py", "__init__.py", "catalog.py", "discounts.py", "invoice.py", "report.py", "cli.py"]


def _todos(statuses: list[str], tag: str) -> ToolCall:
    items = [
        "检查 pricing 各模块重复的金额逻辑与测试套件",
        "新建 pricing/money.py 实现精确 Decimal 金额模型",
        "重构 catalog/discounts/invoice/report/cli 并跑通测试",
    ]
    return ToolCall(
        f"todo_{tag}",
        "todo_write",
        {"todos": [{"content": c, "status": s} for c, s in zip(items, statuses)]},
    )


def build_script(ws: Path) -> list:
    srcs = {m: (SOLUTION_DIR / m).read_text(encoding="utf-8") for m in MODULES}
    steps: list = [
        LLMResponse("先建立重构计划，阅读 pricing 各模块与现有测试。", [
            _todos(["in_progress", "pending", "pending"], "1"),
            ToolCall("ls_root", "list_dir", {"path": ".", "depth": 2}),
            ToolCall("rd_cat", "read_file", {"path": "pricing/catalog.py"}),
            ToolCall("rd_disc", "read_file", {"path": "pricing/discounts.py"}),
            ToolCall("rd_inv", "read_file", {"path": "pricing/invoice.py"}),
            ToolCall("rd_rep", "read_file", {"path": "pricing/report.py"}),
            ToolCall("rd_cli", "read_file", {"path": "pricing/cli.py"}),
        ]),
        LLMResponse("阅读受保护的验收测试，确认外部输出格式契约。", [
            ToolCall("rd_t1", "read_file", {"path": "tests/test_invoice.py"}),
            ToolCall("rd_t2", "read_file", {"path": "tests/test_report.py"}),
            ToolCall("rd_t3", "read_file", {"path": "tests/test_cli.py"}),
        ]),
        LLMResponse("创建共享模块 pricing/money.py，统一使用 Decimal 与 ROUND_HALF_UP，拒绝 float。", [
            _todos(["completed", "in_progress", "pending"], "2"),
            ToolCall("wr_money", "write_file", {"path": "pricing/money.py", "content": srcs["money.py"]}),
        ]),
        LLMResponse("将 catalog、discounts、invoice、report、cli 与 __init__.py 全部迁移至 pricing.money。", [
            _todos(["completed", "completed", "in_progress"], "3"),
            ToolCall("wr_init", "write_file", {"path": "pricing/__init__.py", "content": srcs["__init__.py"]}),
            ToolCall("wr_cat", "write_file", {"path": "pricing/catalog.py", "content": srcs["catalog.py"]}),
            ToolCall("wr_disc", "write_file", {"path": "pricing/discounts.py", "content": srcs["discounts.py"]}),
            ToolCall("wr_inv", "write_file", {"path": "pricing/invoice.py", "content": srcs["invoice.py"]}),
            ToolCall("wr_rep", "write_file", {"path": "pricing/report.py", "content": srcs["report.py"]}),
            ToolCall("wr_cli", "write_file", {"path": "pricing/cli.py", "content": srcs["cli.py"]}),
        ]),
        LLMResponse("运行 pytest 并用 grep 确认不再残留 float 调用或手写 .2f 格式化。", [
            ToolCall("sh_test", "run_shell", {"command": "python -m pytest -q"}),
            ToolCall("gr_float", "grep", {"pattern": "float\\(", "path": "pricing"}),
        ]),
        LLMResponse("标记全部计划项完成。", [
            _todos(["completed", "completed", "completed"], "4"),
        ]),
        LLMResponse("重构完成，进入最终自检。", []),
        LLMResponse("核对导出符号与 money 模块。", [
            ToolCall("rv_init", "read_file", {"path": "pricing/__init__.py"}),
        ]),
        LLMResponse(
            "已完成共享金额模块抽取与多文件重构：\n"
            "1. 新建 `pricing/money.py`，实现 `round_money`、`parse_amount`、`format_amount` 与不可变 `Money` 类（统一 `Decimal` + `ROUND_HALF_UP`，严拒 `float`）。\n"
            "2. `catalog`、`discounts`、`invoice`、`report`、`cli` 已全部迁移到 `pricing.money`，消除了所有私有解析/格式化函数与浮点误差。\n"
            "3. 原有测试未做任何改动，全部通过。",
            [],
        ),
    ]
    return steps
