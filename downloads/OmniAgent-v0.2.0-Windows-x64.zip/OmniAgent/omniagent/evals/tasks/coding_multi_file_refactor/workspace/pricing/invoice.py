"""Invoices: line items, totals and plain-text rendering."""
from __future__ import annotations

from dataclasses import dataclass, field

from .discounts import coupon_discount

WIDTH = 46


def _fmt(amount: float) -> str:
    """Format a dollar amount like ``$1,234.50`` / ``-$3.00``."""
    if amount < 0:
        return "-${:,.2f}".format(-amount)
    return "${:,.2f}".format(amount)


@dataclass
class LineItem:
    sku: str
    description: str
    unit_price: float
    quantity: int = 1

    def __post_init__(self) -> None:
        if self.quantity <= 0:
            raise ValueError("quantity must be positive")
        self.unit_price = float(self.unit_price)

    @property
    def total(self) -> float:
        return round(self.unit_price * self.quantity, 2)


@dataclass
class Invoice:
    number: str
    customer: str
    items: list[LineItem] = field(default_factory=list)
    tax_rate: float = 0.0
    coupon: str | None = None

    def add(self, item: LineItem) -> None:
        self.items.append(item)

    @property
    def subtotal(self) -> float:
        return round(sum(i.total for i in self.items), 2)

    @property
    def discount(self) -> float:
        return coupon_discount(self.subtotal, self.coupon)

    @property
    def tax_amount(self) -> float:
        return round((self.subtotal - self.discount) * float(self.tax_rate), 2)

    @property
    def total(self) -> float:
        return round(self.subtotal - self.discount + self.tax_amount, 2)

    def render(self) -> str:
        """Plain-text invoice used in e-mails and the CLI."""
        rule = "-" * WIDTH
        lines = [f"INVOICE #{self.number}", f"Customer: {self.customer}", rule]
        for item in self.items:
            lines.append(f"{item.description[:18]:<18}{item.quantity:>4} x {_fmt(item.unit_price):>10}{_fmt(item.total):>11}")
        lines.append(rule)
        lines.append(f"{'Subtotal:':<30}{_fmt(self.subtotal):>16}")
        if self.coupon:
            lines.append(f"{f'Discount ({self.coupon.upper()}):':<30}{_fmt(-self.discount):>16}")
        if self.tax_rate:
            pct = f"{float(self.tax_rate) * 100:g}"
            lines.append(f"{f'Tax ({pct}%):':<30}{_fmt(self.tax_amount):>16}")
        lines.append(f"{'Total:':<30}{_fmt(self.total):>16}")
        return "\n".join(lines)
