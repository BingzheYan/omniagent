"""CLI behaviour (scripts in ops depend on this exact output)."""
from pricing.cli import main

from test_invoice import EXPECTED_1001

CATALOG = """sku,name,price
W1,Widget,$19.99
G7,Gadget deluxe edition XL,"$1,249.00"
"""


def test_quote(tmp_path, capsys):
    path = tmp_path / "catalog.csv"
    path.write_text(CATALOG, encoding="utf-8")
    code = main(["quote", "--catalog", str(path), "--item", "W1:3", "--item", "G7:1",
                 "--tax", "0.0825", "--coupon", "save10", "--number", "1001", "--customer", "ACME Corp"])
    assert code == 0
    assert capsys.readouterr().out == EXPECTED_1001 + "\n"


def test_normalize(capsys):
    assert main(["normalize", "$1,234.5", "-3", " 42 "]) == 0
    assert capsys.readouterr().out == "1234.50\n-3.00\n42.00\n"


def test_sum(capsys):
    assert main(["sum", "$19.99", "0.01", "1,000"]) == 0
    assert capsys.readouterr().out == "1020.00\n"


def test_invalid_amount_exit_code(capsys):
    assert main(["normalize", "twelve"]) == 2
    assert "error" in capsys.readouterr().err
