"""Report output is consumed by finance's spreadsheet macros — keep it byte-for-byte stable."""
from pricing.report import summarize

from test_invoice import make_invoices

EXPECTED = """\
Invoice   Customer                     Total
1001      ACME Corp                $1,275.26
1002      Globex                     $374.00
1003      Initech                      $0.00
ADJ                                ($150.25)
ADJ                                   $12.00
TOTAL                              $1,511.01"""


def test_summary_table():
    assert summarize(make_invoices(), adjustments=["-150.25", "12"]) == EXPECTED


def test_negative_grand_total_uses_parentheses():
    out = summarize([], adjustments=["-1234.5"])
    assert out.splitlines()[-1] == f"{'TOTAL':<30}{'($1,234.50)':>14}"
