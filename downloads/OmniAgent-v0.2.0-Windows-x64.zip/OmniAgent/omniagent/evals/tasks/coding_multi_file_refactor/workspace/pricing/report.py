"""Management reports across many invoices (accounting style: negatives in parentheses)."""
from __future__ import annotations

from collections import defaultdict
from typing import Iterable

from .invoice import Invoice


def money(value: float) -> str:
    """Accounting format: ``$1,234.50`` or ``($1,234.50)`` for negatives."""
    text = f"${abs(value):,.2f}"
    return f"({text})" if value < 0 else text


def revenue_by_customer(invoices: Iterable[Invoice]) -> dict[str, float]:
    """Total invoiced amount per customer, sorted by customer name."""
    totals: dict[str, float] = defaultdict(float)
    for inv in invoices:
        totals[inv.customer] += inv.total
    return {k: round(totals[k], 2) for k in sorted(totals)}


def summarize(invoices: Iterable[Invoice], adjustments: Iterable[float] = ()) -> str:
    """Render a revenue summary table.

    ``adjustments`` are manual corrections (credit notes are negative).
    """
    invoices = list(invoices)
    rows = [f"{'Invoice':<10}{'Customer':<20}{'Total':>14}"]
    for inv in invoices:
        rows.append(f"{inv.number:<10}{inv.customer[:19]:<20}{money(inv.total):>14}")
    adj = [float(a) for a in adjustments]
    for a in adj:
        rows.append(f"{'ADJ':<10}{'':<20}{money(a):>14}")
    grand = sum(inv.total for inv in invoices) + sum(adj)
    rows.append(f"{'TOTAL':<30}{money(grand):>14}")
    return "\n".join(rows)
