"""Coupon and percentage discounts."""
from __future__ import annotations

COUPONS: dict[str, tuple[str, float]] = {
    "SAVE10": ("percent", 10.0),
    "SAVE15": ("percent", 15.0),
    "FLAT5": ("flat", 5.0),
    "FLAT20": ("flat", 20.0),
}


def _round2(value: float) -> float:
    # nudge to avoid 0.125 -> 0.12 surprises
    return round(value + 1e-9, 2)


def percent_off(amount: float, pct: float) -> float:
    """Return the discount for ``pct`` percent of ``amount`` (rounded to cents)."""
    if not 0 <= pct <= 100:
        raise ValueError(f"percentage out of range: {pct}")
    return _round2(amount * pct / 100)


def coupon_discount(subtotal: float, code: str | None) -> float:
    """Discount granted by ``code`` on ``subtotal``; never more than the subtotal itself."""
    if not code:
        return 0.0
    try:
        kind, value = COUPONS[code.strip().upper()]
    except KeyError:
        raise ValueError(f"unknown coupon {code!r}") from None
    discount = percent_off(subtotal, value) if kind == "percent" else _round2(value)
    return min(discount, subtotal)
