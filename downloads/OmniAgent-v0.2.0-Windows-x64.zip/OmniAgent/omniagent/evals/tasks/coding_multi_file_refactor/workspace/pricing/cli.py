"""Command line entry point: ``python -m pricing.cli <command> ...``."""
from __future__ import annotations

import argparse
import sys
from typing import Sequence

from .catalog import load_catalog_csv
from .invoice import Invoice, LineItem


def _parse_price(text: str) -> float:
    """Parse user input such as ``$1,234.50`` or ``-3``."""
    cleaned = text.strip().replace("$", "").replace(",", "")
    return float(cleaned)


def _fmt_money(value: float) -> str:
    """Machine-readable amount: no symbol, no grouping (``1234.50``)."""
    return "%.2f" % value


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="pricing")
    sub = parser.add_subparsers(dest="command", required=True)

    quote = sub.add_parser("quote", help="render an invoice for catalog items")
    quote.add_argument("--catalog", required=True)
    quote.add_argument("--item", action="append", default=[], metavar="SKU:QTY")
    quote.add_argument("--tax", default="0")
    quote.add_argument("--coupon")
    quote.add_argument("--number", default="DRAFT")
    quote.add_argument("--customer", default="Walk-in")

    norm = sub.add_parser("normalize", help="normalize amounts to plain decimals")
    norm.add_argument("amounts", nargs="+")

    total = sub.add_parser("sum", help="add up amounts")
    total.add_argument("amounts", nargs="+")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    try:
        if args.command == "quote":
            catalog = load_catalog_csv(args.catalog)
            inv = Invoice(args.number, args.customer, tax_rate=float(args.tax), coupon=args.coupon)
            for spec in args.item:
                sku, _, qty = spec.partition(":")
                product = catalog[sku]
                inv.add(LineItem(product.sku, product.name, product.unit_price, int(qty or 1)))
            print(inv.render())
        elif args.command == "normalize":
            for raw in args.amounts:
                print(_fmt_money(_parse_price(raw)))
        elif args.command == "sum":
            print(_fmt_money(sum(_parse_price(a) for a in args.amounts)))
    except (ValueError, KeyError) as e:
        print(f"error: {e}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
