"""Product catalog loading."""
from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Mapping


@dataclass(frozen=True)
class Product:
    sku: str
    name: str
    unit_price: float


def _to_cents(text: str) -> int:
    """Parse a price such as ``"$1,234.50"`` into integer cents."""
    cleaned = text.strip().replace("$", "").replace(",", "")
    if not cleaned:
        raise ValueError(f"empty price: {text!r}")
    return int(round(float(cleaned) * 100))


def load_catalog(rows: Iterable[Mapping[str, str]]) -> dict[str, Product]:
    """Build a ``sku -> Product`` mapping from rows with ``sku``, ``name`` and ``price`` keys."""
    catalog: dict[str, Product] = {}
    for row in rows:
        sku = row["sku"].strip()
        if sku in catalog:
            raise ValueError(f"duplicate sku {sku!r}")
        catalog[sku] = Product(sku, row["name"].strip(), _to_cents(row["price"]) / 100)
    return catalog


def load_catalog_csv(path: str | Path) -> dict[str, Product]:
    with open(path, newline="", encoding="utf-8") as fh:
        return load_catalog(csv.DictReader(fh))
