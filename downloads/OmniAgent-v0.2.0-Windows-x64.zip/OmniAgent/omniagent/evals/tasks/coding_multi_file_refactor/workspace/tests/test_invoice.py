"""Behavioural tests for invoice rendering.  These pin the current output and must stay green."""
from pricing import Invoice, LineItem

EXPECTED_1001 = """\
INVOICE #1001
Customer: ACME Corp
----------------------------------------------
Widget               3 x     $19.99     $59.97
Gadget deluxe edit   1 x  $1,249.00  $1,249.00
----------------------------------------------
Subtotal:                            $1,308.97
Discount (SAVE10):                    -$130.90
Tax (8.25%):                            $97.19
Total:                               $1,275.26"""

EXPECTED_1002 = """\
INVOICE #1002
Customer: Globex
----------------------------------------------
Service hour         4 x     $85.00    $340.00
----------------------------------------------
Subtotal:                              $340.00
Tax (10%):                              $34.00
Total:                                 $374.00"""

EXPECTED_1003 = """\
INVOICE #1003
Customer: Initech
----------------------------------------------
Pen                  4 x      $2.50     $10.00
----------------------------------------------
Subtotal:                               $10.00
Discount (FLAT20):                     -$10.00
Total:                                   $0.00"""


def make_invoices():
    inv1 = Invoice("1001", "ACME Corp", tax_rate="0.0825", coupon="save10")
    inv1.add(LineItem("W1", "Widget", "19.99", 3))
    inv1.add(LineItem("G7", "Gadget deluxe edition XL", "1249.00", 1))
    inv2 = Invoice("1002", "Globex", tax_rate="0.1")
    inv2.add(LineItem("S", "Service hour", "85", 4))
    inv3 = Invoice("1003", "Initech", coupon="FLAT20")
    inv3.add(LineItem("P", "Pen", "2.5", 4))
    return inv1, inv2, inv3


def test_render_with_coupon_and_tax():
    assert make_invoices()[0].render() == EXPECTED_1001


def test_render_integer_tax_rate_label():
    assert make_invoices()[1].render() == EXPECTED_1002


def test_flat_coupon_never_exceeds_subtotal():
    assert make_invoices()[2].render() == EXPECTED_1003


def test_quantity_must_be_positive():
    import pytest

    with pytest.raises(ValueError):
        LineItem("X", "x", "1.00", 0)
