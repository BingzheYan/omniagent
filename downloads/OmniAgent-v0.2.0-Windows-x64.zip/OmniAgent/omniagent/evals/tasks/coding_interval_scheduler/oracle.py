"""Scripted "perfect model" trajectory for coding_interval_scheduler.

The fixes are expressed as exact ``edit_file`` replacements (``EDITS``); the
reference ``solution/`` directory is produced by applying the very same edits,
so the oracle and the solution can never drift apart.
"""
from __future__ import annotations

from pathlib import Path

from omniagent.llm.types import LLMResponse, ToolCall

INTERVALS = "scheduler/intervals.py"
PLANNER = "scheduler/planner.py"

# (path, old_string, new_string) — applied in order.
EDITS: list[tuple[str, str, str]] = [
    (INTERVALS, "from datetime import datetime\n", "from datetime import datetime, timezone\n"),
    (INTERVALS, "_EPOCH_NAIVE = datetime(1970, 1, 1)\n", "_EPOCH = datetime(1970, 1, 1, tzinfo=timezone.utc)\n"),
    (INTERVALS, "        if self.end < self.start:\n", "        if self.end <= self.start:\n"),
    (INTERVALS, "        return self.start <= other.end and other.start <= self.end\n",
     "        return self.start < other.end and other.start < self.end\n"),
    (INTERVALS, "        return self.start <= minute <= self.end\n", "        return self.start <= minute < self.end\n"),
    (INTERVALS,
     "    if not 0 <= hours <= 23 or not 0 <= minutes <= 59:\n",
     "    if not 0 <= hours <= 24 or not 0 <= minutes <= 59 or (hours == 24 and minutes != 0):\n"),
    (INTERVALS,
     "    if dt.tzinfo is not None:\n"
     "        dt = dt.replace(tzinfo=None)  # normalise to naive for arithmetic\n"
     "    return int((dt - _EPOCH_NAIVE).total_seconds()) // 60\n",
     "    if dt.tzinfo is None:\n"
     "        dt = dt.replace(tzinfo=timezone.utc)\n"
     "    else:\n"
     "        dt = dt.astimezone(timezone.utc)\n"
     "    return int((dt - _EPOCH).total_seconds() // 60)\n"),
    (INTERVALS,
     "    merged: list[Interval] = []\n    for iv in intervals:\n",
     "    merged: list[Interval] = []\n    for iv in sorted(intervals):\n"),
    (INTERVALS,
     "            merged[-1] = Interval(last.start, iv.end, label)\n",
     "            merged[-1] = Interval(last.start, max(last.end, iv.end), label)\n"),
    (INTERVALS, "    items = list(intervals)\n", "    items = sorted(intervals)\n"),
    (INTERVALS,
     "    for iv in intervals:\n        if ends and ends[0] < iv.start:\n",
     "    for iv in sorted(intervals):\n        if ends and ends[0] <= iv.start:\n"),
    (INTERVALS,
     "    for iv in merge_intervals(busy):\n"
     "        if iv.start > cursor and iv.start - cursor > min_duration:\n"
     "            slots.append(Interval(cursor, iv.start))\n"
     "        cursor = iv.end\n"
     "    if window_end - cursor > min_duration:\n",
     "    for iv in merge_intervals(busy):\n"
     "        if iv.end <= cursor:\n"
     "            continue  # entirely before the window / already covered\n"
     "        if iv.start >= window_end:\n"
     "            break  # everything from here on is after the window\n"
     "        if iv.start > cursor and iv.start - cursor >= min_duration:\n"
     "            slots.append(Interval(cursor, iv.start))\n"
     "        cursor = max(cursor, iv.end)\n"
     "    if window_end > cursor and window_end - cursor >= min_duration:\n"),
    (PLANNER, "        return list(self._require_room(room))\n", "        return sorted(self._require_room(room))\n"),
]

_REPRO = r'''
from datetime import datetime, timedelta, timezone
from scheduler import *
print("touch overlap:", Interval(0, 60).overlaps(Interval(60, 120)))
print("rooms back-to-back:", min_meeting_rooms([Interval(0, 30), Interval(30, 60)]))
print("merge nested:", merge_intervals([Interval(0, 100), Interval(10, 20)]))
print("free before window:", find_free_slots([Interval(480, 500)], 540, 600))
cst = timezone(timedelta(hours=8))
print("tz:", to_minutes(datetime(2024, 3, 1, 9, tzinfo=cst)) == to_minutes(datetime(2024, 3, 1, 1)))
'''


def _todos(status: list[str]) -> ToolCall:
    items = ["复现用户报告的问题", "修复 intervals.py 中的区间/时间换算 bug", "修复 planner 排序", "运行测试验证"]
    return ToolCall(f"todo{''.join(s[0] for s in status)}", "todo_write",
                    {"todos": [{"content": c, "status": s} for c, s in zip(items, status)]})


def build_script(ws: Path) -> list:
    steps: list = [
        LLMResponse("先制定计划并查看项目结构。", [
            _todos(["in_progress", "pending", "pending", "pending"]),
            ToolCall("ls1", "list_dir", {"path": ".", "depth": 2}),
        ]),
        LLMResponse("阅读源码与现有测试。", [
            ToolCall("rd1", "read_file", {"path": INTERVALS}),
            ToolCall("rd2", "read_file", {"path": PLANNER}),
            ToolCall("rd3", "read_file", {"path": "tests/test_intervals.py"}),
        ]),
        LLMResponse("写一个小脚本复现报告中的问题。", [
            ToolCall("py1", "run_shell", {"command": f"python - <<'EOF'\n{_REPRO}\nEOF"}),
        ]),
        LLMResponse("问题都复现了：闭区间比较、未排序输入、嵌套合并、窗口裁剪、时区换算。开始逐个修复。", [
            _todos(["completed", "in_progress", "pending", "pending"]),
        ]),
    ]
    n = 0
    for path, old, new in EDITS:
        if path != INTERVALS:
            continue
        n += 1
        steps.append(LLMResponse("", [ToolCall(f"ed{n}", "edit_file", {"path": path, "old_string": old, "new_string": new})]))
    steps.append(LLMResponse("修复 bookings() 未按时间排序的问题。", [
        _todos(["completed", "completed", "in_progress", "pending"]),
    ]))
    for path, old, new in EDITS:
        if path != PLANNER:
            continue
        n += 1
        steps.append(LLMResponse("", [ToolCall(f"ed{n}", "edit_file", {"path": path, "old_string": old, "new_string": new})]))
    steps += [
        LLMResponse("运行复现脚本和测试。", [
            ToolCall("py2", "run_shell", {"command": f"python - <<'EOF'\n{_REPRO}\nEOF"}),
            ToolCall("t1", "run_shell", {"command": "python -m pytest -q"}),
        ]),
        LLMResponse("", [_todos(["completed", "completed", "completed", "completed"])]),
        LLMResponse("修改已完成，准备最终自检。", []),
        LLMResponse("复核关键修复文件。", [
            ToolCall("rv1", "read_file", {"path": PLANNER}),
        ]),
        LLMResponse(
            "已修复全部问题，API 保持不变：\n"
            "- `Interval.overlaps/contains` 改为半开区间 `[start, end)`；拒绝零长度区间。\n"
            "- `merge_intervals` / `can_attend_all` / `min_meeting_rooms` 先排序；合并时取 `max(end)` 处理嵌套；"
            "空出的会议室可在同一分钟复用（`<=`）。\n"
            "- `find_free_slots` 裁剪窗口外的忙碌区间，`min_duration` 改为包含边界。\n"
            "- `parse_hhmm` 支持 `24:00`；`to_minutes` 对 aware datetime 先转换到 UTC。\n"
            "- `RoomPlanner.bookings` 按时间排序。\n测试全部通过。",
            [],
        ),
    ]
    return steps


def apply_edits(root: Path) -> None:
    """Apply ``EDITS`` to a copy of the workspace rooted at ``root`` (used to build solution/)."""
    for path, old, new in EDITS:
        p = root / path
        text = p.read_text(encoding="utf-8")
        assert text.count(old) == 1, (path, old)
        p.write_text(text.replace(old, new, 1), encoding="utf-8")
