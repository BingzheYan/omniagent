"""Hidden acceptance tests for the scheduler bug-fix task."""
from datetime import datetime, timedelta, timezone

import pytest

from scheduler import (
    Interval,
    RoomPlanner,
    can_attend_all,
    find_free_slots,
    merge_intervals,
    min_meeting_rooms,
    parse_hhmm,
    to_minutes,
)

CST = timezone(timedelta(hours=8))


# --------------------------------------------------------------------------- Interval
def test_touching_intervals_do_not_overlap():
    a, b = Interval(0, 60), Interval(60, 120)
    assert not a.overlaps(b)
    assert not b.overlaps(a)
    assert a.overlaps(Interval(59, 61))
    assert Interval(0, 100).overlaps(Interval(10, 20))


def test_contains_is_half_open():
    iv = Interval(10, 20)
    assert iv.contains(10)
    assert iv.contains(19)
    assert not iv.contains(20)
    assert not iv.contains(9)


@pytest.mark.parametrize("start,end", [(5, 5), (6, 5)])
def test_empty_or_negative_interval_rejected(start, end):
    with pytest.raises(ValueError):
        Interval(start, end)


# --------------------------------------------------------------------------- parsing / conversions
def test_parse_end_of_day():
    assert parse_hhmm("24:00") == 1440
    assert parse_hhmm("00:00") == 0


@pytest.mark.parametrize("bad", ["24:01", "25:00", "9:60", "0930", "", "ab:cd"])
def test_parse_rejects_invalid(bad):
    with pytest.raises(ValueError):
        parse_hhmm(bad)


def test_to_minutes_naive_is_utc_and_counts_days():
    assert to_minutes(datetime(1970, 1, 1, 0, 0)) == 0
    assert to_minutes(datetime(1970, 1, 2, 0, 30)) == 1470


def test_to_minutes_aware_is_converted_to_utc():
    local = datetime(2024, 3, 1, 9, 0, tzinfo=CST)
    assert to_minutes(local) == to_minutes(datetime(2024, 3, 1, 1, 0))
    assert to_minutes(local) == to_minutes(datetime(2024, 3, 1, 1, 0, tzinfo=timezone.utc))


def test_from_datetimes_mixed_timezones_overlap():
    shanghai = Interval.from_datetimes(datetime(2024, 5, 6, 9, 0, tzinfo=CST), datetime(2024, 5, 6, 10, 0, tzinfo=CST))
    utc = Interval.from_datetimes(datetime(2024, 5, 6, 1, 30), datetime(2024, 5, 6, 2, 30))
    assert shanghai.overlaps(utc)
    assert min_meeting_rooms([shanghai, utc]) == 2


def test_overnight_meeting_duration():
    iv = Interval.from_datetimes(datetime(2024, 5, 6, 23, 0, tzinfo=CST), datetime(2024, 5, 7, 1, 30, tzinfo=CST))
    assert iv.duration == 150


# --------------------------------------------------------------------------- merge
def test_merge_unsorted_input():
    got = merge_intervals([Interval(50, 60), Interval(0, 10), Interval(5, 20)])
    assert got == [Interval(0, 20), Interval(50, 60)]


def test_merge_nested_intervals_keeps_outer_end():
    got = merge_intervals([Interval(0, 100), Interval(10, 20), Interval(30, 40)])
    assert got == [Interval(0, 100)]


def test_merge_touching_intervals():
    assert merge_intervals([Interval(10, 20), Interval(0, 10)]) == [Interval(0, 20)]


def test_merge_empty():
    assert merge_intervals([]) == []


# --------------------------------------------------------------------------- can_attend_all
def test_can_attend_back_to_back():
    assert can_attend_all([Interval(0, 30), Interval(30, 60), Interval(60, 90)])


def test_can_attend_detects_conflict_in_unsorted_input():
    assert not can_attend_all([Interval(0, 10), Interval(50, 60), Interval(5, 15)])


# --------------------------------------------------------------------------- min rooms
def test_rooms_back_to_back_share_room():
    assert min_meeting_rooms([Interval(0, 30), Interval(30, 60), Interval(60, 90)]) == 1


def test_rooms_unsorted_input():
    assert min_meeting_rooms([Interval(60, 90), Interval(0, 30), Interval(10, 70)]) == 2


def test_rooms_equal_start_and_end_times():
    meetings = [Interval(10, 20), Interval(0, 10), Interval(10, 15), Interval(5, 10)]
    assert min_meeting_rooms(meetings) == 2


def test_rooms_empty():
    assert min_meeting_rooms([]) == 0


# --------------------------------------------------------------------------- free slots
def test_free_slots_ignores_busy_before_window():
    assert find_free_slots([Interval(480, 500)], 540, 600) == [Interval(540, 600)]


def test_free_slots_clips_busy_crossing_window_start():
    assert find_free_slots([Interval(510, 570)], 540, 720) == [Interval(570, 720)]


def test_free_slots_ignores_busy_after_window():
    got = find_free_slots([Interval(800, 900), Interval(600, 620)], 540, 720)
    assert got == [Interval(540, 600), Interval(620, 720)]


def test_free_slots_min_duration_is_inclusive():
    got = find_free_slots([Interval(600, 630)], 540, 720, min_duration=60)
    assert got == [Interval(540, 600), Interval(630, 720)]
    assert find_free_slots([Interval(600, 630)], 540, 720, min_duration=61) == [Interval(630, 720)]


def test_free_slots_unsorted_nested_busy_and_end_of_day():
    busy = [Interval(1300, 1440), Interval(600, 700), Interval(620, 640)]
    got = find_free_slots(busy, parse_hhmm("08:00"), parse_hhmm("24:00"), min_duration=30)
    assert got == [Interval(480, 600), Interval(700, 1300)]


# --------------------------------------------------------------------------- planner
def test_planner_back_to_back_uses_same_room():
    planner = RoomPlanner(["A", "B"])
    assert planner.book(Interval.from_hhmm("09:00", "10:00")) == "A"
    assert planner.book(Interval.from_hhmm("10:00", "11:00")) == "A"


def test_planner_bookings_are_chronological_and_free_slots_clip():
    planner = RoomPlanner(["A"])
    planner.book(Interval.from_hhmm("14:00", "15:00"))
    planner.book(Interval.from_hhmm("07:30", "09:30"))
    assert planner.bookings("A") == [Interval.from_hhmm("07:30", "09:30"), Interval.from_hhmm("14:00", "15:00")]
    assert planner.free_slots("A", parse_hhmm("09:00"), parse_hhmm("18:00"), min_duration=30) == [
        Interval.from_hhmm("09:30", "14:00"),
        Interval.from_hhmm("15:00", "18:00"),
    ]
