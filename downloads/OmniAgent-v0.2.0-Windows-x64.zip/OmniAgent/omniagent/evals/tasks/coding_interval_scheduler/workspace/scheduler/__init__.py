"""Meeting-room scheduling toolkit."""
from .intervals import (
    MINUTES_PER_DAY,
    Interval,
    can_attend_all,
    find_free_slots,
    format_hhmm,
    merge_intervals,
    min_meeting_rooms,
    parse_hhmm,
    to_minutes,
)
from .planner import NoRoomAvailable, RoomPlanner

__all__ = [
    "MINUTES_PER_DAY",
    "Interval",
    "NoRoomAvailable",
    "RoomPlanner",
    "can_attend_all",
    "find_free_slots",
    "format_hhmm",
    "merge_intervals",
    "min_meeting_rooms",
    "parse_hhmm",
    "to_minutes",
]
