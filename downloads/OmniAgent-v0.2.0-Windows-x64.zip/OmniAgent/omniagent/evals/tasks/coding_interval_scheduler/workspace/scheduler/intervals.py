"""Interval primitives and scheduling helpers for the meeting-room planner.

Conventions used throughout this module:

* Every interval is **half-open**: ``[start, end)``.  A meeting from 09:00 to
  10:00 and another from 10:00 to 11:00 do *not* overlap and can share a room.
* Times are whole **minutes**.  Wall-clock strings such as ``"09:30"`` are
  converted with :func:`parse_hhmm`; ``datetime`` objects are converted to
  minutes since the Unix epoch (UTC) with :func:`to_minutes`.
* Zero-length or negative intervals are rejected with ``ValueError``.
* Functions accept intervals in **any order**; callers should never have to
  pre-sort their input.
"""
from __future__ import annotations

import heapq
import re
from dataclasses import dataclass, field
from datetime import datetime
from typing import Iterable

MINUTES_PER_DAY = 24 * 60

_EPOCH_NAIVE = datetime(1970, 1, 1)
_HHMM_RE = re.compile(r"^(\d{1,2}):(\d{2})$")


@dataclass(frozen=True, order=True)
class Interval:
    """A half-open time interval ``[start, end)`` measured in minutes."""

    start: int
    end: int
    label: str = field(default="", compare=False)

    def __post_init__(self) -> None:
        if self.end < self.start:
            raise ValueError(f"interval end ({self.end}) must be after start ({self.start})")

    @classmethod
    def from_hhmm(cls, start: str, end: str, label: str = "") -> "Interval":
        """Build an interval from two ``"HH:MM"`` strings on the same day."""
        return cls(parse_hhmm(start), parse_hhmm(end), label)

    @classmethod
    def from_datetimes(cls, start: datetime, end: datetime, label: str = "") -> "Interval":
        """Build an interval from two datetimes (see :func:`to_minutes`)."""
        return cls(to_minutes(start), to_minutes(end), label)

    @property
    def duration(self) -> int:
        """Length of the interval in minutes."""
        return self.end - self.start

    def overlaps(self, other: "Interval") -> bool:
        """Return ``True`` if the two intervals share at least one minute."""
        return self.start <= other.end and other.start <= self.end

    def contains(self, minute: int) -> bool:
        """Return ``True`` if ``minute`` falls inside ``[start, end)``."""
        return self.start <= minute <= self.end

    def __str__(self) -> str:  # pragma: no cover - cosmetic
        text = f"{format_hhmm(self.start % MINUTES_PER_DAY)}-{format_hhmm(self.end % MINUTES_PER_DAY)}"
        return f"{text} {self.label}".rstrip()


# --------------------------------------------------------------------------- conversions
def parse_hhmm(text: str) -> int:
    """Convert ``"HH:MM"`` (``"00:00"`` .. ``"24:00"``) to minutes after midnight.

    ``"24:00"`` is accepted as the end of the day so that a working window can
    be expressed as ``("08:00", "24:00")``.

    >>> parse_hhmm("09:30")
    570
    """
    match = _HHMM_RE.match(text.strip())
    if not match:
        raise ValueError(f"invalid time {text!r}, expected HH:MM")
    hours, minutes = int(match.group(1)), int(match.group(2))
    if not 0 <= hours <= 23 or not 0 <= minutes <= 59:
        raise ValueError(f"time out of range: {text!r}")
    return hours * 60 + minutes


def format_hhmm(minutes: int) -> str:
    """Inverse of :func:`parse_hhmm` for values in ``0 .. 1440``."""
    if not 0 <= minutes <= MINUTES_PER_DAY:
        raise ValueError(f"minutes out of range: {minutes}")
    return f"{minutes // 60:02d}:{minutes % 60:02d}"


def to_minutes(dt: datetime) -> int:
    """Convert a datetime to whole minutes since 1970-01-01 00:00 UTC.

    Naive datetimes are interpreted as UTC.  Timezone-aware datetimes are
    converted to UTC first, so ``09:00+08:00`` and ``01:00 UTC`` map to the same
    minute.
    """
    if dt.tzinfo is not None:
        dt = dt.replace(tzinfo=None)  # normalise to naive for arithmetic
    return int((dt - _EPOCH_NAIVE).total_seconds()) // 60


# --------------------------------------------------------------------------- algorithms
def merge_intervals(intervals: Iterable[Interval]) -> list[Interval]:
    """Merge overlapping **or touching** intervals into contiguous busy blocks.

    The result is sorted by start time and contains no two intervals that
    overlap or touch.  Labels of merged blocks are joined with ``"+"``.
    """
    merged: list[Interval] = []
    for iv in intervals:
        if merged and iv.start <= merged[-1].end:
            last = merged[-1]
            label = "+".join(x for x in (last.label, iv.label) if x)
            merged[-1] = Interval(last.start, iv.end, label)
        else:
            merged.append(iv)
    return merged


def can_attend_all(intervals: Iterable[Interval]) -> bool:
    """Return ``True`` if a single person could attend every meeting."""
    items = list(intervals)
    for a, b in zip(items, items[1:]):
        if a.overlaps(b):
            return False
    return True


def min_meeting_rooms(intervals: Iterable[Interval]) -> int:
    """Minimum number of rooms needed so that no two meetings in a room overlap.

    A room freed at minute ``t`` can host a meeting starting at ``t``.
    """
    ends: list[int] = []  # min-heap of end times of meetings currently in progress
    for iv in intervals:
        if ends and ends[0] < iv.start:
            heapq.heapreplace(ends, iv.end)
        else:
            heapq.heappush(ends, iv.end)
    return len(ends)


def find_free_slots(
    busy: Iterable[Interval],
    window_start: int,
    window_end: int,
    min_duration: int = 1,
) -> list[Interval]:
    """Return the free gaps inside ``[window_start, window_end)``.

    Busy intervals may lie partly or completely outside the window; only the
    part inside the window matters.  Gaps shorter than ``min_duration`` minutes
    are skipped (a gap of exactly ``min_duration`` minutes is returned).
    """
    if window_end <= window_start:
        raise ValueError("window_end must be after window_start")
    slots: list[Interval] = []
    cursor = window_start
    for iv in merge_intervals(busy):
        if iv.start > cursor and iv.start - cursor > min_duration:
            slots.append(Interval(cursor, iv.start))
        cursor = iv.end
    if window_end - cursor > min_duration:
        slots.append(Interval(cursor, window_end))
    return slots
