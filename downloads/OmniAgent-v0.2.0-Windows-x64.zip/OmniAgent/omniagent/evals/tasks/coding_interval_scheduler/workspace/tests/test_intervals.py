from scheduler import Interval, RoomPlanner, format_hhmm, merge_intervals, min_meeting_rooms, parse_hhmm


def test_parse_and_format_roundtrip():
    assert parse_hhmm("09:30") == 570
    assert parse_hhmm(" 7:05 ") == 425
    assert format_hhmm(570) == "09:30"


def test_merge_disjoint_sorted():
    a = Interval(60, 120)
    b = Interval(180, 240)
    assert merge_intervals([a, b]) == [a, b]


def test_merge_overlapping_sorted():
    assert merge_intervals([Interval(0, 30), Interval(20, 50)]) == [Interval(0, 50)]


def test_rooms_for_overlapping_meetings():
    meetings = [Interval(0, 60), Interval(10, 50), Interval(20, 40)]
    assert min_meeting_rooms(meetings) == 3


def test_planner_books_second_room_on_conflict():
    planner = RoomPlanner(["A", "B"])
    assert planner.book(Interval.from_hhmm("09:00", "10:00")) == "A"
    assert planner.book(Interval.from_hhmm("09:30", "10:30")) == "B"
