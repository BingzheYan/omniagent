"""A tiny in-memory room booking service built on :mod:`scheduler.intervals`."""
from __future__ import annotations

from typing import Iterable

from .intervals import Interval, find_free_slots


class NoRoomAvailable(Exception):
    """Raised when a booking request cannot be satisfied."""


class RoomPlanner:
    """Keeps the bookings of a fixed set of rooms.

    Rooms are tried in the order they were declared when no explicit room is
    requested.
    """

    def __init__(self, rooms: Iterable[str]) -> None:
        self._bookings: dict[str, list[Interval]] = {room: [] for room in rooms}
        if not self._bookings:
            raise ValueError("at least one room is required")

    @property
    def rooms(self) -> list[str]:
        return list(self._bookings)

    def _require_room(self, room: str) -> list[Interval]:
        try:
            return self._bookings[room]
        except KeyError:
            raise KeyError(f"unknown room {room!r}") from None

    def is_free(self, room: str, interval: Interval) -> bool:
        """Return ``True`` if ``room`` has no booking overlapping ``interval``."""
        return not any(b.overlaps(interval) for b in self._require_room(room))

    def book(self, interval: Interval, room: str | None = None) -> str:
        """Book ``interval`` and return the name of the room that was used.

        If ``room`` is given only that room is considered; otherwise the first
        free room (in declaration order) is chosen.
        """
        candidates = [room] if room is not None else self.rooms
        for name in candidates:
            if self.is_free(name, interval):
                self._bookings[name].append(interval)
                return name
        raise NoRoomAvailable(f"no room available for {interval}")

    def bookings(self, room: str) -> list[Interval]:
        """Bookings of ``room`` in chronological order."""
        return list(self._require_room(room))

    def free_slots(self, room: str, window_start: int, window_end: int, min_duration: int = 1) -> list[Interval]:
        """Free gaps of ``room`` inside the given window (see :func:`find_free_slots`)."""
        return find_free_slots(self._require_room(room), window_start, window_end, min_duration)
