# scheduler

Small meeting-room scheduling toolkit used by the office booking bot.

```python
from scheduler import Interval, RoomPlanner, min_meeting_rooms, parse_hhmm

standup = Interval.from_hhmm("09:00", "09:15", "standup")
review = Interval.from_hhmm("09:15", "10:00", "design review")
min_meeting_rooms([standup, review])  # -> 1, back-to-back meetings share a room

planner = RoomPlanner(["Everest", "K2"])
planner.book(standup)                 # -> "Everest"
planner.free_slots("Everest", parse_hhmm("08:00"), parse_hhmm("18:00"), min_duration=30)
```

## Semantics

* Intervals are half-open `[start, end)` in minutes; touching intervals do not overlap.
* `merge_intervals` merges overlapping **and** touching intervals.
* `"24:00"` is a valid end-of-day time.
* Naive datetimes are treated as UTC; aware datetimes are converted to UTC.
* Every function accepts intervals in arbitrary order.

## Development

```bash
python -m pytest -q
```
