"""Automated checker for office_doc_rewrite."""
from __future__ import annotations

import hashlib
import re
from pathlib import Path
from typing import Any

from omniagent.tools.documents import extract_text
from omniagent.tools.research import inspect_document

COLLOQUIALISMS = ("咱们觉得", "特麻烦", "拍脑袋", "糟心事", "黄花菜都凉了", "弄个系统", "干三块活儿", "砍掉", "别外传")
REQUIRED_FACTS = ("380", "220", "110", "50", "18", "11", "240", "60", "2026", "99.5")


def _sha256(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def check(ws: Path, agent_result: str, events: list[dict[str, Any]], task_dir: Path) -> dict[str, Any]:
    orig_ref = task_dir / "workspace" / "drafts" / "智慧预算平台立项方案初稿.docx"
    orig_ws = ws / "drafts" / "智慧预算平台立项方案初稿.docx"
    if not orig_ws.exists():
        return {"passed": False, "score": 0.0, "details": "原始初稿被删除", "metrics": {}}
    if _sha256(orig_ws) != _sha256(orig_ref):
        return {"passed": False, "score": 0.0, "details": "原始初稿内容被覆盖修改，违反保留原件要求", "metrics": {}}

    rev_candidates = [
        ws / "outputs" / "智慧预算平台立项方案_修订版.docx",
        *(sorted((ws / "outputs").glob("*修订版*.docx")) if (ws / "outputs").exists() else []),
        *sorted(ws.glob("*修订版*.docx")),
    ]
    rev_path = next((p for p in rev_candidates if p.exists()), None)
    if rev_path is None:
        return {"passed": False, "score": 0.0, "details": "未找到生成的 *修订版*.docx 文件", "metrics": {}}

    doc_check = inspect_document(rev_path, doc_type="report", workspace=ws)
    doc_score = int(doc_check["score"])
    text = extract_text(rev_path)

    failures: list[str] = []
    if doc_score < 85:
        failures.append(f"check_document 得分 {doc_score} < 85")
    if doc_check["metrics"]["headings_count"] < 4:
        failures.append(f"修订版章节标题层级不足（当前 {doc_check['metrics']['headings_count']} 个）")

    leftover_slang = [w for w in COLLOQUIALISMS if w in text]
    if leftover_slang:
        failures.append(f"修订版仍残留口语化表达：{', '.join(leftover_slang)}")

    missing_facts = [f for f in REQUIRED_FACTS if f not in text]
    if missing_facts:
        failures.append(f"修订版遗漏了原稿关键量化事实：{', '.join(missing_facts)}")

    # Check that final response lists key revisions (>= 3 bullet/numbered items or explicit revision summary)
    rev_items = re.findall(r"(?:^|\n)\s*(?:[-*•]|\d+[.、）)])\s*\S+", agent_result or "")
    if len(rev_items) < 3 or not re.search(r"修改|修订|口语|结构|规范|量化|预算", agent_result or ""):
        failures.append("最终回复未清晰列出至少 3 条主要修订点说明")

    passed = len(failures) == 0
    return {
        "passed": passed,
        "score": doc_score / 100.0 if passed else max(0.0, (doc_score - 20 * len(failures)) / 100.0),
        "details": (
            f"文档修订核验通过：原稿完好无损，修订版 check_document={doc_score}/100，全部事实数字保留且口语化表达清零，回复包含 {len(rev_items)} 条修订说明。"
            if passed
            else "；".join(failures)
        ),
        "metrics": {
            "check_document_score": doc_score,
            "headings": doc_check["metrics"]["headings_count"],
            "revision_bullets": len(rev_items),
        },
    }
