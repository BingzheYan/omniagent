"""OmniAgent 自动化评测包入口。"""
from __future__ import annotations

from .runner import (
    TASKS_ROOT,
    EvalSuiteResult,
    EvalTaskResult,
    TaskSpec,
    discover_tasks,
    main,
    run_eval_suite,
    run_single_task,
    select_tasks,
)

__all__ = [
    "EvalSuiteResult",
    "EvalTaskResult",
    "TASKS_ROOT",
    "TaskSpec",
    "discover_tasks",
    "main",
    "run_eval_suite",
    "run_single_task",
    "select_tasks",
]
