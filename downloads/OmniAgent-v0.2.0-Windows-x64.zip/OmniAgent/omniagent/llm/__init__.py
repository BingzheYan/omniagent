from __future__ import annotations

from omniagent.config import ModelProfile

from .types import LLMProvider, LLMResponse, Message, ToolCall, ToolSchema, Usage

__all__ = ["create_provider", "LLMProvider", "LLMResponse", "Message", "ToolCall", "ToolSchema", "Usage"]


def create_provider(profile: ModelProfile) -> LLMProvider:
    if profile.provider == "anthropic":
        from .anthropic_provider import AnthropicProvider

        return AnthropicProvider(profile)
    if profile.provider == "openai":
        from .openai_provider import OpenAIProvider

        return OpenAIProvider(profile)
    if profile.provider == "mock":
        from .mock_provider import MockProvider

        return MockProvider(profile)
    raise ValueError(f"不支持的 provider: {profile.provider}（可选 openai / anthropic / mock）")
