"""与具体厂商无关的统一消息 / 工具调用类型。"""
from __future__ import annotations

import abc
import asyncio
import logging
from dataclasses import asdict, dataclass, field
from typing import Any, Awaitable, Callable

log = logging.getLogger(__name__)

DeltaCallback = Callable[[str, str], Awaitable[None]]  # (kind: "text"|"thinking", text)


@dataclass
class ToolCall:
    id: str
    name: str
    arguments: dict[str, Any]
    parse_error: str | None = None  # 模型给出的参数不是合法 JSON 时记录


@dataclass
class Message:
    role: str  # system | user | assistant | tool
    content: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)
    tool_call_id: str | None = None
    name: str | None = None  # tool 消息对应的工具名
    is_error: bool = False
    meta: dict[str, Any] = field(default_factory=dict)  # 不发给模型的附加信息

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Message":
        d = dict(d)
        d["tool_calls"] = [ToolCall(**tc) for tc in d.get("tool_calls") or []]
        return cls(**d)


def message_images(m: "Message") -> list[dict[str, str]]:
    """消息附带的图片（由 view_image 等工具放入 meta["images"]）。

    每项: {"media_type": "image/png", "data": "<base64>", "path": "相对路径(可选)"}
    """
    imgs = m.meta.get("images") if m.meta else None
    return [i for i in (imgs or []) if isinstance(i, dict) and i.get("data")]


@dataclass
class Usage:
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0

    def add(self, other: "Usage") -> None:
        self.input_tokens += other.input_tokens
        self.output_tokens += other.output_tokens
        self.cache_read_tokens += other.cache_read_tokens


@dataclass
class LLMResponse:
    content: str
    tool_calls: list[ToolCall]
    usage: Usage = field(default_factory=Usage)
    stop_reason: str | None = None
    thinking: str = ""


@dataclass
class ToolSchema:
    name: str
    description: str
    parameters: dict[str, Any]


class LLMProvider(abc.ABC):
    """所有模型后端的统一接口。"""

    def __init__(self, profile):
        self.profile = profile

    @property
    def model_name(self) -> str:
        return self.profile.model

    @abc.abstractmethod
    async def _complete(
        self,
        system: str,
        messages: list[Message],
        tools: list[ToolSchema],
        on_delta: DeltaCallback | None,
    ) -> LLMResponse: ...

    async def complete(
        self,
        system: str,
        messages: list[Message],
        tools: list[ToolSchema] | None = None,
        on_delta: DeltaCallback | None = None,
        retries: int = 4,
    ) -> LLMResponse:
        delay = 2.0
        for attempt in range(retries + 1):
            try:
                return await self._complete(system, messages, tools or [], on_delta)
            except asyncio.CancelledError:
                raise
            except Exception as e:  # noqa: BLE001
                if attempt >= retries or not _is_retryable(e):
                    raise
                log.warning("LLM 调用失败（第 %d 次），%.0fs 后重试: %s", attempt + 1, delay, e)
                await asyncio.sleep(delay)
                delay = min(delay * 2, 30)
        raise RuntimeError("unreachable")


def _is_retryable(e: Exception) -> bool:
    status = getattr(e, "status_code", None) or getattr(getattr(e, "response", None), "status_code", None)
    if status is not None:
        return status in (408, 409, 425, 429) or status >= 500
    name = type(e).__name__.lower()
    return any(k in name for k in ("timeout", "connection", "ratelimit", "overloaded", "apierror"))
