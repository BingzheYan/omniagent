"""OpenAI 兼容协议后端：OpenAI / DeepSeek / 通义千问 / Kimi / GLM / Ollama / vLLM 等。"""
from __future__ import annotations

import json
from typing import Any

from openai import AsyncOpenAI

from .types import DeltaCallback, LLMProvider, LLMResponse, Message, ToolCall, Usage, message_images


def _parse_args(raw: str) -> tuple[dict[str, Any], str | None]:
    if not raw or not raw.strip():
        return {}, None
    try:
        val = json.loads(raw)
        return (val if isinstance(val, dict) else {"value": val}), None
    except json.JSONDecodeError as e:
        return {}, f"工具参数不是合法 JSON: {e}. 原始内容前 300 字符: {raw[:300]}"


class OpenAIProvider(LLMProvider):
    def __init__(self, profile):
        super().__init__(profile)
        self.client = AsyncOpenAI(
            api_key=profile.resolve_api_key() or "EMPTY",
            base_url=profile.resolve_base_url() if hasattr(profile, "resolve_base_url") else profile.base_url,
            timeout=600,
            max_retries=0,
        )
        self._stream_usage_supported = True

    @staticmethod
    def _convert(system: str, messages: list[Message], vision: bool = True,
                 include_reasoning: bool = False) -> list[dict[str, Any]]:
        """转换为 chat.completions 格式。

        chat.completions 的 tool 消息不能携带图片：工具返回的图片会在这一组 tool 消息之后，
        以一条额外的 user 消息（image_url data URI）发送。
        对于 DeepSeek Reasoner 等推理模型，同一轮工具调用链中的 assistant 消息需回传 reasoning_content。
        """
        out: list[dict[str, Any]] = [{"role": "system", "content": system}]
        pending: list[tuple[str, dict[str, str]]] = []  # (工具名, 图片)
        last_real_user = max(
            (i for i, m in enumerate(messages) if m.role == "user" and not m.meta.get("system")),
            default=-1,
        )

        def flush():
            if not pending:
                return
            parts: list[dict[str, Any]] = [{"type": "text", "text": "以下是上面工具调用返回的图片（系统自动附加）："}]
            for name, img in pending:
                label = img.get("path") or name
                parts.append({"type": "text", "text": f"[{name}] {label}"})
                parts.append({"type": "image_url", "image_url": {
                    "url": f"data:{img.get('media_type') or 'image/png'};base64,{img['data']}"}})
            out.append({"role": "user", "content": parts})
            pending.clear()

        for idx, m in enumerate(messages):
            if m.role != "tool":
                flush()
            if m.role == "assistant":
                d: dict[str, Any] = {"role": "assistant", "content": m.content or None}
                if m.tool_calls:
                    d["tool_calls"] = [
                        {
                            "id": tc.id,
                            "type": "function",
                            "function": {"name": tc.name, "arguments": json.dumps(tc.arguments, ensure_ascii=False)},
                        }
                        for tc in m.tool_calls
                    ]
                if include_reasoning and idx > last_real_user and m.tool_calls:
                    d["reasoning_content"] = str(m.meta.get("thinking") or "")
                if d["content"] is None and not m.tool_calls:
                    d["content"] = ""
                out.append(d)
            elif m.role == "tool":
                images = message_images(m)
                content = m.content or "(空)"
                if images and not vision:
                    content += f"\n[附带的 {len(images)} 张图片未发送：当前模型不支持图像输入]"
                elif images:
                    pending.extend((m.name or "tool", img) for img in images)
                out.append({"role": "tool", "tool_call_id": m.tool_call_id, "content": content})
            else:
                out.append({"role": m.role, "content": m.content})
        flush()
        return out

    async def _complete(self, system, messages, tools, on_delta: DeltaCallback | None) -> LLMResponse:
        p = self.profile
        is_reasoner = "reasoner" in (p.model or "").lower()
        kwargs: dict[str, Any] = {
            "model": p.model,
            "messages": self._convert(system, messages, bool(getattr(p, "vision", True)), include_reasoning=is_reasoner),
            "max_tokens": p.max_tokens,
            "stream": True,
        }
        if p.temperature is not None:
            kwargs["temperature"] = p.temperature
        if tools:
            kwargs["tools"] = [
                {"type": "function", "function": {"name": t.name, "description": t.description, "parameters": t.parameters}}
                for t in tools
            ]
        kwargs.update(p.extra.get("request_params", {}))
        if self._stream_usage_supported:
            kwargs["stream_options"] = {"include_usage": True}

        try:
            stream = await self.client.chat.completions.create(**kwargs)
        except Exception as e:  # 部分兼容服务不支持 stream_options
            if "stream_options" in kwargs and "stream_options" in str(e):
                self._stream_usage_supported = False
                kwargs.pop("stream_options")
                stream = await self.client.chat.completions.create(**kwargs)
            else:
                raise

        text_parts: list[str] = []
        thinking_parts: list[str] = []
        calls: dict[int, dict[str, str]] = {}
        usage = Usage()
        finish = None
        async for chunk in stream:
            if getattr(chunk, "usage", None):
                u = chunk.usage
                usage.input_tokens = u.prompt_tokens or 0
                usage.output_tokens = u.completion_tokens or 0
                details = getattr(u, "prompt_tokens_details", None)
                if details is not None and getattr(details, "cached_tokens", None):
                    usage.cache_read_tokens = details.cached_tokens
            if not chunk.choices:
                continue
            choice = chunk.choices[0]
            delta = choice.delta
            if choice.finish_reason:
                finish = choice.finish_reason
            if delta is None:
                continue
            reasoning = getattr(delta, "reasoning_content", None)
            if reasoning:
                thinking_parts.append(reasoning)
                if on_delta:
                    await on_delta("thinking", reasoning)
            if delta.content:
                text_parts.append(delta.content)
                if on_delta:
                    await on_delta("text", delta.content)
            for tc in delta.tool_calls or []:
                idx = tc.index if tc.index is not None else len(calls)
                slot = calls.setdefault(idx, {"id": "", "name": "", "args": ""})
                if tc.id:
                    slot["id"] = tc.id
                if tc.function is not None:
                    if tc.function.name:
                        slot["name"] += tc.function.name
                    if tc.function.arguments:
                        slot["args"] += tc.function.arguments

        tool_calls = []
        for i, idx in enumerate(sorted(calls)):
            slot = calls[idx]
            args, err = _parse_args(slot["args"])
            tool_calls.append(ToolCall(id=slot["id"] or f"call_{i}", name=slot["name"], arguments=args, parse_error=err))
        return LLMResponse(
            content="".join(text_parts),
            tool_calls=tool_calls,
            usage=usage,
            stop_reason=finish,
            thinking="".join(thinking_parts),
        )
