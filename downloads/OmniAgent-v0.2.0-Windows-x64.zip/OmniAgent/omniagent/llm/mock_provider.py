"""离线 Mock 后端：用于单元测试，以及无 API Key 时完整演示思维链、文件变更审阅、子智能体与外部连接器链路。"""
from __future__ import annotations

import asyncio
import itertools
import os
import re
from typing import Callable, Union

from .types import LLMProvider, LLMResponse, Message, ToolCall, Usage

Step = Union[LLMResponse, Callable[[list[Message]], LLMResponse]]


class MockProvider(LLMProvider):
    def __init__(self, profile, script: list[Step] | None = None):
        super().__init__(profile)
        self.script = list(script) if script is not None else None
        self.calls: list[list[Message]] = []
        self._ids = itertools.count(1)

    def _demo(self, messages: list[Message], system: str = "") -> LLMResponse:
        """默认演示脚本：展示完整思维链（CoT）→ 规划 → 探查工作区/外部连接器 → 编写并精确修订文件 → 自检交付。"""
        is_sub = "# 你是子智能体" in system
        last_user = max((i for i, m in enumerate(messages) if m.role == "user" and not m.meta.get("system")), default=0)
        turn_msgs = messages[last_user:]
        n_tool = sum(1 for m in turn_msgs if m.role == "tool")
        task = messages[last_user].content if messages else ""

        if is_sub:
            if n_tool == 0:
                return LLMResponse(
                    thinking="作为调研子智能体，我先扫描工作区目录并汇总已有数据资产与文件结构。",
                    content="",
                    tool_calls=[ToolCall(f"s{next(self._ids)}", "list_dir", {"path": "."})],
                )
            listing = next((m.content for m in reversed(turn_msgs) if m.role == "tool"), "")
            return LLMResponse(
                thinking="已完成目录扫描，整理结构化调研结论返回主控智能体。",
                content=f"工作区调研摘要：\n{listing[:400]}",
                tool_calls=[],
            )

        conn_match = re.search(r"@connector:([\w.\-]+)", task)
        url_match = re.search(r"https?://[^\s)\]>\"']+", task)
        has_memory_ctx = "# 跨会话长期记忆与用户画像" in system
        mem_note = ""
        if has_memory_ctx:
            mem_snippet = system.split("# 跨会话长期记忆与用户画像", 1)[1].strip().splitlines()
            preview_lines = [re.sub(r"\*+", "", l.lstrip("- *")) for l in mem_snippet if l.strip().startswith("-")][:3]
            if preview_lines:
                mem_note = "0. 已自动召回长期记忆与用户画像（" + " / ".join(x[:56] for x in preview_lines) + "），本轮将严格遵循既有体例并衔接在办进度；\n"

        if n_tool == 0:
            calls = [
                ToolCall(f"m{next(self._ids)}", "todo_write", {"todos": [
                    {"content": "委派调研子智能体探查工作区与外部接入数据源", "status": "in_progress"},
                    {"content": "编写分析处理脚本与初稿报告", "status": "pending"},
                    {"content": "精确修订报告并核验产出", "status": "pending"},
                ]}),
                ToolCall(f"m{next(self._ids)}", "delegate_task", {
                    "agent_type": "researcher",
                    "role": "工作区与数据调研专家",
                    "task": "扫描当前工作区目录结构并汇报可分析的数据文件。",
                }),
            ]
            if conn_match:
                calls.append(ToolCall(f"m{next(self._ids)}", "connector_query", {"connector": conn_match.group(1)}))
            elif url_match:
                calls.append(ToolCall(f"m{next(self._ids)}", "browser_inspect", {"url": url_match.group(0), "render_js": False}))
            return LLMResponse(
                thinking=(
                    f"正在拆解用户任务：「{task[:80]}」\n"
                    + mem_note
                    + "1. 首先使用 todo_write 建立可追踪的三阶段执行计划；\n"
                    + "2. 派出只读子智能体 `researcher`（工作区与数据调研专家）扫描输入材料"
                    + (f"，并调用 connector_query 读取外部连接器 `{conn_match.group(1)}` 的数据；\n" if conn_match else "；\n")
                    + "3. 随后生成可复现脚本与正式报告，并通过 edit_file 做精确修订以生成逐行审阅 Diff。"
                ),
                content="",
                tool_calls=calls,
            )

        wrote_files = any(
            tc.name == "write_file"
            for m in turn_msgs if m.role == "assistant"
            for tc in m.tool_calls
        )
        edited_files = any(
            tc.name == "edit_file"
            for m in turn_msgs if m.role == "assistant"
            for tc in m.tool_calls
        )

        if not wrote_files:
            tool_obs = "\n".join(m.content[:300] for m in turn_msgs if m.role == "tool" and m.name != "todo_write")
            return LLMResponse(
                thinking=(
                    "已获取工作区与数据源信息。现在生成两份核心产物：\n"
                    "- `outputs/analyze_metrics.py`：自动化数据核查与指标汇总脚本；\n"
                    "- `outputs/mock_report.md`：结构化分析报告初稿（待下一步精细化润色）。"
                ),
                content="",
                tool_calls=[
                    ToolCall(f"m{next(self._ids)}", "todo_write", {"todos": [
                        {"content": "探查工作区文件与外部接入数据源", "status": "completed"},
                        {"content": "编写分析处理脚本与初稿报告", "status": "in_progress"},
                        {"content": "精确修订报告并核验产出", "status": "pending"},
                    ]}),
                    ToolCall(f"m{next(self._ids)}", "write_file", {
                        "path": "outputs/analyze_metrics.py",
                        "content": (
                            '"""自动化指标汇总脚本（Mock 演示）。"""\n'
                            "from pathlib import Path\n\n"
                            "def summarize_workspace(root: str = '.') -> dict:\n"
                            "    files = [p.name for p in Path(root).rglob('*') if p.is_file()]\n"
                            "    return {'file_count': len(files), 'sample': files[:10]}\n\n"
                            "if __name__ == '__main__':\n"
                            "    print(summarize_workspace())\n"
                        ),
                    }),
                    ToolCall(f"m{next(self._ids)}", "write_file", {
                        "path": "outputs/mock_report.md",
                        "content": (
                            f"# 演示报告\n\n"
                            f"## 一、任务概述\n任务：{task[:240]}\n\n"
                            f"## 二、数据与环境摘要\n状态：初稿待核验\n\n"
                            f"```\n{tool_obs[:400]}\n```\n\n"
                            f"这是 Mock 模型生成的报告，用于验证工具链路。\n"
                        ),
                    }),
                ],
            )

        if not edited_files:
            return LLMResponse(
                thinking=(
                    "初稿已写入。现在使用 edit_file 将报告中的「初稿待核验」更新为正式结论摘要，"
                    "以生成清晰的增量 Diff 供侧边栏审阅，并将所有计划项标记为 completed。"
                ),
                content="",
                tool_calls=[
                    ToolCall(f"m{next(self._ids)}", "edit_file", {
                        "path": "outputs/mock_report.md",
                        "old_string": "状态：初稿待核验",
                        "new_string": "状态：已完成结构化校验 ✅\n- 指标脚本：`outputs/analyze_metrics.py`\n- 审阅建议：可在右侧变更审阅栏查看逐行 Diff",
                    }),
                    ToolCall(f"m{next(self._ids)}", "todo_write", {"todos": [
                        {"content": "探查工作区文件与外部接入数据源", "status": "completed"},
                        {"content": "编写分析处理脚本与初稿报告", "status": "completed"},
                        {"content": "精确修订报告并核验产出", "status": "completed"},
                    ]}),
                ],
            )

        has_review = any(
            m.role == "user" and m.meta.get("system") and "自检" in m.content
            for m in turn_msgs
        )
        if not has_review:
            return LLMResponse(
                thinking="所有计划步骤均已执行完毕，准备触发系统交付前质量自检。",
                content="",
                tool_calls=[],
            )

        return LLMResponse(
            thinking="正在复核所有计划项与产出文件：`outputs/mock_report.md` 与 `outputs/analyze_metrics.py` 均已生成且修订无误，可以向用户交付。",
            content=(
                "✅ 演示完成：已生成并修订 `outputs/mock_report.md` 与 `outputs/analyze_metrics.py`。\n\n"
                "- 可在上方折叠区展开查看**完整思维链（CoT）与工具调用轨迹**\n"
                "- 可点击**文件变更卡片 / Review 按钮**在右侧可伸缩侧边栏查看逐行 Diff 与编辑文件\n"
                "（当前为离线 Mock 演示模型，配置真实大模型 API Key 后即可启用完整推理能力）"
            ),
            tool_calls=[],
        )

    async def _complete(self, system, messages, tools, on_delta):
        self.calls.append(list(messages))
        if self.script is None:
            resp = self._demo(messages, system)
        elif not self.script:
            resp = LLMResponse(content="(mock 脚本已结束)", tool_calls=[])
        else:
            step = self.script.pop(0)
            resp = step(messages) if callable(step) else step
        pace = 0.028 if (on_delta and not os.environ.get("PYTEST_CURRENT_TEST")) else 0.0
        if on_delta and resp.thinking:
            for i in range(0, len(resp.thinking), 16):
                await on_delta("thinking", resp.thinking[i:i + 16])
                if pace:
                    await asyncio.sleep(pace)
        if on_delta and resp.content:
            for i in range(0, len(resp.content), 14):
                await on_delta("text", resp.content[i:i + 14])
                if pace:
                    await asyncio.sleep(pace)
        resp.usage = Usage(
            input_tokens=sum(len(m.content) for m in messages) // 3,
            output_tokens=(len(resp.content) + len(resp.thinking)) // 3,
        )
        return resp
