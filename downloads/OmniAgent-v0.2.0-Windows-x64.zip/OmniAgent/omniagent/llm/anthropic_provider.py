"""Anthropic Claude 后端（原生 Messages API，支持流式、工具调用、提示缓存）。"""
from __future__ import annotations

from typing import Any

from anthropic import AsyncAnthropic

from .types import DeltaCallback, LLMProvider, LLMResponse, Message, ToolCall, Usage, message_images


class AnthropicProvider(LLMProvider):
    def __init__(self, profile):
        super().__init__(profile)
        kwargs: dict[str, Any] = {"max_retries": 0, "timeout": 600}
        api_key = profile.resolve_api_key()
        token = None if api_key else (profile.resolve_auth_token() if hasattr(profile, "resolve_auth_token") else None)
        if token:
            kwargs["auth_token"] = token  # ANTHROPIC_AUTH_TOKEN → Authorization: Bearer
        else:
            kwargs["api_key"] = api_key
        base_url = profile.resolve_base_url() if hasattr(profile, "resolve_base_url") else profile.base_url
        if base_url:
            kwargs["base_url"] = base_url
        self.client = AsyncAnthropic(**kwargs)

    @staticmethod
    def _tool_result_content(m: Message, vision: bool) -> Any:
        images = message_images(m)
        text = m.content or "(空)"
        if not images:
            return text
        if not vision:
            return text + f"\n[附带的 {len(images)} 张图片未发送：当前模型不支持图像输入]"
        blocks: list[dict[str, Any]] = [{"type": "text", "text": text}]
        for img in images:
            blocks.append({"type": "image", "source": {"type": "base64", "media_type": img.get("media_type") or "image/png",
                                                       "data": img["data"]}})
        return blocks

    @staticmethod
    def _convert(messages: list[Message], vision: bool = True) -> list[dict[str, Any]]:
        """转换为 Anthropic 格式，并合并相邻同角色消息（API 要求 user/assistant 交替）。"""
        out: list[dict[str, Any]] = []

        def push(role: str, blocks: list[dict[str, Any]]):
            if not blocks:
                return
            if out and out[-1]["role"] == role:
                out[-1]["content"].extend(blocks)
            else:
                out.append({"role": role, "content": list(blocks)})

        for m in messages:
            if m.role == "assistant":
                blocks: list[dict[str, Any]] = []
                if m.content:
                    blocks.append({"type": "text", "text": m.content})
                for tc in m.tool_calls:
                    blocks.append({"type": "tool_use", "id": tc.id, "name": tc.name, "input": tc.arguments})
                if not blocks:
                    blocks.append({"type": "text", "text": "(继续)"})
                push("assistant", blocks)
            elif m.role == "tool":
                push(
                    "user",
                    [
                        {
                            "type": "tool_result",
                            "tool_use_id": m.tool_call_id,
                            "content": AnthropicProvider._tool_result_content(m, vision),
                            "is_error": bool(m.is_error),
                        }
                    ],
                )
            else:
                push("user", [{"type": "text", "text": m.content or "(空)"}])
        # 在最后一条消息上打缓存断点，提高长任务的缓存命中率
        if out and out[-1]["content"]:
            last = out[-1]["content"][-1]
            if last.get("type") in ("text", "tool_result"):
                last["cache_control"] = {"type": "ephemeral"}
        return out

    async def _complete(self, system, messages, tools, on_delta: DeltaCallback | None) -> LLMResponse:
        p = self.profile
        kwargs: dict[str, Any] = {
            "model": p.model,
            "max_tokens": p.max_tokens,
            "system": [{"type": "text", "text": system, "cache_control": {"type": "ephemeral"}}],
            "messages": self._convert(messages, bool(getattr(p, "vision", True))),
        }
        if p.temperature is not None:
            kwargs["temperature"] = p.temperature
        if tools:
            schemas = [{"name": t.name, "description": t.description, "input_schema": t.parameters} for t in tools]
            schemas[-1]["cache_control"] = {"type": "ephemeral"}
            kwargs["tools"] = schemas
        kwargs.update(p.extra.get("request_params", {}))

        async with self.client.messages.stream(**kwargs) as stream:
            async for event in stream:
                if event.type == "content_block_delta":
                    d = event.delta
                    if d.type == "text_delta" and on_delta:
                        await on_delta("text", d.text)
                    elif d.type == "thinking_delta" and on_delta:
                        await on_delta("thinking", d.thinking)
            final = await stream.get_final_message()

        text, thinking, calls = [], [], []
        for block in final.content:
            if block.type == "text":
                text.append(block.text)
            elif block.type == "thinking":
                thinking.append(block.thinking)
            elif block.type == "tool_use":
                calls.append(ToolCall(id=block.id, name=block.name, arguments=dict(block.input or {})))
        u = final.usage
        usage = Usage(
            input_tokens=(u.input_tokens or 0) + (getattr(u, "cache_read_input_tokens", 0) or 0)
            + (getattr(u, "cache_creation_input_tokens", 0) or 0),
            output_tokens=u.output_tokens or 0,
            cache_read_tokens=getattr(u, "cache_read_input_tokens", 0) or 0,
        )
        return LLMResponse(
            content="".join(text), tool_calls=calls, usage=usage, stop_reason=final.stop_reason, thinking="".join(thinking)
        )
