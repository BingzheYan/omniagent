"""双向外部协议与状态追踪引擎：
1. EmailBackend     — 标准 IMAP/SMTP 邮件收发、会话线程回复（In-Reply-To / References）、附件提取 + 离线沙箱邮箱
2. CalendarBackend  — RFC 5545 iCalendar (.ics) 解析与生成、CalDAV 同步、冲突检测、日程增删改与到期提醒
3. WebSessionEngine — 有状态交互式 Web 会话（Cookie 保持、表单字段自动索引、输入填充、简历/附件上传、按钮点击提交）
4. TrackerStore     — 跨会话外部动态持续追踪器（邮件回信跟进、日程提醒、求职投递流水线、外部接口轮询监控）
"""
from __future__ import annotations

import datetime as dt
import email
import email.policy
import html.parser
import imaplib
import json
import mimetypes
import re
import smtplib
import sqlite3
import threading
import time
import urllib.parse
import uuid
from email.header import decode_header
from email.message import EmailMessage
from email.utils import formataddr, make_msgid, parsedate_to_datetime
from pathlib import Path
from typing import Any

import httpx


# ============================================================================ 1. Email Backend (IMAP + SMTP + Sandbox)

MAILBOX_SCHEMA = """
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS mail_messages (
    id TEXT PRIMARY KEY,
    message_id TEXT NOT NULL,
    thread_id TEXT NOT NULL,
    folder TEXT NOT NULL DEFAULT 'INBOX',
    sender TEXT NOT NULL,
    recipients TEXT NOT NULL,
    cc TEXT DEFAULT '',
    subject TEXT NOT NULL,
    body TEXT NOT NULL,
    in_reply_to TEXT DEFAULT '',
    references_hdr TEXT DEFAULT '',
    attachments TEXT DEFAULT '[]',
    is_read INTEGER DEFAULT 0,
    is_flagged INTEGER DEFAULT 0,
    ts REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_mail_folder ON mail_messages(folder, ts DESC);
CREATE INDEX IF NOT EXISTS idx_mail_thread ON mail_messages(thread_id, ts ASC);
"""


def _decode_mime_words(raw: str | None) -> str:
    if not raw:
        return ""
    parts = []
    for chunk, enc in decode_header(raw):
        if isinstance(chunk, bytes):
            parts.append(chunk.decode(enc or "utf-8", errors="replace"))
        else:
            parts.append(str(chunk))
    return "".join(parts).strip()


class EmailBackend:
    """支持真实 IMAP/SMTP 与本地 SQLite 沙箱双模式的双向邮件引擎。"""

    def __init__(self, workspace: Path, config: dict[str, Any] | None = None):
        self.workspace = Path(workspace).resolve()
        self.cfg = dict(config or {})
        self.mode = "imap_smtp" if (self.cfg.get("imap_host") or self.cfg.get("smtp_host")) and self.cfg.get("mode") != "sandbox" else "sandbox"
        self.db_path = Path(self.cfg.get("mailbox_db") or (self.workspace / ".omniagent" / "mailbox.db")).resolve()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(self.db_path), check_same_thread=False, isolation_level=None)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(MAILBOX_SCHEMA)

    def close(self) -> None:
        self.conn.close()

    def seed_inbound(
        self,
        *,
        sender: str,
        subject: str,
        body: str,
        recipient: str = "me@omniagent.local",
        in_reply_to: str = "",
        attachments: list[str] | None = None,
    ) -> dict[str, Any]:
        """向本地沙箱收件箱注入一封外部来信（便于离线模拟测试或本地邮件网关接入）。"""
        uid = f"m_{uuid.uuid4().hex[:10]}"
        msg_id = make_msgid(domain="external.mail")
        thread_id = msg_id
        if in_reply_to:
            parent = self.conn.execute(
                "SELECT thread_id FROM mail_messages WHERE message_id=?", (in_reply_to,)
            ).fetchone()
            if parent:
                thread_id = parent["thread_id"]
        now = time.time()
        self.conn.execute(
            """INSERT INTO mail_messages(id, message_id, thread_id, folder, sender, recipients, subject, body,
               in_reply_to, references_hdr, attachments, is_read, ts)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,0,?)""",
            (uid, msg_id, thread_id, "INBOX", sender, recipient, subject, body,
             in_reply_to, in_reply_to, json.dumps(attachments or [], ensure_ascii=False), now),
        )
        row = self.conn.execute("SELECT * FROM mail_messages WHERE id=?", (uid,)).fetchone()
        return dict(row) | {"attachments": json.loads(row["attachments"] or "[]"), "is_read": False}

    def list_messages(self, *, folder: str = "INBOX", unread_only: bool = False, query: str = "", limit: int = 20
                      ) -> list[dict[str, Any]]:
        if self.mode == "imap_smtp" and self.cfg.get("imap_host"):
            return self._imap_list(folder=folder, unread_only=unread_only, query=query, limit=limit)
        sql = "SELECT * FROM mail_messages WHERE folder=?"
        params: list[Any] = [folder.upper()]
        if unread_only:
            sql += " AND is_read=0"
        if query:
            sql += " AND (subject LIKE ? OR sender LIKE ? OR body LIKE ?)"
            pat = f"%{query}%"
            params.extend([pat, pat, pat])
        sql += " ORDER BY ts DESC LIMIT ?"
        params.append(limit)
        rows = self.conn.execute(sql, params).fetchall()
        return [dict(r) | {"attachments": json.loads(r["attachments"] or "[]"), "is_read": bool(r["is_read"])} for r in rows]

    def read_message(self, msg_uid: str, *, save_attachments_dir: Path | None = None) -> dict[str, Any]:
        if self.mode == "imap_smtp" and self.cfg.get("imap_host") and not msg_uid.startswith("m_"):
            return self._imap_read(msg_uid, save_attachments_dir=save_attachments_dir)
        row = self.conn.execute(
            "SELECT * FROM mail_messages WHERE id=? OR message_id=?", (msg_uid, msg_uid)
        ).fetchone()
        if not row:
            raise KeyError(f"邮件不存在: {msg_uid}")
        self.conn.execute("UPDATE mail_messages SET is_read=1 WHERE id=?", (row["id"],))
        d = dict(row)
        d["is_read"] = True
        d["attachments"] = json.loads(row["attachments"] or "[]")
        thread_rows = self.conn.execute(
            "SELECT id, sender, subject, ts, folder FROM mail_messages WHERE thread_id=? ORDER BY ts ASC",
            (row["thread_id"],),
        ).fetchall()
        d["thread_messages"] = [dict(x) for x in thread_rows]
        return d

    def send_or_draft(
        self,
        *,
        to: str,
        subject: str,
        body: str,
        cc: str = "",
        reply_to_id: str = "",
        attachments: list[Path] | None = None,
        draft_only: bool = False,
    ) -> dict[str, Any]:
        in_reply_to = ""
        refs = ""
        thread_id = ""
        if reply_to_id:
            orig = self.read_message(reply_to_id)
            in_reply_to = orig.get("message_id") or ""
            prev_refs = orig.get("references_hdr") or ""
            refs = (f"{prev_refs} {in_reply_to}").strip()
            thread_id = orig.get("thread_id") or in_reply_to
            if not subject:
                sub = orig.get("subject") or ""
                subject = sub if sub.lower().startswith("re:") else f"Re: {sub}"
            if not to:
                to = orig.get("sender") or ""

        msg_id = make_msgid(domain="omniagent.local")
        thread_id = thread_id or msg_id
        folder = "DRAFTS" if draft_only else "SENT"
        sender_addr = str(self.cfg.get("from_email") or self.cfg.get("username") or "me@omniagent.local")

        if not draft_only and self.mode == "imap_smtp" and self.cfg.get("smtp_host"):
            self._smtp_send(
                sender=sender_addr, to=to, cc=cc, subject=subject, body=body,
                msg_id=msg_id, in_reply_to=in_reply_to, references=refs, attachments=attachments,
            )

        uid = f"m_{uuid.uuid4().hex[:10]}"
        att_names = [str(p) for p in (attachments or [])]
        now = time.time()
        self.conn.execute(
            """INSERT INTO mail_messages(id, message_id, thread_id, folder, sender, recipients, cc, subject, body,
               in_reply_to, references_hdr, attachments, is_read, ts)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,1,?)""",
            (uid, msg_id, thread_id, folder, sender_addr, to, cc, subject, body,
             in_reply_to, refs, json.dumps(att_names, ensure_ascii=False), now),
        )
        return {
            "id": uid,
            "message_id": msg_id,
            "thread_id": thread_id,
            "folder": folder,
            "to": to,
            "subject": subject,
            "status": "draft_saved" if draft_only else "sent",
            "mode": self.mode,
        }

    def thread_status(self, thread_or_msg_id: str) -> dict[str, Any]:
        row = self.conn.execute(
            "SELECT thread_id FROM mail_messages WHERE thread_id=? OR id=? OR message_id=? LIMIT 1",
            (thread_or_msg_id, thread_or_msg_id, thread_or_msg_id),
        ).fetchone()
        if not row:
            return {"found": False, "messages": [], "has_new_external_reply": False}
        tid = row["thread_id"]
        msgs = [
            dict(r) for r in self.conn.execute(
                "SELECT id, message_id, folder, sender, recipients, subject, body, is_read, ts FROM mail_messages WHERE thread_id=? ORDER BY ts ASC",
                (tid,),
            ).fetchall()
        ]
        last = msgs[-1] if msgs else {}
        return {
            "found": True,
            "thread_id": tid,
            "message_count": len(msgs),
            "latest_folder": last.get("folder"),
            "latest_sender": last.get("sender"),
            "latest_subject": last.get("subject"),
            "latest_snippet": str(last.get("body") or "")[:240],
            "has_new_external_reply": bool(last.get("folder") == "INBOX"),
            "messages": msgs,
        }

    # ---- Real IMAP / SMTP implementations ----
    def _imap_conn(self) -> imaplib.IMAP4:
        host = str(self.cfg["imap_host"])
        port = int(self.cfg.get("imap_port") or 993)
        use_ssl = bool(self.cfg.get("use_ssl", True))
        cli = imaplib.IMAP4_SSL(host, port) if use_ssl else imaplib.IMAP4(host, port)
        cli.login(str(self.cfg.get("username") or ""), str(self.cfg.get("password") or ""))
        return cli

    def _imap_list(self, *, folder: str, unread_only: bool, query: str, limit: int) -> list[dict[str, Any]]:
        cli = self._imap_conn()
        try:
            cli.select(folder or "INBOX", readonly=True)
            crit = "UNSEEN" if unread_only else "ALL"
            _typ, data = cli.search(None, crit)
            ids = (data[0].split() if data and data[0] else [])[-limit:]
            out: list[dict[str, Any]] = []
            for num in reversed(ids):
                _t, msg_data = cli.fetch(num, "(BODY.PEEK[HEADER.FIELDS (SUBJECT FROM TO DATE MESSAGE-ID REFERENCES)])")
                if not msg_data or not msg_data[0]:
                    continue
                em = email.message_from_bytes(msg_data[0][1], policy=email.policy.default)
                subj = _decode_mime_words(em.get("Subject"))
                frm = _decode_mime_words(em.get("From"))
                if query and query.lower() not in f"{subj} {frm}".lower():
                    continue
                dt_val = time.time()
                try:
                    if em.get("Date"):
                        dt_val = parsedate_to_datetime(em.get("Date")).timestamp()
                except Exception:  # noqa: BLE001
                    pass
                out.append({
                    "id": num.decode(),
                    "message_id": str(em.get("Message-ID") or "").strip(),
                    "thread_id": str(em.get("References") or em.get("Message-ID") or "").split()[0] if (em.get("References") or em.get("Message-ID")) else num.decode(),
                    "folder": folder,
                    "sender": frm,
                    "recipients": _decode_mime_words(em.get("To")),
                    "subject": subj,
                    "is_read": not unread_only,
                    "ts": dt_val,
                })
            return out
        finally:
            try:
                cli.logout()
            except Exception:  # noqa: BLE001
                pass

    def _imap_read(self, uid: str, *, save_attachments_dir: Path | None = None) -> dict[str, Any]:
        cli = self._imap_conn()
        try:
            cli.select("INBOX", readonly=False)
            _t, msg_data = cli.fetch(uid.encode(), "(RFC822)")
            if not msg_data or not msg_data[0]:
                raise KeyError(f"IMAP 邮件未找到: {uid}")
            em = email.message_from_bytes(msg_data[0][1], policy=email.policy.default)
            body_text = ""
            saved_atts: list[str] = []
            for part in em.walk():
                cdisp = str(part.get("Content-Disposition") or "")
                ctype = part.get_content_type()
                if "attachment" in cdisp and part.get_filename():
                    fname = Path(_decode_mime_words(part.get_filename())).name
                    if save_attachments_dir:
                        save_attachments_dir.mkdir(parents=True, exist_ok=True)
                        dest = save_attachments_dir / fname
                        dest.write_bytes(part.get_payload(decode=True) or b"")
                        saved_atts.append(str(dest))
                    else:
                        saved_atts.append(fname)
                elif ctype == "text/plain" and not body_text:
                    payload = part.get_payload(decode=True) or b""
                    body_text = payload.decode(part.get_content_charset() or "utf-8", errors="replace")
            return {
                "id": uid,
                "message_id": str(em.get("Message-ID") or "").strip(),
                "thread_id": (str(em.get("References") or em.get("Message-ID") or "").split() or [uid])[0],
                "sender": _decode_mime_words(em.get("From")),
                "recipients": _decode_mime_words(em.get("To")),
                "subject": _decode_mime_words(em.get("Subject")),
                "body": body_text[:30_000],
                "in_reply_to": str(em.get("In-Reply-To") or "").strip(),
                "references_hdr": str(em.get("References") or "").strip(),
                "attachments": saved_atts,
            }
        finally:
            try:
                cli.logout()
            except Exception:  # noqa: BLE001
                pass

    def _smtp_send(self, *, sender: str, to: str, cc: str, subject: str, body: str, msg_id: str,
                   in_reply_to: str, references: str, attachments: list[Path] | None) -> None:
        em = EmailMessage()
        em["From"] = formataddr((str(self.cfg.get("sender_name") or ""), sender)) if self.cfg.get("sender_name") else sender
        em["To"] = to
        if cc:
            em["Cc"] = cc
        em["Subject"] = subject
        em["Message-ID"] = msg_id
        if in_reply_to:
            em["In-Reply-To"] = in_reply_to
        if references:
            em["References"] = references
        em.set_content(body)
        for p in attachments or []:
            if p.is_file():
                mtype, _ = mimetypes.guess_type(p.name)
                maintype, subtype = (mtype or "application/octet-stream").split("/", 1)
                em.add_attachment(p.read_bytes(), maintype=maintype, subtype=subtype, filename=p.name)

        host = str(self.cfg["smtp_host"])
        port = int(self.cfg.get("smtp_port") or 465)
        user = str(self.cfg.get("username") or sender)
        pw = str(self.cfg.get("password") or "")
        if port == 465:
            with smtplib.SMTP_SSL(host, port, timeout=25) as s:
                if pw:
                    s.login(user, pw)
                s.send_message(em)
        else:
            with smtplib.SMTP(host, port, timeout=25) as s:
                s.starttls()
                if pw:
                    s.login(user, pw)
                s.send_message(em)


# ============================================================================ 2. Calendar Backend (.ics + CalDAV + SQLite)

CALENDAR_SCHEMA = """
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS calendar_events (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    start_iso TEXT NOT NULL,
    end_iso TEXT NOT NULL,
    start_ts REAL NOT NULL,
    end_ts REAL NOT NULL,
    location TEXT DEFAULT '',
    description TEXT DEFAULT '',
    attendees TEXT DEFAULT '[]',
    reminder_minutes INTEGER DEFAULT 15,
    reminded INTEGER DEFAULT 0,
    status TEXT DEFAULT 'confirmed',
    created REAL NOT NULL,
    updated REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_cal_time ON calendar_events(start_ts ASC, end_ts ASC);
"""


def _parse_iso_ts(iso_str: str) -> tuple[str, float]:
    s = str(iso_str).strip()
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", s):
        s += "T09:00:00"
    s_norm = s.replace(" ", "T")
    if s_norm.endswith("Z"):
        d = dt.datetime.fromisoformat(s_norm[:-1]).replace(tzinfo=dt.timezone.utc)
    else:
        d = dt.datetime.fromisoformat(s_norm)
    return d.isoformat(timespec="minutes"), d.timestamp()


def generate_ics_event(ev: dict[str, Any]) -> str:
    """生成符合 RFC 5545 标准的 iCalendar (.ics) 日程邀请文件。"""
    def _ics_dt(ts: float) -> str:
        return dt.datetime.fromtimestamp(ts, tz=dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")

    def _esc_ics(val: str) -> str:
        return str(val or "").replace("\\", "\\\\").replace("\n", "\\n").replace(",", "\\,").replace(";", "\\;")

    lines = [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        "PRODID:-//OmniAgent//Autonomous Calendar//CN",
        "CALSCALE:GREGORIAN",
        "METHOD:PUBLISH",
        "BEGIN:VEVENT",
        f"UID:{ev['id']}@omniagent.local",
        f"DTSTAMP:{_ics_dt(time.time())}",
        f"DTSTART:{_ics_dt(ev['start_ts'])}",
        f"DTEND:{_ics_dt(ev['end_ts'])}",
        f"SUMMARY:{_esc_ics(ev['title'])}",
    ]
    if ev.get("location"):
        lines.append(f"LOCATION:{_esc_ics(ev['location'])}")
    if ev.get("description"):
        lines.append(f"DESCRIPTION:{_esc_ics(ev['description'])}")
    for att in ev.get("attendees") or []:
        lines.append(f"ATTENDEE;CN={_esc_ics(att)}:mailto:{_esc_ics(att)}")
    rem = int(ev.get("reminder_minutes") or 0)
    if rem > 0:
        lines += [
            "BEGIN:VALARM",
            f"TRIGGER:-PT{rem}M",
            "ACTION:DISPLAY",
            f"DESCRIPTION:日程提醒：{_esc_ics(ev['title'])}",
            "END:VALARM",
        ]
    lines += ["END:VEVENT", "END:VCALENDAR"]
    return "\r\n".join(lines) + "\r\n"


def parse_ics_text(ics_text: str) -> list[dict[str, Any]]:
    """解析标准 .ics 文本中的全部 VEVENT 事件。"""
    unfolded = re.sub(r"\r?\n[ \t]", "", ics_text or "")
    events: list[dict[str, Any]] = []
    cur: dict[str, str] | None = None
    for line in unfolded.splitlines():
        s = line.strip()
        if s == "BEGIN:VEVENT":
            cur = {}
        elif s == "END:VEVENT" and cur is not None:
            events.append(cur)
            cur = None
        elif cur is not None and ":" in s:
            k, _, v = s.partition(":")
            base_k = k.split(";")[0].upper()
            cur[base_k] = v.replace("\\n", "\n").replace("\\,", ",")
    parsed: list[dict[str, Any]] = []
    for e in events:
        raw_s = e.get("DTSTART", "")
        raw_e = e.get("DTEND", raw_s)
        try:
            fmt = "%Y%m%dT%H%M%SZ" if raw_s.endswith("Z") else ("%Y%m%dT%H%M%S" if "T" in raw_s else "%Y%m%d")
            ds = dt.datetime.strptime(raw_s, fmt)
            de = dt.datetime.strptime(raw_e, "%Y%m%dT%H%M%SZ" if raw_e.endswith("Z") else ("%Y%m%dT%H%M%S" if "T" in raw_e else "%Y%m%d"))
            if de <= ds:
                de = ds + dt.timedelta(hours=1)
            parsed.append({
                "uid": e.get("UID") or f"ics_{uuid.uuid4().hex[:8]}",
                "title": e.get("SUMMARY") or "未命名日程",
                "start_iso": ds.isoformat(timespec="minutes"),
                "end_iso": de.isoformat(timespec="minutes"),
                "location": e.get("LOCATION", ""),
                "description": e.get("DESCRIPTION", ""),
            })
        except ValueError:
            continue
    return parsed


class CalendarBackend:
    """日历与提醒管理引擎（本地持久化 + .ics 导入导出 + 可选 CalDAV 推送）。"""

    def __init__(self, workspace: Path, config: dict[str, Any] | None = None):
        self.workspace = Path(workspace).resolve()
        self.cfg = dict(config or {})
        self.db_path = Path(self.cfg.get("calendar_db") or (self.workspace / ".omniagent" / "calendar.db")).resolve()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(self.db_path), check_same_thread=False, isolation_level=None)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(CALENDAR_SCHEMA)

    def close(self) -> None:
        self.conn.close()

    @staticmethod
    def _row_dict(r: sqlite3.Row) -> dict[str, Any]:
        d = dict(r)
        d["attendees"] = json.loads(r["attendees"] or "[]")
        d["reminded"] = bool(r["reminded"])
        return d

    def list_events(self, *, start_iso: str = "", end_iso: str = "", include_cancelled: bool = False
                    ) -> list[dict[str, Any]]:
        clauses = []
        params: list[Any] = []
        if not include_cancelled:
            clauses.append("status<>'cancelled'")
        if start_iso:
            _, ts = _parse_iso_ts(start_iso)
            clauses.append("end_ts >= ?")
            params.append(ts)
        if end_iso:
            _, ts = _parse_iso_ts(end_iso)
            clauses.append("start_ts <= ?")
            params.append(ts)
        where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
        rows = self.conn.execute(f"SELECT * FROM calendar_events {where} ORDER BY start_ts ASC LIMIT 200", params).fetchall()
        return [self._row_dict(r) for r in rows]

    def check_conflicts(self, start_iso: str, end_iso: str, exclude_id: str = "") -> list[dict[str, Any]]:
        _, s_ts = _parse_iso_ts(start_iso)
        _, e_ts = _parse_iso_ts(end_iso)
        rows = self.conn.execute(
            "SELECT * FROM calendar_events WHERE status='confirmed' AND start_ts < ? AND end_ts > ? AND id <> ? ORDER BY start_ts ASC",
            (e_ts, s_ts, exclude_id),
        ).fetchall()
        return [self._row_dict(r) for r in rows]

    async def upsert_event(
        self,
        *,
        title: str,
        start_iso: str,
        end_iso: str = "",
        location: str = "",
        description: str = "",
        attendees: list[str] | None = None,
        reminder_minutes: int = 15,
        event_id: str = "",
    ) -> dict[str, Any]:
        s_iso, s_ts = _parse_iso_ts(start_iso)
        if end_iso:
            e_iso, e_ts = _parse_iso_ts(end_iso)
        else:
            e_dt = dt.datetime.fromtimestamp(s_ts) + dt.timedelta(hours=1)
            e_iso, e_ts = e_dt.isoformat(timespec="minutes"), e_dt.timestamp()
        if e_ts <= s_ts:
            raise ValueError("结束时间必须晚于开始时间")

        conflicts = self.check_conflicts(s_iso, e_iso, exclude_id=event_id)
        eid = event_id or f"cal_{uuid.uuid4().hex[:10]}"
        now = time.time()
        self.conn.execute(
            """INSERT INTO calendar_events(id, title, start_iso, end_iso, start_ts, end_ts, location, description,
               attendees, reminder_minutes, status, created, updated)
               VALUES (?,?,?,?,?,?,?,?,?,?,'confirmed',?,?)
               ON CONFLICT(id) DO UPDATE SET title=excluded.title, start_iso=excluded.start_iso,
               end_iso=excluded.end_iso, start_ts=excluded.start_ts, end_ts=excluded.end_ts,
               location=excluded.location, description=excluded.description, attendees=excluded.attendees,
               reminder_minutes=excluded.reminder_minutes, updated=excluded.updated""",
            (eid, title.strip(), s_iso, e_iso, s_ts, e_ts, location.strip(), description.strip(),
             json.dumps(attendees or [], ensure_ascii=False), int(reminder_minutes), now, now),
        )
        ev = self._row_dict(self.conn.execute("SELECT * FROM calendar_events WHERE id=?", (eid,)).fetchone())
        ev["conflicts"] = conflicts

        # 若配置了远程 CalDAV 地址，同步推送 .ics
        caldav_url = str(self.cfg.get("caldav_url") or "").rstrip("/")
        if caldav_url.startswith(("http://", "https://")):
            ics_body = generate_ics_event(ev)
            auth = (str(self.cfg["username"]), str(self.cfg.get("password") or "")) if self.cfg.get("username") else None
            async with httpx.AsyncClient(timeout=20, auth=auth) as client:
                await client.put(f"{caldav_url}/{eid}.ics", content=ics_body.encode("utf-8"),
                                 headers={"Content-Type": "text/calendar; charset=utf-8"})
        return ev

    def delete_event(self, event_id: str) -> bool:
        cur = self.conn.execute("DELETE FROM calendar_events WHERE id=?", (event_id,))
        return cur.rowcount > 0

    def due_reminders(self, within_minutes: int = 60, now_ts: float | None = None) -> list[dict[str, Any]]:
        now = now_ts if now_ts is not None else time.time()
        horizon = now + within_minutes * 60
        rows = self.conn.execute(
            """SELECT * FROM calendar_events
               WHERE status='confirmed' AND end_ts >= ? AND (start_ts - reminder_minutes * 60) <= ?
               ORDER BY start_ts ASC""",
            (now, horizon),
        ).fetchall()
        return [self._row_dict(r) for r in rows]


# ============================================================================ 3. Interactive Web Session Engine

class _InteractiveDOMParser(html.parser.HTMLParser):
    """提取网页文本、表单结构以及所有可交互控件（input / textarea / select / button / a），赋予稳定短引用 [e1]..[eN]。"""

    SKIP = {"script", "style", "noscript", "svg"}

    def __init__(self, base_url: str):
        super().__init__()
        self.base_url = base_url
        self.skip = 0
        self.in_title = False
        self.title = ""
        self.text_parts: list[str] = []
        self.forms: list[dict[str, Any]] = []
        self.elements: dict[str, dict[str, Any]] = {}
        self._counter = 0
        self._cur_form: dict[str, Any] | None = None
        self._cur_select: dict[str, Any] | None = None
        self._cur_option_val: str | None = None
        self._cur_option_text: list[str] = []
        self._cur_textarea: dict[str, Any] | None = None
        self._cur_textarea_buf: list[str] = []
        self._cur_btn: dict[str, Any] | None = None
        self._cur_btn_buf: list[str] = []

    def _next_ref(self) -> str:
        self._counter += 1
        return f"e{self._counter}"

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]):
        ad = {k.lower(): (v or "") for k, v in attrs}
        if tag in self.SKIP:
            self.skip += 1
            return
        if tag == "title":
            self.in_title = True
            return
        if tag in ("p", "div", "br", "li", "tr", "h1", "h2", "h3", "h4", "section", "article", "label"):
            self.text_parts.append("\n")
        if tag == "form":
            action = urllib.parse.urljoin(self.base_url, ad.get("action") or self.base_url)
            self._cur_form = {
                "form_index": len(self.forms),
                "action": action,
                "method": (ad.get("method") or "GET").upper(),
                "enctype": ad.get("enctype") or "application/x-www-form-urlencoded",
                "fields": {},
                "files": {},
            }
            self.forms.append(self._cur_form)
        elif tag == "input":
            itype = (ad.get("type") or "text").lower()
            name = ad.get("name") or ad.get("id") or ""
            val = ad.get("value") or ""
            if self._cur_form is not None and name and itype not in ("submit", "button", "file", "checkbox", "radio"):
                self._cur_form["fields"][name] = val
            elif self._cur_form is not None and name and itype in ("checkbox", "radio") and "checked" in ad:
                self._cur_form["fields"][name] = val or "on"
            if itype == "hidden":
                return
            ref = self._next_ref()
            el = {
                "ref": ref,
                "tag": "input",
                "type": itype,
                "name": name,
                "label": ad.get("placeholder") or ad.get("aria-label") or name,
                "value": val,
                "required": "required" in ad,
                "form_index": self._cur_form["form_index"] if self._cur_form is not None else None,
            }
            self.elements[ref] = el
        elif tag == "textarea":
            name = ad.get("name") or ad.get("id") or ""
            ref = self._next_ref()
            el = {
                "ref": ref,
                "tag": "textarea",
                "type": "textarea",
                "name": name,
                "label": ad.get("placeholder") or ad.get("aria-label") or name,
                "value": "",
                "required": "required" in ad,
                "form_index": self._cur_form["form_index"] if self._cur_form is not None else None,
            }
            self.elements[ref] = el
            self._cur_textarea = el
            self._cur_textarea_buf = []
        elif tag == "select":
            name = ad.get("name") or ad.get("id") or ""
            ref = self._next_ref()
            el = {
                "ref": ref,
                "tag": "select",
                "type": "select",
                "name": name,
                "label": ad.get("aria-label") or name,
                "value": "",
                "options": [],
                "form_index": self._cur_form["form_index"] if self._cur_form is not None else None,
            }
            self.elements[ref] = el
            self._cur_select = el
        elif tag == "option" and self._cur_select is not None:
            self._cur_option_val = ad.get("value")
            self._cur_option_text = []
            self._cur_option_selected = "selected" in ad
        elif tag in ("button", "a"):
            if tag == "a" and not ad.get("href"):
                return
            ref = self._next_ref()
            el = {
                "ref": ref,
                "tag": tag,
                "type": (ad.get("type") or ("link" if tag == "a" else "submit")).lower(),
                "name": ad.get("name") or "",
                "value": ad.get("value") or "",
                "href": urllib.parse.urljoin(self.base_url, ad["href"]) if tag == "a" else "",
                "label": ad.get("aria-label") or "",
                "form_index": self._cur_form["form_index"] if self._cur_form is not None else None,
            }
            self.elements[ref] = el
            self._cur_btn = el
            self._cur_btn_buf = []

    def handle_endtag(self, tag: str):
        if tag in self.SKIP:
            self.skip = max(0, self.skip - 1)
            return
        if tag == "title":
            self.in_title = False
        elif tag == "form":
            self._cur_form = None
        elif tag == "textarea" and self._cur_textarea is not None:
            val = "".join(self._cur_textarea_buf).strip()
            self._cur_textarea["value"] = val
            if self._cur_textarea["form_index"] is not None and self._cur_textarea["name"]:
                self.forms[self._cur_textarea["form_index"]]["fields"][self._cur_textarea["name"]] = val
            self._cur_textarea = None
        elif tag == "option" and self._cur_select is not None:
            txt = "".join(self._cur_option_text).strip()
            val = self._cur_option_val if self._cur_option_val is not None and self._cur_option_val != "" else txt
            self._cur_select["options"].append({"value": val, "label": txt})
            if getattr(self, "_cur_option_selected", False) or not self._cur_select["value"]:
                self._cur_select["value"] = val
                fi = self._cur_select["form_index"]
                if fi is not None and self._cur_select["name"]:
                    self.forms[fi]["fields"][self._cur_select["name"]] = val
            self._cur_option_val = None
        elif tag == "select":
            self._cur_select = None
        elif tag in ("button", "a") and self._cur_btn is not None:
            lbl = re.sub(r"\s+", " ", "".join(self._cur_btn_buf)).strip()
            if lbl:
                self._cur_btn["label"] = lbl
            self._cur_btn = None

    def handle_data(self, data: str):
        if self.in_title:
            self.title += data
            return
        if self.skip:
            return
        self.text_parts.append(data)
        if self._cur_textarea is not None:
            self._cur_textarea_buf.append(data)
        if self._cur_option_val is not None or self._cur_select is not None:
            self._cur_option_text.append(data)
        if self._cur_btn is not None:
            self._cur_btn_buf.append(data)

    def clean_text(self) -> str:
        t = "".join(self.text_parts)
        t = re.sub(r"[ \t\r]+", " ", t)
        t = re.sub(r"\n\s*\n+", "\n\n", t)
        return t.strip()


class InteractiveWebSession:
    """有状态跨步网页交互会话：支持登录 Cookie 保持、岗位/业务列表跳转、表单填写、简历/文件上传与提交。"""

    def __init__(self, headers: dict[str, str] | None = None):
        base_headers = {"User-Agent": "Mozilla/5.0 (Macintosh; OmniAgent/2.0) Chrome/126.0 Safari/537.36"}
        if headers:
            base_headers.update(headers)
        self.client = httpx.AsyncClient(follow_redirects=True, timeout=35.0, headers=base_headers)
        self.current_url: str = ""
        self.status_code: int = 0
        self.title: str = ""
        self.text: str = ""
        self.forms: list[dict[str, Any]] = []
        self.elements: dict[str, dict[str, Any]] = {}

    async def close(self) -> None:
        await self.client.aclose()

    def _parse_response(self, resp: httpx.Response) -> dict[str, Any]:
        self.current_url = str(resp.url)
        self.status_code = resp.status_code
        ctype = resp.headers.get("content-type", "")
        if "json" in ctype:
            self.title = "JSON Response"
            self.text = resp.text[:25_000]
            self.forms = []
            self.elements = {}
            return self.snapshot()
        p = _InteractiveDOMParser(self.current_url)
        p.feed(resp.text)
        self.title = p.title.strip()
        self.text = p.clean_text()
        self.forms = p.forms
        self.elements = p.elements
        return self.snapshot()

    async def goto(self, url: str) -> dict[str, Any]:
        target = urllib.parse.urljoin(self.current_url, url) if self.current_url and not url.startswith(("http://", "https://")) else url
        resp = await self.client.get(target)
        return self._parse_response(resp)

    def _find_element(self, target: str) -> dict[str, Any]:
        if target in self.elements:
            return self.elements[target]
        low = target.strip().lower()
        for el in self.elements.values():
            if el.get("name", "").lower() == low or el.get("label", "").lower() == low:
                return el
        for el in self.elements.values():
            if low in el.get("label", "").lower() or low in el.get("name", "").lower():
                return el
        raise KeyError(f"未在当前页面找到控件 '{target}'。可用控件请查看 snapshot 输出。")

    def fill(self, target: str, value: str) -> str:
        el = self._find_element(target)
        el["value"] = str(value)
        fi = el.get("form_index")
        if fi is not None and el.get("name"):
            self.forms[fi]["fields"][el["name"]] = str(value)
        return f"已填写 [{el['ref']}] ({el.get('name') or el.get('label')}) = {str(value)[:80]}"

    def upload_file(self, target: str, file_path: Path) -> str:
        if not file_path.is_file():
            raise FileNotFoundError(f"待上传文件不存在: {file_path}")
        el = self._find_element(target)
        fi = el.get("form_index")
        if fi is None:
            if not self.forms:
                raise ValueError("当前页面不存在可上传文件的表单")
            fi = 0
        field_name = el.get("name") or "file"
        self.forms[fi]["files"][field_name] = file_path
        el["value"] = str(file_path.name)
        return f"已挂载上传文件 [{el['ref']}] ({field_name}) <- {file_path.name} ({file_path.stat().st_size} B)"

    async def click_or_submit(self, target: str = "") -> dict[str, Any]:
        if target:
            el = self._find_element(target)
            if el["tag"] == "a" and el.get("href"):
                return await self.goto(el["href"])
            fi = el.get("form_index")
            if el.get("name") and el.get("value") and fi is not None:
                self.forms[fi]["fields"][el["name"]] = el["value"]
        else:
            fi = 0 if self.forms else None

        if fi is None or fi >= len(self.forms):
            raise ValueError("当前页面没有可提交的 <form> 表单")
        form = self.forms[fi]
        method = form["method"]
        action = form["action"]
        fields = dict(form["fields"])
        files_map = form["files"]

        if method == "GET":
            resp = await self.client.get(action, params=fields)
        elif files_map or "multipart" in form["enctype"].lower():
            opened = []
            try:
                mp_files = {}
                for fname, fpath in files_map.items():
                    fh = open(fpath, "rb")
                    opened.append(fh)
                    mtype = mimetypes.guess_type(fpath.name)[0] or "application/octet-stream"
                    mp_files[fname] = (fpath.name, fh, mtype)
                resp = await self.client.request(method, action, data=fields, files=mp_files or None)
            finally:
                for fh in opened:
                    fh.close()
        else:
            resp = await self.client.request(method, action, data=fields)
        return self._parse_response(resp)

    def snapshot(self) -> dict[str, Any]:
        controls = []
        for el in list(self.elements.values())[:80]:
            desc = f"[{el['ref']}] <{el['tag']} type={el['type']}>"
            if el.get("name"):
                desc += f" name='{el['name']}'"
            if el.get("label"):
                desc += f" label='{el['label'][:50]}'"
            if el.get("value"):
                desc += f" value='{str(el['value'])[:40]}'"
            if el.get("options"):
                opts = ", ".join(o["value"] for o in el["options"][:8])
                desc += f" options=[{opts}]"
            if el.get("href"):
                desc += f" -> {el['href']}"
            controls.append(desc)
        return {
            "url": self.current_url,
            "status": self.status_code,
            "title": self.title,
            "text": self.text[:15_000],
            "form_count": len(self.forms),
            "controls": controls,
        }


# ============================================================================ 4. Persistent External Tracker Store

TRACKER_SCHEMA = """
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS external_trackers (
    id TEXT PRIMARY KEY,
    kind TEXT NOT NULL,
    title TEXT NOT NULL,
    target_ref TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'watching',
    due_ts REAL,
    meta TEXT NOT NULL DEFAULT '{}',
    history TEXT NOT NULL DEFAULT '[]',
    created REAL NOT NULL,
    updated REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_tracker_status ON external_trackers(status, updated DESC);
"""


class TrackerStore:
    """持久化追踪外部动作状态：邮件往来动态、日程到期提醒、求职岗位投递跟进、外部 API 状态监控。"""

    def __init__(self, db_path: str | Path):
        self.db_path = Path(db_path).expanduser().resolve()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(self.db_path), check_same_thread=False, isolation_level=None)
        self.conn.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        with self.lock:
            self.conn.executescript(TRACKER_SCHEMA)

    def close(self) -> None:
        with self.lock:
            self.conn.close()

    @staticmethod
    def _to_dict(r: sqlite3.Row) -> dict[str, Any]:
        return {
            "id": r["id"],
            "kind": r["kind"],
            "title": r["title"],
            "target_ref": r["target_ref"] or "",
            "status": r["status"],
            "due_ts": r["due_ts"],
            "meta": json.loads(r["meta"] or "{}"),
            "history": json.loads(r["history"] or "[]"),
            "created": r["created"],
            "updated": r["updated"],
        }

    def upsert(
        self,
        *,
        kind: str,
        title: str,
        target_ref: str = "",
        status: str = "watching",
        due_iso: str = "",
        meta: dict[str, Any] | None = None,
        note: str = "",
        tracker_id: str = "",
    ) -> dict[str, Any]:
        now = time.time()
        due_ts = _parse_iso_ts(due_iso)[1] if due_iso else None
        with self.lock:
            prev = None
            if tracker_id:
                prev = self.conn.execute("SELECT * FROM external_trackers WHERE id=?", (tracker_id,)).fetchone()
            elif target_ref:
                prev = self.conn.execute(
                    "SELECT * FROM external_trackers WHERE kind=? AND target_ref=?", (kind, target_ref)
                ).fetchone()

            if prev:
                tid = prev["id"]
                merged_meta = {**json.loads(prev["meta"] or "{}"), **(meta or {})}
                hist = json.loads(prev["history"] or "[]")
                if note or status != prev["status"]:
                    hist.append({"ts": now, "status": status, "note": note or f"状态变更为 {status}"})
                self.conn.execute(
                    """UPDATE external_trackers SET title=?, target_ref=?, status=?, due_ts=COALESCE(?, due_ts),
                       meta=?, history=?, updated=? WHERE id=?""",
                    (title or prev["title"], target_ref or prev["target_ref"], status, due_ts,
                     json.dumps(merged_meta, ensure_ascii=False), json.dumps(hist[-30:], ensure_ascii=False), now, tid),
                )
            else:
                tid = tracker_id or f"trk_{uuid.uuid4().hex[:8]}"
                hist = [{"ts": now, "status": status, "note": note or "建立外部跟踪项"}]
                self.conn.execute(
                    """INSERT INTO external_trackers(id, kind, title, target_ref, status, due_ts, meta, history, created, updated)
                       VALUES (?,?,?,?,?,?,?,?,?,?)""",
                    (tid, kind, title, target_ref, status, due_ts,
                     json.dumps(meta or {}, ensure_ascii=False), json.dumps(hist, ensure_ascii=False), now, now),
                )
            row = self.conn.execute("SELECT * FROM external_trackers WHERE id=?", (tid,)).fetchone()
            return self._to_dict(row)

    def list_trackers(self, *, kind: str = "", status: str = "", limit: int = 100) -> list[dict[str, Any]]:
        clauses = []
        params: list[Any] = []
        if kind:
            clauses.append("kind=?")
            params.append(kind)
        if status:
            clauses.append("status=?")
            params.append(status)
        where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
        with self.lock:
            rows = self.conn.execute(
                f"SELECT * FROM external_trackers {where} ORDER BY updated DESC LIMIT ?", (*params, limit)
            ).fetchall()
            return [self._to_dict(r) for r in rows]

    def delete(self, tracker_id: str) -> bool:
        with self.lock:
            cur = self.conn.execute("DELETE FROM external_trackers WHERE id=?", (tracker_id,))
            return cur.rowcount > 0

    async def poll_updates(self, workspace: Path, email_cfg: dict[str, Any] | None = None,
                           calendar_cfg: dict[str, Any] | None = None) -> list[dict[str, Any]]:
        """主动巡检所有活跃跟踪器（检查邮件是否有新回复、日程是否即将到期、API 监控端点是否变更）。"""
        alerts: list[dict[str, Any]] = []
        active = [t for t in self.list_trackers(limit=100) if t["status"] not in ("completed", "archived")]

        mail = EmailBackend(workspace, email_cfg)
        cal = CalendarBackend(workspace, calendar_cfg)
        try:
            # 1. 检查日历即将开始的提醒
            for ev in cal.due_reminders(within_minutes=60):
                alerts.append({
                    "kind": "calendar_reminder",
                    "title": f"即将开始：{ev['title']}（{ev['start_iso']}）",
                    "detail": f"地点：{ev.get('location') or '未指定'} · 提前 {ev['reminder_minutes']} 分钟提醒",
                    "event_id": ev["id"],
                })

            for tr in active:
                if tr["kind"] == "email_thread" and tr["target_ref"]:
                    st = mail.thread_status(tr["target_ref"])
                    if st.get("has_new_external_reply"):
                        self.upsert(
                            tracker_id=tr["id"], kind="email_thread", title=tr["title"],
                            status="reply_received",
                            note=f"收到新回复（来自 {st.get('latest_sender')}）：{st.get('latest_snippet', '')[:80]}",
                        )
                        alerts.append({
                            "kind": "email_thread",
                            "tracker_id": tr["id"],
                            "title": f"邮件线程有新回复：{tr['title']}",
                            "detail": f"来自 {st.get('latest_sender')}：{st.get('latest_snippet', '')[:120]}",
                        })
                elif tr["kind"] == "api_monitor" and tr["target_ref"].startswith(("http://", "https://")):
                    try:
                        async with httpx.AsyncClient(timeout=10) as client:
                            r = await client.get(tr["target_ref"])
                        digest = r.text[:300]
                        prev_digest = tr["meta"].get("last_snapshot")
                        if prev_digest is not None and prev_digest != digest:
                            self.upsert(
                                tracker_id=tr["id"], kind="api_monitor", title=tr["title"],
                                status="changed", meta={"last_snapshot": digest},
                                note=f"监测到外部接口返回内容更新 (HTTP {r.status_code})",
                            )
                            alerts.append({
                                "kind": "api_monitor",
                                "tracker_id": tr["id"],
                                "title": f"外部系统状态变更：{tr['title']}",
                                "detail": digest[:140],
                            })
                        elif prev_digest is None:
                            self.upsert(
                                tracker_id=tr["id"], kind="api_monitor", title=tr["title"],
                                status=tr["status"], meta={"last_snapshot": digest},
                            )
                    except Exception:  # noqa: BLE001
                        pass
                elif tr["due_ts"] and tr["due_ts"] <= time.time() + 1800:
                    alerts.append({
                        "kind": tr["kind"],
                        "tracker_id": tr["id"],
                        "title": f"跟踪事项到期提醒：{tr['title']}",
                        "detail": f"当前状态：{tr['status']}",
                    })
        finally:
            mail.close()
            cal.close()
        return alerts
