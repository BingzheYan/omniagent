"""真实浏览器自动化驱动（Playwright + 本机 Google Chrome / Edge / Chromium）。

用于对接需要登录、由 JavaScript 渲染的企业业务系统（报销平台、OA、ERP、CRM、招聘网站等）：
- 持久化浏览器配置（登录态 Cookie 跨任务保留），默认有界面运行，用户可在弹出的窗口中亲自登录 / 完成验证码；
- 页面控件快照：遍历主文档与全部 iframe，为可交互元素分配稳定编号 [e1]..[eN] 并推断字段标签；
- 填写 / 下拉选择 / 勾选 / 点击 / 上传附件 / 按键 / 滚动 / 等待 / 读取表格；
- 每一步自动截图，供工作台右侧「操作」栏实时展示。
"""
from __future__ import annotations

import asyncio
import os
import platform
import re
import time
from pathlib import Path
from typing import Any

SNAPSHOT_JS = r"""
(startIdx) => {
  const txt = (s) => (s || '').replace(/\s+/g, ' ').trim();
  const vis = (el) => {
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    const s = getComputedStyle(el);
    return s.visibility !== 'hidden' && s.display !== 'none' && parseFloat(s.opacity || '1') > 0.05;
  };
  const labelOf = (el) => {
    const aria = el.getAttribute('aria-label');
    if (aria) return txt(aria);
    if (el.id) {
      try { const l = document.querySelector('label[for="' + CSS.escape(el.id) + '"]'); if (l && txt(l.innerText)) return txt(l.innerText); } catch (e) {}
    }
    const lb = el.closest('label');
    if (lb && txt(lb.innerText) && txt(lb.innerText).length < 40) return txt(lb.innerText);
    const item = el.closest('.layui-form-item, .ant-form-item, .el-form-item, .form-group, .ant-row, .lcz-form-item, [class*="form-item"], [class*="FormItem"], [class*="field"], tr');
    if (item) {
      const cand = item.querySelector('.layui-form-label, .ant-form-item-label, .el-form-item__label, label, [class*="label"], th, td');
      if (cand && cand !== el && !cand.contains(el) && txt(cand.innerText)) return txt(cand.innerText).slice(0, 40);
    }
    let p = el.previousElementSibling;
    for (let i = 0; p && i < 2; i++, p = p.previousElementSibling) {
      const t = txt(p.innerText || p.textContent);
      if (t && t.length < 30) return t;
    }
    const par = el.parentElement && el.parentElement.previousElementSibling;
    if (par && txt(par.innerText) && txt(par.innerText).length < 30) return txt(par.innerText);
    return '';
  };
  const SEL = 'input, textarea, select, button, a[href], [role=button], [role=menuitem], [role=tab], [role=option], [role=checkbox], [role=radio], [role=combobox], [role=switch], [role=treeitem], [contenteditable=true], .layui-btn, .ant-btn, .el-button, .layui-nav-item > a, .layui-tab-title li, [class*="menu-item"], [class*="menuItem"], [class*="nav-item"], [class*="btn"], [onclick], li[class*="item"]';
  const out = [];
  const seen = new Set();
  let idx = startIdx;
  document.querySelectorAll('[data-omni-ref]').forEach((e) => e.removeAttribute('data-omni-ref'));
  for (const el of document.querySelectorAll(SEL)) {
    if (seen.has(el)) continue;
    const tag = el.tagName.toLowerCase();
    const type = (el.getAttribute('type') || '').toLowerCase();
    if (tag === 'input' && type === 'hidden') continue;
    const isFile = tag === 'input' && type === 'file';
    if (!isFile && !vis(el)) continue;
    // 跳过与父级可点击元素重复的嵌套节点
    if (!['input', 'textarea', 'select'].includes(tag)) {
      const anc = el.parentElement && el.parentElement.closest(SEL);
      if (anc && seen.has(anc) && txt(anc.innerText) === txt(el.innerText)) continue;
    }
    seen.add(el);
    idx += 1;
    const ref = 'e' + idx;
    el.setAttribute('data-omni-ref', ref);
    const item = { ref, tag, type, label: labelOf(el), text: txt(el.innerText || el.value || '').slice(0, 60),
      name: el.getAttribute('name') || '', placeholder: el.getAttribute('placeholder') || '',
      value: (tag === 'input' || tag === 'textarea' || tag === 'select') ? String(el.value || '').slice(0, 60) : '',
      disabled: !!el.disabled, readonly: !!el.readOnly, required: !!el.required || /required|is-required|ant-form-item-required/.test(el.className + ' ' + ((el.closest('.ant-form-item, .el-form-item, .layui-form-item') || {}).className || '')),
      checked: (type === 'checkbox' || type === 'radio') ? !!el.checked : undefined, role: el.getAttribute('role') || '' };
    if (tag === 'select') item.options = Array.from(el.options).slice(0, 20).map((o) => txt(o.text));
    if (type === 'password') item.value = item.value ? '******' : '';
    out.push(item);
    if (out.length >= 220) break;
  }
  const bodyText = txt(document.body ? document.body.innerText : '').slice(0, 7000);
  return { items: out, next: idx, text: bodyText, title: document.title || '' };
}
"""

TABLES_JS = r"""
() => Array.from(document.querySelectorAll('table')).slice(0, 8).map((t) =>
  Array.from(t.rows).slice(0, 60).map((r) => Array.from(r.cells).map((c) => (c.innerText || '').replace(/\s+/g, ' ').trim()))
).filter((t) => t.length > 0)
"""

SET_VALUE_JS = r"""
(el, value) => {
  const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
  const desc = Object.getOwnPropertyDescriptor(proto, 'value');
  el.removeAttribute('readonly');
  if (desc && desc.set) desc.set.call(el, value); else el.value = value;
  for (const t of ['input', 'change', 'blur']) el.dispatchEvent(new Event(t, { bubbles: true }));
  return el.value;
}
"""

LOGIN_HINT_RE = re.compile(r"login|signin|sso|passport|auth|登录", re.I)


def default_headless() -> bool:
    env = os.environ.get("OMNI_BROWSER_HEADLESS")
    if env is not None:
        return env.strip().lower() not in ("0", "false", "no", "")
    if os.environ.get("PYTEST_CURRENT_TEST"):
        return True
    if platform.system() == "Darwin" or platform.system() == "Windows":
        return False
    return not bool(os.environ.get("DISPLAY"))


def describe_item(it: dict[str, Any]) -> str:
    tag, typ = it["tag"], it.get("type") or ""
    kind = {"a": "链接", "button": "按钮", "select": "下拉框", "textarea": "多行输入"}.get(tag, "")
    if tag == "input":
        kind = {"file": "文件上传", "checkbox": "勾选框", "radio": "单选", "password": "密码框", "submit": "按钮",
                "button": "按钮", "date": "日期", "number": "数字输入"}.get(typ, "输入框")
    if not kind:
        kind = {"button": "按钮", "menuitem": "菜单", "tab": "页签", "option": "选项", "checkbox": "勾选框",
                "combobox": "下拉框", "treeitem": "树节点"}.get(it.get("role") or "", "可点击")
    parts = [f"[{it['ref']}] {kind}"]
    label = it.get("label") or ""
    if label:
        parts.append(f"「{label}」")
    if it.get("text") and it["text"] != label and tag not in ("input", "textarea", "select"):
        parts.append(f"“{it['text']}”")
    if it.get("placeholder"):
        parts.append(f"(提示:{it['placeholder']})")
    if it.get("name"):
        parts.append(f"name={it['name']}")
    if it.get("value"):
        parts.append(f"当前值={it['value']}")
    if it.get("options"):
        parts.append("选项=" + "/".join(it["options"][:12]))
    flags = [f for f, on in (("必填", it.get("required")), ("只读", it.get("readonly")), ("禁用", it.get("disabled"))) if on]
    if it.get("checked") is not None:
        flags.append("已勾选" if it["checked"] else "未勾选")
    if it.get("frame"):
        flags.append(f"iframe#{it['frame']}")
    if flags:
        parts.append("〔" + "，".join(flags) + "〕")
    return " ".join(parts)


class BrowserAutomationSession:
    """一个持久化浏览器会话（对应一个业务系统）。"""

    def __init__(self, name: str, *, profile_dir: Path, shots_dir: Path, headless: bool | None = None,
                 rel=lambda p: str(p)):
        self.name = name
        self.profile_dir = profile_dir
        self.shots_dir = shots_dir
        self.headless = default_headless() if headless is None else headless
        self.rel = rel
        self._pw = None
        self.context = None
        self.page = None
        self.items: dict[str, dict[str, Any]] = {}
        self.step = 0
        self.browser_label = ""
        self.started = time.time()

    async def start(self) -> None:
        from playwright.async_api import async_playwright

        self.profile_dir.mkdir(parents=True, exist_ok=True)
        self.shots_dir.mkdir(parents=True, exist_ok=True)
        self._pw = await async_playwright().start()
        args = ["--disable-blink-features=AutomationControlled", "--no-first-run", "--no-default-browser-check"]
        last_err: Exception | None = None
        for channel, label in (("chrome", "Google Chrome"), ("msedge", "Microsoft Edge"), (None, "Chromium")):
            try:
                kw: dict[str, Any] = dict(headless=self.headless, args=args, viewport={"width": 1366, "height": 860},
                                          locale="zh-CN", accept_downloads=True)
                if channel:
                    kw["channel"] = channel
                self.context = await self._pw.chromium.launch_persistent_context(str(self.profile_dir), **kw)
                self.browser_label = label
                break
            except Exception as e:  # noqa: BLE001
                last_err = e
                continue
        if self.context is None:
            await self._pw.stop()
            raise RuntimeError(f"无法启动浏览器（请安装 Google Chrome，或运行 `playwright install chromium`）：{last_err}")
        self.context.set_default_timeout(15000)
        self.page = self.context.pages[0] if self.context.pages else await self.context.new_page()
        self.context.on("page", self._on_new_page)

    def _on_new_page(self, page) -> None:
        self.page = page

    async def _settle(self, timeout: int = 8000) -> None:
        try:
            await self.page.wait_for_load_state("domcontentloaded", timeout=timeout)
            await self.page.wait_for_load_state("networkidle", timeout=timeout)
        except Exception:  # noqa: BLE001
            pass
        await asyncio.sleep(0.35)

    async def goto(self, url: str) -> None:
        await self.page.goto(url, wait_until="domcontentloaded", timeout=45000)
        await self._settle(12000)

    async def snapshot(self) -> dict[str, Any]:
        self.items = {}
        lines: list[str] = []
        texts: list[str] = []
        idx = 0
        frames = [self.page.main_frame] + [f for f in self.page.frames if f != self.page.main_frame]
        for fi, fr in enumerate(frames):
            try:
                res = await fr.evaluate(SNAPSHOT_JS, idx)
            except Exception:  # noqa: BLE001
                continue
            idx = res["next"]
            for it in res["items"]:
                it["frame"] = fi
                it["_frame_obj"] = fr
                self.items[it["ref"]] = it
            if res["text"]:
                texts.append(res["text"] if fi == 0 else f"[iframe#{fi} {fr.url[:80]}]\n{res['text'][:3000]}")
        for it in self.items.values():
            lines.append(describe_item({**it, "frame": it["frame"] or None}))
        title = ""
        try:
            title = await self.page.title()
        except Exception:  # noqa: BLE001
            pass
        has_password = any(it.get("type") == "password" for it in self.items.values())
        return {"url": self.page.url, "title": title, "text": "\n".join(texts)[:9000], "controls": lines,
                "frames": len(frames), "login_page": has_password or bool(LOGIN_HINT_RE.search(self.page.url))}

    # ------------------------------------------------------------- 定位
    def _match_items(self, key: str) -> list[dict[str, Any]]:
        k = key.strip().lower()
        if not k:
            return []
        exact, fuzzy = [], []
        for it in self.items.values():
            fields = [it.get("label", ""), it.get("placeholder", ""), it.get("name", ""), it.get("text", "")]
            low = [f.lower().strip().rstrip("：:*").lstrip("*") for f in fields if f]
            if k in low:
                exact.append(it)
            elif any(k in f for f in low):
                fuzzy.append(it)
        return exact or fuzzy

    async def locate(self, target: str, *, prefer_input: bool = False):
        t = (target or "").strip()
        if re.fullmatch(r"e\d+", t):
            it = self.items.get(t)
            if not it:
                await self.snapshot()
                it = self.items.get(t)
            if not it:
                raise LookupError(f"控件 {t} 不存在（页面可能已变化，请重新 snapshot）")
            return it["_frame_obj"].locator(f'[data-omni-ref="{t}"]').first, it
        if t.startswith(("css=", "xpath=", "text=")) or t.startswith(("#", ".", "//")):
            sel = t[4:] if t.startswith("css=") else t
            for fr in self.page.frames:
                loc = fr.locator(sel)
                try:
                    if await loc.count():
                        return loc.first, {"ref": t, "tag": "", "type": ""}
                except Exception:  # noqa: BLE001
                    continue
            raise LookupError(f"未找到选择器 {t}")
        if not self.items:
            await self.snapshot()
        cands = self._match_items(t)
        if prefer_input:
            ins = [c for c in cands if c["tag"] in ("input", "textarea", "select") or c.get("role") == "combobox"]
            cands = ins or cands
        else:
            btn = [c for c in cands if c["tag"] not in ("input", "textarea", "select")]
            cands = btn or cands
        if cands:
            it = cands[0]
            return it["_frame_obj"].locator(f'[data-omni-ref="{it["ref"]}"]').first, it
        # 文本兜底（含 iframe）
        for fr in self.page.frames:
            for loc in (fr.get_by_role("button", name=t), fr.get_by_role("link", name=t), fr.get_by_text(t, exact=True),
                        fr.get_by_text(t)):
                try:
                    if await loc.count() and await loc.first.is_visible():
                        return loc.first, {"ref": f"text:{t}", "tag": "", "type": ""}
                except Exception:  # noqa: BLE001
                    continue
        raise LookupError(f"未找到与「{t}」匹配的控件，请先 snapshot 查看控件编号")

    # ------------------------------------------------------------- 动作
    async def click(self, target: str) -> str:
        loc, it = await self.locate(target)
        try:
            await loc.scroll_into_view_if_needed(timeout=4000)
        except Exception:  # noqa: BLE001
            pass
        try:
            await loc.click(timeout=8000)
        except Exception:  # noqa: BLE001
            await loc.click(timeout=5000, force=True)
        await self._settle()
        return f"已点击 {it.get('ref')} {it.get('label') or it.get('text') or target}"

    async def fill(self, target: str, value: str) -> str:
        loc, it = await self.locate(target, prefer_input=True)
        masked = "******" if (it.get("type") == "password" or "密码" in (it.get("label") or "")) else value
        tag = it.get("tag")
        if tag == "select":
            return await self.select(target, value)
        try:
            await loc.scroll_into_view_if_needed(timeout=3000)
        except Exception:  # noqa: BLE001
            pass
        try:
            if it.get("readonly"):
                raise RuntimeError("readonly")
            await loc.fill(str(value), timeout=6000)
        except Exception:  # noqa: BLE001
            try:
                await loc.evaluate(SET_VALUE_JS, str(value))
            except Exception as e:  # noqa: BLE001
                raise RuntimeError(f"无法填写 {it.get('ref')}：{e}") from None
        return f"「{it.get('label') or it.get('placeholder') or it.get('name') or target}」= {masked}"

    async def select(self, target: str, value: str) -> str:
        loc, it = await self.locate(target, prefer_input=True)
        label = it.get("label") or target
        if it.get("tag") == "select":
            try:
                await loc.select_option(label=value, timeout=5000)
            except Exception:  # noqa: BLE001
                await loc.select_option(value=value, timeout=5000)
            return f"「{label}」选择 {value}"
        # 自定义下拉（layui / antd / element）：先点开，再点击匹配选项
        await loc.click(timeout=6000)
        await asyncio.sleep(0.45)
        opt_sel = ("dd, [role=option], .ant-select-item-option, .el-select-dropdown__item, .layui-select-title + dl dd, "
                   "li[class*='option'], li[class*='item'], .dropdown-menu li, .lcz-select-option")
        for fr in [it.get("_frame_obj") or self.page.main_frame] + list(self.page.frames):
            try:
                opts = fr.locator(opt_sel).filter(has_text=value)
                n = await opts.count()
                for i in range(min(n, 10)):
                    o = opts.nth(i)
                    if await o.is_visible():
                        await o.click(timeout=5000)
                        await self._settle(4000)
                        return f"「{label}」选择 {value}"
            except Exception:  # noqa: BLE001
                continue
        try:
            await loc.fill(value, timeout=3000)
            await asyncio.sleep(0.5)
            await self.page.keyboard.press("Enter")
            return f"「{label}」输入并回车选择 {value}"
        except Exception:  # noqa: BLE001
            raise RuntimeError(f"下拉框「{label}」中未找到选项「{value}」") from None

    async def check(self, target: str, checked: bool = True) -> str:
        loc, it = await self.locate(target, prefer_input=True)
        try:
            if checked:
                await loc.check(timeout=5000)
            else:
                await loc.uncheck(timeout=5000)
        except Exception:  # noqa: BLE001
            await loc.click(timeout=5000, force=True)
        return f"「{it.get('label') or target}」{'已勾选' if checked else '已取消勾选'}"

    async def upload(self, target: str, files: list[Path]) -> str:
        loc, it = await self.locate(target, prefer_input=True) if target else (None, {})
        paths = [str(p) for p in files]
        if loc is not None and it.get("tag") == "input" and it.get("type") == "file":
            await loc.set_input_files(paths, timeout=10000)
        elif loc is not None:
            try:
                async with self.page.expect_file_chooser(timeout=8000) as fc_info:
                    await loc.click(timeout=6000)
                fc = await fc_info.value
                await fc.set_files(paths)
            except Exception:  # noqa: BLE001
                inp = None
                for fr in self.page.frames:
                    cand = fr.locator("input[type=file]")
                    if await cand.count():
                        inp = cand.last
                        break
                if inp is None:
                    raise RuntimeError("未找到文件上传控件") from None
                await inp.set_input_files(paths, timeout=10000)
        else:
            for fr in self.page.frames:
                cand = fr.locator("input[type=file]")
                if await cand.count():
                    await cand.last.set_input_files(paths, timeout=10000)
                    break
            else:
                raise RuntimeError("页面中没有文件上传控件")
        await self._settle(10000)
        return f"已上传 {len(paths)} 个附件：" + "、".join(Path(p).name for p in paths)

    async def press(self, key: str) -> str:
        await self.page.keyboard.press(key)
        await self._settle(5000)
        return f"按键 {key}"

    async def scroll(self, direction: str = "down", amount: int = 700) -> str:
        dy = amount if direction != "up" else -amount
        await self.page.mouse.wheel(0, dy)
        await asyncio.sleep(0.4)
        return f"页面滚动 {'↓' if dy > 0 else '↑'} {abs(dy)}px"

    async def wait_for(self, text: str = "", seconds: float = 0, timeout: float = 30) -> str:
        if seconds:
            await asyncio.sleep(min(seconds, 120))
            return f"等待 {seconds} 秒"
        deadline = time.time() + timeout
        while time.time() < deadline:
            for fr in self.page.frames:
                try:
                    if text and await fr.get_by_text(text).count():
                        return f"页面已出现「{text}」"
                except Exception:  # noqa: BLE001
                    continue
            await asyncio.sleep(1)
        raise TimeoutError(f"等待 {timeout:.0f} 秒仍未出现「{text}」")

    async def is_logged_in(self, until_text: str = "", until_url: str = "") -> bool:
        if until_url and until_url in self.page.url:
            return True
        if until_text:
            for fr in self.page.frames:
                try:
                    if await fr.get_by_text(until_text).count():
                        return True
                except Exception:  # noqa: BLE001
                    continue
            return False
        if until_url:
            return False
        for fr in self.page.frames:
            try:
                if await fr.locator("input[type=password]:visible").count():
                    return False
            except Exception:  # noqa: BLE001
                continue
        try:
            body = await self.page.evaluate("() => (document.body && document.body.innerText || '').slice(0, 3000)")
        except Exception:  # noqa: BLE001
            body = ""
        if re.search(r"登录失效|请重新登录|请先登录|扫码登录|账号登录", body):
            return False
        return not LOGIN_HINT_RE.search(self.page.url)

    async def tables(self) -> list[list[list[str]]]:
        out: list[list[list[str]]] = []
        for fr in self.page.frames:
            try:
                out.extend(await fr.evaluate(TABLES_JS))
            except Exception:  # noqa: BLE001
                continue
        return out[:10]

    async def screenshot(self, label: str) -> str:
        self.step += 1
        safe = re.sub(r"[^\w\u4e00-\u9fa5-]+", "_", label)[:24]
        p = self.shots_dir / f"{self.step:03d}_{safe}.jpg"
        try:
            await self.page.screenshot(path=str(p), type="jpeg", quality=72, full_page=False, timeout=10000)
        except Exception:  # noqa: BLE001
            return ""
        return self.rel(p)

    async def close(self) -> None:
        try:
            if self.context is not None:
                await self.context.close()
        finally:
            if self._pw is not None:
                await self._pw.stop()
            self.context = self._pw = self.page = None
