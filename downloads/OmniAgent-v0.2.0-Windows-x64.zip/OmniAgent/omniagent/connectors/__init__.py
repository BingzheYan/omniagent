"""外部应用、网页、数据库与 MCP 连接器中心（Connectors Hub）。

支持五类外部系统接入：
  1. http_api     — 任意 REST / GraphQL / SaaS API（飞书、Notion、GitHub、ERP/CRM、内部接口，支持 Bearer/Header/Basic/Query 认证）
  2. sqlite       — 外部软件的 SQLite 数据库文件（只读连接、自动探查表结构、SQL 查询并导出 CSV 供分析）
  3. local_folder — 外部软件的数据/导出目录（安全受控地列出、读取 Word/Excel/PDF/CSV/JSON 或导入工作区）
  4. web_app      — 外部网页 / 业务后台（支持 Cookie / Header 登录态、Headless Chrome 动态渲染与 HTML 表格提取）
  5. mcp          — 标准 Model Context Protocol (MCP) Stdio 服务（自动发现工具与资源并调用）
"""
from __future__ import annotations

import asyncio
import csv
import html.parser
import io
import json
import os
import re
import shutil
import sqlite3
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

import httpx

CONNECTOR_KINDS = ("http_api", "sqlite", "local_folder", "web_app", "mcp", "email", "calendar", "webhook", "graphql")


@dataclass
class ConnectorSpec:
    name: str
    title: str
    kind: str  # http_api | sqlite | local_folder | web_app | mcp
    description: str = ""
    config: dict[str, Any] = field(default_factory=dict)
    enabled: bool = True
    source: str = "user"  # workspace | global | user

    def public_dict(self) -> dict[str, Any]:
        """脱敏后的字典（隐藏 token / password / cookies 等敏感值）。"""
        d = asdict(self)
        cfg = dict(d.get("config") or {})
        for k in list(cfg):
            if any(s in k.lower() for s in ("token", "secret", "password", "key", "cookie", "auth_value")):
                v = str(cfg[k] or "")
                cfg[k] = (v[:4] + "…" + v[-3:]) if len(v) > 8 else ("****" if v else "")
        d["config"] = cfg
        return d


def load_file_connectors(workspace: Path | None = None) -> dict[str, ConnectorSpec]:
    out: dict[str, ConnectorSpec] = {}
    paths: list[tuple[Path, str]] = [(Path.home() / ".omniagent" / "connectors.json", "global")]
    if workspace:
        paths.append((Path(workspace) / ".omniagent" / "connectors.json", "workspace"))
    for p, src in paths:
        if not p.is_file():
            continue
        try:
            raw = json.loads(p.read_text(encoding="utf-8"))
            items = raw.get("connectors", raw) if isinstance(raw, dict) else raw
            if isinstance(items, dict):
                items = [{"name": k, **v} for k, v in items.items()]
            for it in items or []:
                if not isinstance(it, dict) or not it.get("name"):
                    continue
                spec = ConnectorSpec(
                    name=str(it["name"]).strip(),
                    title=str(it.get("title") or it["name"]),
                    kind=str(it.get("kind") or "http_api"),
                    description=str(it.get("description") or ""),
                    config=dict(it.get("config") or {}),
                    enabled=bool(it.get("enabled", True)),
                    source=src,
                )
                if spec.enabled:
                    out[spec.name] = spec
        except Exception:  # noqa: BLE001
            continue
    return out


# ============================================================================ HTML 表格与正文解析

class HTMLPageParser(html.parser.HTMLParser):
    """同时提取网页正文、标题、链接和所有 HTML <table> 二维表。"""

    SKIP = {"script", "style", "noscript", "svg", "template"}
    BLOCK = {"p", "div", "br", "li", "tr", "h1", "h2", "h3", "h4", "h5", "h6", "section", "article", "header"}

    def __init__(self):
        super().__init__()
        self.skip = 0
        self.in_title = False
        self.title = ""
        self.parts: list[str] = []
        self.links: list[tuple[str, str]] = []
        self._cur_href: str | None = None
        self._cur_link_text: list[str] = []
        self.tables: list[list[list[str]]] = []
        self._cur_table: list[list[str]] | None = None
        self._cur_row: list[str] | None = None
        self._cur_cell: list[str] | None = None

    def handle_starttag(self, tag, attrs):
        ad = dict(attrs)
        if tag in self.SKIP:
            self.skip += 1
            return
        if tag == "title":
            self.in_title = True
        elif tag in self.BLOCK:
            self.parts.append("\n")
        if tag in ("h1", "h2", "h3"):
            self.parts.append("#" * int(tag[1]) + " ")
        elif tag == "li":
            self.parts.append("- ")
        elif tag == "a" and ad.get("href"):
            self._cur_href = ad["href"]
            self._cur_link_text = []
        elif tag == "table":
            self._cur_table = []
        elif tag == "tr" and self._cur_table is not None:
            self._cur_row = []
        elif tag in ("td", "th") and self._cur_row is not None:
            self._cur_cell = []

    def handle_endtag(self, tag):
        if tag in self.SKIP:
            self.skip = max(0, self.skip - 1)
            return
        if tag == "title":
            self.in_title = False
        elif tag == "a" and self._cur_href:
            label = "".join(self._cur_link_text).strip()
            if label and len(self.links) < 80:
                self.links.append((label[:80], self._cur_href))
            self._cur_href = None
        elif tag in ("td", "th") and self._cur_cell is not None and self._cur_row is not None:
            self._cur_row.append(re.sub(r"\s+", " ", "".join(self._cur_cell)).strip())
            self._cur_cell = None
        elif tag == "tr" and self._cur_row is not None and self._cur_table is not None:
            if any(self._cur_row):
                self._cur_table.append(self._cur_row)
            self._cur_row = None
        elif tag == "table" and self._cur_table is not None:
            if self._cur_table:
                self.tables.append(self._cur_table)
            self._cur_table = None
        if tag in self.BLOCK:
            self.parts.append("\n")

    def handle_data(self, data):
        if self.in_title:
            self.title += data
        if self.skip:
            return
        self.parts.append(data)
        if self._cur_href is not None:
            self._cur_link_text.append(data)
        if self._cur_cell is not None:
            self._cur_cell.append(data)

    def clean_text(self) -> str:
        t = "".join(self.parts)
        t = re.sub(r"[ \t\r\f\v]+", " ", t)
        t = re.sub(r"\n\s*\n+", "\n\n", t)
        return t.strip()


def find_chrome_binary() -> str | None:
    pf = os.environ.get("ProgramFiles", r"C:\Program Files")
    pfx86 = os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")
    local_app = os.environ.get("LOCALAPPDATA", "")
    for cand in (
        os.environ.get("CHROME_BIN"),
        shutil.which("google-chrome"),
        shutil.which("chrome"),
        shutil.which("chromium"),
        shutil.which("chromium-browser"),
        shutil.which("msedge"),
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
        "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser",
        str(Path(pf) / "Google" / "Chrome" / "Application" / "chrome.exe"),
        str(Path(pfx86) / "Google" / "Chrome" / "Application" / "chrome.exe"),
        str(Path(local_app) / "Google" / "Chrome" / "Application" / "chrome.exe") if local_app else None,
        str(Path(pf) / "Microsoft" / "Edge" / "Application" / "msedge.exe"),
        str(Path(pfx86) / "Microsoft" / "Edge" / "Application" / "msedge.exe"),
        str(Path(pf) / "BraveSoftware" / "Brave-Browser" / "Application" / "brave.exe"),
    ):
        if cand and Path(cand).exists():
            return cand
    return None


async def render_url_content(
    url: str,
    *,
    headers: dict[str, str] | None = None,
    cookies: str | None = None,
    render_js: bool = True,
    screenshot_path: Path | None = None,
    timeout: int = 30,
) -> dict[str, Any]:
    """抓取网页（支持动态 JS 渲染、截图与 HTML 表格结构化提取）。"""
    req_headers = {"User-Agent": "Mozilla/5.0 (Macintosh; OmniAgent/2.0) Chrome/126.0 Safari/537.36"}
    if headers:
        req_headers.update({str(k): str(v) for k, v in headers.items()})
    if cookies:
        req_headers["Cookie"] = cookies

    html_text = ""
    status_code = 200
    ctype = "text/html"
    used_chrome = False
    chrome = find_chrome_binary() if (render_js and not headers and not cookies or screenshot_path) else None

    if chrome and (render_js or screenshot_path) and not cookies and not headers:
        try:
            if screenshot_path:
                screenshot_path.parent.mkdir(parents=True, exist_ok=True)
                sproc = await asyncio.create_subprocess_exec(
                    chrome, "--headless=new", "--disable-gpu", "--no-first-run", "--hide-scrollbars",
                    "--window-size=1440,960", f"--screenshot={screenshot_path}", url,
                    stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL,
                )
                await asyncio.wait_for(sproc.wait(), timeout=timeout)
            proc = await asyncio.create_subprocess_exec(
                chrome, "--headless=new", "--disable-gpu", "--no-first-run", "--virtual-time-budget=4000",
                "--dump-dom", url,
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL,
            )
            out, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            dom = out.decode("utf-8", "replace")
            if "<html" in dom.lower() or "<body" in dom.lower():
                html_text = dom
                used_chrome = True
        except Exception:  # noqa: BLE001
            html_text = ""

    if not html_text:
        async with httpx.AsyncClient(follow_redirects=True, timeout=timeout, headers=req_headers) as client:
            r = await client.get(url)
            status_code = r.status_code
            ctype = r.headers.get("content-type", "")
            if "json" in ctype:
                return {"status": status_code, "content_type": ctype, "title": "", "text": r.text,
                        "tables": [], "links": [], "rendered_js": False}
            html_text = r.text

    parser = HTMLPageParser()
    parser.feed(html_text)
    return {
        "status": status_code,
        "content_type": ctype,
        "title": parser.title.strip(),
        "text": parser.clean_text(),
        "tables": parser.tables,
        "links": parser.links,
        "rendered_js": used_chrome,
    }


# ============================================================================ 五类连接器执行逻辑

async def execute_http_api(spec: ConnectorSpec, *, endpoint: str = "", method: str = "GET",
                           params: dict | None = None, json_body: Any = None) -> dict[str, Any]:
    cfg = spec.config
    base = str(cfg.get("base_url") or "").rstrip("/")
    ep = str(endpoint or cfg.get("default_endpoint") or "").lstrip("/")
    url = endpoint if endpoint.startswith(("http://", "https://")) else (f"{base}/{ep}" if ep else base)
    if not url.startswith(("http://", "https://")):
        raise ValueError(f"连接器 {spec.name} 缺少有效的 base_url")
    headers = {"Accept": "application/json, text/plain, */*", **(cfg.get("headers") or {})}
    qparams = dict(params or {})
    auth_type = (cfg.get("auth_type") or "none").lower()
    auth_val = str(cfg.get("auth_value") or cfg.get("token") or cfg.get("api_key") or "")
    auth = None
    if auth_type == "bearer" and auth_val:
        headers["Authorization"] = f"Bearer {auth_val}"
    elif auth_type == "header" and auth_val:
        headers[str(cfg.get("auth_key") or "X-API-Key")] = auth_val
    elif auth_type == "query" and auth_val:
        qparams[str(cfg.get("auth_key") or "api_key")] = auth_val
    elif auth_type == "basic" and auth_val:
        user, _, pw = auth_val.partition(":")
        auth = (user, pw)

    async with httpx.AsyncClient(follow_redirects=True, timeout=45, headers=headers, auth=auth) as client:
        r = await client.request(method.upper(), url, params=qparams or None, json=json_body)
    ctype = r.headers.get("content-type", "")
    parsed = None
    if "json" in ctype:
        try:
            parsed = r.json()
        except ValueError:
            parsed = None
    return {"status": r.status_code, "url": str(r.url), "content_type": ctype,
            "json": parsed, "text": r.text[:50_000]}


def execute_sqlite(spec: ConnectorSpec, *, action: str = "schema", sql: str = "", limit: int = 500
                   ) -> dict[str, Any]:
    db_path = Path(str(spec.config.get("db_path") or "")).expanduser().resolve()
    writable = bool(spec.config.get("write_enabled", False))
    if not db_path.is_file() and not writable:
        raise FileNotFoundError(f"数据库文件不存在: {db_path}")
    uri = str(db_path) if writable else f"{db_path.as_uri()}?mode=ro"
    conn = sqlite3.connect(uri, uri=not writable)
    try:
        if action == "schema":
            tables = [r[0] for r in conn.execute(
                "SELECT name FROM sqlite_master WHERE type IN ('table','view') AND name NOT LIKE 'sqlite_%' ORDER BY name"
            ).fetchall()]
            schema = {}
            for t in tables:
                cols = conn.execute(f'PRAGMA table_info("{t}")').fetchall()
                cnt = conn.execute(f'SELECT COUNT(*) FROM "{t}"').fetchone()[0]
                schema[t] = {"rows": cnt, "columns": [{"name": c[1], "type": c[2]} for c in cols]}
            return {"db_path": str(db_path), "tables": schema}
        cleaned = sql.strip().rstrip(";")
        is_read = bool(re.match(r"^(SELECT|WITH|PRAGMA|EXPLAIN)\b", cleaned, re.IGNORECASE))
        if not is_read and not writable:
            raise PermissionError("出于安全保护，当前 SQLite 连接器为只读模式（如需写入请在连接器配置开启 write_enabled）")
        cur = conn.execute(cleaned)
        if not is_read:
            conn.commit()
            return {"columns": ["affected_rows"], "rows": [[cur.rowcount]], "returned": 1}
        cols = [d[0] for d in (cur.description or [])]
        rows = [list(r) for r in cur.fetchmany(limit)]
        return {"columns": cols, "rows": rows, "returned": len(rows)}
    finally:
        conn.close()


def execute_local_folder(spec: ConnectorSpec, *, action: str = "list", subpath: str = "", pattern: str = "*"
                         ) -> dict[str, Any]:
    root = Path(str(spec.config.get("folder_path") or "")).expanduser().resolve()
    if not root.exists():
        raise FileNotFoundError(f"连接目录不存在: {root}")
    base = root if root.is_dir() else root.parent
    target = (base / subpath).resolve() if subpath else root
    target.relative_to(base)  # 防止越界
    if action == "list":
        if target.is_file():
            return {"root": str(base), "files": [{"path": target.name, "size": target.stat().st_size}]}
        files = []
        for p in sorted(target.rglob(pattern)):
            if p.is_file() and not any(part.startswith(".") for part in p.relative_to(base).parts):
                files.append({"path": str(p.relative_to(base)), "size": p.stat().st_size})
                if len(files) >= 300:
                    break
        return {"root": str(base), "files": files}
    if not target.is_file():
        raise FileNotFoundError(f"文件不存在: {subpath}")
    from omniagent.tools.documents import DOC_EXTS, extract_text

    if target.suffix.lower() in DOC_EXTS:
        text = extract_text(target)
    else:
        text = target.read_text(encoding="utf-8", errors="replace")
    return {"path": str(target.relative_to(base)), "full_path": str(target), "content": text[:60_000]}


class MCPStdioSession:
    """轻量级标准 MCP (Model Context Protocol) JSON-RPC 2.0 Stdio 客户端。"""

    def __init__(self, command: str, args: list[str] | None = None, env: dict[str, str] | None = None,
                 cwd: str | None = None):
        self.command = command
        self.args = list(args or [])
        self.env = {**os.environ, **(env or {})}
        self.cwd = cwd or None
        self.proc: asyncio.subprocess.Process | None = None
        self._id = 0

    async def __aenter__(self):
        self.proc = await asyncio.create_subprocess_exec(
            self.command, *self.args, stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE, env=self.env, cwd=self.cwd, limit=16 * 1024 * 1024,
        )
        await self.request("initialize", {
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": {"name": "OmniAgent", "version": "0.2.0"},
        })
        await self.notify("notifications/initialized", {})
        return self

    async def __aexit__(self, *exc):
        if self.proc and self.proc.returncode is None:
            self.proc.terminate()
            try:
                await asyncio.wait_for(self.proc.wait(), 2)
            except asyncio.TimeoutError:
                self.proc.kill()

    async def notify(self, method: str, params: dict) -> None:
        assert self.proc and self.proc.stdin
        msg = json.dumps({"jsonrpc": "2.0", "method": method, "params": params}) + "\n"
        self.proc.stdin.write(msg.encode("utf-8"))
        await self.proc.stdin.drain()

    async def request(self, method: str, params: dict, timeout: float = 30.0) -> Any:
        assert self.proc and self.proc.stdin and self.proc.stdout
        self._id += 1
        req_id = self._id
        line = json.dumps({"jsonrpc": "2.0", "id": req_id, "method": method, "params": params}) + "\n"
        self.proc.stdin.write(line.encode("utf-8"))
        await self.proc.stdin.drain()

        async def _read():
            while True:
                raw = await self.proc.stdout.readline()
                if not raw:
                    err = (await self.proc.stderr.read()).decode("utf-8", "replace")[:500] if self.proc.stderr else ""
                    raise RuntimeError(f"MCP 服务提前退出: {err}")
                try:
                    obj = json.loads(raw.decode("utf-8", "replace"))
                except ValueError:
                    continue
                if obj.get("id") == req_id:
                    if "error" in obj:
                        raise RuntimeError(f"MCP 错误: {obj['error']}")
                    return obj.get("result")

        return await asyncio.wait_for(_read(), timeout=timeout)


async def execute_mcp(spec: ConnectorSpec, *, action: str = "list_tools", tool_name: str = "",
                      arguments: dict | None = None, resource_uri: str = "") -> dict[str, Any]:
    cfg = spec.config
    cmd = str(cfg.get("command") or "").strip()
    if not cmd:
        raise ValueError(f"MCP 连接器 {spec.name} 缺少 command")
    args = cfg.get("args") or []
    if isinstance(args, str):
        args = [a for a in args.split(" ") if a]
    async with MCPStdioSession(cmd, args, cfg.get("env") or {}, cfg.get("cwd") or None) as mcp:
        if action == "list_tools":
            res = await mcp.request("tools/list", {})
            return {"tools": res.get("tools", [])}
        if action == "list_resources":
            res = await mcp.request("resources/list", {})
            return {"resources": res.get("resources", [])}
        if action == "read_resource":
            return await mcp.request("resources/read", {"uri": resource_uri})
        if action == "call_tool":
            if not tool_name:
                raise ValueError("call_tool 需要提供 tool_name")
            return await mcp.request("tools/call", {"name": tool_name, "arguments": arguments or {}}, timeout=60)
        raise ValueError(f"未知的 MCP action: {action}")


async def test_connector(spec: ConnectorSpec) -> dict[str, Any]:
    """验证连接器是否可用并返回简要摘要（供 UI「测试连接」按钮使用）。"""
    if spec.kind == "sqlite":
        info = await asyncio.to_thread(execute_sqlite, spec, action="schema")
        return {"ok": True, "summary": f"连接成功，共 {len(info['tables'])} 张表：{', '.join(list(info['tables'])[:8])}"}
    if spec.kind == "local_folder":
        info = await asyncio.to_thread(execute_local_folder, spec, action="list")
        return {"ok": True, "summary": f"目录可访问，共发现 {len(info['files'])} 个文件"}
    if spec.kind == "http_api":
        info = await execute_http_api(spec)
        return {"ok": info["status"] < 400, "summary": f"HTTP {info['status']} · {info['content_type'][:40]}"}
    if spec.kind == "web_app":
        url = str(spec.config.get("url") or "")
        info = await render_url_content(url, headers=spec.config.get("headers"), cookies=spec.config.get("cookies"),
                                        render_js=bool(spec.config.get("render_js", True)))
        return {"ok": info["status"] < 400,
                "summary": f"页面已读取：{info['title'] or url}（提取到 {len(info['tables'])} 张表格）"}
    if spec.kind == "mcp":
        info = await execute_mcp(spec, action="list_tools")
        names = [t.get("name", "") for t in info.get("tools", [])]
        return {"ok": True, "summary": f"MCP 握手成功，发现 {len(names)} 个工具：{', '.join(names[:8])}"}
    if spec.kind == "email":
        from .protocols import EmailBackend

        mb = EmailBackend(Path.cwd(), spec.config)
        try:
            msgs = await asyncio.to_thread(mb.list_messages, limit=5)
            return {"ok": True, "summary": f"邮箱连接就绪（{mb.mode} 模式），收件箱最近 {len(msgs)} 封邮件"}
        finally:
            mb.close()
    if spec.kind == "calendar":
        from .protocols import CalendarBackend

        cb = CalendarBackend(Path.cwd(), spec.config)
        try:
            evs = cb.list_events()
            return {"ok": True, "summary": f"日历引擎就绪，当前共有 {len(evs)} 项有效日程"}
        finally:
            cb.close()
    if spec.kind == "webhook":
        url = str(spec.config.get("webhook_url") or spec.config.get("url") or "")
        return {"ok": url.startswith(("http://", "https://")), "summary": f"Webhook 端点已就绪：{url[:60]}"}
    if spec.kind == "graphql":
        info = await execute_http_api(spec, method="POST", json_body={"query": "{ __typename }"})
        return {"ok": info["status"] < 400, "summary": f"GraphQL 端点 HTTP {info['status']}"}
    raise ValueError(f"不支持的连接器类型: {spec.kind}")


def rows_to_csv_bytes(rows: list[list[Any]], columns: list[str] | None = None) -> bytes:
    buf = io.StringIO()
    w = csv.writer(buf)
    if columns:
        w.writerow(columns)
    for r in rows:
        w.writerow(r)
    return buf.getvalue().encode("utf-8-sig")
