"""多维长期记忆存储引擎（SQLite + FTS5）：
1. 用户画像（User Persona Portrait）：6 大维度结构化描绘用户的身份领域、公文规范、学术体例、写作语言风格、编程习惯与数据工作流偏好；
2. 在办项目与文稿进度（Ongoing Projects & Deliverables）：跨对话持续追踪同一篇文章、报告或工程“已做完哪些内容、还有哪些待完善、关键口径与关联文件”；
3. 原子化长期记忆条目（Atomic Memories）：偏好、纠错教训（Correction）、格式模板（Format Spec）、业务背景（Domain Fact）与历史里程碑（Episodic），支持去重、冲突覆盖演化与混合相关性检索。
"""
from __future__ import annotations

import json
import math
import re
import sqlite3
import threading
import time
import uuid
from pathlib import Path
from typing import Any

PORTRAIT_DIMENSIONS: dict[str, dict[str, str]] = {
    "identity": {
        "title": "身份背景与业务领域",
        "desc": "职业角色、研究方向、所在行业/机构类型与专业深度偏好",
    },
    "official_doc_format": {
        "title": "公文与正式文书规范",
        "desc": "如 GB/T 9704 版式、标题序号层级、红头/发文字号/落款惯例、行文庄重度",
    },
    "academic_paper_format": {
        "title": "学术论文与期刊体例",
        "desc": "目标期刊风格（如《财政研究》）、三线表与图注规范、计量识别方法偏好、参考文献制式",
    },
    "writing_style": {
        "title": "写作风格与表达禁忌",
        "desc": "结构偏好（如结论先行）、详略程度、语气语调、禁用套话/AI腔词汇",
    },
    "coding_prefs": {
        "title": "编程架构与工程习惯",
        "desc": "主力技术栈、包管理器、代码风格、类型注解、测试验收标准与 Git 习惯",
    },
    "data_and_workflow": {
        "title": "数据口径与协作工作流",
        "desc": "金额/数量单位（如万元）、小数位数、图表配色字体、默认交付格式与修改保留原件习惯",
    },
}

MEMORY_CATEGORIES: dict[str, str] = {
    "format_spec": "格式与体例规范",
    "correction": "纠错与避坑教训",
    "preference": "个人习惯与偏好",
    "domain_fact": "业务口径与背景事实",
    "episodic": "历史任务纪要",
}

PROJECT_KINDS: dict[str, str] = {
    "paper": "学术论文",
    "official_doc": "公文方案",
    "report": "数据分析报告",
    "code_project": "软件工程",
    "general": "综合事项",
}

# 敏感信息脱敏：绝不把密钥/Token/密码写入长期记忆
_SECRET_PATTERNS = [
    re.compile(r"\b(sk-[A-Za-z0-9_\-]{12,})\b"),
    re.compile(r"\b(tvly-[A-Za-z0-9_\-]{10,})\b"),
    re.compile(r"\b(gh[pousr]_[A-Za-z0-9]{16,})\b"),
    re.compile(r"(?i)(api[_-]?key|token|secret|password|passwd|密码|密钥)\s*[:=：]\s*([^\s,，;；\"']{6,})"),
]

SCHEMA = """
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS portrait_traits (
    dimension TEXT NOT NULL,
    trait_key TEXT NOT NULL,
    value TEXT NOT NULL,
    confidence REAL NOT NULL DEFAULT 0.75,
    evidence_count INTEGER NOT NULL DEFAULT 1,
    source TEXT NOT NULL DEFAULT 'inferred',
    updated REAL NOT NULL,
    PRIMARY KEY (dimension, trait_key)
);
CREATE TABLE IF NOT EXISTS memories (
    id TEXT PRIMARY KEY,
    category TEXT NOT NULL DEFAULT 'preference',
    topic_key TEXT DEFAULT '',
    content TEXT NOT NULL,
    tags TEXT NOT NULL DEFAULT '[]',
    importance INTEGER NOT NULL DEFAULT 3,
    pinned INTEGER NOT NULL DEFAULT 0,
    source TEXT NOT NULL DEFAULT 'auto',
    conv_id TEXT DEFAULT '',
    hit_count INTEGER NOT NULL DEFAULT 0,
    created REAL NOT NULL,
    updated REAL NOT NULL,
    last_used REAL,
    superseded_by TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_mem_active ON memories(superseded_by, pinned DESC, importance DESC, updated DESC);
CREATE TABLE IF NOT EXISTS projects (
    slug TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    kind TEXT NOT NULL DEFAULT 'general',
    status TEXT NOT NULL DEFAULT 'active',
    summary TEXT NOT NULL DEFAULT '',
    completed_items TEXT NOT NULL DEFAULT '[]',
    pending_items TEXT NOT NULL DEFAULT '[]',
    key_facts TEXT NOT NULL DEFAULT '[]',
    artifacts TEXT NOT NULL DEFAULT '[]',
    last_conv_id TEXT DEFAULT '',
    created REAL NOT NULL,
    updated REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_proj_status ON projects(status, updated DESC);
CREATE TABLE IF NOT EXISTS usage_telemetry (
    key TEXT PRIMARY KEY,
    count INTEGER NOT NULL DEFAULT 0,
    updated REAL NOT NULL
);
"""


def redact_secrets(text: str) -> str:
    s = str(text or "")
    for rx in _SECRET_PATTERNS:
        if rx.groups >= 2:
            s = rx.sub(r"\1: [REDACTED]", s)
        else:
            s = rx.sub("[REDACTED]", s)
    return s.strip()


def _slugify(title: str) -> str:
    clean = re.sub(r"[^\w\u4e00-\u9fff\-]+", "-", title.strip().lower()).strip("-")
    return clean[:48] or f"proj-{uuid.uuid4().hex[:8]}"


def _cjk_tokens(text: str) -> set[str]:
    """提取中英文检索词元（英文单词 + 中文二元组/三元组），用于高召回率相关性打分。"""
    s = text.lower()
    tokens = set(re.findall(r"[a-z0-9_.\-]{2,}", s))
    for chunk in re.findall(r"[\u4e00-\u9fff]{2,}", s):
        if len(chunk) == 2:
            tokens.add(chunk)
        else:
            for i in range(len(chunk) - 1):
                tokens.add(chunk[i: i + 2])
            for i in range(len(chunk) - 2):
                tokens.add(chunk[i: i + 3])
    return tokens


def _unique_list(items: list[str], limit: int = 30) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for raw in items or []:
        s = redact_secrets(str(raw)).strip()
        if not s:
            continue
        norm = re.sub(r"\s+", "", s.lower())
        if norm in seen:
            continue
        seen.add(norm)
        out.append(s[:300])
        if len(out) >= limit:
            break
    return out


def _task_core_norm(s: str) -> str:
    """归一化事项核心短语，使「待补充：机制检验」与「已完成机制检验 / 补充机制检验」能自动匹配核销。"""
    t = re.sub(r"\s+", "", str(s or "").lower())
    t = re.sub(r"^(待补充|待完善|待完成|已完成|已补齐)[:：]?", "", t)
    t = re.sub(r"^(补充|完善|完成|撰写|增加)", "", t)
    return t


class MemoryStore:
    """单用户/单工作区的多维长期记忆引擎。"""

    def __init__(self, db_path: str | Path):
        self.db_path = Path(db_path).expanduser().resolve()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(self.db_path), check_same_thread=False, isolation_level=None)
        self.conn.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        with self.lock:
            self.conn.executescript(SCHEMA)
            self.fts = self._init_fts()

    def _init_fts(self) -> bool:
        try:
            self.conn.execute(
                "CREATE VIRTUAL TABLE IF NOT EXISTS mem_fts USING fts5(mem_id UNINDEXED, content, tags, tokenize='trigram')"
            )
            return True
        except sqlite3.OperationalError:
            return False

    def close(self) -> None:
        with self.lock:
            self.conn.close()

    # ================================================================== 1. 用户画像（User Persona Portrait）
    def upsert_trait(
        self,
        dimension: str,
        trait_key: str,
        value: str,
        *,
        confidence: float = 0.8,
        source: str = "inferred",
    ) -> dict[str, Any]:
        if dimension not in PORTRAIT_DIMENSIONS:
            dimension = "writing_style"
        trait_key = str(trait_key).strip()[:64] or "general"
        clean_val = redact_secrets(value)[:400]
        if not clean_val:
            return {}
        now = time.time()
        with self.lock:
            prev = self.conn.execute(
                "SELECT confidence, evidence_count, source FROM portrait_traits WHERE dimension=? AND trait_key=?",
                (dimension, trait_key),
            ).fetchone()
            if prev:
                ev = int(prev["evidence_count"]) + 1
                new_src = "explicit" if (source == "explicit" or prev["source"] == "explicit") else source
                boosted = min(0.99, max(float(prev["confidence"]), confidence) + 0.05)
                conf = 0.98 if new_src == "explicit" else round(boosted, 2)
                self.conn.execute(
                    "UPDATE portrait_traits SET value=?, confidence=?, evidence_count=?, source=?, updated=? "
                    "WHERE dimension=? AND trait_key=?",
                    (clean_val, conf, ev, new_src, now, dimension, trait_key),
                )
            else:
                conf = 0.96 if source == "explicit" else round(min(max(confidence, 0.3), 0.95), 2)
                self.conn.execute(
                    "INSERT INTO portrait_traits(dimension, trait_key, value, confidence, evidence_count, source, updated) "
                    "VALUES (?,?,?,?,1,?,?)",
                    (dimension, trait_key, clean_val, conf, source, now),
                )
            row = self.conn.execute(
                "SELECT * FROM portrait_traits WHERE dimension=? AND trait_key=?", (dimension, trait_key)
            ).fetchone()
            return dict(row) if row else {}

    def delete_trait(self, dimension: str, trait_key: str) -> bool:
        with self.lock:
            cur = self.conn.execute(
                "DELETE FROM portrait_traits WHERE dimension=? AND trait_key=?", (dimension, trait_key)
            )
            return cur.rowcount > 0

    def get_portrait(self) -> dict[str, Any]:
        with self.lock:
            rows = self.conn.execute(
                "SELECT * FROM portrait_traits ORDER BY confidence DESC, evidence_count DESC, updated DESC"
            ).fetchall()
            telem = {
                r["key"]: r["count"]
                for r in self.conn.execute("SELECT key, count FROM usage_telemetry ORDER BY count DESC").fetchall()
            }
        dims: dict[str, dict[str, Any]] = {}
        for dim, meta in PORTRAIT_DIMENSIONS.items():
            dims[dim] = {"dimension": dim, "title": meta["title"], "desc": meta["desc"], "traits": []}
        for r in rows:
            d = r["dimension"] if r["dimension"] in dims else "writing_style"
            dims[d]["traits"].append({
                "dimension": d,
                "trait_key": r["trait_key"],
                "value": r["value"],
                "confidence": r["confidence"],
                "evidence_count": r["evidence_count"],
                "source": r["source"],
                "updated": r["updated"],
            })
        return {"dimensions": list(dims.values()), "telemetry": telem, "trait_count": len(rows)}

    def bump_telemetry(self, key: str, delta: int = 1) -> int:
        now = time.time()
        with self.lock:
            self.conn.execute(
                "INSERT INTO usage_telemetry(key, count, updated) VALUES (?,?,?) "
                "ON CONFLICT(key) DO UPDATE SET count=usage_telemetry.count+excluded.count, updated=excluded.updated",
                (key, delta, now),
            )
            row = self.conn.execute("SELECT count FROM usage_telemetry WHERE key=?", (key,)).fetchone()
            return int(row["count"]) if row else delta

    # ================================================================== 2. 原子化长期记忆（Atomic Memories）
    @staticmethod
    def _mem_dict(r: sqlite3.Row) -> dict[str, Any]:
        return {
            "id": r["id"],
            "category": r["category"],
            "category_label": MEMORY_CATEGORIES.get(r["category"], r["category"]),
            "topic_key": r["topic_key"] or "",
            "content": r["content"],
            "tags": json.loads(r["tags"] or "[]"),
            "importance": r["importance"],
            "pinned": bool(r["pinned"]),
            "source": r["source"],
            "conv_id": r["conv_id"] or "",
            "hit_count": r["hit_count"],
            "created": r["created"],
            "updated": r["updated"],
            "last_used": r["last_used"],
        }

    def upsert_memory(
        self,
        content: str,
        *,
        category: str = "preference",
        topic_key: str = "",
        tags: list[str] | None = None,
        importance: int = 3,
        pinned: bool = False,
        source: str = "auto",
        conv_id: str = "",
        mem_id: str | None = None,
    ) -> dict[str, Any] | None:
        clean = redact_secrets(content)[:1500]
        if len(clean) < 3:
            return None
        if category not in MEMORY_CATEGORIES:
            category = "preference"
        importance = max(1, min(int(importance or 3), 5))
        if category in ("correction", "format_spec") and importance < 4:
            importance = 4
        tag_list = [str(t).strip()[:32] for t in (tags or []) if str(t).strip()][:12]
        topic = str(topic_key or "").strip().lower()[:80]
        now = time.time()

        with self.lock:
            if mem_id:
                existing = self.conn.execute("SELECT * FROM memories WHERE id=?", (mem_id,)).fetchone()
                if existing:
                    self.conn.execute(
                        "UPDATE memories SET category=?, topic_key=?, content=?, tags=?, importance=?, pinned=?, updated=? WHERE id=?",
                        (category, topic or existing["topic_key"], clean, json.dumps(tag_list, ensure_ascii=False),
                         importance, int(pinned), now, mem_id),
                    )
                    self._sync_fts(mem_id, clean, tag_list)
                    return self.get_memory(mem_id)

            # 1) 完全相同文本去重：直接提升重要性与更新时间
            norm_clean = re.sub(r"\s+", "", clean.lower())
            active_rows = self.conn.execute(
                "SELECT * FROM memories WHERE superseded_by='' ORDER BY updated DESC LIMIT 300"
            ).fetchall()
            for r in active_rows:
                if re.sub(r"\s+", "", r["content"].lower()) == norm_clean:
                    new_imp = max(int(r["importance"]), importance)
                    new_pin = int(bool(r["pinned"]) or pinned)
                    merged_tags = list(dict.fromkeys(json.loads(r["tags"] or "[]") + tag_list))[:12]
                    self.conn.execute(
                        "UPDATE memories SET importance=?, pinned=?, tags=?, updated=? WHERE id=?",
                        (new_imp, new_pin, json.dumps(merged_tags, ensure_ascii=False), now, r["id"]),
                    )
                    self._sync_fts(r["id"], r["content"], merged_tags)
                    return self.get_memory(r["id"])

            new_id = mem_id or f"mem_{uuid.uuid4().hex[:10]}"
            # 2) 同 topic_key 的冲突演化：新偏好/规范自动取代旧条目（保留可追溯性）
            if topic:
                old_same_topic = self.conn.execute(
                    "SELECT id FROM memories WHERE superseded_by='' AND topic_key=? AND category=?",
                    (topic, category),
                ).fetchall()
                for old in old_same_topic:
                    self.conn.execute("UPDATE memories SET superseded_by=?, updated=? WHERE id=?", (new_id, now, old["id"]))
                    if self.fts:
                        self.conn.execute("DELETE FROM mem_fts WHERE mem_id=?", (old["id"],))

            self.conn.execute(
                "INSERT INTO memories(id, category, topic_key, content, tags, importance, pinned, source, conv_id, created, updated) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (new_id, category, topic, clean, json.dumps(tag_list, ensure_ascii=False),
                 importance, int(pinned), source, conv_id, now, now),
            )
            self._sync_fts(new_id, clean, tag_list)
            return self.get_memory(new_id)

    def _sync_fts(self, mem_id: str, content: str, tags: list[str]) -> None:
        if not self.fts:
            return
        self.conn.execute("DELETE FROM mem_fts WHERE mem_id=?", (mem_id,))
        self.conn.execute("INSERT INTO mem_fts(mem_id, content, tags) VALUES (?,?,?)",
                          (mem_id, content, " ".join(tags)))

    def get_memory(self, mem_id: str) -> dict[str, Any] | None:
        with self.lock:
            r = self.conn.execute("SELECT * FROM memories WHERE id=?", (mem_id,)).fetchone()
            return self._mem_dict(r) if r else None

    def delete_memory(self, mem_id: str) -> bool:
        with self.lock:
            if self.fts:
                self.conn.execute("DELETE FROM mem_fts WHERE mem_id=?", (mem_id,))
            cur = self.conn.execute("DELETE FROM memories WHERE id=?", (mem_id,))
            return cur.rowcount > 0

    def list_memories(self, *, category: str = "", q: str = "", limit: int = 200) -> list[dict[str, Any]]:
        q = (q or "").strip()
        if q:
            return self.search_memories(q, category=category, limit=limit, bump_hits=False)
        with self.lock:
            if category:
                rows = self.conn.execute(
                    "SELECT * FROM memories WHERE superseded_by='' AND category=? "
                    "ORDER BY pinned DESC, importance DESC, updated DESC LIMIT ?",
                    (category, limit),
                ).fetchall()
            else:
                rows = self.conn.execute(
                    "SELECT * FROM memories WHERE superseded_by='' "
                    "ORDER BY pinned DESC, importance DESC, updated DESC LIMIT ?",
                    (limit,),
                ).fetchall()
            return [self._mem_dict(r) for r in rows]

    def search_memories(self, query: str, *, category: str = "", limit: int = 12,
                        bump_hits: bool = True) -> list[dict[str, Any]]:
        """混合相关性召回：结合 CJK 二/三元组重叠度、FTS5 匹配、重要性权重、置顶与时间新鲜度。"""
        q = (query or "").strip()
        with self.lock:
            rows = self.conn.execute(
                "SELECT * FROM memories WHERE superseded_by=''" + (" AND category=?" if category else ""),
                (category,) if category else (),
            ).fetchall()
            if not rows:
                return []
            if not q:
                ranked = sorted(rows, key=lambda r: (r["pinned"], r["importance"], r["updated"]), reverse=True)[:limit]
                return [self._mem_dict(r) for r in ranked]

            fts_hits: set[str] = set()
            if self.fts and len(q) >= 3:
                try:
                    phrase = '"' + q[:60].replace('"', '""') + '"'
                    fts_hits = {
                        r[0] for r in self.conn.execute(
                            "SELECT mem_id FROM mem_fts WHERE mem_fts MATCH ? LIMIT 50", (phrase,)
                        ).fetchall()
                    }
                except sqlite3.OperationalError:
                    fts_hits = set()

            q_tokens = _cjk_tokens(q)
            now = time.time()
            scored: list[tuple[float, sqlite3.Row]] = []
            for r in rows:
                text = f"{r['content']} {r['tags']} {r['topic_key']}"
                m_tokens = _cjk_tokens(text)
                overlap = len(q_tokens & m_tokens) if q_tokens else 0
                substr_bonus = 3.0 if q.lower() in text.lower() else 0.0
                fts_bonus = 2.5 if r["id"] in fts_hits else 0.0
                lex_score = overlap / max(1.0, math.sqrt(len(q_tokens) or 1)) + substr_bonus + fts_bonus
                if lex_score <= 0:
                    continue
                age_days = max(0.0, (now - float(r["updated"])) / 86400.0)
                recency = 1.0 / (1.0 + age_days / 30.0)
                score = lex_score * 2.2 + float(r["importance"]) * 0.45 + (1.2 if r["pinned"] else 0.0) + recency * 0.4
                scored.append((score, r))

            scored.sort(key=lambda x: x[0], reverse=True)
            chosen = [r for _, r in scored[:limit]]
            if bump_hits and chosen:
                ids = [r["id"] for r in chosen]
                placeholders = ",".join("?" * len(ids))
                self.conn.execute(
                    f"UPDATE memories SET hit_count=hit_count+1, last_used=? WHERE id IN ({placeholders})",
                    (now, *ids),
                )
            return [self._mem_dict(r) for r in chosen]

    # ================================================================== 3. 在办项目与文稿进度（Ongoing Projects）
    @staticmethod
    def _proj_dict(r: sqlite3.Row) -> dict[str, Any]:
        done = json.loads(r["completed_items"] or "[]")
        pending = json.loads(r["pending_items"] or "[]")
        total = len(done) + len(pending)
        return {
            "slug": r["slug"],
            "title": r["title"],
            "kind": r["kind"],
            "kind_label": PROJECT_KINDS.get(r["kind"], "综合事项"),
            "status": r["status"],
            "summary": r["summary"],
            "completed_items": done,
            "pending_items": pending,
            "key_facts": json.loads(r["key_facts"] or "[]"),
            "artifacts": json.loads(r["artifacts"] or "[]"),
            "progress_pct": round(len(done) * 100 / total) if total else (100 if r["status"] == "completed" else 0),
            "last_conv_id": r["last_conv_id"] or "",
            "created": r["created"],
            "updated": r["updated"],
        }

    def upsert_project(
        self,
        title: str,
        *,
        slug: str = "",
        kind: str = "general",
        status: str = "active",
        summary: str = "",
        completed_items: list[str] | None = None,
        pending_items: list[str] | None = None,
        key_facts: list[str] | None = None,
        artifacts: list[str] | None = None,
        merge: bool = True,
        conv_id: str = "",
    ) -> dict[str, Any]:
        slug = (_slugify(slug) if slug else _slugify(title))
        if kind not in PROJECT_KINDS:
            kind = "general"
        if status not in ("active", "blocked", "completed", "archived"):
            status = "active"
        now = time.time()

        with self.lock:
            prev = self.conn.execute("SELECT * FROM projects WHERE slug=?", (slug,)).fetchone()
            if prev and merge:
                old_done = json.loads(prev["completed_items"] or "[]")
                old_pending = json.loads(prev["pending_items"] or "[]")
                old_facts = json.loads(prev["key_facts"] or "[]")
                old_arts = json.loads(prev["artifacts"] or "[]")

                new_done = _unique_list(old_done + (completed_items or []), limit=40)
                done_norms = {re.sub(r"\s+", "", x.lower()) for x in new_done} | {_task_core_norm(x) for x in new_done if len(_task_core_norm(x)) >= 3}
                # 已进入 completed_items 的事项自动从 pending_items 移除！
                raw_pending = (pending_items if pending_items is not None else old_pending)
                if pending_items is not None and merge and old_pending:
                    raw_pending = list(pending_items) + [p for p in old_pending if p not in pending_items]
                filtered_pending = [
                    p for p in _unique_list(raw_pending, limit=40)
                    if re.sub(r"\s+", "", p.lower()) not in done_norms and _task_core_norm(p) not in done_norms
                ]
                merged_facts = _unique_list((key_facts or []) + old_facts, limit=25)
                merged_arts = _unique_list((artifacts or []) + old_arts, limit=30)
                final_title = title.strip()[:120] or prev["title"]
                final_summary = redact_secrets(summary)[:600] if summary else prev["summary"]
                final_kind = kind if kind != "general" else prev["kind"]
                self.conn.execute(
                    """UPDATE projects SET title=?, kind=?, status=?, summary=?, completed_items=?, pending_items=?,
                       key_facts=?, artifacts=?, last_conv_id=?, updated=? WHERE slug=?""",
                    (final_title, final_kind, status, final_summary,
                     json.dumps(new_done, ensure_ascii=False),
                     json.dumps(filtered_pending, ensure_ascii=False),
                     json.dumps(merged_facts, ensure_ascii=False),
                     json.dumps(merged_arts, ensure_ascii=False),
                     conv_id or prev["last_conv_id"], now, slug),
                )
            else:
                done_l = _unique_list(completed_items or [], limit=40)
                done_norms = {re.sub(r"\s+", "", x.lower()) for x in done_l}
                pend_l = [p for p in _unique_list(pending_items or [], limit=40)
                          if re.sub(r"\s+", "", p.lower()) not in done_norms]
                self.conn.execute(
                    """INSERT INTO projects(slug, title, kind, status, summary, completed_items, pending_items,
                       key_facts, artifacts, last_conv_id, created, updated)
                       VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
                       ON CONFLICT(slug) DO UPDATE SET title=excluded.title, kind=excluded.kind, status=excluded.status,
                       summary=excluded.summary, completed_items=excluded.completed_items, pending_items=excluded.pending_items,
                       key_facts=excluded.key_facts, artifacts=excluded.artifacts, last_conv_id=excluded.last_conv_id,
                       updated=excluded.updated""",
                    (slug, title.strip()[:120] or slug, kind, status, redact_secrets(summary)[:600],
                     json.dumps(done_l, ensure_ascii=False),
                     json.dumps(pend_l, ensure_ascii=False),
                     json.dumps(_unique_list(key_facts or [], 25), ensure_ascii=False),
                     json.dumps(_unique_list(artifacts or [], 30), ensure_ascii=False),
                     conv_id, prev["created"] if prev else now, now),
                )
            row = self.conn.execute("SELECT * FROM projects WHERE slug=?", (slug,)).fetchone()
            return self._proj_dict(row)

    def get_project(self, slug: str) -> dict[str, Any] | None:
        with self.lock:
            r = self.conn.execute("SELECT * FROM projects WHERE slug=?", (slug,)).fetchone()
            return self._proj_dict(r) if r else None

    def list_projects(self, *, include_archived: bool = False, limit: int = 50) -> list[dict[str, Any]]:
        with self.lock:
            if include_archived:
                rows = self.conn.execute("SELECT * FROM projects ORDER BY updated DESC LIMIT ?", (limit,)).fetchall()
            else:
                rows = self.conn.execute(
                    "SELECT * FROM projects WHERE status<>'archived' ORDER BY CASE status WHEN 'active' THEN 0 WHEN 'blocked' THEN 1 ELSE 2 END, updated DESC LIMIT ?",
                    (limit,),
                ).fetchall()
            return [self._proj_dict(r) for r in rows]

    def delete_project(self, slug: str) -> bool:
        with self.lock:
            cur = self.conn.execute("DELETE FROM projects WHERE slug=?", (slug,))
            return cur.rowcount > 0

    def find_matching_project(self, text: str, conv_id: str = "") -> dict[str, Any] | None:
        """根据当前会话 ID、提及的文件路径或标题关键词自动关联已有在办项目。"""
        projects = self.list_projects(include_archived=False, limit=30)
        if not projects:
            return None
        if conv_id:
            for p in projects:
                if p["last_conv_id"] == conv_id:
                    return p
        low = (text or "").lower()
        for p in projects:
            if p["title"].lower() in low or p["slug"].lower() in low:
                return p
            for art in p["artifacts"]:
                base = Path(art).name.lower()
                if len(base) >= 4 and base in low:
                    return p
        q_tok = _cjk_tokens(text)
        best, best_score = None, 0.0
        for p in projects:
            p_tok = _cjk_tokens(p["title"] + " " + p["summary"] + " " + " ".join(p["artifacts"]))
            if not p_tok:
                continue
            overlap = len(q_tok & p_tok) / max(3, min(len(q_tok) or 1, len(p_tok)))
            if overlap > best_score and overlap >= 0.35:
                best, best_score = p, overlap
        return best

    # ================================================================== 4. 系统提示词上下文构建 & 总览
    def build_prompt_context(self, current_task: str = "", conv_id: str = "", max_chars: int = 4200) -> str:
        """为 Agent 系统提示词组装高信噪比的长期记忆块（用户画像 + 纠错与格式铁律 + 在办项目进度 + 动态相关召回）。"""
        portrait = self.get_portrait()
        sections: list[str] = []

        # (A) 用户画像摘要
        trait_lines: list[str] = []
        for dim in portrait["dimensions"]:
            if not dim["traits"]:
                continue
            vals = "；".join(
                f"{t['value']}" + ("（明确要求）" if t["source"] == "explicit" else "")
                for t in dim["traits"][:5]
            )
            trait_lines.append(f"- **{dim['title']}**：{vals}")
        if trait_lines:
            sections.append("## 用户画像与习惯偏好（请在写作、编码与分析中主动贴合，无需用户重复叮嘱）\n" + "\n".join(trait_lines))

        # (B) 核心常驻规范与纠错教训（pinned 或高优先级 format_spec / correction）
        core_mems = [
            m for m in self.list_memories(limit=40)
            if m["pinned"] or m["importance"] >= 4 or m["category"] in ("correction", "format_spec")
        ][:12]
        recalled = self.search_memories(current_task, limit=8, bump_hits=True) if current_task.strip() else []
        core_ids = {m["id"] for m in core_mems}
        extra_recalled = [m for m in recalled if m["id"] not in core_ids][:6]

        if core_mems or extra_recalled:
            mem_lines = []
            for m in core_mems + extra_recalled:
                tag = MEMORY_CATEGORIES.get(m["category"], m["category"])
                mem_lines.append(f"- [{tag}] {m['content']}")
            sections.append("## 长期记忆（格式铁律、历史纠错与相关背景）\n" + "\n".join(mem_lines))

        # (C) 在办项目 / 文稿连续性状态
        active_projs = [p for p in self.list_projects(limit=8) if p["status"] in ("active", "blocked")]
        matched = self.find_matching_project(current_task, conv_id=conv_id) if current_task else None
        if matched and all(p["slug"] != matched["slug"] for p in active_projs):
            active_projs.insert(0, matched)
        elif matched:
            active_projs.sort(key=lambda p: 0 if p["slug"] == matched["slug"] else 1)

        if active_projs:
            proj_lines = []
            for p in active_projs[:4]:
                star = " ★当前关联" if (matched and p["slug"] == matched["slug"]) else ""
                line = f"- **{p['title']}**（`{p['slug']}` · {p['kind_label']} · 进度 {p['progress_pct']}%{star}）"
                if p["summary"]:
                    line += f"\n  - 概述：{p['summary']}"
                if p["completed_items"]:
                    line += "\n  - 已完成：" + "；".join(p["completed_items"][:6])
                if p["pending_items"]:
                    line += "\n  - **待完善/下一步**：" + "；".join(p["pending_items"][:6])
                if p["key_facts"]:
                    line += "\n  - 关键口径/结论：" + "；".join(p["key_facts"][:4])
                if p["artifacts"]:
                    line += "\n  - 关联文件：" + ", ".join(p["artifacts"][:6])
                proj_lines.append(line)
            sections.append(
                "## 在办工作与文稿连续性记录（续写或修改同一篇报告/论文/项目时，请直接衔接已完成工作并重点推进待完善项）\n"
                + "\n".join(proj_lines)
            )

        if not sections:
            return ""
        body = "\n\n".join(sections)
        if len(body) > max_chars:
            body = body[: max_chars - 40] + "\n…（更多历史记忆可通过 memory_search 检索）"
        return "\n# 跨会话长期记忆与用户画像\n" + body + "\n"

    def overview(self) -> dict[str, Any]:
        portrait = self.get_portrait()
        memories = self.list_memories(limit=200)
        projects = self.list_projects(include_archived=True, limit=50)
        return {
            "portrait": portrait,
            "memories": memories,
            "projects": projects,
            "stats": {
                "traits": portrait["trait_count"],
                "memories": len(memories),
                "active_projects": sum(1 for p in projects if p["status"] in ("active", "blocked")),
                "total_projects": len(projects),
            },
            "categories": MEMORY_CATEGORIES,
            "dimensions": PORTRAIT_DIMENSIONS,
            "project_kinds": PROJECT_KINDS,
        }

    def clear_all(self) -> None:
        with self.lock:
            self.conn.execute("DELETE FROM portrait_traits")
            self.conn.execute("DELETE FROM memories")
            self.conn.execute("DELETE FROM projects")
            self.conn.execute("DELETE FROM usage_telemetry")
            if self.fts:
                self.conn.execute("DELETE FROM mem_fts")
