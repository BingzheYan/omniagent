"""自主记忆提炼与画像演化引擎（MemoryExtractor）。

每次对话轮次结束时自动运行（零阻塞、零敏感信息泄露）：
1. 显式偏好/规范/纠错挖掘：从用户自然语言中识别公文格式、期刊论文体例、写作禁忌、数据口径、编程规范、身份背景与纠错指令；
2. 隐式日常行为画像合成：统计用户高频使用的技能、文档样式、产出文件格式与工作模式，自动沉淀用户习惯画像；
3. 在办文稿与项目进度连续性追踪：自动汇总同一篇文章/报告/工程“已完成哪些章节与分析、还有哪些待完善事项（来自未完计划、质检报告、用户分步指令与后续建议）”。
"""
from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import Any

from omniagent.llm.types import LLMProvider, Message

from .store import MemoryStore, redact_secrets

log = logging.getLogger(__name__)

# 句子切分
_SENT_SPLIT = re.compile(r"[\n。！？!?；;]+")

# --------------------------------------------------------------------------- 规则模式库
_JOURNALS = ("《财政研究》", "《税务研究》", "《财贸经济》", "《经济研究》", "《管理世界》", "《中国工业经济》",
             "《金融研究》", "《数量经济技术经济研究》", "《会计研究》", "《公共管理学报》")

_EXPLICIT_TRIGGERS = re.compile(
    r"(记住|请记住|以后都|以后统一|每次都|默认用|默认使用|统一使用|统一采用|一律用|一律采用|"
    r"我的习惯是|我习惯|我喜欢用|我偏好|不要用|别用|禁止使用|切忌|严禁|千万不要|不要出现|"
    r"格式要求|排版要求|体例要求|公文格式|写作风格|口径统一)"
)

_CORRECTION_TRIGGERS = re.compile(
    r"^(不对|错了|不是这样|改一下|注意：?不要|请不要|以后不要|别再|修正一下|这里有问题)"
    r"|(不要.{1,24}而是|改成统一|不能用.{1,18}要用)"
)

_IDENTITY_PATTERNS = [
    (re.compile(r"我是(?:一名|一个|做|从事)?([^\n，,。；;]{2,28}(?:研究员|学者|博士|研究生|教授|老师|工程师|架构师|分析师|公务员|秘书|财务|审计|编辑|产品经理|负责人|专员|干部))"), "role"),
    (re.compile(r"(?:我在|我们单位是|所在单位是|就职于)([^\n，,。；;]{2,28})"), "org"),
    (re.compile(r"我的(?:研究方向|主攻方向|主要工作|核心业务)是([^\n。；;]{3,45})"), "focus"),
]

_DEFERRED_WORK_RE = re.compile(
    r"(?:后面再|稍后再|下次再|下一步再|待会儿再|留到后面|暂不|先不写|还需要补充|尚需完善|有待完善|待补充)([^\n。！？!?；;]{3,60})"
)


def _extract_Explicit_signals(user_text: str, store: MemoryStore, conv_id: str) -> list[dict[str, Any]]:
    """从用户的单轮输入中提取高置信度偏好、格式铁律、纠错教训与身份特征。"""
    learned: list[dict[str, Any]] = []
    text = redact_secrets(user_text)
    if not text:
        return learned

    # 1. 身份与研究/业务方向
    for rx, tkey in _IDENTITY_PATTERNS:
        m = rx.search(text)
        if m:
            val = m.group(1).strip(" ，,。：:")
            if 2 <= len(val) <= 45:
                tr = store.upsert_trait("identity", tkey, val, confidence=0.95, source="explicit")
                learned.append({"kind": "portrait", "dimension": "identity", "summary": f"身份背景：{val}", "data": tr})

    # 2. 期刊/学术体例偏好
    found_journals = [j for j in _JOURNALS if j in text or j.strip("《》") in text]
    if found_journals:
        j_str = "、".join(dict.fromkeys(found_journals))
        store.upsert_trait("academic_paper_format", "target_journal", f"偏好参照 {j_str} 期刊体例与论证深度",
                           confidence=0.92, source="explicit")
        mem = store.upsert_memory(
            f"撰写学术论文时优先参照 {j_str} 的章节范式、三线表排版与实证论证规范。",
            category="format_spec", topic_key="academic_journal_style", tags=["学术论文", "期刊格式"],
            importance=5, source="explicit", conv_id=conv_id,
        )
        if mem:
            learned.append({"kind": "memory", "category": "format_spec", "summary": mem["content"], "id": mem["id"]})

    # 计量与统计表格细节偏好
    if re.search(r"括号(?:里|内|中)?(?:放|填|写|报告|展示)?\s*(t\s*值|标准误|稳健标准误|聚类标准误)", text, re.I):
        m = re.search(r"括号(?:里|内|中)?(?:放|填|写|报告|展示)?\s*(t\s*值|标准误|稳健标准误|聚类标准误)", text, re.I)
        val = f"回归表括号内报告{m.group(1)}"
        store.upsert_trait("academic_paper_format", "reg_parentheses", val, confidence=0.96, source="explicit")
        mem = store.upsert_memory(f"计量回归三线表规范：{val}。", category="format_spec",
                                  topic_key="reg_parentheses", tags=["回归表", "三线表"], importance=5,
                                  source="explicit", conv_id=conv_id)
        if mem:
            learned.append({"kind": "memory", "category": "format_spec", "summary": mem["content"], "id": mem["id"]})

    # 3. 公文规范特征
    if re.search(r"(GB/?T\s*9704|党政机关公文|红头文件|发文字号|仿宋_?GB2312|三号仿宋|公文格式)", text, re.I):
        spec_parts = ["遵循 GB/T 9704《党政机关公文格式》标准（标题二号小标宋、正文三号仿宋、四级序号“一、（一）1.（1）”"]
        if "红头" in text or "版头" in text:
            spec_parts.append("含规范红头版头与版记")
        spec_val = "，".join(spec_parts) + "）"
        store.upsert_trait("official_doc_format", "gongwen_standard", spec_val, confidence=0.95, source="explicit")
        mem = store.upsert_memory(spec_val, category="format_spec", topic_key="official_doc_standard",
                                  tags=["公文格式", "GB/T9704"], importance=5, source="explicit", conv_id=conv_id)
        if mem:
            learned.append({"kind": "memory", "category": "format_spec", "summary": mem["content"], "id": mem["id"]})

    # 4. 数据单位、精度与保留原稿习惯
    if m := re.search(r"(?:金额|数值|资金|预算|数据)?(?:单位)?(?:统一|一律|默认)?(?:用|采用|使用|折算为)\s*(万元|亿元|千元|元|百分比)", text):
        val = f"金额与统计指标单位优先统一使用「{m.group(1)}」"
        store.upsert_trait("data_and_workflow", "number_unit", val, confidence=0.95, source="explicit")
        mem = store.upsert_memory(val, category="format_spec", topic_key="number_unit",
                                  tags=["数据口径", "单位"], importance=4, source="explicit", conv_id=conv_id)
        if mem:
            learned.append({"kind": "memory", "category": "format_spec", "summary": mem["content"], "id": mem["id"]})

    if m := re.search(r"保留\s*([一二三四1234])\s*位小数", text):
        val = f"统计表与回归结果默认保留 {m.group(1)} 位小数"
        store.upsert_trait("data_and_workflow", "decimal_places", val, confidence=0.95, source="explicit")
        mem = store.upsert_memory(val, category="format_spec", topic_key="decimal_places",
                                  tags=["数据精度"], importance=4, source="explicit", conv_id=conv_id)
        if mem:
            learned.append({"kind": "memory", "category": "format_spec", "summary": mem["content"], "id": mem["id"]})

    # 5. 逐句扫描显式偏好、禁忌与纠错指令
    for raw_sent in _SENT_SPLIT.split(text):
        sent = raw_sent.strip()
        if len(sent) < 5 or len(sent) > 220:
            continue
        is_corr = bool(_CORRECTION_TRIGGERS.search(sent))
        is_pref = bool(_EXPLICIT_TRIGGERS.search(sent))
        if not (is_corr or is_pref):
            continue
        # 避免把纯一次性任务描述（如“帮我写一篇5000字报告”）误判，除非带有长期/习惯/禁止词
        cat = "correction" if is_corr else ("format_spec" if "格式" in sent or "体例" in sent or "字体" in sent or "表" in sent else "preference")
        # 自动归入最匹配的画像维度
        dim = "writing_style"
        if any(k in sent for k in ("公文", "红头", "通知", "请示", "函", "落款", "仿宋", "小标宋")):
            dim = "official_doc_format"
        elif any(k in sent for k in ("论文", "期刊", "三线表", "回归", "实证", "参考文献", "摘要", "固定效应", "DID")):
            dim = "academic_paper_format"
        elif any(k in sent for k in ("代码", "函数", "测试", "pytest", "python", "typescript", "git", "注释", "类型", "依赖", "uv", "npm")):
            dim = "coding_prefs"
        elif any(k in sent for k in ("图表", "配色", "小数", "单位", "Excel", "CSV", "原件", "修订版", "PDF", "目录")):
            dim = "data_and_workflow"

        # 生成稳定的 topic_key 以便后续同类规则演化覆盖
        topic_words = re.findall(r"[\u4e00-\u9fff]{2,4}|[a-zA-Z]{3,12}", sent)[:3]
        tkey = f"rule_{'_'.join(topic_words).lower()}"[:48] if topic_words else f"rule_{abs(hash(sent)) % 100000}"

        cleaned_rule = re.sub(r"^(请记住|记住)[：:，,\s]*", "", sent)
        store.upsert_trait(dim, tkey, cleaned_rule, confidence=0.95, source="explicit")
        mem = store.upsert_memory(
            cleaned_rule, category=cat, topic_key=tkey,
            tags=[dim, "用户明确要求"], importance=5 if is_corr else 4,
            pinned=is_corr, source="explicit", conv_id=conv_id,
        )
        if mem and not any(x.get("id") == mem["id"] for x in learned):
            learned.append({"kind": "memory", "category": cat, "summary": mem["content"], "id": mem["id"]})

    return learned


def _update_behavioral_telemetry(
    turn_messages: list[Message],
    turn_changes: list[dict[str, Any]],
    mode: str,
    agent_profile: str,
    store: MemoryStore,
) -> list[dict[str, Any]]:
    """根据用户日常使用的工具、技能与产出文件自动累积行为统计并合成画像特征。"""
    learned: list[dict[str, Any]] = []
    if mode and mode != "auto":
        c = store.bump_telemetry(f"mode:{mode}")
        if c == 3:
            label = "高频使用软件工程研发模式" if mode == "code" else "高频使用科研与政务办公模式"
            store.upsert_trait("identity", f"habit_mode_{mode}", label, confidence=0.78, source="inferred")

    if agent_profile and agent_profile != "general":
        store.bump_telemetry(f"agent:{agent_profile}")

    exts: set[str] = set()
    for fc in turn_changes or []:
        p = str(fc.get("path") or "")
        ext = Path(p).suffix.lower()
        if ext:
            exts.add(ext)
            cnt = store.bump_telemetry(f"ext:{ext}")
            if ext == ".docx" and cnt == 2:
                store.upsert_trait("data_and_workflow", "prefer_docx", "常以正式 Word (.docx) 作为报告与文稿交付物",
                                   confidence=0.76, source="inferred")
            elif ext == ".pptx" and cnt == 2:
                store.upsert_trait("data_and_workflow", "prefer_pptx", "常需制作结构化汇报演示文稿 (.pptx)",
                                   confidence=0.76, source="inferred")

    if ".docx" in exts and ".pdf" in exts:
        cnt = store.bump_telemetry("combo:docx_pdf")
        if cnt >= 1:
            store.upsert_trait("data_and_workflow", "dual_docx_pdf", "正式文稿习惯同时产出可编辑 .docx 与定稿 .pdf 双格式",
                               confidence=0.82, source="inferred")

    for m in turn_messages:
        if m.role != "assistant":
            continue
        for tc in m.tool_calls:
            if tc.name == "load_skill":
                sk = str(tc.arguments.get("name") or "")
                if sk:
                    cnt = store.bump_telemetry(f"skill:{sk}")
                    if sk == "fiscal-paper" and cnt >= 1:
                        store.upsert_trait("academic_paper_format", "fiscal_empirical",
                                           "从事财税与公共经济实证研究，注重双向固定效应、稳健性检验与学术三线表",
                                           confidence=0.85, source="inferred")
                    elif sk == "official-document" and cnt >= 1:
                        store.upsert_trait("official_doc_format", "gongwen_usage",
                                           "日常起草符合 GB/T 9704 规范的党政机关公文材料",
                                           confidence=0.85, source="inferred")
            elif tc.name == "create_document":
                st = str(tc.arguments.get("style") or "")
                if st == "academic":
                    store.bump_telemetry("doc_style:academic")
                    store.upsert_trait("academic_paper_format", "academic_docx_style",
                                       "论文排版采用国标学术样式（宋体/Times混排、三线表、居中图注与编号公式）",
                                       confidence=0.84, source="inferred")
            elif tc.name == "connector_query":
                cname = str(tc.arguments.get("connector") or "")
                if cname:
                    store.bump_telemetry(f"connector:{cname}")
                    store.upsert_trait("data_and_workflow", f"conn_{cname}",
                                       f"常接入并查询外部数据源连接器 `{cname}`",
                                       confidence=0.82, source="inferred")
    return learned


def _extract_check_document_issues(turn_messages: list[Message]) -> list[str]:
    """如果本轮运行过 check_document 且仍有未解决扣分项，自动提取为项目的待完善事项。"""
    last_check = None
    for m in reversed(turn_messages):
        if m.role == "tool" and m.name == "check_document":
            last_check = m.content
            break
    if not last_check:
        return []
    issues: list[str] = []
    for line in last_check.splitlines():
        s = line.strip()
        if re.match(r"^[-•*]\s*\[(error|warn|warning|严重|警告|建议)\]", s, re.I) or s.startswith("⚠"):
            issues.append(re.sub(r"^[-•*⚠\s]+", "", s)[:180])
    return issues[:6]


def _extract_assistant_next_steps(final_text: str) -> list[str]:
    """从助手最终回复的“待完善 / 后续建议 / 下一步 / 未完成”小节提取待推进项。"""
    if not final_text:
        return []
    lines = final_text.splitlines()
    capture = False
    pending: list[str] = []
    for line in lines:
        s = line.strip()
        if re.match(r"^#{1,4}\s*.*(待完善|后续建议|下一步|尚未完成|未完成|后续可扩展|待补充)", s):
            capture = True
            continue
        if capture and re.match(r"^#{1,4}\s+", s):
            break
        if capture:
            m = re.match(r"^[-*•\d.)]+\s+(.*)", s)
            if m and len(m.group(1).strip()) >= 4:
                pending.append(m.group(1).strip()[:180])
    return pending[:6]


def _infer_project_kind(text: str, artifacts: list[str]) -> str:
    joined = (text + " " + " ".join(artifacts)).lower()
    if any(k in joined for k in ("论文", "实证", "固定效应", "回归", "面板", "期刊", "财政研究", "fiscal_paper")):
        return "paper"
    if any(k in joined for k in ("公文", "请示", "通知", "红头", "批复", "函", "纪要", "立项方案")):
        return "official_doc"
    if any(k in joined for k in ("报告", "分析", "台账", "销售", "预算", ".docx", ".pptx", ".xlsx")):
        return "report"
    if any(Path(a).suffix.lower() in (".py", ".ts", ".js", ".go", ".rs", ".java") for a in artifacts) or \
            any(k in joined for k in ("重构", "修复", "单元测试", "接口", "组件", "微服务", "应用")):
        return "code_project"
    return "general"


def _infer_project_title(user_task: str, conv_title: str, artifacts: list[str]) -> str:
    """优先从动作短语或书名号中提取真实的报告/论文/工程标题，而非截取整段自我介绍。"""
    # 1. 匹配「起草/撰写/完成/编制/分析/完善《XXX》」或非期刊类《XXX》
    m_act = re.search(r"(?:起草|撰写|编写|编制|完成|修改|完善|推进|研究)\s*《([^》]{3,48})》", user_task)
    if m_act:
        return f"《{m_act.group(1).strip()}》"
    for m_bk in re.finditer(r"《([^》]{4,48})》", user_task):
        cand = f"《{m_bk.group(1).strip()}》"
        if cand not in _JOURNALS:
            return cand
    # 2. 匹配「起草/撰写/构建/开发一份 XXX（报告/论文/方案/系统/应用）」
    m_obj = re.search(
        r"(?:起草|撰写|编写|编制|构建|开发|制作)(?:一份|一篇|一个)?([^\n，,。；;]{4,36}?(?:报告|论文|方案|请示|通知|系统|应用|模块|台账|PPT))",
        user_task,
    )
    if m_obj:
        return m_obj.group(1).strip()
    clean_conv = (conv_title or "").strip()
    if clean_conv and not clean_conv.startswith(("我是", "请记住", "记住")):
        return clean_conv[:56]
    if artifacts:
        return f"项目：{Path(artifacts[0]).stem}"
    return (clean_conv or user_task.strip().splitlines()[0])[:56]


def _consolidate_ongoing_project(
    *,
    conv_id: str,
    conv_title: str,
    user_task: str,
    final_text: str,
    todos: list[dict[str, Any]],
    turn_changes: list[dict[str, Any]],
    turn_messages: list[Message],
    incomplete: bool,
    store: MemoryStore,
) -> dict[str, Any] | None:
    """自动追踪并更新在办文稿/报告/工程的「已完成内容」与「待完善事项」。"""
    artifacts = [str(f["path"]) for f in (turn_changes or []) if f.get("path")]
    matched = store.find_matching_project(f"{conv_title}\n{user_task}\n{' '.join(artifacts)}", conv_id=conv_id)

    # 仅在命中已有项目、有计划拆解、或产出了实质文件时建立/更新项目追踪（跳过简单闲聊问答）
    if not matched and not todos and not artifacts and len(user_task.strip()) < 30:
        return None

    done_items: list[str] = [
        str(t["content"]).strip()
        for t in (todos or [])
        if t.get("status") == "completed" and t.get("content")
    ]
    pending_items: list[str] = [
        str(t["content"]).strip()
        for t in (todos or [])
        if t.get("status") in ("pending", "in_progress") and t.get("content")
    ]

    for f in turn_changes or []:
        p = f.get("path")
        if not p:
            continue
        verb = "已新建" if f.get("status") == "added" else "已修订"
        stat = "" if f.get("binary") else f" (+{f.get('added', 0)} -{f.get('removed', 0)})"
        done_items.append(f"{verb}文件 `{p}`{stat}")

    # 用户明确提到的留待后续补充事项
    for m in _DEFERRED_WORK_RE.finditer(user_task):
        item = re.sub(r"^(补充|完善|完成)\s*", "", m.group(1).strip(" ，,。：:；;"))
        if len(item) >= 3:
            pending_items.append(f"待补充：{item}")

    pending_items.extend(_extract_check_document_issues(turn_messages))
    pending_items.extend(_extract_assistant_next_steps(final_text))

    title = matched["title"] if matched else _infer_project_title(user_task, conv_title, artifacts)
    slug = matched["slug"] if matched else ""
    kind = matched["kind"] if matched else _infer_project_kind(f"{title} {user_task}", artifacts)
    summary_line = ""
    if final_text:
        first_para = next((l.strip("#* >") for l in final_text.splitlines() if len(l.strip("#* >")) >= 10), "")
        summary_line = first_para[:240]

    status = "active"
    if not incomplete and done_items and not pending_items and not _DEFERRED_WORK_RE.search(user_task):
        # 虽然首轮交付完成，仍保持 active（如报告初稿完成，用户常会继续改稿），除非用户明确说定稿结项
        if re.search(r"(定稿|结项|全部完结|归档该项目)", user_task):
            status = "completed"

    proj = store.upsert_project(
        title,
        slug=slug,
        kind=kind,
        status=status,
        summary=summary_line,
        completed_items=done_items,
        pending_items=pending_items,
        artifacts=artifacts,
        merge=True,
        conv_id=conv_id,
    )
    return proj


LLM_MEMORY_PROMPT = """你是长期记忆提炼器。阅读本轮【用户输入】与【智能体交付摘要】，仅提取值得跨会话长期保留的高价值信息（没有则返回空数组）：
1. portrait_traits: 用户画像特征 [{dimension: "identity"|"official_doc_format"|"academic_paper_format"|"writing_style"|"coding_prefs"|"data_and_workflow", trait_key: "英文短键", value: "简洁中文描述"}]
2. memories: 长期记忆 [{category: "format_spec"|"correction"|"preference"|"domain_fact", topic_key: "英文短键", content: "具体可复用规则或事实", importance: 3..5}]
不要提取一次性临时指令或密码密钥。严格只输出合法 JSON 对象 {"portrait_traits": [...], "memories": [...]}。"""


async def consolidate_turn_memory(
    store: MemoryStore,
    *,
    conv_id: str,
    conv_title: str,
    user_task: str,
    final_text: str,
    turn_messages: list[Message],
    todos: list[dict[str, Any]],
    turn_changes: list[dict[str, Any]],
    mode: str = "auto",
    agent_profile: str = "general",
    incomplete: bool = False,
    llm: LLMProvider | None = None,
    enable_llm_pass: bool = False,
) -> dict[str, Any]:
    """在每轮任务结束时综合更新用户画像、长期记忆条目与在办项目连续性记录。"""
    events: list[dict[str, Any]] = []
    events.extend(_extract_Explicit_signals(user_task, store, conv_id))
    events.extend(_update_behavioral_telemetry(turn_messages, turn_changes, mode, agent_profile, store))

    proj = _consolidate_ongoing_project(
        conv_id=conv_id,
        conv_title=conv_title,
        user_task=user_task,
        final_text=final_text,
        todos=todos,
        turn_changes=turn_changes,
        turn_messages=turn_messages,
        incomplete=incomplete,
        store=store,
    )
    if proj:
        events.append({
            "kind": "project",
            "slug": proj["slug"],
            "title": proj["title"],
            "completed_count": len(proj["completed_items"]),
            "pending_count": len(proj["pending_items"]),
            "summary": f"已同步项目进度「{proj['title']}」（已完成 {len(proj['completed_items'])} 项，待完善 {len(proj['pending_items'])} 项）",
        })

    # 可选的真实模型深度语义提炼（严禁在 mock 模型下触发任何外部请求）
    if enable_llm_pass and llm is not None and getattr(llm.profile, "provider", "mock") != "mock" and len(user_task) >= 12:
        try:
            snippet = f"【用户输入】\n{redact_secrets(user_task)[:2000]}\n\n【智能体交付摘要】\n{redact_secrets(final_text)[:1500]}"
            resp = await llm.complete(LLM_MEMORY_PROMPT, [Message("user", snippet)], tools=None, retries=0)
            m = re.search(r"\{.*\}", resp.content, re.S)
            if m:
                parsed = json.loads(m.group(0))
                for tr in (parsed.get("portrait_traits") or [])[:4]:
                    if tr.get("dimension") and tr.get("value"):
                        store.upsert_trait(tr["dimension"], tr.get("trait_key") or "llm_trait", tr["value"],
                                           confidence=0.85, source="inferred")
                for mm in (parsed.get("memories") or [])[:4]:
                    if mm.get("content"):
                        rec = store.upsert_memory(
                            mm["content"], category=mm.get("category") or "preference",
                            topic_key=mm.get("topic_key") or "", importance=int(mm.get("importance") or 3),
                            source="llm", conv_id=conv_id,
                        )
                        if rec:
                            events.append({"kind": "memory", "category": rec["category"], "summary": rec["content"], "id": rec["id"]})
        except Exception as e:  # noqa: BLE001
            log.debug("optional llm memory pass skipped: %s", e)

    return {"updated": bool(events), "events": events, "project": proj}
