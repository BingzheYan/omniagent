"""
党政机关公文 python-docx 排版模板（依据 GB/T 9704-2012《党政机关公文格式》）
========================================================================
用法（在 OmniAgent 的 python 工具中）：

    exec(open("omniagent/skills/official-document/gongwen_template.py", encoding="utf-8").read())
    doc = GongWen()
    doc.banshou(organ="××省财政厅文件", wenhao="×财预〔2025〕12号")          # 版头
    doc.title("关于做好2026年省级部门预算编制工作的通知")                    # 标题（可用 \\n 手动分行）
    doc.zhusong("省直各部门：")                                              # 主送机关
    doc.body([                                                               # 正文：按序号自动套层级字体
        "为贯彻落实……，现就有关事项通知如下。",
        "一、总体要求",
        "（一）坚持零基预算理念。打破支出固化格局……",
        "1.严格控制一般性支出。……",
        "（1）……",
    ])
    doc.fujian(["2026年省级部门预算编制时间安排表", "2026年省级部门预算编制说明"])
    doc.signature(organ="××省财政厅", date="2025年3月12日", sealed=True)
    doc.fuzhu("（联系人：×××，电话：0000-0000000）")                        # 可选；请示必须写
    doc.banji(chaosong="省委办公厅，省人大常委会办公厅，省政府办公厅。",
              yinfa_organ="××省财政厅办公室", yinfa_date="2025年3月12日")
    doc.save("outputs/关于做好2026年省级部门预算编制工作的通知.docx")

说明：
- 字体名写入 eastAsia 槽位。若目标机器未安装“方正小标宋简体/仿宋_GB2312/楷体_GB2312”，
  Word 会替换显示，但文件中的字体名仍符合规范；可传 fonts={...} 覆盖（例如 macOS 上用 "STFangsong"）。
- 版记用“浮动表格”锚定到版心底部，自动置于最后一页末行位置；正文过长时请检查是否与版记重叠。
- 发文机关标志字号标准未作硬性规定（以醒目、美观、庄重为原则），默认 36pt，可用 organ_size 调整。
"""
import re
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING, WD_TAB_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Mm, Pt, RGBColor

# ---- 字号对照（单位 pt）----
SIZE = {"初号": 42, "小初": 36, "一号": 26, "小一": 24, "二号": 22, "小二": 18,
        "三号": 16, "小三": 15, "四号": 14, "小四": 12, "五号": 10.5}
RED = RGBColor(0xFF, 0x00, 0x00)
LINE = Pt(28.95)          # 固定行距：22 行 × 28.95pt ≈ 225mm（版心高）
CHAR = 16                 # 3 号字 1 个字宽 = 16pt（用于“空二字”等缩进计算）

DEFAULT_FONTS = {
    "xbs": "方正小标宋简体",   # 发文机关标志、标题
    "fs": "仿宋_GB2312",       # 正文
    "ht": "黑体",              # 一级标题、密级、紧急程度
    "kt": "楷体_GB2312",       # 二级标题、签发人姓名
    "st": "宋体",              # 页码
}


def set_run_font(run, name, size_pt, bold=False, color=None):
    run.font.name = name
    run.font.size = Pt(size_pt)
    run.font.bold = bold
    if color is not None:
        run.font.color.rgb = color
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.insert(0, rfonts)
    for k in ("w:ascii", "w:hAnsi", "w:eastAsia", "w:cs"):
        rfonts.set(qn(k), name)


def text_width(s):
    """以“字”为单位估算宽度：汉字/全角=1，半角数字字母=0.5。"""
    return sum(0.5 if ord(c) < 0x2E80 and c not in "〔〕（）：；，。" else 1 for c in s)


PPR_AFTER_PBDR = ("w:shd", "w:tabs", "w:suppressAutoHyphens", "w:kinsoku", "w:wordWrap", "w:overflowPunct",
                  "w:topLinePunct", "w:autoSpaceDE", "w:autoSpaceDN", "w:bidi", "w:adjustRightInd", "w:snapToGrid",
                  "w:spacing", "w:ind", "w:contextualSpacing", "w:mirrorIndents", "w:suppressOverlap", "w:jc",
                  "w:textDirection", "w:textAlignment", "w:textboxTightWrap", "w:outlineLvl", "w:divId",
                  "w:cnfStyle", "w:rPr", "w:sectPr", "w:pPrChange")


def _border(p, side, sz=8, color="FF0000", space=0):
    """给段落加边框（按 OOXML 规定的子元素顺序插入，避免 Word 报“文件损坏”）。"""
    ppr = p._p.get_or_add_pPr()
    bdr = ppr.find(qn("w:pBdr"))
    if bdr is None:
        bdr = OxmlElement("w:pBdr")
        ppr.insert_element_before(bdr, *PPR_AFTER_PBDR)
    el = OxmlElement(f"w:{side}")
    el.set(qn("w:val"), "single"); el.set(qn("w:sz"), str(sz))
    el.set(qn("w:space"), str(space)); el.set(qn("w:color"), color)
    bdr.append(el)


def _add_field(run, instr):
    for tag, attr in (("w:fldChar", "begin"), ("w:instrText", instr), ("w:fldChar", "end")):
        el = OxmlElement(tag)
        if tag == "w:fldChar":
            el.set(qn("w:fldCharType"), attr)
        else:
            el.set(qn("xml:space"), "preserve"); el.text = attr
        run._r.append(el)


class GongWen:
    def __init__(self, fonts=None, organ_size=36):
        self.f = {**DEFAULT_FONTS, **(fonts or {})}
        self.organ_size = organ_size
        self.doc = Document()
        self._setup_page()
        self._setup_normal()
        self._setup_page_number()

    # ---------------- 页面 ----------------
    def _setup_page(self):
        s = self.doc.sections[0]
        s.page_width, s.page_height = Mm(210), Mm(297)
        s.top_margin, s.left_margin = Mm(37), Mm(28)        # 天头 37mm，订口 28mm
        s.right_margin = Mm(210 - 28 - 156)                  # 26mm → 版心宽 156mm
        s.bottom_margin = Mm(297 - 37 - 225)                 # 35mm → 版心高 225mm
        s.header_distance, s.footer_distance = Mm(15), Mm(25)  # 使页码一字线约距版心下缘 7mm，可实测微调
        # 文档网格：每页 22 行
        sectpr = s._sectPr
        grid = sectpr.find(qn("w:docGrid"))
        if grid is None:
            grid = OxmlElement("w:docGrid"); sectpr.append(grid)
        grid.set(qn("w:type"), "lines"); grid.set(qn("w:linePitch"), "579")

    def _setup_normal(self):
        st = self.doc.styles["Normal"]
        st.font.name = self.f["fs"]; st.font.size = Pt(16)
        st.element.get_or_add_rPr()
        rfonts = st.element.rPr.find(qn("w:rFonts"))
        if rfonts is None:
            rfonts = OxmlElement("w:rFonts"); st.element.rPr.insert(0, rfonts)
        for k in ("w:ascii", "w:hAnsi", "w:eastAsia"):
            rfonts.set(qn(k), self.f["fs"])
        pf = st.paragraph_format
        pf.line_spacing_rule = WD_LINE_SPACING.EXACTLY; pf.line_spacing = LINE
        pf.space_before = Pt(0); pf.space_after = Pt(0)

    def _setup_page_number(self):
        """页码：4 号半角宋体，“— 1 —”，单页居右空一字，双页居左空一字。"""
        self.doc.settings.odd_and_even_pages_header_footer = True
        s = self.doc.sections[0]
        for footer, align in ((s.footer, WD_ALIGN_PARAGRAPH.RIGHT), (s.even_page_footer, WD_ALIGN_PARAGRAPH.LEFT)):
            p = footer.paragraphs[0]
            p.alignment = align
            if align == WD_ALIGN_PARAGRAPH.RIGHT:
                p.paragraph_format.right_indent = Pt(14)
            else:
                p.paragraph_format.left_indent = Pt(14)
            r1 = p.add_run("— "); set_run_font(r1, self.f["st"], 14)
            r2 = p.add_run(); set_run_font(r2, self.f["st"], 14); _add_field(r2, "PAGE")
            r3 = p.add_run(" —"); set_run_font(r3, self.f["st"], 14)

    # ---------------- 基础段落 ----------------
    def _p(self, align=WD_ALIGN_PARAGRAPH.JUSTIFY, first_indent_chars=0, left_chars=0, right_chars=0, exact=True):
        p = self.doc.add_paragraph()
        p.alignment = align
        pf = p.paragraph_format
        if exact:
            pf.line_spacing_rule = WD_LINE_SPACING.EXACTLY; pf.line_spacing = LINE
        pf.first_line_indent = Pt(CHAR * first_indent_chars) if first_indent_chars else None
        if left_chars:
            pf.left_indent = Pt(CHAR * left_chars)
        if right_chars:
            pf.right_indent = Pt(CHAR * right_chars)
        return p

    def blank(self, n=1):
        for _ in range(n):
            self._p()

    # ---------------- 版头 ----------------
    def banshou(self, organ, wenhao, fenhao=None, miji=None, jinji=None, qianfaren=None):
        """organ: 发文机关标志（如“××省财政厅文件”）；wenhao: 发文字号（年份用六角括号〔〕，序号不编虚位，不加“第”）。
        qianfaren 非空时按上行文排版：发文字号居左空一字、签发人居右空一字，机关标志上边缘距版心上边缘 80mm。"""
        top_lines = 0
        for txt, font in ((fenhao, "fs"), (miji, "ht"), (jinji, "ht")):
            if txt:
                r = self._p(WD_ALIGN_PARAGRAPH.LEFT).add_run(txt)
                set_run_font(r, self.f[font], 16); top_lines += 1
        p = self._p(WD_ALIGN_PARAGRAPH.CENTER, exact=False)
        offset_mm = (80 if qianfaren else 35) - top_lines * 10.2
        p.paragraph_format.space_before = Mm(max(offset_mm, 0))
        p.paragraph_format.line_spacing = 1.0
        set_run_font(p.add_run(organ), self.f["xbs"], self.organ_size, color=RED)
        self.blank(2)                                          # 机关标志下空二行
        if qianfaren:
            p = self._p(WD_ALIGN_PARAGRAPH.LEFT, left_chars=1, right_chars=1)
            set_run_font(p.add_run(wenhao), self.f["fs"], 16)
            p.paragraph_format.tab_stops.add_tab_stop(Mm(156) - Pt(CHAR * 2), WD_TAB_ALIGNMENT.RIGHT)
            set_run_font(p.add_run("\t签发人："), self.f["fs"], 16)
            set_run_font(p.add_run(qianfaren), self.f["kt"], 16)
        else:
            p = self._p(WD_ALIGN_PARAGRAPH.CENTER)
            set_run_font(p.add_run(wenhao), self.f["fs"], 16)
        _border(p, "bottom", sz=8, color="FF0000", space=11)  # 发文字号下 4mm 红色分隔线（≈11pt）
        self.blank(2)                                          # 分隔线下空二行排标题

    # ---------------- 主体 ----------------
    def title(self, text):
        for line in text.split("\n"):
            p = self._p(WD_ALIGN_PARAGRAPH.CENTER)
            p.paragraph_format.line_spacing = Pt(36)           # 2 号字标题行距略大，避免截字
            set_run_font(p.add_run(line), self.f["xbs"], 22)
        self.blank(1)                                          # 标题下空一行

    def zhusong(self, text):
        p = self._p(WD_ALIGN_PARAGRAPH.JUSTIFY)                # 居左顶格，末尾全角冒号
        set_run_font(p.add_run(text), self.f["fs"], 16)

    LEVELS = [
        (re.compile(r"^[一二三四五六七八九十]+、"), "ht", False, "line"),   # 一级：黑体，整行
        (re.compile(r"^（[一二三四五六七八九十]+）"), "kt", False, "lead"),  # 二级：楷体，标题句
        (re.compile(r"^\d+[.．]"), "fs", True, "lead"),                     # 三级：仿宋（实践常加粗）
        (re.compile(r"^（\d+）"), "fs", False, "lead"),                     # 四级：仿宋
    ]

    def para(self, text):
        p = self._p(first_indent_chars=2)                      # 每段左空二字，回行顶格
        for pat, font, bold, mode in self.LEVELS:
            if pat.match(text):
                if mode == "line":
                    set_run_font(p.add_run(text), self.f[font], 16, bold=bold)
                else:
                    m = re.search(r"[。：:]", text)            # 段首标题句到第一个句号/冒号为止
                    head, rest = (text[: m.end()], text[m.end():]) if m else (text, "")
                    set_run_font(p.add_run(head), self.f[font], 16, bold=bold)
                    if rest:
                        set_run_font(p.add_run(rest), self.f["fs"], 16)
                return p
        set_run_font(p.add_run(text), self.f["fs"], 16)
        return p

    def body(self, paragraphs):
        for t in paragraphs:
            t = t.strip()
            if t:
                self.para(t)

    def fujian(self, names):
        """附件说明：正文下空一行，左空二字“附件：”；多个附件用 1. 2. 编号，名称后不加标点。"""
        if not names:
            return
        self.blank(1)
        if len(names) == 1:
            p = self._p(WD_ALIGN_PARAGRAPH.LEFT, left_chars=5)
            p.paragraph_format.first_line_indent = Pt(-CHAR * 3)
            set_run_font(p.add_run(f"附件：{names[0]}"), self.f["fs"], 16)
            return
        for i, n in enumerate(names, 1):
            # 首行“附件：1.名称”从左空二字起；其后各行序号与“1.”对齐；回行与附件名称首字对齐
            p = self._p(WD_ALIGN_PARAGRAPH.LEFT, left_chars=6)
            p.paragraph_format.first_line_indent = Pt(-CHAR * (4 if i == 1 else 1))
            set_run_font(p.add_run(f"附件：{i}.{n}" if i == 1 else f"{i}.{n}"), self.f["fs"], 16)

    def signature(self, organ, date, sealed=True):
        """sealed=True：成文日期右空四字，署名以日期为准居中，印章下压署名和日期（盖章前留 3 行空白）。
        sealed=False：正文下空一行右空二字排署名，下一行排日期，日期首字比署名首字右移二字。
        成文日期用阿拉伯数字标全年月日，月、日不编虚位（如 2025年3月2日）。"""
        wd, wo, line = text_width(date), text_width(organ), 28
        if sealed:
            self.blank(3)
            left_date = line - 4 - wd
            left_org = left_date + (wd - wo) / 2
        else:
            self.blank(1)
            left_org = line - 2 - wo
            left_date = left_org + 2
        for txt, left in ((organ, left_org), (date, left_date)):
            p = self._p(WD_ALIGN_PARAGRAPH.LEFT)
            p.paragraph_format.left_indent = Pt(CHAR * max(left, 0))
            set_run_font(p.add_run(txt), self.f["fs"], 16)

    def fuzhu(self, text):
        p = self._p(WD_ALIGN_PARAGRAPH.LEFT, left_chars=2)     # 附注：成文日期下一行，左空二字，加圆括号
        set_run_font(p.add_run(text), self.f["fs"], 16)

    # ---------------- 版记 ----------------
    def banji(self, yinfa_organ, yinfa_date, chaosong=None):
        """版记：浮动表格锚定在版心底部。首末分隔线粗（0.35mm≈1pt），中间细线（0.25mm≈0.75pt）。
        抄送 4 号仿宋左右各空一字，末尾句号；印发机关左空一字、印发日期右空一字，日期后加“印发”。"""
        rows = (1 if chaosong else 0) + 1
        tbl = self.doc.add_table(rows=rows, cols=1)
        tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
        tblpr = tbl._tbl.tblPr
        # 子元素顺序：tblStyle, tblpPr, …, tblW, jc, …, tblBorders, shd, tblLayout, tblCellMar, tblLook
        pos = OxmlElement("w:tblpPr")
        for k, v in (("w:vertAnchor", "margin"), ("w:horzAnchor", "margin"), ("w:tblpYSpec", "bottom"), ("w:tblpXSpec", "center")):
            pos.set(qn(k), v)
        tblpr.insert_element_before(pos, "w:tblOverlap", "w:bidiVisual", "w:tblStyleRowBandSize", "w:tblStyleColBandSize",
                                    "w:tblW", "w:jc", "w:tblCellSpacing", "w:tblInd", "w:tblBorders", "w:shd",
                                    "w:tblLayout", "w:tblCellMar", "w:tblLook")
        tw = tblpr.find(qn("w:tblW"))
        if tw is None:
            tw = OxmlElement("w:tblW")
            tblpr.insert_element_before(tw, "w:jc", "w:tblCellSpacing", "w:tblInd", "w:tblBorders", "w:shd",
                                        "w:tblLayout", "w:tblCellMar", "w:tblLook")
        tw.set(qn("w:w"), str(int(156 / 25.4 * 1440))); tw.set(qn("w:type"), "dxa")
        borders = OxmlElement("w:tblBorders")
        for side, sz in (("top", 8), ("left", 0), ("bottom", 8), ("right", 0), ("insideH", 6), ("insideV", 0)):
            el = OxmlElement(f"w:{side}")
            el.set(qn("w:val"), "single" if sz else "nil")
            if sz:
                el.set(qn("w:sz"), str(sz)); el.set(qn("w:color"), "000000")
            borders.append(el)
        tblpr.insert_element_before(borders, "w:shd", "w:tblLayout", "w:tblCellMar", "w:tblLook")
        cells = [r.cells[0] for r in tbl.rows]
        for c in cells:
            c.width = Mm(156)
        i = 0
        if chaosong:
            p = cells[0].paragraphs[0]
            p.paragraph_format.left_indent = Pt(14); p.paragraph_format.right_indent = Pt(14)
            p.paragraph_format.first_line_indent = None
            p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.EXACTLY; p.paragraph_format.line_spacing = LINE
            set_run_font(p.add_run(f"抄送：{chaosong}"), self.f["fs"], 14)
            i = 1
        p = cells[i].paragraphs[0]
        p.paragraph_format.left_indent = Pt(14); p.paragraph_format.first_line_indent = None
        p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.EXACTLY; p.paragraph_format.line_spacing = LINE
        p.paragraph_format.tab_stops.add_tab_stop(Mm(156) - Pt(14) - Mm(2), WD_TAB_ALIGNMENT.RIGHT)
        set_run_font(p.add_run(f"{yinfa_organ}\t{yinfa_date}印发"), self.f["fs"], 14)

    def page_break(self):
        self.doc.add_page_break()

    def save(self, path):
        import os
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        self.doc.save(path)
        return path


if __name__ == "__main__":   # 自测：生成一份示例通知
    d = GongWen()
    d.banshou(organ="××省财政厅文件", wenhao="×财预〔2025〕12号")
    d.title("××省财政厅关于做好2026年\n省级部门预算编制工作的通知")
    d.zhusong("省直各部门：")
    d.body(["为深入贯彻……，现就做好2026年省级部门预算编制工作通知如下。",
            "一、总体要求", "（一）坚持零基预算理念。打破支出固化格局，……",
            "1.严格控制一般性支出。……", "（1）……", "二、工作安排",
            "请各部门于2025年4月30日前将预算草案报送省财政厅。"])
    d.fujian(["2026年省级部门预算编制时间安排表", "2026年省级部门预算编制说明"])
    d.signature("××省财政厅", "2025年3月12日", sealed=True)
    d.fuzhu("（联系人：×××，电话：0000-0000000）")
    d.banji(chaosong="省委办公厅，省人大常委会办公厅，省政府办公厅。", yinfa_organ="××省财政厅办公室", yinfa_date="2025年3月12日")
    print(d.save("/tmp/omni_skill_test/gongwen_demo.docx"))
