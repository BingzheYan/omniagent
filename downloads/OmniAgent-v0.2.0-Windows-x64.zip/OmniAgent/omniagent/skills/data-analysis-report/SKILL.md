---
name: data-analysis-report
description: 对用户提供的数据（Excel/CSV/数据库导出等）做探索性分析并撰写数据分析报告时使用：需求澄清、数据体检、清洗留痕、总体-结构-趋势-对比-归因-预测分析框架、图表选择、结论先行的报告结构、数字复核、create_document(style="report") 输出与 check_document 自检。关键词：数据分析、分析报告、经营分析、统计分析、月报、季报、年报、同比、环比、占比、趋势、异常、可视化、图表、Excel 分析、销售分析、财务分析、收支分析。
---

# 数据分析报告 Skill

目标：把一份原始数据变成一份**结论先行、数字可追溯、图表规范**的分析报告（.docx/.pdf/.html）。全流程 8 步，用 `todo_write` 跟踪：

```
1. 需求澄清 → 2. 数据体检 → 3. 清洗（留痕） → 4. 分析（总体-结构-趋势-对比-归因-预测）
5. 作图 → 6. 写报告（结论先行） → 7. 数字复核 + check_document → 8. 交付说明
```

> **诚信底线**：报告中的每一个数字都必须来自本次实际运行的代码输出；不得估计、补造或“取整美化”到改变含义的程度。数据不足以支持某个结论时，明说“数据不足以判断”。

---

## 1. 需求澄清（开工前 1 次 `ask_user`，已明确的跳过）

| 问题 | 为什么要问 |
|---|---|
| 报告给谁看？（领导/业务部门/外部客户） | 决定详略、术语深度、是否需要执行摘要 |
| 要回答的核心问题是什么？（1–3 个） | 分析围绕问题，而不是把所有字段都画一遍 |
| 时间范围、口径（含税/不含税、自然月/财务月、按下单/按支付） | 避免口径错误导致结论全错 |
| 关注的关键指标（KPI）和对比基准（同比、预算、目标、竞品） | 没有基准的数字没有意义 |
| 输出格式与篇幅（docx/pdf/html；几页） | 默认 docx，8–15 页 |
| 是否有既有模板/往期报告 | 有则 `read_file` 读取并沿用结构和口径 |

若用户只丢下一个文件说“分析一下”，先做第 2 步体检，再基于数据提出 3 个候选分析问题让用户确认（或在无法询问时自行选择最有业务价值的问题并在报告中说明）。

---

## 2. 数据体检（只读不改）

```python
import pandas as pd, numpy as np
df = pd.read_excel("data/raw/sales.xlsx", sheet_name=0)      # 多 sheet：pd.read_excel(path, sheet_name=None) 返回 dict
# CSV 编码问题：pd.read_csv(path, encoding="utf-8-sig") / encoding="gbk"
print(df.shape); print(df.dtypes); print(df.head())

def health_check(df):
    rep = pd.DataFrame({
        "类型": df.dtypes.astype(str),
        "非空数": df.notna().sum(),
        "缺失率%": (df.isna().mean() * 100).round(2),
        "唯一值数": df.nunique(),
        "示例值": df.apply(lambda s: s.dropna().iloc[0] if s.notna().any() else None),
    })
    print("行数：", len(df), "；完全重复行：", df.duplicated().sum())
    return rep
print(health_check(df))
print(df.describe(include="all").T)
```

体检清单（发现的问题都记下来，写进报告“数据说明”）：
- [ ] 形状、字段含义（不明字段问用户，不要猜）
- [ ] 类型：日期是否被读成字符串？金额是否混入“元”“,”？编码/ID 是否被读成数字丢了前导 0（读入时 `dtype={"编码": str}`）？
- [ ] 缺失：哪些字段、比例、是否集中在某时段/某类别（系统性缺失要说明）
- [ ] 重复：完全重复行；业务主键（订单号）重复
- [ ] 异常：负值、0 值、极端值、未来日期、逻辑矛盾（退款 > 销售额）
- [ ] 口径：合计行/小计行混在明细里（Excel 常见）——必须删除，否则重复计算
- [ ] 时间覆盖：起止日期、是否有断档月份

---

## 3. 清洗（每一步留痕）

原则：**原始数据不覆盖**（`data/raw/` 只读），清洗结果另存 `data/clean/`；每一步记录“做了什么、影响多少行”，最终写入报告附录。

```python
log = []
def step(desc, before, after):
    log.append({"步骤": desc, "处理前行数": before, "处理后行数": after, "影响行数": before - after})

n = len(df); df = df.drop_duplicates(); step("删除完全重复行", n, len(df))
n = len(df); df = df[~df["门店"].astype(str).str.contains("合计|小计|总计", na=False)]; step("删除合计/小计行", n, len(df))
df["日期"] = pd.to_datetime(df["日期"], errors="coerce")
n = len(df); df = df.dropna(subset=["日期"]); step("删除日期无法解析的行", n, len(df))
df["金额"] = pd.to_numeric(df["金额"].astype(str).str.replace(r"[,元￥\s]", "", regex=True), errors="coerce")
df["月份"] = df["日期"].dt.to_period("M")
clean_log = pd.DataFrame(log); print(clean_log)
df.to_csv("data/clean/sales_clean.csv", index=False, encoding="utf-8-sig")
```

缺失值处理决策：
| 情形 | 处理 |
|---|---|
| 缺失 < 5% 且随机 | 删除或保留不填（统计时自然排除） |
| 关键指标缺失、可由其他字段推出 | 推算（如 金额 = 单价×数量），并标注 |
| 时间序列中断 1–2 期 | 线性插值（说明） |
| 大量缺失或系统性缺失 | 不填，单独说明，结论限定适用范围 |

异常值：先**识别和核实**，不要直接删；能确认是录入错误的修正/剔除，真实的极端值保留并单独分析（往往是重要发现）。

---

## 4. 分析框架：总体 → 结构 → 趋势 → 对比 → 归因 → 预测

| 层次 | 回答的问题 | 典型方法 | 典型图 |
|---|---|---|---|
| 总体 | 规模多大？达成如何？ | 合计、均值、完成率、KPI 卡片 | 指标卡、子弹图 |
| 结构 | 由什么组成？谁贡献最大？ | 占比、帕累托（二八）、集中度 | 条形图（排序）、堆积条形、树图 |
| 趋势 | 怎么变化？ | 同比、环比、移动平均、累计、季节性 | 折线图、面积图 |
| 对比 | 和谁比？好不好？ | 与目标/预算/上年/同行对比、分组差异 | 分组条形、哑铃图、子弹图 |
| 归因 | 为什么变化？ | 因素分解（量×价）、贡献度、交叉分析、相关 | 瀑布图、散点图、热力图 |
| 预测 | 接下来会怎样？ | 趋势外推、季节性朴素、回归（谨慎） | 折线 + 预测区间 |

### 4.1 常用 pandas 代码

```python
# 分组汇总
g = df.groupby("区域").agg(销售额=("金额", "sum"), 订单数=("订单号", "nunique"), 客单价=("金额", "mean"))
g["占比%"] = (g["销售额"] / g["销售额"].sum() * 100).round(1)
g = g.sort_values("销售额", ascending=False)

# 透视表：区域 × 月份
pv = df.pivot_table(index="区域", columns="月份", values="金额", aggfunc="sum", fill_value=0, margins=True, margins_name="合计")

# 月度序列 + 同比/环比
m = df.groupby("月份")["金额"].sum().sort_index()
m.index = m.index.to_timestamp()
m = m.asfreq("MS")                       # 补齐缺失月份为 NaN，避免 shift 错位
ts = pd.DataFrame({"金额": m})
ts["环比%"] = ts["金额"].pct_change() * 100
ts["同比%"] = ts["金额"].pct_change(12) * 100          # 月度数据同比 = 12 期前
ts["近3月均值"] = ts["金额"].rolling(3).mean()
ts["年累计"] = ts.groupby(ts.index.year)["金额"].cumsum()
ts["累计同比%"] = ts["年累计"].pct_change(12) * 100

# 帕累托：多少比例的客户贡献了 80% 的销售额
c = df.groupby("客户")["金额"].sum().sort_values(ascending=False)
cum = c.cumsum() / c.sum()
n80 = int((cum < 0.8).sum()) + 1
print(f"前 {n80} 个客户（占 {n80 / len(c):.1%}）贡献了 80% 的销售额")

# 价量分解：销售额变动 = 量的贡献 + 价的贡献 + 交互项
def price_volume(q0, p0, q1, p1):
    return {"量的贡献": (q1 - q0) * p0, "价的贡献": (p1 - p0) * q0, "交互": (q1 - q0) * (p1 - p0)}

# 异常检测：IQR 与 z-score
def iqr_outliers(s, k=1.5):
    q1, q3 = s.quantile([0.25, 0.75]); iqr = q3 - q1
    return (s < q1 - k * iqr) | (s > q3 + k * iqr)
def z_outliers(s, z=3):
    return ((s - s.mean()) / s.std()).abs() > z
df["异常_IQR"] = iqr_outliers(df["金额"])
# 时间序列异常：与滚动中位数的偏离（对季节/趋势更稳健）
resid = ts["金额"] - ts["金额"].rolling(5, center=True, min_periods=3).median()
ts["异常"] = z_outliers(resid.fillna(0), z=2.5)
```

注意：
- **百分比 vs 百分点**：增长率相减用“百分点”（占比从 30% 到 35%，“提高 5 个百分点”，不是“提高 5%”）。
- **基数过小**的增长率（如从 2 到 10，增长 400%）不宜作为亮点，应同时给出绝对值。
- 同比时注意**春节错月**、工作日差异等可比性问题，必要时用 1–2 月合并。
- 均值容易被极值拉偏：偏态分布同时报告中位数。
- 相关不等于因果：归因结论用“可能与……有关”，除非有实验或准实验设计。

### 4.2 简单预测（仅在用户需要时；必须注明方法与不确定性）

```python
# 季节性朴素 + 趋势：用去年同期 × (近12个月同比增速均值)
growth = ts["同比%"].dropna().tail(12).mean() / 100
fc_idx = pd.date_range(ts.index[-1] + pd.offsets.MonthBegin(), periods=6, freq="MS")
fc = pd.Series([ts["金额"].get(d - pd.DateOffset(years=1), np.nan) * (1 + growth) for d in fc_idx], index=fc_idx)
# 更正式：statsmodels.tsa.holtwinters.ExponentialSmoothing(m, trend="add", seasonal="add", seasonal_periods=12)
# 样本 < 24 个月时不建议做季节性模型；预测结果只作参考并在报告中注明。
```

---

## 5. 图表选择与设计规范

### 5.1 问题 → 图表

| 想表达 | 用 | 不要用 |
|---|---|---|
| 随时间变化（≥6 个时点） | 折线图 | 3D 柱、过多系列（>5 条线时拆分小多图） |
| 少数时点比较 | 柱状图 | 折线（会暗示连续性） |
| 类别排名/比较 | **横向条形图，按数值排序** | 饼图（>5 类时） |
| 构成（占比） | 100% 堆积条形；类别 ≤5 可用环形图 | 多个饼图并排比较 |
| 构成随时间变化 | 堆积面积/堆积柱 | 多个饼图 |
| 实际 vs 目标 | 子弹图、带目标线的柱状图 | 双饼图 |
| 增减分解（从 A 到 B 的原因） | 瀑布图 | 普通柱状图 |
| 两变量关系 | 散点图（+趋势线） | 双轴折线（易误导） |
| 分布 | 直方图、箱线图 | 均值柱状图 |
| 二维交叉（区域×月份） | 热力图 | 大表格 |
| 二八结构 | 帕累托图（条形 + 累计折线） | — |

### 5.2 设计规则

```python
import matplotlib.pyplot as plt
try:
    from omniagent.research import academic_style, savefig   # 中文字体自动检测
    academic_style()
except ImportError:
    plt.rcParams["font.sans-serif"] = ["PingFang SC", "Heiti SC", "Microsoft YaHei", "SimHei", "Noto Sans CJK SC"]
    plt.rcParams["axes.unicode_minus"] = False
    savefig = lambda fig, p: fig.savefig(p, dpi=300, bbox_inches="tight")

# 排序横向条形图 + 数据标签 + 高亮重点
top = g["销售额"].sort_values()
fig, ax = plt.subplots(figsize=(7, 4))
colors = ["#C00000" if i == top.idxmax() else "#A6A6A6" for i in top.index]   # 只高亮要强调的那一个
ax.barh(top.index.astype(str), top.values / 1e4, color=colors)
for y, v in enumerate(top.values / 1e4):
    ax.text(v, y, f" {v:,.1f}", va="center", fontsize=9)
ax.set_xlabel("销售额（万元）")
for s in ["top", "right"]:
    ax.spines[s].set_visible(False)
savefig(fig, "outputs/figures/fig1_region_sales.png")
```

1. **一图一结论**：图题写结论（报告图题中“图1 华东区贡献近四成销售额”），图内不重复写标题。
2. 坐标轴标注**名称与单位**；数值大时换算成万元/亿元，千分位分隔。
3. 柱状图/条形图纵轴**从 0 开始**；折线图可不从 0，但不得刻意夸大波动。
4. 颜色克制：默认灰色 + 1 种强调色；同一维度在全报告中颜色一致（如“本年”始终深蓝，“上年”始终浅灰）。
5. 去掉无意义元素：3D、阴影、网格过密、图例可直接标注在线尾时去掉图例。
6. 数据标签只标关键点（最大值、最新值、拐点），避免满屏数字。
7. 300 dpi 保存到 `outputs/figures/`，文件名带序号；若 `view_image` 可用，逐张查看（中文乱码、标签重叠、截断）。

---

## 6. 报告结构：结论先行（金字塔）

```markdown
# <报告标题：对象 + 时间 + 主题，如“2025年1—9月华东区销售分析报告”>

## 执行摘要

<1 句总述：总体结论。>

1. **<核心发现1，带数字>**：1—9月销售额 3.42 亿元，同比增长 8.6%，完成年度目标的 78.2%。
2. **<核心发现2>**：……
3. **<核心发现3>**：……
（3–5 条，每条“结论 + 关键数字 + 简短原因”）

**主要建议**：① ……；② ……；③ ……

## 一、分析背景与数据说明
（目的、数据来源、时间范围、口径、清洗要点与局限——详细清洗日志放附录）

## 二、总体情况
## 三、结构分析
## 四、趋势分析
## 五、对比与归因
## 六、（可选）预测与风险
## 七、结论与建议
（建议 = 针对发现的具体动作：谁、做什么、预期效果；按优先级排列）

## 附录
（附表1 数据清洗日志；附表2 指标定义；附表3 明细数据表）
```

写作要点：
- 每节开头一句**小结论**，然后用图表和数字支撑（“先说结论，再给证据”）。
- 图表引用顺序：先文字“如图2所示”，再放图，再解读；表格同理（`表1 各区域销售额及占比` 放在表格上方单独一行）。Markdown 写法：
  - 图：`![图2 2025年月度销售额及同比增速](outputs/figures/fig2_trend.png)`，下一行可写 `资料来源：公司ERP系统。`
  - 表：标题行 `表1 各区域销售额及占比` → Markdown 表格 → `注：……`
- 表格用 `df_to_markdown(df, digits=1)`（`from omniagent.research import df_to_markdown`；无该函数时用 `df.to_markdown(index=False, floatfmt=".1f")`）。金额统一单位、小数位一致、千分位。
- 用词：“增长/下降 x%”“提高/降低 x 个百分点”“占比 x%”“贡献了增量的 x%”；避免“大幅”“显著”等无数字形容（统计检验意义上的“显著”除外）。
- 篇幅：执行摘要 ≤ 1 页；正文每节 1–2 页；图 5–10 幅。

---

## 7. 生成文档、数字复核与自检

1. 写 `report/report.md`（可按章节 `write_file` 后合并）。
2. **数字复核**（必须做）：把报告中所有数字抽出来与代码结果对照：
   ```python
   import re
   text = open("report/report.md", encoding="utf-8").read()
   nums = sorted(set(re.findall(r"\d[\d,]*\.?\d*%?", text)))
   print(len(nums), nums[:200])
   ```
   为关键数字建立“数字台账” `outputs/numbers.json`（指标名 → 值 → 产生它的代码/表格），逐条核对；发现报告数字与输出不一致，以代码输出为准修改报告。
3. 生成：
   ```
   create_document(source_path="report/report.md", output_path="outputs/分析报告.docx", style="report", toc=True)
   ```
   需要 PDF 再输出 `.pdf`；需要网页版输出 `.html`。
4. 自检：`check_document(path="outputs/分析报告.docx", paper_type="report")`，修复所有“严重”问题（图表未引用、编号不连续、图片未嵌入、占位符、空章节等），目标得分 ≥ 85。
5. 用 `read_file` 打开生成的 docx 快速通读一遍，确认执行摘要中的数字与正文一致。

---

## 8. 交付说明（回复用户时）

- 交付物路径：报告（docx/pdf）、图表目录、清洗后数据、分析脚本（建议把关键代码另存 `outputs/analysis.py` 以便复现）。
- 3–5 条核心结论（与执行摘要一致）。
- 数据质量与局限：缺失、口径假设、无法回答的问题。
- `check_document` 得分；需用户确认的口径或假设。

---

## 9. 常见坑

| 坑 | 规避 |
|---|---|
| Excel 中含合计行导致数字翻倍 | 体检时检查“合计/小计”关键词与末行 |
| 月份缺失导致 `pct_change(12)` 错位 | 先 `asfreq("MS")` 补齐 |
| 百分比和百分点混用 | 占比/比率之差一律用“个百分点” |
| 平均数掩盖分布 | 同时给中位数、分位数或箱线图 |
| 图表很多但没有结论 | 每张图回答一个问题，图题即结论 |
| 结论与数字对不上 | 数字台账 + 复核脚本 |
| 饼图 10 个类别 | 改排序条形图，其余合并为“其他” |
