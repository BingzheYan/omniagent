---
name: new-project
description: 从零创建一个可直接运行的新项目/工具/脚本工程：需求澄清、技术选型、目录脚手架、核心实现、测试、README 与一键运行验证。适用于“帮我写一个 xx 工具/应用/服务/爬虫/命令行程序/网站/小游戏”“新建项目”“搭一个脚手架”等任务。
---

# 新建项目（New Project）

交付标准：**用户按 README 的命令能一次跑起来，测试全部通过。** 不交付半成品、伪代码或 TODO 占位。

## 1. 明确需求（不要过度提问）
- 提炼：核心功能（必须有）、输入/输出、使用方式（CLI / Web / 库 / 脚本）、运行环境、数据来源。
- 能合理推断的自行决定并在汇报中写明假设；只有关键信息缺失且猜错代价高时才 ask_user。
- 用 todo_write 拆出计划：脚手架 → 核心功能（按模块）→ 测试 → README → 端到端运行验证。

## 2. 技术选型（优先简单、成熟、少依赖）
- 先看环境：`python --version`、`node --version`、`uv --version` 等，选择本机已有的工具链。
- 默认推荐：
  - Python 工具/CLI：标准库 + `argparse`（或 `typer`），`pytest` 测试，`pyproject.toml` 声明依赖。
  - Python Web API：FastAPI + uvicorn；简单页面可直接返回 HTML 或用 Jinja2。
  - 前端/全栈：Vite + 原生 TS/React；纯静态页面直接用单个 HTML + JS 即可。
  - 数据处理：pandas；绘图 matplotlib。
- 不确定某个库的 API 时，先装上并用 `python -c` 验证，不要凭记忆写不存在的接口。

## 3. 脚手架（Python 示例，其他语言按其惯例）
```
<project>/
├── pyproject.toml        # 名称、版本、依赖、[project.scripts] 入口、pytest 配置
├── README.md
├── .gitignore            # .venv/ __pycache__/ .pytest_cache/ dist/ .env 等
├── src/<pkg>/            # 或扁平的 <pkg>/，小项目都可以
│   ├── __init__.py
│   ├── __main__.py       # 支持 python -m <pkg>
│   ├── cli.py            # 参数解析与入口，只做 I/O 编排
│   └── core.py           # 纯逻辑，便于测试
└── tests/
    └── test_core.py
```
- 项目放在用户指定目录；未指定时在工作区下新建一个以项目命名的子目录，不要把文件散落在工作区根目录。
- 逻辑与 I/O 分离：核心函数接收参数、返回结果，不直接读 stdin / 打印，方便测试。
- 配置走命令行参数或环境变量（提供 `.env.example`），**不要硬编码密钥**。
- 用户没要求就不要 `git init` 之后提交；如需初始化仓库，只做 `git init` 并写好 `.gitignore`。

## 4. 实现
- 小步推进：每完成一个模块就运行一次（`python -m <pkg> --help`、一个示例输入），不要写完全部再第一次运行。
- 错误处理：对用户输入、文件、网络给出清晰错误信息和非 0 退出码；不要吞异常。
- 代码风格：类型注解、简短的模块/函数 docstring、有意义的命名；不留 `pass`/`TODO`/“此处省略”。
- 需要示例数据时生成一份小样例（如 `examples/sample.csv`），并在 README 中使用它。

## 5. 测试
- 为核心逻辑写 pytest 测试：正常路径、边界条件（空输入、非法输入）、至少一个端到端用例（可用 `subprocess` 或直接调用 `main([...])`）。
- 外部依赖（网络、API）用 mock / 本地假数据，测试不能依赖外网。
- 运行：创建隔离环境后安装并测试，例如：
  ```bash
  cd <project>
  uv venv && uv pip install -e ".[dev]"   # 或 python -m venv .venv && .venv/bin/pip install -e ".[dev]"
  .venv/bin/python -m pytest -q
  ```
  **测试必须实际运行并全部通过**；失败就修复代码（不是修改断言去迁就错误结果）。

## 6. README（中文，面向使用者）
必须包含：
1. 一句话简介 + 功能列表
2. 环境要求（语言版本）
3. 安装步骤（可直接复制的命令）
4. 使用示例（命令 + 预期输出片段）
5. 配置项说明（参数 / 环境变量）
6. 运行测试的方法
7. 项目结构简述

## 7. 最终验证（交付前逐项打勾）
- [ ] 在干净环境中按 README 的安装命令执行成功
- [ ] README 中的每个示例命令都实际运行过且输出与描述一致
- [ ] `pytest -q` 全部通过（记录通过数量）
- [ ] Web 服务：用 `run_shell(background=true)` 启动，`curl` 访问关键接口验证，再用 `process` 工具停止
- [ ] 无硬编码密钥、无调试打印残留、无 TODO 占位
- [ ] `.gitignore` 覆盖虚拟环境、缓存与本地密钥文件

## 8. 汇报
- 项目位置与目录结构
- 如何安装、运行、测试（命令）
- 已实现功能 / 未实现或简化的部分（如实说明）
- 关键设计决策与假设
- 测试结果（如 `12 passed`）与已验证的运行示例
