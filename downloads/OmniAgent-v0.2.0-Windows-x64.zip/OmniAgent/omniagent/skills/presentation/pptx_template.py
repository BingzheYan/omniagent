"""
python-pptx 精细排版模板（16:9）——当 create_presentation 的默认版式不够用时使用
================================================================================
用法（OmniAgent python 工具中）：

    exec(open("omniagent/skills/presentation/pptx_template.py", encoding="utf-8").read())
    deck = Deck(theme="navy")                       # 主题：navy / teal / red / gray
    deck.cover("2025年全省财政收支分析", "财政厅预算处 | 2025年12月")
    deck.agenda(["收支总体情况", "结构变化", "风险与建议"])
    deck.section("01", "收支总体情况")
    deck.kpi("一般公共预算收入同比增长5.2%，好于年初预期",
             [("4,312亿元", "一般公共预算收入", "+5.2%"), ("7,980亿元", "一般公共预算支出", "+3.1%"),
              ("54.0%", "财政自给率", "+1.1个百分点")], notes="先讲总量，再讲结构")
    deck.chart("税收收入占比连续三年回升，收入质量改善", "outputs/figures/tax_share.png",
               takeaways=["税收占比 76.3%，较上年提高 1.8 个百分点", "增值税、企业所得税贡献最大"],
               source="资料来源：××省财政厅", notes="……")
    deck.bullets("三项建议", ["压减一般性支出", "  非急需非刚性支出压减 10% 以上", "盘活存量资金"])
    deck.closing("谢谢！欢迎批评指正")
    deck.save("outputs/财政收支分析.pptx")

所有页面均为空白版式 + 自绘形状，字体统一为“微软雅黑”（可传 font= 修改），
标题栏为纯色色块，页脚带页码。图片按比例缩放到给定区域内，不会变形。
"""
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Emu, Inches, Pt

THEMES = {
    "navy": {"main": "1F3864", "accent": "C00000", "light": "E9EEF6", "text": "262626", "muted": "7F7F7F"},
    "teal": {"main": "0F5257", "accent": "E07A1F", "light": "E6F0F0", "text": "262626", "muted": "7F7F7F"},
    "red":  {"main": "A50021", "accent": "D4A017", "light": "F7EAEA", "text": "262626", "muted": "7F7F7F"},
    "gray": {"main": "404040", "accent": "2E75B6", "light": "F2F2F2", "text": "262626", "muted": "7F7F7F"},
}
W, H = Inches(13.333), Inches(7.5)


def rgb(hex_):
    return RGBColor.from_string(hex_)


class Deck:
    def __init__(self, theme="navy", font="微软雅黑"):
        self.c = THEMES[theme]
        self.font = font
        self.prs = Presentation()
        self.prs.slide_width, self.prs.slide_height = W, H
        self.blank = self.prs.slide_layouts[6]
        self.n = 0

    # ---------- 基础绘制 ----------
    def _text(self, slide, x, y, w, h, text, size=18, bold=False, color=None, align=PP_ALIGN.LEFT,
              anchor=MSO_ANCHOR.TOP, wrap=True):
        tb = slide.shapes.add_textbox(x, y, w, h)
        tf = tb.text_frame
        tf.word_wrap = wrap
        tf.vertical_anchor = anchor
        tf.margin_left = tf.margin_right = Inches(0.05)
        lines = text if isinstance(text, list) else [text]
        for i, line in enumerate(lines):
            p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
            p.alignment = align
            r = p.add_run()
            r.text = line
            f = r.font
            f.size, f.bold, f.name = Pt(size), bold, self.font
            f.color.rgb = rgb(color or self.c["text"])
            self._ea(r)
        return tb

    def _ea(self, run):
        """设置东亚字体，避免中文回退成宋体。"""
        from pptx.oxml.ns import qn
        rpr = run._r.get_or_add_rPr()
        ea = rpr.find(qn("a:ea"))
        if ea is None:
            ea = rpr.makeelement(qn("a:ea"), {})
            rpr.append(ea)
        ea.set("typeface", self.font)

    def _rect(self, slide, x, y, w, h, fill, shape=MSO_SHAPE.RECTANGLE):
        s = slide.shapes.add_shape(shape, x, y, w, h)
        s.fill.solid(); s.fill.fore_color.rgb = rgb(fill)
        s.line.fill.background()
        s.shadow.inherit = False
        return s

    def _new(self, title=None, notes=None):
        s = self.prs.slides.add_slide(self.blank)
        self.n += 1
        if title:
            self._rect(s, 0, 0, W, Inches(1.0), self.c["main"])                      # 标题栏
            self._rect(s, 0, Inches(1.0), W, Inches(0.06), self.c["accent"])         # 强调细线
            self._text(s, Inches(0.5), Inches(0.12), Inches(12.3), Inches(0.8), title, size=26, bold=True,
                       color="FFFFFF", anchor=MSO_ANCHOR.MIDDLE)
            self._text(s, Inches(12.3), Inches(7.05), Inches(0.8), Inches(0.35), str(self.n), size=11,
                       color=self.c["muted"], align=PP_ALIGN.RIGHT)                   # 页码
        if notes:
            s.notes_slide.notes_text_frame.text = notes
        return s

    def _picture_fit(self, slide, path, x, y, w, h):
        """等比缩放图片放入 (x,y,w,h) 区域并居中。"""
        pic = slide.shapes.add_picture(path, x, y)
        r = min(w / pic.width, h / pic.height)
        pic.width, pic.height = int(pic.width * r), int(pic.height * r)
        pic.left = int(x + (w - pic.width) / 2)
        pic.top = int(y + (h - pic.height) / 2)
        return pic

    # ---------- 页面类型 ----------
    def cover(self, title, subtitle="", notes=None):
        s = self._new(notes=notes)
        self._rect(s, 0, 0, W, H, self.c["main"])
        self._rect(s, Inches(0.8), Inches(3.55), Inches(1.2), Inches(0.08), self.c["accent"])
        self._text(s, Inches(0.8), Inches(1.9), Inches(11.5), Inches(1.6), title, size=40, bold=True,
                   color="FFFFFF", anchor=MSO_ANCHOR.BOTTOM)
        if subtitle:
            self._text(s, Inches(0.8), Inches(3.8), Inches(11.5), Inches(0.8), subtitle, size=20, color="D9D9D9")
        return s

    def agenda(self, items, title="目录", notes=None):
        s = self._new(title, notes)
        for i, it in enumerate(items):
            y = Inches(1.6 + i * 1.0)
            box = self._rect(s, Inches(1.2), y, Inches(0.8), Inches(0.7), self.c["main"])
            self._text(s, Inches(1.2), y, Inches(0.8), Inches(0.7), f"{i + 1:02d}", size=22, bold=True,
                       color="FFFFFF", align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
            self._text(s, Inches(2.3), y, Inches(9), Inches(0.7), it, size=24, anchor=MSO_ANCHOR.MIDDLE)
        return s

    def section(self, num, title, notes=None):
        s = self._new(notes=notes)
        self._rect(s, 0, 0, Inches(4.5), H, self.c["main"])
        self._text(s, Inches(0.6), Inches(2.6), Inches(3.5), Inches(2), num, size=88, bold=True, color="FFFFFF")
        self._text(s, Inches(5.2), Inches(3.0), Inches(7.5), Inches(1.4), title, size=36, bold=True,
                   anchor=MSO_ANCHOR.MIDDLE)
        return s

    def kpi(self, title, cards, takeaway=None, notes=None):
        """cards: [(大数字, 指标名, 变化说明), ...] 建议 2–4 张。"""
        s = self._new(title, notes)
        n = len(cards)
        gap, left = Inches(0.4), Inches(0.6)
        cw = int((W - 2 * left - gap * (n - 1)) / n)
        for i, (big, label, delta) in enumerate(cards):
            x = int(left + i * (cw + gap))
            self._rect(s, x, Inches(1.8), cw, Inches(3.4), self.c["light"], MSO_SHAPE.ROUNDED_RECTANGLE)
            self._rect(s, x, Inches(1.8), cw, Inches(0.12), self.c["main"])
            self._text(s, x, Inches(2.2), cw, Inches(1.3), big, size=44, bold=True, color=self.c["main"],
                       align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
            self._text(s, x, Inches(3.6), cw, Inches(0.6), label, size=18, align=PP_ALIGN.CENTER)
            if delta:
                col = self.c["accent"] if delta.strip().startswith(("-", "－", "↓", "下降")) else "2E7D32"
                self._text(s, x, Inches(4.25), cw, Inches(0.6), delta, size=18, bold=True, color=col,
                           align=PP_ALIGN.CENTER)
        if takeaway:
            self._text(s, left, Inches(5.7), W - 2 * left, Inches(1.0), takeaway, size=18, color=self.c["muted"])
        return s

    def chart(self, title, image, takeaways=None, source=None, notes=None):
        """左图右文（有 takeaways 时）或整页大图。"""
        s = self._new(title, notes)
        if takeaways:
            self._picture_fit(s, image, Inches(0.5), Inches(1.35), Inches(8.3), Inches(5.4))
            self._rect(s, Inches(9.1), Inches(1.5), Inches(3.8), Inches(5.0), self.c["light"])
            self._text(s, Inches(9.3), Inches(1.65), Inches(3.4), Inches(0.5), "要点", size=18, bold=True,
                       color=self.c["main"])
            self._text(s, Inches(9.3), Inches(2.2), Inches(3.4), Inches(4.2), [f"■ {t}" for t in takeaways],
                       size=16)
        else:
            self._picture_fit(s, image, Inches(0.6), Inches(1.35), Inches(12.1), Inches(5.5))
        if source:
            self._text(s, Inches(0.5), Inches(6.95), Inches(10), Inches(0.4), source, size=11, color=self.c["muted"])
        return s

    def bullets(self, title, items, notes=None):
        """items 中以两个空格开头的为二级要点。"""
        s = self._new(title, notes)
        tb = s.shapes.add_textbox(Inches(0.8), Inches(1.5), Inches(11.7), Inches(5.3))
        tf = tb.text_frame; tf.word_wrap = True
        for i, it in enumerate(items):
            lvl = 1 if it.startswith("  ") else 0
            p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
            r = p.add_run(); r.text = ("– " if lvl else "■ ") + it.strip()
            r.font.size = Pt(18 if lvl else 22); r.font.name = self.font
            r.font.bold = not lvl
            r.font.color.rgb = rgb(self.c["muted"] if lvl else self.c["text"])
            self._ea(r)
            p.level = lvl
            p.space_after = Pt(10 if lvl else 6)
        return s

    def closing(self, text="谢谢！", sub="", notes=None):
        s = self._new(notes=notes)
        self._rect(s, 0, 0, W, H, self.c["main"])
        self._text(s, 0, Inches(2.8), W, Inches(1.2), text, size=40, bold=True, color="FFFFFF",
                   align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
        if sub:
            self._text(s, 0, Inches(4.0), W, Inches(0.8), sub, size=18, color="D9D9D9", align=PP_ALIGN.CENTER)
        return s

    def save(self, path):
        import os
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        self.prs.save(path)
        return path


def audit_pptx(path, max_chars=150):
    """自检：逐页统计字数、图片数、是否有备注，标出超量页面。"""
    prs = Presentation(path)
    rows = []
    for i, sl in enumerate(prs.slides, 1):
        texts = [sh.text_frame.text.strip() for sh in sl.shapes if sh.has_text_frame and sh.text_frame.text.strip()]
        chars = sum(len(t.replace("\n", "")) for t in texts)
        pics = sum(1 for sh in sl.shapes if sh.shape_type == 13)
        notes = sl.has_notes_slide and bool(sl.notes_slide.notes_text_frame.text.strip())
        title = next((t for t in texts if not t.isdigit()), "")
        flag = "⚠ 字数过多" if chars > max_chars else ""
        rows.append((i, title[:30], chars, pics, notes, flag))
    for r in rows:
        print(f"第{r[0]:>2}页 | 字数 {r[2]:>4} | 图片 {r[3]} | 备注 {'有' if r[4] else '无'} | {r[1]} {r[5]}")
    return rows


if __name__ == "__main__":
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot([2021, 2022, 2023, 2024], [72.1, 73.0, 74.5, 76.3], marker="o")
    fig.savefig("/tmp/omni_skill_test/chart.png", dpi=200, bbox_inches="tight")
    d = Deck()
    d.cover("2025年全省财政收支分析", "预算处 | 2025年12月")
    d.agenda(["收支总体情况", "结构变化", "风险与建议"])
    d.section("01", "收支总体情况")
    d.kpi("收入同比增长5.2%，好于预期", [("4,312亿元", "一般公共预算收入", "+5.2%"),
                                       ("7,980亿元", "一般公共预算支出", "+3.1%"), ("54.0%", "财政自给率", "-0.4个百分点")],
          takeaway="注：示例数据", notes="先讲总量")
    d.chart("税收占比连续三年回升", "/tmp/omni_skill_test/chart.png", takeaways=["占比76.3%", "提高1.8个百分点"],
            source="资料来源：示例")
    d.bullets("三项建议", ["压减一般性支出", "  非急需非刚性支出压减10%以上", "盘活存量资金"])
    d.closing("谢谢！")
    p = d.save("/tmp/omni_skill_test/demo.pptx")
    audit_pptx(p)
