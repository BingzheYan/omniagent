# fiscal-paper 资源：paper.md 骨架模板 + 回归代码模板

本文件供 `fiscal-paper` Skill 引用。用法：`read_file omniagent/skills/fiscal-paper/templates.md`，按需复制对应部分。

- 第一部分：**paper.md 全文骨架**（含每节写作指引；尖括号 `<…>` 内为指引文字，成稿前必须全部替换删除，否则 `check_document` 会判为占位符）。
- 第二部分：**回归代码模板**（已用模拟省级面板测试通过：linearmodels 6.x / statsmodels 0.14）。

---

## 第一部分：paper.md 骨架

````markdown
# <论文题目：≤25字，含核心解释变量、被解释变量与研究对象，如“财政分权、地方政府行为与经济增长——基于中国省级面板数据的经验证据”>

摘要：<200–400字。第1句：研究问题与意义；第2句：数据与方法（“本文基于2010—2022年中国30个省份面板数据，采用双向固定效应模型/多期双重差分法……”）；第3–4句：主要发现，含关键数字（“……财政分权程度每提高1个标准差，经济增长率提高约x个百分点”）；第5句：机制与异质性；第6句：政策含义。若用模拟数据，首句即写明“本文使用模拟数据演示研究方法”。>

关键词：<词1>；<词2>；<词3>；<词4>

Abstract: <与中文摘要对应的英文，150–250 words，时态：研究内容用一般现在时，发现可用一般过去时或现在时。>

Keywords: <keyword1>; <keyword2>; <keyword3>; <keyword4>

## 一、引言

<第1段：现实背景与政策事实（引用权威统计数据，注明来源年份）。>

<第2段：提出研究问题——已有研究关注了……，但对……仍缺乏系统的经验证据。>

<第3段：本文做了什么——数据、方法、主要发现（简要）。>

<第4段：边际贡献三点式：第一，……；第二，……；第三，……。>

<第5段：结构安排：本文余下部分安排如下：第二部分……；第三部分……>

## 二、文献综述

### （一）<文献脉络一：如财政分权的经济增长效应>

<按观点归类评述，“作者（年份）”格式引用。>

### （二）<文献脉络二：如财政分权与地方政府支出行为>

### （三）文献评述

<共识—分歧—不足 → 引出本文切入点，与引言三点贡献对应。>

## 三、制度背景与理论分析

### （一）制度背景

<政策时间线、覆盖范围、关键条款；可放“表1 政策实施时间与试点地区”。>

### （二）理论分析与研究假设

<X→Y 的直接逻辑，提出：>

**假设H1**：<可检验的方向性命题。>

<机制逻辑 X→M→Y：>

**假设H2**：<机制假设。>

<异质性/调节逻辑：>

**假设H3**：<异质性假设。>

## 四、研究设计

### （一）模型设定

为检验假设H1，本文构建如下双向固定效应模型：

$$ \ln GDP_{it} = \alpha_0 + \beta_1 FD_{it} + \gamma X_{it} + \mu_i + \lambda_t + \varepsilon_{it} $$

其中，$i$ 和 $t$ 分别表示省份和年份；$\ln GDP_{it}$ 为……；$FD_{it}$ 为……；$X_{it}$ 为控制变量集合；$\mu_i$ 和 $\lambda_t$ 分别为省份固定效应和年份固定效应；$\varepsilon_{it}$ 为随机扰动项。若 $\beta_1$ 显著为正，则假设H1得到支持。

### （二）变量定义

1. 被解释变量。<定义、计算方法、文献依据。>

2. 核心解释变量。<多种度量：收入分权、支出分权、财政自主度；基准用哪一种、为什么。>

3. 控制变量。<每个控制变量一句话说明为何控制。>

各变量的具体定义见表1。

表1 主要变量定义

<粘贴 var_table() 输出的 Markdown 表>

注：<如需说明。>

### （三）数据来源与描述性统计

<数据来源（年鉴/数据库名称与年份范围）、样本筛选（剔除西藏等原因）、清洗步骤（平减基期、取对数、1%/99%缩尾、缺失值处理与最终样本量）。>

主要变量的描述性统计见表2。

表2 描述性统计

<粘贴 describe_table() 输出>

注：所有连续变量均已在1%和99%分位缩尾处理。<模拟数据时加：本表基于模拟数据，仅用于方法演示。>

<解读：核心变量均值、标准差、极差体现的地区差异；不逐个复述。>

## 五、实证结果分析

### （一）基准回归结果

表3报告了基准回归结果。<逐列说明设定：列（1）仅加入核心解释变量……列（4）同时控制省份与年份固定效应。>

表3 基准回归结果

<粘贴 regtable() 输出>

注：<粘贴 regtable 返回的 note_line，如：括号内为省份层面聚类稳健标准误；*、**、***分别表示在10%、5%、1%的水平上显著。>

<解读：显著性+方向+大小+经济含义；与已有文献对比。假设H1得到验证。>

### （二）内生性处理

<潜在内生性来源：反向因果、遗漏变量、测量误差。对策：工具变量（逐条论证相关性与外生性）、滞后一期、准自然实验。>

表4 内生性检验：工具变量估计

<表：第一阶段 + 第二阶段，报告第一阶段F值>

注：<……>

### （三）稳健性检验

<逐项说明动机：1.替换核心解释变量；2.替换被解释变量；3.剔除直辖市；4.改变缩尾比例；5.调整样本期；6.改变聚类层级；7.安慰剂检验。>

表5 稳健性检验

<多列表>

注：<……>

如图2所示，<安慰剂检验估计系数分布……真实估计值位于分布右侧尾部……>

![图2 安慰剂检验：随机处理组估计系数分布](outputs/figures/fig2_placebo.png)

注：竖线为基准回归真实估计系数；随机抽样500次。

<解读。>

## 六、异质性与机制分析

### （一）异质性分析

<分组依据与理论预期。>

表6 异质性分析

<分组回归表 + 最后一行“组间系数差异检验 p 值”>

注：组间系数差异检验采用<交互项法/费舍尔组合检验（自助抽样1000次）>。

### （二）机制分析

<依据江艇（2022），聚焦 X 对机制变量 M 的影响，并结合理论与文献论证 M 对 Y 的作用。>

表7 机制检验

<表>

注：<……>

<解读，假设H2得到支持。>

## 七、结论与政策建议

### （一）研究结论

<3–4 条，每条带核心数字，与假设一一对应。>

### （二）政策建议

<与结论一一对应，3–4 条：主体（中央/省级/市县）+ 工具（转移支付公式、事权与支出责任清单、债务限额管理……）+ 方向。>

### （三）研究不足与展望

<1 段。>

## 参考文献

[1] <作者. 题名[J]. 刊名, 年份, 卷(期): 页码.>

[2] <……>
````

---

## 第二部分：回归代码模板

> 在 python 工具中**按块执行**，每块执行后检查输出再继续。变量名请替换为实际变量：`province`（个体）、`year`（时间）、`lngdp`（Y）、`fd`（X）、`open`/`urban`（控制）、`first_treat`（首次处理年份，从未处理 = 0）、`z`（工具变量）、`selfsuff`（门槛/分组变量）、`m`（机制变量）。

### A. 读入、清洗与保存

```python
import numpy as np, pandas as pd, os, warnings
warnings.filterwarnings("ignore")
os.makedirs("outputs/tables", exist_ok=True); os.makedirs("outputs/figures", exist_ok=True)

df = pd.read_csv("data/clean/panel.csv")          # 或 pd.read_excel(...)
print(df.shape, df["province"].nunique(), df["year"].min(), df["year"].max())
print("是否平衡面板：", df.groupby("province")["year"].count().nunique() == 1)
print(df.isna().mean().sort_values(ascending=False).head(10))   # 缺失比例

def winsorize(s, lower=0.01, upper=0.99):
    lo, hi = s.quantile([lower, upper])
    return s.clip(lo, hi)

# 平减（示例：deflator 以 2010=100）与对数化
# df["rgdp"] = df["gdp"] / df["deflator"] * 100
# df["lngdp"] = np.log(df["rgdp"])
for c in ["fd", "open", "urban"]:
    df[c] = winsorize(df[c])
df.to_csv("data/clean/panel_final.csv", index=False)
```

> **没有真实数据、用户同意用模拟数据时**，可用下面的生成器（结果必须标注“模拟数据”）：

```python
rng = np.random.default_rng(2024)
provs = [f"P{i:02d}" for i in range(30)]; years = list(range(2010, 2023))
df = pd.DataFrame([(p, y) for p in provs for y in years], columns=["province", "year"])
first = {p: rng.choice([2014, 2016, 2018, 0]) for p in provs}          # 交错处理时点，0=从未处理
df["first_treat"] = df["province"].map(first)
df["did"] = ((df["first_treat"] > 0) & (df["year"] >= df["first_treat"])).astype(int)
df["z"] = rng.normal(size=len(df))
df["fd"] = rng.normal(0.5, 0.1, len(df)) + 0.05 * df["z"]
df["open"] = rng.normal(0.3, 0.1, len(df)); df["urban"] = rng.normal(0.6, 0.1, len(df))
df["m"] = 0.5 * df["fd"] + rng.normal(0, .05, len(df))
df["selfsuff"] = rng.uniform(0.2, 0.9, len(df))
df["region"] = rng.choice(["东部", "中部", "西部"], len(df))
df["lngdp"] = (1 + 0.8 * df["fd"] + 0.1 * df["did"] + 0.2 * df["open"]
               + df.groupby("province").cumcount() * 0.02 + rng.normal(0, .1, len(df)))
```

### B. 变量表、描述统计、相关系数、VIF

```python
from omniagent.research import var_table, describe_table, corr_table, vif_table
labels = {"lngdp": "lnGDP", "fd": "FD", "open": "Open", "urban": "Urban"}
cols = list(labels)
t1 = var_table([("被解释变量", "经济增长", "lnGDP", "实际GDP的自然对数"),
                ("核心解释变量", "财政分权", "FD", "人均地方本级财政支出/人均中央本级财政支出"),
                ("控制变量", "对外开放", "Open", "进出口总额/GDP"),
                ("控制变量", "城镇化率", "Urban", "城镇常住人口/总人口")])
t2 = describe_table(df, cols, labels=labels, digits=3)
t_corr = corr_table(df, cols, labels=labels, stars=True)
t_vif = vif_table(df, ["fd", "open", "urban"], labels=labels)
for name, t in [("表1_变量定义", t1), ("表2_描述统计", t2), ("附表_相关系数", t_corr), ("附表_VIF", t_vif)]:
    open(f"outputs/tables/{name}.md", "w", encoding="utf-8").write(t)
print(t2)
```

### C. 基准回归（逐步加入控制变量与固定效应）

```python
from linearmodels.panel import PanelOLS
from omniagent.research import regtable
pdf = df.set_index(["province", "year"])
fit = lambda f: PanelOLS.from_formula(f, data=pdf, drop_absorbed=True).fit(cov_type="clustered", cluster_entity=True)
m1 = fit("lngdp ~ 1 + fd")
m2 = fit("lngdp ~ 1 + fd + open + urban")
m3 = fit("lngdp ~ 1 + fd + open + urban + EntityEffects")
m4 = fit("lngdp ~ 1 + fd + open + urban + EntityEffects + TimeEffects")
md, note = regtable([m1, m2, m3, m4], model_names=["(1)", "(2)", "(3)", "(4)"],
                    var_labels={"fd": "FD", "open": "Open", "urban": "Urban"}, keep=["fd", "open", "urban"],
                    add_rows={"控制变量": ["否", "是", "是", "是"], "省份固定效应": ["否", "否", "是", "是"],
                              "年份固定效应": ["否", "否", "否", "是"]},
                    se="括号内为省份层面聚类稳健标准误", digits=3)
open("outputs/tables/表3_基准回归.md", "w", encoding="utf-8").write(md + "\n\n" + note)
print(md); print(note)
# 经济含义：相对于样本均值/标准差的幅度
b = m4.params["fd"]; sd = df["fd"].std()
print(f"FD 每提高1个标准差({sd:.3f})，lnGDP 变化 {b*sd:.4f}，约 {100*b*sd:.2f}%")
```

statsmodels 等价写法（需要省份线性趋势、交互项时更灵活）：

```python
import statsmodels.formula.api as smf
groups = pd.factorize(df["province"])[0]
ols = smf.ols("lngdp ~ fd + open + urban + C(province) + C(year)", data=df).fit(
        cov_type="cluster", cov_kwds={"groups": groups})
# 省份特定时间趋势：+ C(province):year
print(ols.params["fd"], ols.bse["fd"])
```

### D. 工具变量 2SLS

```python
from linearmodels.iv import IV2SLS
iv = IV2SLS.from_formula("lngdp ~ 1 + open + urban + C(province) + C(year) + [fd ~ z]", data=df
        ).fit(cov_type="clustered", clusters=df["province"])
diag = iv.first_stage.diagnostics
print(diag[["partial.rsquared", "f.stat", "f.pval"]])       # f.stat：排除工具的聚类稳健 Wald 统计量（单工具≈KP F）
print(iv.first_stage.individual["fd"].params["z"])           # 第一阶段系数
print(iv.params["fd"], iv.std_errors["fd"])
print(iv.wu_hausman())                                      # 内生性检验
# 多个工具变量时：iv.wooldridge_overid；或用 IVGMM 得到 Hansen J：
# from linearmodels.iv import IVGMM; g = IVGMM.from_formula(...).fit(cov_type="clustered", clusters=...); g.j_stat
```

### E. 事件研究（平行趋势）与图

```python
from omniagent.research import academic_style, event_study_plot, savefig
d = df.copy()
d["rel"] = np.where(d["first_treat"] > 0, d["year"] - d["first_treat"], np.nan)
d["rel_b"] = d["rel"].clip(-5, 5)                              # 两端合并
periods = [k for k in range(-5, 6) if k != -1]                 # 基期 -1 省略
names = []
for k in periods:
    nm = f"pre{abs(k)}" if k < 0 else f"post{k}"
    d[nm] = (d["rel_b"] == k).astype(int); names.append(nm)
es = PanelOLS.from_formula("lngdp ~ " + " + ".join(names) + " + open + urban + EntityEffects + TimeEffects",
                           data=d.set_index(["province", "year"])).fit(cov_type="clustered", cluster_entity=True)
coefs = [es.params[n] for n in names]; ses = [es.std_errors[n] for n in names]
i0 = periods.index(0)                                           # 在 -1 位置插入基期 0
periods_all = periods[:i0] + [-1] + periods[i0:]
coefs_all = coefs[:i0] + [0.0] + coefs[i0:]; ses_all = ses[:i0] + [0.0] + ses[i0:]
pre = [n for n in names if n.startswith("pre")]
print("政策前系数联合为0的 Wald 检验 p 值：", es.wald_test(formula=" = ".join(pre) + " = 0").pval)
academic_style()
fig = event_study_plot(coefs_all, ses_all, periods_all, ref_period=-1)
savefig(fig, "outputs/figures/fig3_event_study.png")
```

### F. 交错 DID 稳健估计：手写 Callaway–Sant'Anna ATT(g,t)

```python
def att_gt(data, y, unit, time, gvar, control="never", base_period="universal"):
    """组别-时期平均处理效应（无协变量版本）。control: "never"=从未处理组 / "notyet"=尚未处理组。
    base_period="universal"：所有期都与 g-1 比（e=-1 恒为 0，与 TWFE 事件研究图可比）；
    "varying"：处理前用相邻期“短差分”（CS 原文默认，e=-1 也有估计值）。"""
    out = []
    wide = data.pivot(index=unit, columns=time, values=y)
    g_of = data.groupby(unit)[gvar].first()
    tlist = sorted(data[time].unique())
    for g in sorted(g_of[g_of > 0].unique()):
        treated = g_of.index[g_of == g]
        base = g - 1
        if base not in tlist:
            continue
        for t in tlist:
            ctrl = g_of.index[g_of == 0] if control == "never" else g_of.index[(g_of == 0) | (g_of > max(t, base))]
            ref = base if (t >= g or base_period == "universal") else t - 1
            if t == ref:
                out.append({"g": g, "t": t, "e": t - g, "att": 0.0, "n_g": len(treated)}); continue
            if ref not in tlist or len(ctrl) == 0:
                continue
            dy_t = (wide.loc[treated, t] - wide.loc[treated, ref]).mean()
            dy_c = (wide.loc[ctrl, t] - wide.loc[ctrl, ref]).mean()
            out.append({"g": g, "t": t, "e": t - g, "att": dy_t - dy_c, "n_g": len(treated)})
    return pd.DataFrame(out)

def cs_event(data, y="lngdp", unit="province", time="year", gvar="first_treat", B=199, seed=1, control="never",
             base_period="universal"):
    """按相对时间 e 聚合（组规模加权），整群自助法标准误；返回 (事件研究表, 处理后总体ATT)。"""
    agg_fn = lambda x: np.average(x["att"], weights=x["n_g"])
    est = att_gt(data, y, unit, time, gvar, control, base_period)
    agg = est.groupby("e").apply(agg_fn)
    units = data[unit].unique(); r = np.random.default_rng(seed); boots = []
    for _ in range(B):
        samp = r.choice(units, len(units), replace=True)
        bd = pd.concat([data[data[unit] == u].assign(**{unit: f"{u}_{i}"}) for i, u in enumerate(samp)])
        be = att_gt(bd, y, unit, time, gvar, control, base_period)
        if len(be):
            boots.append(be.groupby("e").apply(agg_fn))
    se = pd.concat(boots, axis=1).std(axis=1)
    post = est[est["e"] >= 0]
    return pd.DataFrame({"att": agg, "se": se}), np.average(post["att"], weights=post["n_g"])

ev, overall = cs_event(df, B=199)
print("CS 处理后总体 ATT：", round(overall, 4)); print(ev)
fig = event_study_plot(ev["att"].tolist(), ev["se"].tolist(), ev.index.tolist(), ref_period=-1)
savefig(fig, "outputs/figures/fig4_cs_event.png")
```

### G. 安慰剂检验（随机分配处理时点）

```python
import matplotlib.pyplot as plt
def placebo(df, n=500, seed=42):
    r = np.random.default_rng(seed); out = []
    g = df.groupby("province")["first_treat"].first()
    for _ in range(n):
        fake = dict(zip(g.index, r.permutation(g.values)))     # 打乱处理组与处理时点
        dd = df.assign(ft=df["province"].map(fake))
        dd["did_f"] = ((dd["ft"] > 0) & (dd["year"] >= dd["ft"])).astype(int)
        res = PanelOLS.from_formula("lngdp ~ did_f + open + urban + EntityEffects + TimeEffects",
                                    data=dd.set_index(["province", "year"])).fit(cov_type="clustered", cluster_entity=True)
        out.append((res.params["did_f"], res.pvalues["did_f"]))
    return pd.DataFrame(out, columns=["beta", "p"])
true_b = PanelOLS.from_formula("lngdp ~ did + open + urban + EntityEffects + TimeEffects", data=pdf
         ).fit(cov_type="clustered", cluster_entity=True).params["did"]
pl = placebo(df, n=500)
print("随机系数均值", pl["beta"].mean(), "；大于真实系数的比例", (pl["beta"] >= true_b).mean())
academic_style()
fig, ax = plt.subplots(figsize=(6.4, 4))
ax.hist(pl["beta"], bins=30, color="0.7", edgecolor="white")
ax.axvline(true_b, color="black", linestyle="--"); ax.set_xlabel("估计系数"); ax.set_ylabel("频数")
savefig(fig, "outputs/figures/fig2_placebo.png")
```

### H. 门槛回归（Hansen 1999，单门槛 + 自助法）

```python
def _within(x, g):
    return x - x.groupby(g).transform("mean")

def hansen_threshold(df, y, x, q, controls, unit="province", trim=0.15, grid=200):
    """返回 (门槛值, F统计量, 系数[x_low, x_high, controls...])。需平衡面板。"""
    qs = np.sort(df[q].unique()); lo, hi = np.quantile(qs, [trim, 1 - trim])
    cand = np.unique(np.quantile(qs[(qs >= lo) & (qs <= hi)], np.linspace(0, 1, grid)))
    yw = _within(df[y], df[unit])
    def ssr(gamma):
        X = pd.DataFrame({"x_low": df[x] * (df[q] <= gamma), "x_high": df[x] * (df[q] > gamma)})
        for c in controls: X[c] = df[c]
        Xw = X.apply(lambda s: _within(s, df[unit]))
        b, *_ = np.linalg.lstsq(Xw.values, yw.values, rcond=None)
        e = yw.values - Xw.values @ b
        return e @ e, b
    g_hat, s1 = min(((g, ssr(g)[0]) for g in cand), key=lambda t: t[1])
    Xw0 = df[[x] + controls].apply(lambda s: _within(s, df[unit]))
    b0, *_ = np.linalg.lstsq(Xw0.values, yw.values, rcond=None); e0 = yw.values - Xw0.values @ b0
    n, N = len(df), df[unit].nunique()
    F1 = (e0 @ e0 - s1) / (s1 / (n - N - len(controls) - 2))
    return g_hat, F1, ssr(g_hat)[1]

g_hat, F1, coef = hansen_threshold(df, "lngdp", "fd", "selfsuff", ["open", "urban"])
print("门槛值", g_hat, "F", F1, "低区制/高区制系数", coef[:2])
# 自助法 p 值（固定 X，残差按个体重抽，300 次；耗时较长可先 B=100 试跑）：
# 在 H0（无门槛）模型下得到拟合值与残差 e0，按个体整块重抽残差构造 y*，对 y* 重新计算 F*，
# p = mean(F* >= F1)。报告门槛估计值、F 值、自助法 p 值与 10%/5%/1% 临界值。
```

### I. 异质性 + 组间系数差异检验

```python
df["high"] = (df["selfsuff"] > df["selfsuff"].median()).astype(int)
sub = {k: PanelOLS.from_formula("lngdp ~ fd + open + urban + EntityEffects + TimeEffects",
        data=g.set_index(["province", "year"])).fit(cov_type="clustered", cluster_entity=True)
       for k, g in df.groupby("high")}
# 交互项法检验组间差异（允许控制变量系数也随组变化时，可把控制变量也与 high 交互）
df["fd_high"] = df["fd"] * df["high"]
gi = PanelOLS.from_formula("lngdp ~ fd + fd_high + high + open + urban + EntityEffects + TimeEffects",
                           data=df.set_index(["province", "year"]), drop_absorbed=True
                           ).fit(cov_type="clustered", cluster_entity=True)
print("组间差异 =", gi.params["fd_high"], "p =", gi.pvalues["fd_high"])
md, note = regtable([sub[0], sub[1]], model_names=["低自给率", "高自给率"], keep=["fd"],
                    add_rows={"控制变量": ["是", "是"], "省份固定效应": ["是", "是"], "年份固定效应": ["是", "是"],
                              "组间差异p值": ["", f"{gi.pvalues['fd_high']:.3f}"]})
```

### J. 机制：X → M（江艇，2022）

```python
mm = PanelOLS.from_formula("m ~ fd + open + urban + EntityEffects + TimeEffects", data=pdf
     ).fit(cov_type="clustered", cluster_entity=True)
print(mm.params["fd"], mm.pvalues["fd"])
# 正文：报告 X 对 M 的因果效应，并用理论与文献论证 M 对 Y 的影响；不以“加入 M 后 X 系数变小”作为主要证据。
```

### K. PSM（基期 Logit + 1:1 近邻卡尺匹配）+ 平衡性

```python
import statsmodels.api as sm
covs = ["open", "urban", "fd"]
base = df[df["year"] == 2013].copy(); base["treat"] = (base["first_treat"] > 0).astype(int)
lg = sm.Logit(base["treat"], sm.add_constant(base[covs])).fit(disp=0)
base["ps"] = lg.predict(sm.add_constant(base[covs]))
caliper = 0.25 * base["ps"].std()
T, C = base[base.treat == 1], base[base.treat == 0].copy()
pairs = []
for i, row in T.iterrows():                       # 有放回近邻匹配
    dist = (C["ps"] - row["ps"]).abs(); j = dist.idxmin()
    if dist[j] <= caliper: pairs.append((row["province"], C.loc[j, "province"]))
keep = {p for pair in pairs for p in pair}
def std_bias(a, b): return 100 * (a.mean() - b.mean()) / np.sqrt((a.var() + b.var()) / 2)
mb = base[base["province"].isin(keep)]
for c in covs:
    print(c, "匹配前偏差%", round(std_bias(T[c], C[c]), 1),
          "匹配后偏差%", round(std_bias(mb[mb.treat == 1][c], mb[mb.treat == 0][c]), 1))
psm_df = df[df["province"].isin(keep)]            # 在匹配样本上重跑 DID
```

### L. 合成控制（单一处理单元）+ 置换检验

```python
from scipy.optimize import minimize
def synth_weights(Y0_pre, y1_pre):
    J = Y0_pre.shape[1]
    r = minimize(lambda w: np.sum((y1_pre - Y0_pre @ w) ** 2), np.ones(J) / J, bounds=[(0, 1)] * J,
                 constraints=({"type": "eq", "fun": lambda w: w.sum() - 1},), method="SLSQP")
    return r.x
wide = df.pivot(index="year", columns="province", values="lngdp")
treated, T0 = "P05", 2016                          # 处理单元与政策年份（替换）
donors = [p for p in wide.columns if p != treated and df.loc[df.province == p, "first_treat"].iloc[0] == 0]
pre = wide.index < T0
w = synth_weights(wide.loc[pre, donors].values, wide.loc[pre, treated].values)
gap = wide[treated] - wide[donors].values @ w
rmspe = lambda g: np.sqrt((g[~pre] ** 2).mean()) / np.sqrt((g[pre] ** 2).mean())
ratio_true = rmspe(gap)
ratios = []
for p in donors:                                    # 置换：把每个对照单元当作“处理单元”
    others = [q for q in donors if q != p]
    wp = synth_weights(wide.loc[pre, others].values, wide.loc[pre, p].values)
    ratios.append(rmspe(wide[p] - wide[others].values @ wp))
print("权重：", dict(zip(donors, np.round(w, 3))), "置换 p 值：", np.mean(np.array(ratios) >= ratio_true))
```

### M. 结果落盘与核对

```python
# 每张表都写入 outputs/tables/；写正文前打印核对：
import glob
for f in sorted(glob.glob("outputs/tables/*.md")):
    print("=" * 20, f); print(open(f, encoding="utf-8").read()[:1500])
```
