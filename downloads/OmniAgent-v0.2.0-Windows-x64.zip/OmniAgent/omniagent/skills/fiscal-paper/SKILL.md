---
name: fiscal-paper
description: 撰写财政/税收领域的学术论文与实证研究（目标期刊《财政研究》《税务研究》《财贸经济》《经济研究》《管理世界》等）时使用：选题、文献综述、理论机制与研究假设、面板固定效应/DID/事件研究/IV/门槛/中介调节/PSM/合成控制等识别策略、变量与描述统计、回归表、稳健性与异质性、三线表与学术图、GB/T 7714 参考文献、create_document(style="academic") 排版与 check_document 自检。关键词：财政、税收、税务、财政分权、转移支付、地方政府债务、论文、实证、期刊、投稿、计量、回归、财政研究、税务研究。
---

# 财政科学研究论文写作 Skill

本 Skill 是一份**可直接执行的作业流程**：从和用户确认选题，到产出排版规范的 `.docx/.pdf` 论文，再到用 `check_document` 自检达标。长模板（paper.md 全文骨架、回归代码模板）放在**同目录下的 `templates.md`**，需要时用 `read_file` 读取 `omniagent/skills/fiscal-paper/templates.md`。

---

## ⛔ 学术诚信红线（优先级高于一切其他要求）

1. **绝不编造数据**。没有真实数据时，必须先 `ask_user` 说明，并给出三种选择：①用户提供数据文件；②Agent 从公开来源下载（`web_fetch`/`web_search` 可用时）；③使用**模拟数据**仅演示方法。
2. 选择模拟数据时，必须在**标题（加副标题或括注）、摘要首句、数据来源小节、每张表的表注**中明确标注：“本文使用模拟数据/示例数据，仅用于演示研究方法，结果不具有任何现实含义”。
3. **所有数字（系数、标准误、显著性、样本量、均值、R²）必须来自本次会话中实际运行的代码输出**。写正文前先把结果表保存到 `outputs/tables/*.md`，正文引用时逐一对照；严禁“凭印象”写数字或“为了显著”改数字。
4. **不 p-hacking**：不为凑显著反复更换控制变量/样本而不报告；做过的重要稳健性检验无论结果如何都如实报告。
5. **参考文献只列确信真实存在的文献**。只从下文“可靠文献池”或用户提供/可检索验证的文献中选；任何作者、年份、刊名、卷期、页码有不确定处，标注“［待核实］”，并在交付说明中提醒用户到中国知网/Google Scholar 核对。宁可少列，不可错列、虚构。
6. 因果表述要与识别强度匹配：仅有相关性证据时用“相关”“关联”，不要写“导致”“证明了”。

---

## 0. 启动：确认需求并建立计划

先用 `ask_user` 一次性确认（用户已说明的跳过）：

| 事项 | 需确认内容 | 默认值 |
|---|---|---|
| 题目/研究问题 | 核心解释变量 X、被解释变量 Y、研究对象 | 由 Agent 提 2–3 个候选让用户选 |
| 数据 | 是否已有数据文件？层级（省/市/县/企业）、年份 | 无则按红线处理 |
| 目标期刊 | 《财政研究》《税务研究》《财贸经济》《经济研究》《管理世界》… | 《财政研究》 |
| 字数 | 正文字数 | 1.5 万字左右 |
| 方法偏好 | 是否指定 DID/IV/门槛等 | 按数据结构自动选择 |
| 输出 | docx / pdf / 二者 | docx + pdf |
| 作者信息 | 作者、单位（可留空） | 留空 |

期刊风格差异（写作时据此调整）：
- **《税务研究》**：政策性、实务性强，篇幅较短（约 0.8–1.2 万字），实证可简化，重“问题—原因—对策”，对策需落到税制要素（税基、税率、征管）。
- **《财政研究》**：理论与实证并重，1–1.5 万字，重视制度背景与政策含义。
- **《财贸经济》**：规范实证论文结构，1.5–2 万字，重视识别与稳健性。
- **《经济研究》《管理世界》**：识别策略要求最高，2 万字左右，需充分的内生性处理、机制与异质性，边际贡献要清晰、文献对话要到位。

然后用 `todo_write` 建立计划（示例）：

```
1. 确认选题与数据 → 2. 数据获取与清洗 → 3. 变量构造与描述统计 → 4. 基准回归
5. 内生性与稳健性 → 6. 异质性与机制 → 7. 绘图（趋势/事件研究/系数图）
8. 写作：引言+文献 → 9. 写作：制度背景/理论假设 → 10. 写作：研究设计+实证
11. 写作：结论建议+摘要 → 12. 合并 paper.md → create_document → check_document 迭代 → 交付
```

工作目录约定：`data/raw/`（原始数据，只读）、`data/clean/`（清洗后）、`outputs/tables/`（每张表一个 .md）、`outputs/figures/`（图）、`paper/sections/`（分章节草稿）、`paper/paper.md`（合并稿）、`outputs/paper.docx|pdf`。

---

## 1. 选题：政策背景 + 边际贡献

好的财政选题 = **真实的政策变化/制度差异** + **可度量的变量** + **可识别的因果关系** + **有政策含义**。

常见可识别的政策冲击（可做 DID/事件研究）：营改增（2012 年试点、2016 年全面推开）、“省直管县”财政改革、增值税留抵退税（2019 年起试行、2022 年大规模实施）、所得税分享改革（2002 年）、新《预算法》实施（2015 年）与地方政府债务置换、专项债扩容、“放管服”与减税降费、国地税合并（2018 年）、金税三期/四期、环境保护税开征（2018 年）、个人所得税综合与分类相结合改革（2019 年）等。具体时间与范围以官方文件为准，写入论文前要核实。

**引言中的边际贡献采用三点式**（每点 2–4 句，且与文献综述对应）：
1. **研究视角**：首次/较早从……视角考察……，拓展了……文献；
2. **识别策略/数据**：利用……准自然实验/更细粒度的……数据，缓解了已有研究中的……内生性问题；
3. **机制与政策含义**：揭示了……渠道，并发现……异质性，为……改革提供了经验证据。

避免：“填补空白”“具有重大意义”等空话；贡献必须是具体可检验的。

---

## 2. 文献综述：评述而非罗列

结构：按**主题脉络**（而非按作者）组织 2–3 条线，最后一段“文献评述”。

- 第一条线：X 的经济效应（如财政分权与增长：第一代理论 Oates、Tiebout；第二代/市场维护型联邦主义 Qian & Weingast；中国式分权与晋升激励 周黎安）；
- 第二条线：Y 的影响因素/与本文最相关的直接证据；
- 第三条线：方法或机制相关文献（如 TWFE 偏误、中介效应检验的新共识）。
- **文献评述**：已有研究的①共识；②分歧（结论不一致的原因：样本、指标、识别）；③不足 → 自然引出本文的三点贡献。

写法规范：每段以观点句开头，“××（2007）发现……；与之不同，××（2010）认为……，原因在于……”。正文引用格式统一用“作者（年份）”或上标序号 [n]，**全文只能用一种**，与参考文献表一一对应（正文引用的必须在表中，表中的必须被引用）。

---

## 3. 制度背景、理论机制与研究假设

- **制度背景**（1–2 页）：政策出台背景、时间线、覆盖范围、核心条款，最好配一张“政策时间线表”或“试点地区分布表”。只写与识别有关的事实（例如为何试点选择接近随机）。
- **理论分析**：从激励/约束出发写清 X → M → Y 的逻辑链；可用简单数理模型（目标函数 + 一阶条件 + 比较静态），但财政期刊更多接受严谨的文字推理。
- **研究假设**：每个假设单独成段、加粗编号，表述为可检验的方向性命题：
  - **假设 H1**：财政分权程度提高显著促进地区经济增长。
  - **假设 H2a / H2b**：竞争性假设可并列给出（“促进”/“抑制”）。
  - **假设 H3**：财政分权通过提高基础设施投资促进增长（机制）。
  - **假设 H4**：上述效应在财政自给率较高的地区更强（异质性/调节）。

---

## 4. 识别策略（模型写法 + Python 要点）

> 完整可运行代码在 `templates.md` 的“回归代码模板”一节（已用模拟面板测试通过）。下表给出公式写法与核心调用。所有公式在 Markdown 中用 `$$ ... $$` 单独成行，自动编号；紧跟“其中，……”段解释每个符号。

### 4.1 双向固定效应面板（基准模型）

$$ \ln GDP_{it} = \alpha_0 + \beta_1 FD_{it} + \gamma X_{it} + \mu_i + \lambda_t + \varepsilon_{it} $$

其中，$i$ 表示省份，$t$ 表示年份；$FD_{it}$ 为财政分权；$X_{it}$ 为控制变量向量；$\mu_i$、$\lambda_t$ 分别为省份和年份固定效应；$\varepsilon_{it}$ 为随机扰动项。重点关注 $\beta_1$。

```python
from linearmodels.panel import PanelOLS
pdf = df.set_index(["province", "year"])          # 必须是 (个体, 时间) 双索引
m = PanelOLS.from_formula("lngdp ~ 1 + fd + open + urban + EntityEffects + TimeEffects",
                          data=pdf, drop_absorbed=True).fit(cov_type="clustered", cluster_entity=True)
# 等价写法：PanelOLS(y, X, entity_effects=True, time_effects=True).fit(cov_type="clustered", cluster_entity=True)
# statsmodels 虚拟变量写法（便于加交互项/省份时间趋势）：
import statsmodels.formula.api as smf
m2 = smf.ols("lngdp ~ fd + open + urban + C(province) + C(year)", data=df).fit(
        cov_type="cluster", cov_kwds={"groups": pd.factorize(df["province"])[0]})
```

要点：标准误默认**聚类到个体（省/市）层面**；样本个体数 < 30 时提示聚类标准误可能偏小，可补充 wild cluster bootstrap 或报告稳健标准误作为对照。

### 4.2 多期/交错 DID 与事件研究

$$ Y_{it} = \alpha + \beta\, DID_{it} + \gamma X_{it} + \mu_i + \lambda_t + \varepsilon_{it} $$

$DID_{it}=Treat_i \times Post_{it}$，交错 DID 中 $DID_{it}=1$ 当且仅当地区 $i$ 在 $t$ 年已实施政策。

**TWFE 偏误必须讨论**：处理时点交错且处理效应随时间/组别异质时，TWFE 估计量是各 2×2 DID 的加权平均，其中“已处理组作对照”的比较可能获得负权重（Goodman-Bacon, 2021; de Chaisemartin & D'Haultfœuille, 2020）。应对：
- 报告 Goodman-Bacon 分解或至少说明处理时点分布；
- 用**稳健估计量**作为稳健性检验：Callaway & Sant'Anna (2021) 的 ATT(g,t)（以从未处理/尚未处理组为对照）、Sun & Abraham (2021) 交互加权事件研究、de Chaisemartin & D'Haultfœuille (2020) 的 $DID_M$、Borusyak 等的插补估计量；
- Python 中无现成成熟包时，使用 `templates.md` 里手写的 `att_gt()/cs_event()`（never-treated 对照、整群自助法标准误），并在文中说明“参照 Callaway & Sant'Anna（2021）的思路计算组别—时期平均处理效应”。

**事件研究（平行趋势检验）**：

$$ Y_{it} = \alpha + \sum_{k=-K,\,k\neq -1}^{L} \beta_k D_{it}^{k} + \gamma X_{it} + \mu_i + \lambda_t + \varepsilon_{it} $$

其中 $D_{it}^{k}$ 表示地区 $i$ 在 $t$ 年处于政策实施第 $k$ 年；以政策前一期（$k=-1$）为基期；两端期数合并（binning，如 $k\le -5$、$k\ge 5$）（Beck et al., 2010 的做法）。要求：政策前 $\beta_k$ 不显著（且报告联合检验 p 值），政策后显著。

```python
from omniagent.research import academic_style, event_study_plot, savefig
academic_style()
fig = event_study_plot(coefs_all, ses_all, periods_all, ref_period=-1)   # 95% CI，基期标 0
savefig(fig, "outputs/figures/fig2_event_study.png")
```

### 4.3 工具变量（IV-2SLS）

$$ FD_{it} = \pi_0 + \pi_1 Z_{it} + \gamma X_{it} + \mu_i + \lambda_t + v_{it} $$
$$ Y_{it} = \alpha + \beta \widehat{FD}_{it} + \gamma X_{it} + \mu_i + \lambda_t + \varepsilon_{it} $$

工具变量选取逻辑（必须在正文逐条论证）：①**相关性**：Z 与内生变量 X 强相关（第一阶段系数显著，F 值 > 10，或对照 Stock-Yogo 临界值）；②**外生性/排他性**：Z 只通过 X 影响 Y。财政研究常用思路：历史/地理变量（如历史上的行政区划、地形起伏度）与时间变量交互构造时变 IV、同一省份内其他地区均值（“同群”IV，需讨论空间相关）、Bartik/份额移动工具变量、政策规则带来的外生变动。外生性无法检验，只能论证 + 排他性约束的间接检验（如在 X 无变化样本中 Z 对 Y 无影响）。

```python
from linearmodels.iv import IV2SLS
iv = IV2SLS.from_formula("lngdp ~ 1 + open + urban + C(province) + C(year) + [fd ~ z]", data=df
        ).fit(cov_type="clustered", clusters=df["province"])
print(iv.first_stage.diagnostics)        # 关注 partial.rsquared 与 f.stat（单工具聚类下即稳健Wald F）
```

报告：第一阶段系数与 F 值、第二阶段系数；工具变量多于内生变量时报告过度识别检验（`iv.wooldridge_overid` 稳健版，或改用 `IVGMM` 估计并报告 `res.j_stat` 即 Hansen J）；内生性检验 `iv.wu_hausman()` / `iv.durbin()`；弱工具稳健推断可补充 `iv.anderson_rubin`。表注写明“第一阶段 F 统计量为聚类稳健版本”。

### 4.4 门槛回归（Hansen, 1999）

$$ Y_{it} = \mu_i + \beta_1 X_{it}\, I(q_{it}\le\gamma) + \beta_2 X_{it}\, I(q_{it}>\gamma) + \theta Z_{it} + \varepsilon_{it} $$

$q_{it}$ 为门槛变量（如财政自给率、债务率），$\gamma$ 为待估门槛值。步骤：组内变换 → 格点搜索使残差平方和最小的 $\gamma$（两端各截掉 15%）→ 自助法（300–500 次）检验门槛效应显著性 → 报告门槛估计值与 95% 置信区间 → 双门槛依次搜索。代码见 `templates.md` 的 `hansen_threshold()`；自助法 p 值需自行循环（模板给出写法）。

### 4.5 机制分析：中介效应与调节效应

**按江艇（2022）的建议**：传统“三步法/逐步法”（Baron & Kenny, 1986）在因果推断框架下存在严重问题——第三步把中介变量 M 与 X 同时放入方程，M 本身是 X 的结果（“坏控制”），且 M 的内生性无法处理，系数变化不能解释为中介效应。推荐做法：

1. 只估计 **X → M** 的因果效应（与基准模型同一识别策略）：
$$ M_{it} = \alpha + \delta X_{it} + \gamma Z_{it} + \mu_i + \lambda_t + \varepsilon_{it} $$
2. **M → Y 的关系主要靠理论论证与已有文献支撑**（选择与 Y 关系直接、被广泛证实的 M）；
3. 机制检验应多角度：不同 M 的度量、按“机制强弱”分组的异质性（若机制成立，M 作用空间大的组效应更强）。
4. 如果期刊/用户坚持报告逐步法或 Sobel/Bootstrap 检验，可作为补充放在附录，并在正文声明其局限。

**调节效应**：

$$ Y_{it} = \alpha + \beta_1 X_{it} + \beta_2 X_{it}\times W_{it} + \beta_3 W_{it} + \gamma Z_{it} + \mu_i + \lambda_t + \varepsilon_{it} $$

交互项前对 X 和 W **中心化**；解读 $\beta_2$ 的经济含义（W 每提高一个标准差，X 的边际效应变化多少）；W 应尽量是前定变量（如政策前基期值），避免 W 本身受 X 影响。

### 4.6 PSM-DID

步骤：①用政策前基期协变量做 Logit 估计倾向得分；②1:1（或 1:k）近邻匹配、卡尺 0.25 倍得分标准差（或核匹配）；③**平衡性检验**（匹配前后标准化偏差 < 10%，t 检验不显著），配一张平衡性表或标准化偏差图；④共同支撑域图；⑤在匹配样本上重跑 DID。说明 PSM 只能处理可观测变量的选择偏误。

### 4.7 合成控制法（单一/少数处理单元）

处理单元只有一个或几个（如某省试点）时：用捐赠池中未处理单元的非负、和为 1 的权重合成“反事实”，使政策前结果变量与预测变量拟合最佳（Abadie et al., 2010）。必须报告：权重表、政策前拟合（RMSPE）、处理组 vs 合成组路径图、**置换（安慰剂）检验**——对每个捐赠单元做同样的合成，比较政策后/政策前 RMSPE 比值，计算排序 p 值。代码见 `templates.md` 的 `synth_weights()`。

### 4.8 选择方法的决策规则

| 数据与问题 | 首选 | 补充 |
|---|---|---|
| 连续型政策变量（分权度、转移支付规模），省/市面板 | 双向 FE | IV、滞后一期、动态面板（慎用） |
| 一次性政策、处理组同时受冲击 | 标准 DID + 事件研究 | PSM-DID、安慰剂 |
| 分批试点（交错实施） | 交错 DID + 事件研究 | CS/SA 稳健估计量、Bacon 分解 |
| 单个省份/城市的政策 | 合成控制 | 置换检验、DID 对照 |
| 效应随某变量非线性变化 | 门槛回归 | 分组回归、交互项 |
| 问“通过什么渠道” | X→M 因果 + 理论 | 机制分组异质性 |

---

## 5. 数据来源与清洗

**常用数据来源**（论文中写全称与年份范围）：
- 国家统计局（国家数据 data.stats.gov.cn）、《中国统计年鉴》《中国城市统计年鉴》《中国县域统计年鉴》、各省统计年鉴；
- 财政部官网（预决算公开、财政收支统计）、《中国财政年鉴》《地方财政统计资料》《全国地市县财政统计资料》；
- 税收：《中国税务年鉴》、国家税务总局公开数据；
- 地方政府债务：中国债券信息网、中国地方政府债券信息公开平台、财政部预算司数据、Wind 城投债数据；
- 商业数据库：Wind、CSMAR（国泰安）、EPS、CNRDS（中国研究数据服务平台）、CEIC；企业层面：上市公司财报、中国工业企业数据库。

**清洗规范**（每一步在代码里注释、在论文“数据说明”中交代）：
1. 统一口径：行政区划调整（如重庆 1997 年设直辖市）、统计口径变化（如 2007 年政府收支分类改革）需说明处理方式；
2. 名义变量用 GDP 平减指数或 CPI 以基期（如 2010=100）平减；
3. 规模变量取自然对数（含 0 值用 $\ln(1+x)$）；比率变量保持百分比或小数，全文统一；
4. 连续变量在 1% 和 99% 分位**缩尾**（winsorize，不是删除），是否分年缩尾要说明；
5. 缺失值：少量缺失可用线性插值（说明比例），大量缺失的样本剔除并报告剔除后样本量；不得用均值随意填补核心变量；
6. 剔除西藏（数据缺失严重）、港澳台等，按研究需要说明。
7. 清洗完毕保存 `data/clean/panel.csv`，打印 `df.shape`、年份范围、个体数、是否平衡面板。

---

## 6. 实证部分的标准流水线

> 每一步的产出物都先保存为 `outputs/tables/表N_xxx.md` 或 `outputs/figures/figN_xxx.png`，正文从这些文件取数。

1. **变量定义表**：`var_table([("被解释变量","经济增长","lnGDP","实际GDP的自然对数"), ("核心解释变量","财政分权","FD","人均地方本级财政支出/人均全国财政支出"), ("控制变量",...)])`
2. **描述性统计**：`describe_table(df, cols, labels)`；文字中点出核心变量的均值、标准差与极值差异（体现地区差异），不必逐个变量复述。
3. **相关系数矩阵 / VIF**：`corr_table(df, cols, labels)`，`vif_table(df, cols)`；VIF < 10 即说明不存在严重多重共线性（常放附录或一句话带过）。
4. **基准回归**（表通常 4 列）：(1) 仅核心变量；(2) 加控制变量；(3) 加个体固定效应；(4) 加个体+时间固定效应（首选列）。`md, note = regtable([m1,m2,m3,m4], model_names=["(1)","(2)","(3)","(4)"], var_labels={...}, keep=[...], add_rows={"控制变量":["否","是","是","是"],"省份固定效应":["否","否","是","是"],"年份固定效应":["否","否","否","是"]}, se="括号内为省份层面聚类稳健标准误")`
5. **系数解释（必须讲经济含义）**：
   - 对数—对数：弹性，“FD 每提高 1%，实际 GDP 提高约 $\beta$%”；
   - 水平—对数：“X 提高 1 个单位，Y 提高 $100\beta$%”（近似）；
   - DID：“政策使 Y 平均提高 $\beta$ 个单位，相当于样本均值的 $\beta/\bar Y$ ×100%”；
   - 标准化：“X 每提高一个标准差，Y 变化 $\beta\sigma_X$，约为 Y 标准差的 ×%”。
6. **内生性处理**：IV-2SLS；核心解释变量滞后一期；DID/准自然实验；控制更高阶固定效应（省份×时间趋势）；Oster（2019）系数稳定性（可选）。
7. **稳健性检验**（每项一句话说明动机，结果可合并成一张多列表）：替换核心解释变量度量（收入分权/支出分权/财政自主度）；替换被解释变量；剔除直辖市；改变缩尾比例或不缩尾；改变样本期（剔除 2008–2009 金融危机、2020–2022 疫情年份）；改变聚类层级（省份×年份、地区）；**安慰剂检验**（随机分配处理组/处理时点 500–1000 次，画估计系数核密度图，真实系数位于分布外侧）；控制同期其他政策。
8. **异质性分析**：东中西部、财政自给率高/低（中位数分组）、债务压力高/低、是否资源型地区等。**分组回归后必须做组间系数差异检验**：交互项法（全样本加 X×Group）或费舍尔组合检验（自助法 1000 次）或 SUEST；不能只凭一组显著一组不显著就下结论。
9. **机制分析**：按 4.5 节，X → M 回归表 + 理论论证 + 机制分组异质性。
10. **进一步分析**（可选）：动态效应、空间溢出、成本—收益测算。

---

## 7. 章节—图表对照表与篇幅分配

| 章节 | 建议篇幅（1.5 万字稿） | 必备图表 | 可选图表 |
|---|---|---|---|
| 摘要/关键词/Abstract | 300 字 + 英文 | — | — |
| 一、引言 | 1500–2000 字（10–12%） | — | 图1 核心变量趋势图 |
| 二、文献综述 | 1500–2500 字（12–15%） | — | — |
| 三、制度背景与理论分析（含假设） | 2000–2500 字（15%） | — | 政策时间线表、理论机制框架图 |
| 四、研究设计（模型、变量、数据） | 1500–2000 字（12%） | 模型公式；**变量定义表**；**描述性统计表** | 相关系数表、处理组分布表 |
| 五、实证结果（基准+内生性+稳健性） | 3500–4500 字（25–30%） | **基准回归表**；**内生性（IV/DID）表**；**稳健性表**；事件研究图（DID 必备） | 安慰剂分布图、系数图 |
| 六、异质性与机制分析 | 2000–2500 字（15%） | **异质性表**（含组间差异 p 值）；**机制表** | 系数对比图 |
| 七、结论与政策建议 | 1000–1500 字（8%） | — | — |
| 参考文献 | 25–40 条 | — | — |

正文通常 6–10 张表、2–5 幅图；总字数按期刊调整（1.2–2 万字）。

---

## 8. 图表放置与格式规范（与 create_document academic 样式配合）

**放置顺序**：先文字引出（“如图1所示”“见表3”）→ 图/表紧随其后 → 再用一段文字解读。`check_document` 会检查“每个图N/表N在出现前已在正文中被提及”。

**编号**：图、表分别从 1 连续编号（图1、图2…；表1、表2…），不跳号、不重复；正文提及与题注编号一致。

**Markdown 写法（严格遵守，排版器据此识别）**：

图：
```markdown
如图1所示，2010—2022年各省财政自给率总体呈下降趋势，且地区差异明显。

![图1 2010—2022年各省财政自给率变化趋势](outputs/figures/fig1.png)

资料来源：根据历年《中国财政年鉴》数据计算。

从图1可以看出，……（解读）
```

表：
```markdown
主要变量的描述性统计结果见表2。

表2 描述性统计

| 变量 | 观测值 | 均值 | 标准差 | 最小值 | 中位数 | 最大值 |
|---|---|---|---|---|---|---|
| lnGDP | 390 | 9.812 | 0.874 | 7.651 | 9.790 | 11.902 |

注：所有连续变量均已在1%和99%分位缩尾处理。
```
（上表数字仅示意格式，实际必须来自代码输出。）

公式：`$$ ... $$` 单独成行，自动编号 (1)(2)…；需固定编号用 `\tag{3}`；行内用 `$\beta_1$`；公式后紧跟“其中，……”。分页用单独一行 `\newpage`。

**表格规范**：三线表（排版器自动处理）；表题在上、图题在下；表注说明：①括号内为何种标准误（如“括号内为省份层面聚类稳健标准误”）；②显著性符号（“\*、\*\*、\*\*\* 分别表示在10%、5%、1%的水平上显著”）；③控制变量与固定效应是否加入；④数据为模拟数据时注明。系数统一保留 3 位小数；单位在表头或变量名后注明（亿元、%）；回归表报告 N 和 R²（FE 模型报告组内 R² 并说明）。

**作图规范**：
```python
from omniagent.research import academic_style, savefig
import matplotlib.pyplot as plt
academic_style()                       # 中文字体、无上右边框、灰度友好配色
fig, ax = plt.subplots(figsize=(6.4, 4))
for g, sub in df.groupby("region"):
    s = sub.groupby("year")["selfsuff"].mean()
    ax.plot(s.index, s.values, marker="o", label=g)
ax.set_xlabel("年份"); ax.set_ylabel("财政自给率（%）"); ax.legend(frameon=False)
savefig(fig, "outputs/figures/fig1_selfsuff_trend.png")   # 300 dpi，bbox tight
```
- **图内不放标题**（标题写在 Markdown 图题里）；坐标轴写中文名称与单位；
- 灰度打印可区分：不同线型/标记（实线、虚线、点线；○ □ △），避免仅靠颜色区分；
- 事件研究图：横轴“政策实施相对年份”，纵轴“估计系数”，基期处画竖虚线、0 处画横虚线，95% 置信区间；
- 安慰剂图：核密度/直方图 + 真实系数竖线；
- 每幅图保存后，若 `view_image` 可用，打开 PNG 检查中文是否乱码（方块）、标签是否重叠。

---

## 9. 写作语言规范

- 学术、客观、精炼；用“本文”，少用“笔者认为”“我们”；不用口语（“很多”“非常大”“大家知道”）。
- 每段一个中心句，先结论后论据；段落 150–300 字。
- 结果陈述格式：“列（4）结果显示，FD 的系数为 0.xxx，且在 1% 的水平上显著，表明……。从经济意义看，……”——**显著性 + 方向 + 大小 + 经济含义**四要素齐全。
- 不夸大：“在一定程度上缓解了内生性”而非“彻底解决了内生性”；“提供了经验证据”而非“证明了”。
- 数字与单位：统一使用阿拉伯数字；年份区间用“2010—2022年”（一字线）；百分比与百分点区分清楚。
- 术语前后一致（如“财政自给率”不要中途变成“财政自主度”，除非定义不同）；英文缩写首次出现给出全称。
- 政策建议**基于本文结论**逐条对应（结论 1 → 建议 1），具体可操作（指向哪一级政府、哪项制度、什么工具），避免“加强”“完善”“提高认识”式空话；最后一段写研究不足与展望（1 段即可）。

---

## 10. 写作与排版流程

1. 分章节写作：`write_file paper/sections/01_intro.md` …；章节多时可用 `delegate_task` 并行撰写（把相关结果表文件路径、变量定义、假设编号、文献池传给子任务，并要求“只使用给定文件中的数字”），回收后由主 Agent 统一术语、编号与引用。
2. 合并：用 python 按顺序拼接到 `paper/paper.md`（全文只有一个 `#` 一级标题，即论文题目）。
3. 生成文档：
   ```
   create_document(source_path="paper/paper.md", output_path="outputs/paper.docx",
                   style="academic", title=None, author="作者", affiliation="单位", toc=False)
   create_document(source_path="paper/paper.md", output_path="outputs/paper.pdf", style="academic", ...)
   ```
4. 自检：`check_document(path="outputs/paper.docx", paper_type="fiscal_paper")`，按问题优先级（严重 → 一般 → 建议）修改 `paper.md` 后重新生成，**循环直到得分 ≥ 85 且无“严重”问题**。
5. 视觉检查：若 `view_image` 可用，把 PDF 关键页转成 PNG（例如 `run_shell` 调用 `pdftoppm -png -r 80 outputs/paper.pdf outputs/pages/p` 若已安装），查看表格是否溢出、图片是否清晰、公式编号是否正常。若 PDF 转换不可用，至少交付 docx 并说明。
6. 交付说明：文件路径、字数、图表数、check_document 得分、数据性质（真实/模拟）、需用户核实的文献（［待核实］条目）、未完成事项。

---

## 11. 参考文献：可靠文献池与格式

格式遵循 GB/T 7714-2015，按正文引用顺序（顺序编码制）或按作者音序（著者-出版年制）排列，全文统一。条目模板：
- 期刊：`[1] 作者. 题名[J]. 刊名, 年份, 卷(期): 起止页码.`
- 专著：`[2] 作者. 书名[M]. 出版地: 出版者, 年份.`
- 英文作者：姓在前，名缩写，如 `QIAN Y, WEINGAST B R.`（3 人以上写前 3 人加“等/et al.”）。

**可选文献池**（作者、年份、题名、刊名较为可靠；中文条目只列到期号，页码引用前务必在中国知网核对；任何一项无法核对时加“［待核实］”并告知用户）：

| # | GB/T 7714 条目 | 适用主题 |
|---|---|---|
| 1 | OATES W E. Fiscal Federalism[M]. New York: Harcourt Brace Jovanovich, 1972. | 财政分权理论 |
| 2 | TIEBOUT C M. A Pure Theory of Local Expenditures[J]. Journal of Political Economy, 1956, 64(5): 416-424. | 地方公共品、用脚投票 |
| 3 | QIAN Y, WEINGAST B R. Federalism as a Commitment to Preserving Market Incentives[J]. Journal of Economic Perspectives, 1997, 11(4): 83-92. | 市场维护型联邦主义 |
| 4 | JIN H, QIAN Y, WEINGAST B R. Regional Decentralization and Fiscal Incentives: Federalism, Chinese Style[J]. Journal of Public Economics, 2005, 89(9-10): 1719-1742. | 中国式财政激励 |
| 5 | 林毅夫, 刘志强. 中国的财政分权与经济增长[J]. 北京大学学报(哲学社会科学版), 2000(4). | 分权与增长 |
| 6 | 陈抗, HILLMAN A L, 顾清扬. 财政集权与地方政府行为变化——从援助之手到攫取之手[J]. 经济学(季刊), 2002, 2(1). | 分税制、地方行为 |
| 7 | 张晏, 龚六堂. 分税制改革、财政分权与中国经济增长[J]. 经济学(季刊), 2005, 5(1). | 分权与增长 |
| 8 | 乔宝云, 范剑勇, 冯兴元. 中国的财政分权与小学义务教育[J]. 中国社会科学, 2005(6). | 分权与公共服务 |
| 9 | 周黎安. 中国地方官员的晋升锦标赛模式研究[J]. 经济研究, 2007(7): 36-50. | 晋升激励 |
| 10 | 傅勇, 张晏. 中国式分权与财政支出结构偏向：为增长而竞争的代价[J]. 管理世界, 2007(3). | 支出结构 |
| 11 | 范子英, 张军. 财政分权、转移支付与国内市场整合[J]. 经济研究, 2010(3). | 转移支付 |
| 12 | 毛捷, 吕冰洋, 马光荣. 转移支付与政府扩张：基于“价格效应”的研究[J]. 管理世界, 2015(7). | 转移支付、粘蝇纸效应 |
| 13 | 江艇. 因果推断经验研究中的中介效应与调节效应[J]. 中国工业经济, 2022(5): 100-120. | 机制检验方法 |
| 14 | BARON R M, KENNY D A. The Moderator-Mediator Variable Distinction in Social Psychological Research: Conceptual, Strategic, and Statistical Considerations[J]. Journal of Personality and Social Psychology, 1986, 51(6): 1173-1182. | 中介/调节（传统方法） |
| 15 | CALLAWAY B, SANT'ANNA P H C. Difference-in-Differences with Multiple Time Periods[J]. Journal of Econometrics, 2021, 225(2): 200-230. | 交错 DID |
| 16 | GOODMAN-BACON A. Difference-in-Differences with Variation in Treatment Timing[J]. Journal of Econometrics, 2021, 225(2): 254-277. | TWFE 分解 |
| 17 | SUN L, ABRAHAM S. Estimating Dynamic Treatment Effects in Event Studies with Heterogeneous Treatment Effects[J]. Journal of Econometrics, 2021, 225(2): 175-199. | 事件研究 |
| 18 | DE CHAISEMARTIN C, D'HAULTFŒUILLE X. Two-Way Fixed Effects Estimators with Heterogeneous Treatment Effects[J]. American Economic Review, 2020, 110(9): 2964-2996. | TWFE 偏误 |
| 19 | HANSEN B E. Threshold Effects in Non-Dynamic Panels: Estimation, Testing, and Inference[J]. Journal of Econometrics, 1999, 93(2): 345-368. | 门槛回归 |
| 20 | BECK T, LEVINE R, LEVKOV A. Big Bad Banks? The Winners and Losers from Bank Deregulation in the United States[J]. Journal of Finance, 2010, 65(5): 1637-1667. | 事件研究、多期 DID |
| 21 | ANGRIST J D, PISCHKE J S. Mostly Harmless Econometrics: An Empiricist's Companion[M]. Princeton: Princeton University Press, 2009. | 计量方法 |
| 22 | ROSENBAUM P R, RUBIN D B. The Central Role of the Propensity Score in Observational Studies for Causal Effects[J]. Biometrika, 1983, 70(1): 41-55. | PSM |
| 23 | ABADIE A, DIAMOND A, HAINMUELLER J. Synthetic Control Methods for Comparative Case Studies: Estimating the Effect of California's Tobacco Control Program[J]. Journal of the American Statistical Association, 2010, 105(490): 493-505. | 合成控制 |
| 24 | STOCK J H, YOGO M. Testing for Weak Instruments in Linear IV Regression[M]// ANDREWS D W K, STOCK J H. Identification and Inference for Econometric Models. Cambridge: Cambridge University Press, 2005: 80-108. | 弱工具变量 |

使用规则：
- 只引用与论文内容真正相关的条目；正文中每条至少被引用一次；
- 未列卷期页码的中文条目，交付时在说明中列出“请到中国知网核对卷期页码”；可以 `web_search` 核实（若可用），核实成功再补全；
- 用户需要上表以外的近期文献（如 2020 年后的具体实证论文）时，**只能通过检索验证后加入**，无法验证的不写，或明确标“［待核实］”；绝不凭记忆杜撰题名。

---

## 12. 投稿前自检清单

**内容与诚信**
- [ ] 所有数字可追溯到代码输出（`outputs/tables/` 与正文逐一对照过）
- [ ] 若为模拟数据：标题、摘要、数据部分、表注均已标注
- [ ] 参考文献无虚构；［待核实］条目已在交付说明中列出
- [ ] 因果表述与识别策略强度一致

**结构**
- [ ] 题目 ≤ 25 字，含核心变量与研究对象
- [ ] 摘要 200–400 字：目的—方法/数据—主要发现（含关键数字）—贡献/政策含义
- [ ] 关键词 3–5 个，中文分号分隔；英文 Abstract/Keywords 与中文对应
- [ ] 引言含：现实背景、研究问题、边际贡献三点、结构安排
- [ ] 研究假设编号清晰，并在实证部分逐一回应（“假设 H1 得到验证”）
- [ ] 包含：基准回归、内生性、稳健性（≥4 项）、异质性（含组间差异检验）、机制
- [ ] 结论与政策建议一一对应，最后有研究不足

**格式**
- [ ] 全文一个 H1；二级“一、”三级“（一）”四级“1.”编号连续
- [ ] 图表编号连续，均“先提及后出现”，图题在下、表题在上
- [ ] 每张表有表注（标准误类型、显著性、控制变量/固定效应）
- [ ] 小数位统一（系数 3 位）；单位注明；年份区间用“—”
- [ ] 公式编号连续，符号均有解释
- [ ] 无 TODO/XXX/待补充/【】等占位符；无空章节
- [ ] `check_document(paper_type="fiscal_paper")` 得分 ≥ 85，无严重问题
- [ ] PDF/图片目视检查通过（若工具可用）

---

## 13. 常见错误速查

| 错误 | 修正 |
|---|---|
| 只报告显著的稳健性结果 | 如实报告，解释不显著的原因 |
| 逐步法中介 + Sobel 作为主要机制证据 | 改为 X→M + 理论论证（江艇，2022） |
| 交错 DID 只用 TWFE | 补充 CS/SA 稳健估计与事件研究 |
| “A 组显著 B 组不显著，所以存在异质性” | 做组间系数差异检验 |
| 系数只说“显著为正” | 补充经济含义（弹性、占均值比例） |
| 标准误未聚类或未说明 | 聚类到个体层面并在表注写明 |
| 图里有标题、英文默认字体、彩色无法灰度区分 | `academic_style()`，图题写在 Markdown 中 |
| 表格先于文字出现 | 先写“见表N”，再放表 |
| 参考文献格式混杂（有的有页码有的无、中英文标点混用） | 统一 GB/T 7714，英文条目用英文标点 |
