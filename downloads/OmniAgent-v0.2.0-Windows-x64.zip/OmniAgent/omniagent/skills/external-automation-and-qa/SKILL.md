---
name: external-automation-and-qa
description: 连接外部软件系统（邮箱收发与追踪、日历排期提醒、招聘/业务网站定制简历与求职信投递、OpenAPI自动接入）以及工程/文档全链路实测验收规范。当用户要求连接外部应用联动操作，或交付复杂代码/Web系统/PPT/PDF时必须加载。
---

# 外部软件自主连接联动 & 全链路实测验收规范

## 一、外部系统自主连接与业务闭环方法论
1. **先探测与匹配身份背景**：
   - 调用 `list_connectors` 查看已接入系统；若尚未注册连接器但用户给出了服务地址、文档或环境配置，主动调用 `connector_manage(action="discover" | "register")` 动态完成接入与 `test` 连通性验证。
   - 涉及个性化对外沟通（回复邮件、撰写求职 Cover Letter、填写个人履历）时，**必须先从长期记忆与用户画像（`memory_search`）读取用户的真实经历、语气偏好与专业背景**，严禁编造虚假履历。
2. **邮件自动处理与持续追踪（`email_ops` + `tracker_manage`）**：
   - `email_ops(action="list", unread_only=true)` 扫描待处理来信 → `read` 提取正文、历史上下文与附件 → 按邮件诉求联动其他工具（如核查日历档期、查询业务数据库、审阅附件文档） → 调用 `draft_reply` 或 `send_reply` 回复（保持 `In-Reply-To` 线程完整） → 自动或显式通过 `tracker_manage` 开启回信跟进监控。
3. **日历智能排期与防冲突提醒（`calendar_ops`）**：
   - 新增或调整会议前，**必须先调用 `calendar_ops(action="check_conflicts")`** 核查时段冲突；确认空闲后调用 `add` 设定合理的 `reminder_minutes`（如提前 15/30 分钟），需要跨系统发邀请时附带 `export_ics_path="outputs/invite.ics"`。
4. **求职投递与交互式业务系统填报（`browser_session`）**：
   - 用 `browser_session(action="open", url=...)` 读取目标岗位 JD 与申请表单字段编号 `[e1]..[eN]`；
   - 结合岗位核心要求与用户画像经历，针对每个不同岗位独立撰写定制化的求职信（Cover Letter），并用 `create_document` 输出规范 PDF/DOCX；
   - 用 `browser_session(action="fill", fields={...})` 精准填入基本信息与求职陈述，用 `upload` 挂载简历/Cover Letter 文件，核对无误后调用 `submit` 投递，并用 `tracker_manage(kind="job_application")` 登记投递台账。

## 二、全链路交付前实测验收标准（`verify_deliverable`）
- **代码审查修复与程序开发**：修改完成后必须调用 `verify_deliverable(kind="python_code")`（或运行语言对应测试命令）确认 0 语法错误、0 遗留冲突/TODO、全部单测通过。
- **Web 应用与后端 API 编写**：绝不能只写完代码就结束！必须调用 `verify_deliverable(kind="web_service", server_command="...", endpoints=[...])` 在真实沙箱端口拉起服务、请求核心接口验证 HTTP 200 与返回数据正确。
- **PPT / PDF / Excel / Word 生成与改写**：修改已有演示文稿优先用 `edit_presentation`，PDF 合并/拆分/水印/填表用 `pdf_ops`，交付前调用 `verify_deliverable(kind="office_file", paths=[...])` 确保零空页、零 Excel 公式错误（`#REF!` / `#DIV/0!`）与高分排版质量。
