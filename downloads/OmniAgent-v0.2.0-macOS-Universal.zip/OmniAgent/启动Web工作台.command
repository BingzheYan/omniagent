#!/usr/bin/env bash
cd "$(dirname "$0")"
exec bash "./scripts/mac_bootstrap.sh" web "$@"
