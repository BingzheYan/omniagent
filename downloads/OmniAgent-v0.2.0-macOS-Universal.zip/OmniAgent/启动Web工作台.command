#!/usr/bin/env bash
cd "$(dirname "$0")"
chmod +x ./*.command ./scripts/mac_bootstrap.sh 2>/dev/null || true
xattr -cr ./*.command "./OmniAgent.app" "./dist/OmniAgent.app" "./scripts/mac_bootstrap.sh" 2>/dev/null || true
if [ -f "./scripts/mac_bootstrap.sh" ]; then
  exec bash "./scripts/mac_bootstrap.sh" web "$@"
fi
unset ANTHROPIC_AUTH_TOKEN ANTHROPIC_API_KEY ANTHROPIC_BASE_URL
export PYTHONUTF8=1 PYTHONIOENCODING=utf-8
ROOT="$(pwd)"
export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"
PY="$ROOT/.venv/bin/python"
[ -x "$PY" ] || PY="python3"
PORT="$("$PY" -c '
import socket
for p in (8765, 8766, 8767, 0):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind(("127.0.0.1", p))
            print(s.getsockname()[1])
            break
        except OSError:
            continue
')"
echo "正在启动 OmniAgent Web 工作台 -> http://127.0.0.1:${PORT} ..."
(sleep 1.5 && open "http://127.0.0.1:${PORT}") &
DATA_ARGS=()
[ -d "$ROOT/demo_data" ] && DATA_ARGS=(--data-dir "$ROOT/demo_data")
exec "$PY" -m omniagent web -m deepseek --port "${PORT}" "${DATA_ARGS[@]}" "$@"
