#!/usr/bin/env bash
set -euo pipefail

MODE="${1:-desktop}"
shift || true

export PATH="/opt/homebrew/bin:/usr/local/bin:$HOME/.local/bin:$PATH"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$ROOT"

unset ANTHROPIC_AUTH_TOKEN ANTHROPIC_API_KEY ANTHROPIC_BASE_URL
export PYTHONUTF8=1
export PYTHONIOENCODING=utf-8
export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"

step() {
  printf "\033[1;36m[OmniAgent]\033[0m %s\n" "$1"
}

# 若用户在只读 .dmg 挂载卷内直接双击运行，自动安装到 ~/Applications/OmniAgent 后再启动
if [ ! -w "$ROOT" ]; then
  INSTALL_DIR="$HOME/Applications/OmniAgent"
  step "检测到当前位于只读磁盘镜像，正在自动安装到 $INSTALL_DIR ..."
  mkdir -p "$HOME/Applications"
  rsync -a --exclude ".DS_Store" "$ROOT/" "$INSTALL_DIR/"
  xattr -cr "$INSTALL_DIR" 2>/dev/null || true
  exec bash "$INSTALL_DIR/scripts/mac_bootstrap.sh" "$MODE" "$@"
fi

# 自动清理 macOS 下载隔离属性，避免双击 .app / 二进制被拦截
chmod +x "$ROOT"/*.command "$ROOT/scripts/mac_bootstrap.sh" 2>/dev/null || true
xattr -cr "$ROOT/OmniAgent.app" "$ROOT/dist/OmniAgent.app" 2>/dev/null || true

find_python310() {
  for cand in \
    python3.12 python3.11 python3.13 python3.10 \
    /opt/homebrew/bin/python3.12 /opt/homebrew/bin/python3.11 /opt/homebrew/bin/python3 \
    /usr/local/bin/python3.12 /usr/local/bin/python3.11 /usr/local/bin/python3 \
    /Library/Frameworks/Python.framework/Versions/3.12/bin/python3 \
    /Library/Frameworks/Python.framework/Versions/3.11/bin/python3 \
    python3; do
    if command -v "$cand" >/dev/null 2>&1; then
      if "$cand" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)' 2>/dev/null; then
        command -v "$cand"
        return 0
      fi
    fi
  done
  return 1
}

install_python312_macos() {
  step "未检测到 Python 3.10+，正在自动安装 Python 3.12..."
  if command -v brew >/dev/null 2>&1; then
    brew install python@3.12
    if PY_FOUND="$(find_python310)"; then
      echo "$PY_FOUND"
      return 0
    fi
  fi
  PKG_TMP="/tmp/python-3.12.8-macos11.pkg"
  for url in \
    "https://registry.npmmirror.com/-/binary/python/3.12.8/python-3.12.8-macos11.pkg" \
    "https://www.python.org/ftp/python/3.12.8/python-3.12.8-macos11.pkg"; do
    step "正在下载 Python 3.12 官方安装包: $url"
    if curl -fL --connect-timeout 15 "$url" -o "$PKG_TMP"; then
      step "请在弹出的系统窗口中输入开机密码完成 Python 3.12 安装..."
      sudo installer -pkg "$PKG_TMP" -target /
      rm -f "$PKG_TMP"
      export PATH="/Library/Frameworks/Python.framework/Versions/3.12/bin:$PATH"
      if PY_FOUND="$(find_python310)"; then
        echo "$PY_FOUND"
        return 0
      fi
    fi
  done
  printf "\033[1;31m自动安装 Python 失败，请先访问 https://www.python.org/downloads/ 安装 Python 3.12 后重试。\033[0m\n" >&2
  exit 1
}

VENV_DIR="$ROOT/.venv"
VENV_PY="$VENV_DIR/bin/python"
MARKER="$VENV_DIR/.omni_mac_ready"

if [ -d "$VENV_DIR" ] && [ ! -x "$VENV_PY" ]; then
  step "检测到不兼容的 .venv 目录，正在清理重建..."
  rm -rf "$VENV_DIR"
fi

READY=0
if [ -x "$VENV_PY" ]; then
  if PYTHONPATH="$ROOT" "$VENV_PY" -c "import omniagent, fastapi, uvicorn, openai, httpx, pandas, openpyxl, docx, pptx, fitz" 2>/dev/null; then
    READY=1
    [ -f "$MARKER" ] || date -u +"%Y-%m-%dT%H:%M:%SZ" > "$MARKER"
  fi
fi

if [ "$READY" -eq 0 ]; then
  SYS_PY="$(find_python310 || true)"
  if [ -z "$SYS_PY" ]; then
    SYS_PY="$(install_python312_macos)"
  fi
  if [ ! -x "$VENV_PY" ]; then
    step "正在创建 macOS 独立虚拟环境 (.venv)..."
    "$SYS_PY" -m venv "$VENV_DIR"
  fi
  step "正在安装 OmniAgent 依赖包（首次运行约需 1 分钟，请稍候）..."
  INSTALLED=0
  for idx in \
    "-i https://pypi.tuna.tsinghua.edu.cn/simple --trusted-host pypi.tuna.tsinghua.edu.cn" \
    "-i https://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com" \
    ""; do
    # shellcheck disable=SC2086
    if "$VENV_PY" -m pip install --upgrade pip $idx && "$VENV_PY" -m pip install -e "$ROOT" $idx; then
      INSTALLED=1
      break
    fi
  done
  if [ "$INSTALLED" -eq 0 ]; then
    printf "\033[1;31m依赖安装失败，请检查网络连接后重试。\033[0m\n" >&2
    exit 1
  fi
  "$VENV_PY" -m omniagent desktop --build-app "$ROOT" >/dev/null 2>&1 || true
  date -u +"%Y-%m-%dT%H:%M:%SZ" > "$MARKER"
  step "macOS 运行环境配置完成！"
fi

if [ ! -f "$ROOT/.env" ] && [ -f "$ROOT/.env.example" ]; then
  cp "$ROOT/.env.example" "$ROOT/.env"
fi

DATA_ARGS=()
if [ -d "$ROOT/demo_data" ]; then
  DATA_ARGS=(--data-dir "$ROOT/demo_data")
fi

case "$MODE" in
  setup)
    "$VENV_PY" -m omniagent desktop --build-app "$ROOT"
    "$VENV_PY" -m omniagent --version
    "$VENV_PY" -m omniagent models
    "$VENV_PY" -m omniagent agents
    printf "\n\033[1;32m✅ OmniAgent macOS 版就绪！可直接双击 OmniAgent.app 或 启动桌面端.command 运行。\033[0m\n"
    ;;
  web)
    PORT="$("$VENV_PY" -c '
import socket
for p in (8765, 8766, 8767, 0):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind(("127.0.0.1", p))
            print(s.getsockname()[1])
            break
        except OSError:
            continue
')"
    step "正在启动 OmniAgent Web 工作台 -> http://127.0.0.1:${PORT} ..."
    (sleep 1.5 && open "http://127.0.0.1:${PORT}") &
    exec "$VENV_PY" -m omniagent web -m deepseek --port "$PORT" "${DATA_ARGS[@]}" "$@"
    ;;
  cli)
    step "正在进入 OmniAgent 交互式终端..."
    exec "$VENV_PY" -m omniagent chat -m deepseek "$@"
    ;;
  *)
    for sh_cand in "$ROOT/OmniAgent.app/Contents/MacOS/OmniAgentDesktopShell" "$ROOT/dist/OmniAgent.app/Contents/MacOS/OmniAgentDesktopShell"; do
      if [ -x "$sh_cand" ]; then
        export OMNIAGENT_NATIVE_SHELL="$sh_cand"
        break
      fi
    done
    step "正在启动 OmniAgent macOS 原生桌面端..."
    exec "$VENV_PY" -m omniagent desktop -m deepseek "${DATA_ARGS[@]}" "$@"
    ;;
esac
