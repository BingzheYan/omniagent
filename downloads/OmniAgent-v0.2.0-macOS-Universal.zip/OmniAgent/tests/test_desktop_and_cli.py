"""测试 CLI 子命令（agents / skills / connectors / user / desktop --build-app）与桌面端打包。"""
from __future__ import annotations

import platform
from pathlib import Path

from omniagent.cli import main as cli_main
from omniagent.desktop import build_macos_app_bundle


def test_cli_agents_skills_connectors_user(tmp_path: Path, capsys):
    cli_main(["agents", "-w", str(tmp_path)])
    out = capsys.readouterr().out
    assert "coder" in out and "analyst" in out and "connector" in out

    cli_main(["skills", "-w", str(tmp_path)])
    out = capsys.readouterr().out
    assert "fiscal-paper" in out and "debugging" in out

    cli_main(["connectors", "-w", str(tmp_path)])
    out = capsys.readouterr().out
    assert "连接器" in out

    data_dir = tmp_path / "srv"
    try:
        cli_main(["user", "--data-dir", str(data_dir), "add", "admin1", "--admin", "--password", "password123"])
    except SystemExit as e:
        assert e.code == 0
    try:
        cli_main(["user", "--data-dir", str(data_dir), "list"])
    except SystemExit as e:
        assert e.code == 0
    out = capsys.readouterr().out
    assert "admin1" in out


def test_desktop_app_bundle_builder(tmp_path: Path):
    app_dir = build_macos_app_bundle(tmp_path / "dist")
    assert (app_dir / "Contents" / "Info.plist").is_file()
    assert (app_dir / "Contents" / "MacOS" / "OmniAgent").is_file()
    if platform.system() == "Darwin":
        assert (app_dir / "Contents" / "MacOS" / "OmniAgentDesktopShell").is_file()
