#!/usr/bin/env bash
cd "$(dirname "$0")"
chmod +x ./*.command ./scripts/mac_bootstrap.sh 2>/dev/null || true
xattr -cr ./*.command "./OmniAgent.app" "./dist/OmniAgent.app" "./scripts/mac_bootstrap.sh" 2>/dev/null || true
if [ -f "./scripts/mac_bootstrap.sh" ]; then
  exec bash "./scripts/mac_bootstrap.sh" cli "$@"
fi
unset ANTHROPIC_AUTH_TOKEN ANTHROPIC_API_KEY ANTHROPIC_BASE_URL
export PYTHONUTF8=1 PYTHONIOENCODING=utf-8
ROOT="$(pwd)"
export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"
PY="$ROOT/.venv/bin/python"
[ -x "$PY" ] || PY="python3"
exec "$PY" -m omniagent chat -m deepseek "$@"
