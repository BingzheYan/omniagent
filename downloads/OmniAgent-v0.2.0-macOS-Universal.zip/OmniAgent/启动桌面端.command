#!/usr/bin/env bash
cd "$(dirname "$0")"
xattr -cr "./OmniAgent.app" "./scripts/mac_bootstrap.sh" 2>/dev/null || true
if [ -x "./.venv/bin/python" ] && [ -d "./OmniAgent.app" ]; then
  open "./OmniAgent.app"
else
  exec bash "./scripts/mac_bootstrap.sh" desktop "$@"
fi
