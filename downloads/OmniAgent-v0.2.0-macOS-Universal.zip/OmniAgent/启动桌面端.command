#!/usr/bin/env bash
cd "$(dirname "$0")"
chmod +x ./*.command ./scripts/mac_bootstrap.sh 2>/dev/null || true
xattr -cr ./*.command "./OmniAgent.app" "./dist/OmniAgent.app" "./scripts/mac_bootstrap.sh" 2>/dev/null || true
if [ -f "./scripts/mac_bootstrap.sh" ]; then
  exec bash "./scripts/mac_bootstrap.sh" desktop --detach "$@"
fi
unset ANTHROPIC_AUTH_TOKEN ANTHROPIC_API_KEY ANTHROPIC_BASE_URL
export PYTHONUTF8=1 PYTHONIOENCODING=utf-8
ROOT="$(pwd)"
export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"
for sh_cand in "$ROOT/OmniAgent.app/Contents/MacOS/OmniAgentDesktopShell" "$ROOT/dist/OmniAgent.app/Contents/MacOS/OmniAgentDesktopShell"; do
  if [ -x "$sh_cand" ]; then
    export OMNIAGENT_NATIVE_SHELL="$sh_cand"
    break
  fi
done
PY="$ROOT/.venv/bin/python"
[ -x "$PY" ] || PY="python3"
DATA_ARGS=()
[ -d "$ROOT/demo_data" ] && DATA_ARGS=(--data-dir "$ROOT/demo_data")
exec "$PY" -m omniagent desktop -m deepseek --detach "${DATA_ARGS[@]}" "$@"
