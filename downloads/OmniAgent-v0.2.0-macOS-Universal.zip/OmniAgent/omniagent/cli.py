"""OmniAgent 命令行界面（类似 Claude Code / Codex CLI）。

用法:
  omni                          交互模式（在当前目录作为工作区）
  omni run "任务描述"            一次性自主执行任务
  omni web                      启动 Web 办公工作台
  omni models                   查看模型档案及可用状态
  omni sessions                 查看历史会话
  omni skills                   查看可用技能（Skills）
  omni user list|add|passwd|role|disable|enable   管理 Web 工作台用户
"""
from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import signal
import sys
import threading
from pathlib import Path

from rich.console import Console, Group
from rich.live import Live
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from omniagent import __version__
from omniagent.agent import Agent, list_sessions
from omniagent.config import Settings, load_settings
from omniagent.llm import create_provider

console = Console(highlight=False)

TOOL_ICONS = {
    "read_file": "📖", "write_file": "📝", "edit_file": "✏️ ", "list_dir": "📂", "glob": "🔎", "grep": "🔎",
    "run_shell": "💻", "python": "🐍", "create_document": "📄", "create_presentation": "📊",
    "create_spreadsheet": "📗", "web_fetch": "🌐", "web_search": "🌐", "todo_write": "📋", "ask_user": "❓",
    "delegate_task": "🤖", "delegate_parallel": "🤖", "view_image": "🖼 ", "process": "⚙️ ", "load_skill": "📚",
    "check_document": "🧐", "list_connectors": "🔌", "connector_query": "🔌", "browser_inspect": "🌐",
    "desktop_inspect": "🖥 ", "memory_upsert": "🧠", "memory_search": "🧠", "memory_delete": "🧠",
    "portrait_update": "🪪", "project_memory": "📌",
    "connector_manage": "🔌", "email_ops": "📧", "calendar_ops": "📅", "browser_session": "🧭",
    "desktop_action": "🔔", "tracker_manage": "📡", "verify_deliverable": "🧪",
    "edit_presentation": "📊", "pdf_ops": "📕",
}


class CLIRenderer:
    """把 Agent 事件渲染到终端。"""

    def __init__(self, verbose: bool = False):
        self.verbose = verbose
        self.live: Live | None = None
        self.status = None
        self.buffer = ""
        self.tool_names: dict[str, str] = {}

    def _prefix(self, depth: int) -> str:
        return "  │ " * depth

    def stop_dynamic(self):
        if self.live:
            self.live.stop()
            self.live = None
        if self.status:
            self.status.stop()
            self.status = None

    def spin(self, msg: str):
        self.stop_dynamic()
        self.status = console.status(f"[cyan]{msg}", spinner="dots")
        self.status.start()

    async def __call__(self, e: dict):
        t = e["type"]
        d = e.get("depth", 0)
        pre = self._prefix(d)
        if t == "step":
            self.buffer = ""
            self.spin("思考中…")
        elif t == "thinking_delta":
            if self.status:
                self.status.update("[cyan]深度思考中…")
        elif t == "text_delta":
            if self.status:
                self.status.stop()
                self.status = None
            self.buffer += e["text"]
            if d > 0:
                return  # 子智能体的中间文本不实时显示
            if self.live is None:
                self.live = Live(Markdown(self.buffer), console=console, refresh_per_second=12, vertical_overflow="visible")
                self.live.start()
            else:
                self.live.update(Markdown(self.buffer))
        elif t == "assistant_message":
            self.stop_dynamic()
            if d == 0 and e.get("thinking"):
                th = e["thinking"].strip()
                preview = th if self.verbose or len(th) <= 280 else th[:277] + "…"
                console.print(Panel(Text(preview, style="dim italic"), title="💭 思维链", border_style="bright_black", expand=False))
            if d > 0 and e.get("content"):
                console.print(Text(pre + e["content"].strip()[:400], style="dim"))
        elif t == "file_changes":
            if e.get("final") and e.get("files") and d == 0:
                self.stop_dynamic()
                files = e["files"]
                tot_a = sum(int(f.get("added") or 0) for f in files)
                tot_r = sum(int(f.get("removed") or 0) for f in files)
                body = Text()
                for f in files:
                    body.append(f"  {f['path']}", style="bold white")
                    if f.get("binary"):
                        body.append("  [BIN]\n", style="cyan")
                    else:
                        body.append(f"  +{f.get('added', 0)}", style="green")
                        body.append(f" -{f.get('removed', 0)}\n", style="red")
                body.rstrip()
                console.print(Panel(body, title=f"📄 {len(files)} files changed  +{tot_a} -{tot_r}", border_style="bright_black", expand=False))
        elif t == "tool_start":
            self.stop_dynamic()
            name = e["name"]
            self.tool_names[e["id"]] = name
            if name == "todo_write":
                return
            icon = TOOL_ICONS.get(name, "🔧")
            summary = e.get("summary") or ""
            line = Text(f"{pre}{icon} ", style="bold")
            line.append(name, style="bold magenta")
            if summary:
                line.append(f"  {summary}", style="white")
            console.print(line)
            if name == "python" and self.verbose:
                console.print(Panel(e["arguments"].get("code", ""), border_style="dim", expand=False))
            self.spin(f"执行 {name}…")
        elif t == "tool_end":
            self.stop_dynamic()
            name = e["name"]
            if name == "todo_write":
                return
            content = e.get("content", "")
            style = "red" if e.get("is_error") else "dim"
            data = e.get("data") or {}
            if data.get("diff") and name in ("edit_file", "write_file"):
                first = content.splitlines()[0] if content else ""
                console.print(Text(f"{pre}  ⎿ {first}", style="green"))
                diff_lines = data["diff"].splitlines()[2:28]
                for dl in diff_lines:
                    s = "green" if dl.startswith("+") else "red" if dl.startswith("-") else "cyan" if dl.startswith("@@") else "dim"
                    console.print(Text(f"{pre}     {dl[:160]}", style=s))
                return
            lines = content.splitlines()
            limit = 12 if (e.get("is_error") or self.verbose) else 5
            shown = lines[:limit]
            for i, l in enumerate(shown):
                console.print(Text(f"{pre}  {'⎿' if i == 0 else ' '} {l[:200]}", style=style))
            if len(lines) > limit:
                console.print(Text(f"{pre}    … 共 {len(lines)} 行", style="dim"))
            for img in data.get("images", []) or ([data["image"]] if data.get("image") else []):
                seen = "（已发送给模型查看）" if e.get("images_attached") else ""
                console.print(Text(f"{pre}    🖼  {img}{seen}", style="cyan"))
        elif t == "plan_update":
            self.stop_dynamic()
            todos = e.get("todos", [])
            body = Text()
            for td in todos:
                st = td.get("status")
                mark, style = {"completed": ("☑", "green strike"), "in_progress": ("▶", "bold yellow"),
                               "cancelled": ("✗", "dim strike")}.get(st, ("☐", "white"))
                body.append(f"{mark} {td.get('content')}\n", style=style)
            done = sum(td.get("status") == "completed" for td in todos)
            body.rstrip()
            console.print(Panel(body, title=f"📋 计划 {done}/{len(todos)}", border_style="blue", expand=False))
        elif t == "loop_warning":
            self.stop_dynamic()
            console.print(Text(f"{pre}🔁 检测到重复操作，已提醒智能体换一种思路：{e.get('reason', '')}", style="bold yellow"))
        elif t == "review":
            self.stop_dynamic()
            console.print(Text(f"{pre}🔍 自检第 {e['round']} 轮：核对任务要求与产出…", style="bold blue"))
        elif t == "subagent_start":
            self.stop_dynamic()
            console.print(Panel(e["task"][:500], title=f"🤖 子智能体：{e['role']}", border_style="magenta", expand=False))
        elif t == "subagent_end":
            self.stop_dynamic()
            console.print(Text(f"{pre}🤖 子智能体「{e['role']}」已完成", style="magenta"))
        elif t == "memory_updated":
            if d == 0 and e.get("events"):
                self.stop_dynamic()
                evs = e["events"]
                console.print(Text(f"✦ 已沉淀长期记忆与画像进度（{len(evs)} 项）："
                                   + " · ".join(str(x.get("summary", ""))[:45] for x in evs[:3]), style="cyan"))
        elif t == "compact":
            self.stop_dynamic()
            console.print(Text(f"🗜  上下文已压缩：~{e['before']} → ~{e['after']} tokens", style="yellow"))
        elif t == "status":
            self.spin(e["message"])
        elif t == "approval_request":
            self.stop_dynamic()
        elif t == "error":
            self.stop_dynamic()
            console.print(Panel(e["message"], title="错误", border_style="red"))
        elif t == "done":
            self.stop_dynamic()
            if d == 0:
                u = e.get("usage", {})
                console.print(Text(
                    f"\n✔ 完成  {e['steps']} 步 · {e['elapsed']}s · tokens 输入 {u.get('input_tokens', 0):,} / 输出 "
                    f"{u.get('output_tokens', 0):,}" + ("  (未完全完成)" if e.get("incomplete") else ""), style="bold green"))
        elif t == "cancelled":
            self.stop_dynamic()
            console.print(Text("⏹ 已中断", style="yellow"))


async def _ainput(prompt: str = "") -> str:
    """在守护线程中读取输入，避免退出时阻塞事件循环关闭。"""
    loop = asyncio.get_running_loop()
    fut: asyncio.Future = loop.create_future()

    def _set(fn, val):
        if not fut.done():
            fn(val)

    def worker():
        try:
            r = input(prompt)
            loop.call_soon_threadsafe(_set, fut.set_result, r)
        except BaseException as e:  # noqa: BLE001
            loop.call_soon_threadsafe(_set, fut.set_exception, EOFError() if isinstance(e, KeyboardInterrupt) else e)

    threading.Thread(target=worker, daemon=True).start()
    return await fut


def make_approver(agent_ref: dict, renderer: CLIRenderer):
    async def approver(req: dict) -> bool:
        renderer.stop_dynamic()
        args = req["arguments"]
        detail = args.get("command") or json.dumps(args, ensure_ascii=False)[:800]
        console.print(Panel(Text(detail), title=f"⚠️  需要确认：{req['tool']}（{req['reason']}）", border_style="yellow"))
        ans = (await _ainput("允许执行？[y]是 / [n]否 / [a]本会话全部允许: ")).strip().lower()
        if ans in ("a", "all"):
            agent_ref["agent"].approval = "auto"
            return True
        return ans in ("y", "yes", "是", "")
    return approver


def make_ask_user(renderer: CLIRenderer):
    async def ask(question: str) -> str:
        renderer.stop_dynamic()
        console.print(Panel(Markdown(question), title="❓ 智能体提问", border_style="cyan"))
        return (await _ainput("你的回答 > ")).strip()
    return ask


def build_agent(args, settings: Settings, workspace: Path, interactive: bool) -> tuple[Agent, CLIRenderer]:
    profile = settings.get_model(args.model)
    renderer = CLIRenderer(verbose=getattr(args, "verbose", False))
    ref: dict = {}
    agent = Agent(
        create_provider(profile), settings, workspace, mode=args.mode,
        approval="auto" if getattr(args, "yes", False) else (args.approval or settings.approval),
        on_event=renderer,
        approver=make_approver(ref, renderer) if (interactive or sys.stdin.isatty()) else None,
        ask_user=make_ask_user(renderer) if (interactive or sys.stdin.isatty()) else None,
        max_steps=args.max_steps,
        agent_profile=getattr(args, "agent", "general") or "general",
    )
    ref["agent"] = agent
    if getattr(args, "resume", None):
        sid = args.resume
        if sid == "last":
            sessions = list_sessions(workspace, 1)
            sid = sessions[0]["id"] if sessions else None
        if sid and agent.load(sid):
            console.print(f"[green]已恢复会话 {sid}（{len(agent.messages)} 条消息）[/green]")
        else:
            console.print(f"[yellow]未找到会话 {args.resume}，已新建会话[/yellow]")
    return agent, renderer


async def run_task(agent: Agent, task: str) -> str | None:
    loop = asyncio.get_running_loop()
    job = asyncio.create_task(agent.run(task))
    try:
        loop.add_signal_handler(signal.SIGINT, job.cancel)
    except (NotImplementedError, RuntimeError):
        pass
    try:
        return await job
    except asyncio.CancelledError:
        return None
    except Exception as e:  # noqa: BLE001
        console.print(f"[red]任务失败：{type(e).__name__}: {e}[/red]")
        return None
    finally:
        try:
            loop.remove_signal_handler(signal.SIGINT)
        except (NotImplementedError, RuntimeError):
            pass


def banner(agent: Agent):
    p = agent.llm.profile
    grid = Table.grid(padding=(0, 2))
    grid.add_row("[bold]模型[/bold]", f"{p.name} ({p.model})")
    grid.add_row("[bold]工作区[/bold]", str(agent.workspace))
    grid.add_row("[bold]模式[/bold]", f"{agent.mode}    [bold]审批[/bold] {agent.approval}")
    console.print(Panel(Group(Text("OmniAgent  ·  自主执行型 AI 智能体", style="bold cyan"), grid,
                              Text("输入任务开始；/help 查看命令；Ctrl+C 中断当前任务", style="dim")),
                        border_style="cyan", subtitle=f"v{__version__}"))


HELP = """
**命令**
- `/model [名称]` 查看/切换模型  ·  `/mode [auto|code|office]` 切换模式
- `/approval [auto|smart|always]` 审批策略（auto 全自动 / smart 仅高风险命令确认 / always 全部确认）
- `/plan` 查看当前计划  ·  `/memory` 查看用户画像与长期记忆  ·  `/usage` token 用量  ·  `/compact` 压缩上下文
- `/new` 新会话  ·  `/sessions` 历史会话  ·  `/resume <id>` 恢复会话  ·  `/skills` 可用技能
- `/exit` 退出

多行输入：行尾输入 `\\` 继续下一行。
"""


async def interactive(args, settings: Settings, workspace: Path):
    agent, renderer = build_agent(args, settings, workspace, interactive=True)
    banner(agent)
    try:
        while True:
            try:
                lines = []
                prompt = "\n❯ "
                while True:
                    line = await _ainput(prompt)
                    if line.endswith("\\"):
                        lines.append(line[:-1])
                        prompt = "… "
                        continue
                    lines.append(line)
                    break
                text = "\n".join(lines).strip()
            except (EOFError, KeyboardInterrupt):
                console.print("\n再见 👋")
                break
            if not text:
                continue
            if text.startswith("/"):
                if not await handle_command(text, agent, settings):
                    break
                continue
            await run_task(agent, text)
    finally:
        await agent.close()


async def handle_command(text: str, agent: Agent, settings: Settings) -> bool:
    cmd, _, arg = text.partition(" ")
    arg = arg.strip()
    if cmd in ("/exit", "/quit", "/q"):
        return False
    if cmd == "/help":
        console.print(Markdown(HELP))
    elif cmd == "/model":
        if arg:
            try:
                agent.llm = create_provider(settings.get_model(arg))
                console.print(f"[green]已切换到 {arg} ({agent.llm.profile.model})[/green]")
            except Exception as e:  # noqa: BLE001
                console.print(f"[red]{e}[/red]")
        else:
            print_models(settings, current=agent.llm.profile.name)
    elif cmd == "/mode":
        if arg in ("auto", "code", "office"):
            agent.mode = arg
        console.print(f"模式：{agent.mode}")
    elif cmd == "/approval":
        if arg in ("auto", "smart", "always"):
            agent.approval = arg
        console.print(f"审批策略：{agent.approval}")
    elif cmd == "/plan":
        from omniagent.tools.planning import render_todos

        console.print(render_todos(agent.state.get("todos") or []) or "（暂无计划）")
    elif cmd == "/usage":
        u = agent.usage
        console.print(f"输入 {u.input_tokens:,} · 输出 {u.output_tokens:,} · 缓存命中 {u.cache_read_tokens:,} · "
                      f"当前上下文 ~{agent.last_context_tokens:,}/{agent.llm.profile.context_window:,}")
    elif cmd == "/compact":
        await agent.compact()
    elif cmd in ("/new", "/clear"):
        agent.reset()
        console.print("[green]已开始新会话[/green]")
    elif cmd == "/sessions":
        print_sessions(agent.workspace)
    elif cmd == "/skills":
        print_skills(agent.workspace)
    elif cmd == "/memory":
        print_memory_overview(agent.workspace, query=arg)
    elif cmd == "/resume":
        if agent.load(arg):
            console.print(f"[green]已恢复会话 {arg}[/green]")
        else:
            console.print("[red]会话不存在[/red]")
    else:
        console.print(f"[yellow]未知命令 {cmd}，输入 /help 查看帮助[/yellow]")
    return True


def print_models(settings: Settings, current: str | None = None):
    t = Table(title="模型档案")
    for c in ("名称", "协议", "模型", "视觉", "Base URL", "状态"):
        t.add_column(c)
    for name, p in settings.models.items():
        hint = getattr(p, "key_hint", None) or p.api_key_env
        ok = "[green]可用[/green]" if p.available else f"[dim]需设置 {hint}[/dim]"
        base = (p.resolve_base_url() if hasattr(p, "resolve_base_url") else p.base_url) or "-"
        t.add_row(("➤ " if name == current else "") + name, p.provider, p.model,
                  "✓" if getattr(p, "vision", False) else "-", base, ok)
    console.print(t)


def print_skills(workspace: Path):
    from omniagent.tools.skills import discover_skills

    skills = discover_skills(workspace)
    if not skills:
        console.print("[yellow]没有找到技能。[/yellow] 可在 ~/.omniagent/skills/<名称>/SKILL.md 或 "
                      "<工作区>/.omniagent/skills/<名称>/SKILL.md 添加。")
        return
    t = Table(title=f"可用技能（{len(skills)}）", show_lines=False)
    for c in ("名称", "来源", "说明"):
        t.add_column(c, overflow="fold")
    for sk in sorted(skills.values(), key=lambda x: (x.source != "workspace", x.source != "user", x.name)):
        t.add_row(sk.name, sk.source, sk.description[:160])
    console.print(t)
    console.print("[dim]技能目录：内置 omniagent/skills/ · 用户 ~/.omniagent/skills/ · 工作区 .omniagent/skills/"
                  "（同名时工作区 > 用户 > 内置）[/dim]")


def _user_db(data_dir: str | None):
    from omniagent.web.db import Database
    from omniagent.web.server import default_data_dir

    d = Path(data_dir).expanduser() if data_dir else default_data_dir()
    d.mkdir(parents=True, exist_ok=True)
    return Database(d / "omniagent.db"), d


def _ask_password(prompt: str = "密码: ") -> str:
    import getpass

    while True:
        pw = getpass.getpass(prompt)
        if len(pw) < 6:
            console.print("[red]密码至少 6 位[/red]")
            continue
        if getpass.getpass("再次输入: ") != pw:
            console.print("[red]两次输入不一致[/red]")
            continue
        return pw


def user_command(args) -> int:
    import datetime as dt

    db, d = _user_db(getattr(args, "data_dir", None))
    action = args.user_action
    if action == "list":
        users = db.list_users()
        t = Table(title=f"用户（{d / 'omniagent.db'}）")
        for c in ("ID", "用户名", "角色", "状态", "会话数", "tokens 输入/输出", "最近登录"):
            t.add_column(c)
        for u in users:
            last = dt.datetime.fromtimestamp(u["last_login"]).strftime("%Y-%m-%d %H:%M") if u.get("last_login") else "-"
            t.add_row(str(u["id"]), u["username"], u["role"], u["status"], str(u.get("conversations", 0)),
                      f"{u.get('input_tokens', 0):,}/{u.get('output_tokens', 0):,}", last)
        console.print(t)
        return 0
    name = args.username
    if action == "add":
        if db.get_user_row_by_name(name) is not None:
            console.print(f"[red]用户 {name} 已存在[/red]")
            return 1
        pw = args.password or _ask_password()
        role = "admin" if args.admin else "user"
        db.create_user(name, pw, role, getattr(args, "email", "") or "", "")
        console.print(f"[green]已创建用户 {name}（{role}）[/green]")
        return 0
    row = db.get_user_row_by_name(name)
    if row is None:
        console.print(f"[red]用户 {name} 不存在[/red]")
        return 1
    uid = row["id"]
    if action == "passwd":
        db.update_user(uid, password=args.password or _ask_password("新密码: "))
        db.delete_tokens_except(uid, None)
        console.print(f"[green]已重置 {name} 的密码（其所有登录会话已失效）[/green]")
    elif action == "role":
        db.update_user(uid, role=args.role)
        console.print(f"[green]{name} 的角色已设为 {args.role}[/green]")
    elif action in ("disable", "enable"):
        db.update_user(uid, status="disabled" if action == "disable" else "active")
        if action == "disable":
            db.delete_tokens_except(uid, None)
        console.print(f"[green]已{'禁用' if action == 'disable' else '启用'}用户 {name}[/green]")
    return 0


def print_sessions(workspace: Path):
    import datetime as dt

    t = Table(title=f"历史会话（{workspace}）")
    for c in ("ID", "标题", "模型", "更新时间"):
        t.add_column(c)
    for s in list_sessions(workspace):
        t.add_row(s["id"], s["title"][:50], s.get("model") or "", dt.datetime.fromtimestamp(s["updated"]).strftime("%m-%d %H:%M"))
    console.print(t)


def print_agents(workspace: Path):
    from omniagent.agent.profiles import discover_agents

    t = Table(title="智能体与子智能体（Agents & Subagents）")
    for c in ("标识", "名称", "模式", "来源", "职责说明"):
        t.add_column(c)
    for a in discover_agents(workspace).values():
        t.add_row(f"{a.icon} {a.name}", a.title, a.mode, a.source, a.description[:64])
    console.print(t)


def print_connectors(workspace: Path):
    from omniagent.connectors import load_file_connectors

    conns = load_file_connectors(workspace)
    t = Table(title="已配置的外部连接器（Connectors）")
    for c in ("标识", "名称", "类型", "来源", "说明"):
        t.add_column(c)
    for spec in conns.values():
        t.add_row(spec.name, spec.title, spec.kind, spec.source, spec.description[:60])
    console.print(t)
    if not conns:
        console.print("[dim]提示：可在 Web/桌面端「🔌 接入」界面或 .omniagent/connectors.json 中添加外部系统连接器。[/dim]")


def print_memory_overview(workspace: Path, query: str = ""):
    from omniagent.memory import MemoryStore

    store = MemoryStore(workspace / ".omniagent" / "memory.db")
    try:
        if query:
            hits = store.search_memories(query, limit=15, bump_hits=False)
            t = Table(title=f"长期记忆检索：「{query}」（{len(hits)} 条）")
            for c in ("ID", "类别", "重要度", "内容"):
                t.add_column(c)
            for m in hits:
                t.add_row(m["id"], m["category_label"], f"★{m['importance']}", m["content"])
            console.print(t)
            return

        ov = store.overview()
        tp = Table(title=f"用户画像（{ov['stats']['traits']} 项特征）")
        for c in ("维度", "特征键", "来源", "置信度", "描述"):
            tp.add_column(c)
        for dim in ov["portrait"]["dimensions"]:
            for tr in dim["traits"]:
                tp.add_row(dim["title"], tr["trait_key"], tr["source"], f"{int(tr['confidence']*100)}%", tr["value"])
        console.print(tp)

        if ov["projects"]:
            tj = Table(title=f"在办工作与文稿连续性（{len(ov['projects'])} 项）")
            for c in ("项目", "类型", "进度", "已完成", "待完善"):
                tj.add_column(c)
            for p in ov["projects"][:15]:
                tj.add_row(
                    p["title"], p["kind_label"], f"{p['progress_pct']}%",
                    "；".join(p["completed_items"][:3]) or "-",
                    "；".join(p["pending_items"][:3]) or "-",
                )
            console.print(tj)

        if ov["memories"]:
            tm = Table(title=f"长期记忆库（共 {len(ov['memories'])} 条，展示前 15 条）")
            for c in ("ID", "类别", "重要度", "内容"):
                t.add_column(c) if False else tm.add_column(c)
            for m in ov["memories"][:15]:
                pin = "📌 " if m["pinned"] else ""
                tm.add_row(m["id"], m["category_label"], f"★{m['importance']}", pin + m["content"])
            console.print(tm)
    finally:
        store.close()


def _ensure_windows_utf8() -> None:
    if os.name != "nt":
        return
    os.environ.setdefault("PYTHONUTF8", "1")
    os.environ.setdefault("PYTHONIOENCODING", "utf-8")
    for s in (sys.stdout, sys.stderr):
        if s is not None and hasattr(s, "reconfigure"):
            try:
                s.reconfigure(encoding="utf-8", errors="replace")
            except Exception:  # noqa: BLE001
                pass
    if hasattr(asyncio, "WindowsProactorEventLoopPolicy"):
        try:
            asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())
        except Exception:  # noqa: BLE001
            pass


def main(argv: list[str] | None = None):
    _ensure_windows_utf8()
    parser = argparse.ArgumentParser(prog="omni", description="OmniAgent - 自主执行型 AI 智能体")
    parser.add_argument("-V", "--version", action="version", version=f"omniagent {__version__}")
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("-m", "--model", help="模型档案名（claude/deepseek/qwen/kimi/glm/openai/ollama/mock），默认自动选择")
    common.add_argument("-w", "--workspace", help="工作区目录，默认当前目录")
    common.add_argument("--mode", default="auto", choices=["auto", "code", "office"], help="任务模式")
    common.add_argument("--agent", default="general", help="主智能体角色（general/coder/analyst/writer/connector/reviewer 或自定义）")
    common.add_argument("--approval", choices=["auto", "smart", "always"], help="审批策略")
    common.add_argument("--max-steps", type=int, help="最大执行步数")
    common.add_argument("-r", "--resume", help="恢复会话 ID（或 last）")
    common.add_argument("-v", "--verbose", action="store_true", help="显示更多细节")
    common.add_argument("--debug", action="store_true", help="调试日志")

    sub = parser.add_subparsers(dest="command")
    sub.add_parser("chat", parents=[common], help="交互模式（默认）")
    p_run = sub.add_parser("run", parents=[common], help="一次性自主执行任务")
    p_run.add_argument("task", nargs="+", help="任务描述（也可用 @文件 读取任务文本）")
    p_run.add_argument("-y", "--yes", action="store_true", help="全自动执行，不请求确认")
    p_run.add_argument("--json", action="store_true", help="以 JSON 输出最终结果")
    p_web = sub.add_parser("web", parents=[common], help="启动 Web 工作台")
    p_web.add_argument("--host", default="127.0.0.1")
    p_web.add_argument("--port", type=int, default=8765)
    p_web.add_argument("--data-dir", help="Web 数据目录（用户库、会话、工作区），默认 $OMNI_DATA_DIR 或 ~/.omniagent/server")
    p_desk = sub.add_parser("desktop", parents=[common], help="启动电脑桌面端（原生窗口 / 构建桌面应用包）")
    p_desk.add_argument("--port", type=int, default=0, help="本地服务端口，默认自动分配空闲端口")
    p_desk.add_argument("--data-dir", help="桌面数据目录，默认 $OMNI_DATA_DIR 或 ~/.omniagent/server")
    p_desk.add_argument("--no-auto-login", action="store_true", help="禁用桌面端本机免密自动登录，显示多用户登录页")
    p_desk.add_argument("--build-app", nargs="?", const="dist", metavar="DIR", help="构建可双击的桌面应用包（macOS .app / Windows .vbs+.bat）")
    sub.add_parser("models", parents=[common], help="列出模型档案")
    sub.add_parser("sessions", parents=[common], help="列出历史会话")
    sub.add_parser("skills", parents=[common], help="列出可用技能（Skills）")
    sub.add_parser("agents", parents=[common], help="列出智能体与子智能体（Agents & Subagents）")
    sub.add_parser("connectors", parents=[common], help="列出外部应用连接器（Connectors）")
    p_mem = sub.add_parser("memory", parents=[common], help="查看或管理长期记忆、用户画像与在办项目")
    p_mem.add_argument("mem_action", nargs="?", default="show", choices=["show", "search", "add", "clear"])
    p_mem.add_argument("mem_arg", nargs="*", help="检索词或新增记忆内容")
    p_eval = sub.add_parser("eval", help="运行智能体评测基准（支持 --oracle 离线验证）")
    p_eval.add_argument("eval_args", nargs=argparse.REMAINDER, help="传给 omniagent.evals 的参数")
    p_user = sub.add_parser("user", help="管理 Web 工作台用户")
    p_user.add_argument("--data-dir", help="Web 数据目录，默认 $OMNI_DATA_DIR 或 ~/.omniagent/server")
    usub = p_user.add_subparsers(dest="user_action", required=True)
    usub.add_parser("list", help="列出用户")
    u_add = usub.add_parser("add", help="新建用户")
    u_add.add_argument("username")
    u_add.add_argument("--admin", action="store_true", help="设为管理员")
    u_add.add_argument("--password", help="密码（省略则交互输入）")
    u_add.add_argument("--email", default="")
    u_pw = usub.add_parser("passwd", help="重置密码")
    u_pw.add_argument("username")
    u_pw.add_argument("--password", help="新密码（省略则交互输入）")
    u_role = usub.add_parser("role", help="设置角色")
    u_role.add_argument("username")
    u_role.add_argument("role", choices=["admin", "user"])
    for act, helptext in (("disable", "禁用用户"), ("enable", "启用用户")):
        usub.add_parser(act, help=helptext).add_argument("username")

    argv = sys.argv[1:] if argv is None else argv
    if argv and argv[0] == "eval":
        from omniagent.evals import main as eval_main

        sys.exit(eval_main(argv[1:]) or 0)
    if not argv or (argv[0].startswith("-") and argv[0] not in ("-h", "--help", "-V", "--version")):
        argv = ["chat", *argv]
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if getattr(args, "debug", False) else logging.WARNING,
                        format="%(levelname)s %(name)s: %(message)s")

    if args.command == "user":
        sys.exit(user_command(args))

    workspace = Path(args.workspace or os.getcwd()).expanduser().resolve()
    settings = load_settings(workspace)
    if args.max_steps is None:
        args.max_steps = settings.max_steps

    if args.command == "models":
        print_models(settings)
        return
    if args.command == "sessions":
        print_sessions(workspace)
        return
    if args.command == "skills":
        print_skills(workspace)
        return
    if args.command == "agents":
        print_agents(workspace)
        return
    if args.command == "connectors":
        print_connectors(workspace)
        return
    if args.command == "memory":
        from omniagent.memory import MemoryStore

        act = args.mem_action
        text_arg = " ".join(args.mem_arg or []).strip()
        if act == "show":
            print_memory_overview(workspace)
        elif act == "search":
            print_memory_overview(workspace, query=text_arg)
        elif act == "add":
            if not text_arg:
                console.print("[red]请提供要记住的内容，例如：omni memory add '公文一律采用GB/T 9704格式'[/red]")
                sys.exit(1)
            st = MemoryStore(workspace / ".omniagent" / "memory.db")
            try:
                rec = st.upsert_memory(text_arg, category="preference", importance=4, source="manual")
                console.print(f"[green]✔ 已添加长期记忆 [{rec['id']}]：{rec['content']}[/green]")
            finally:
                st.close()
        elif act == "clear":
            st = MemoryStore(workspace / ".omniagent" / "memory.db")
            try:
                st.clear_all()
                console.print("[yellow]已清空当前工作区的所有长期记忆与用户画像。[/yellow]")
            finally:
                st.close()
        return
    if args.command == "eval":
        from omniagent.evals import main as eval_main

        eval_main(args.eval_args)
        return
    if args.command == "desktop":
        from omniagent.desktop import build_desktop_app, launch_desktop

        if args.build_app:
            app_path = build_desktop_app(args.build_app)
            console.print(f"[bold green]✔ 已生成桌面应用启动包：[/bold green]{app_path}")
            return
        sys.exit(launch_desktop(settings, port=args.port, data_dir=args.data_dir,
                                default_model=args.model, auto_login=not args.no_auto_login))
    if args.command == "web":
        from omniagent.web.server import serve

        serve(None, settings, host=args.host, port=args.port, default_model=args.model, data_dir=args.data_dir)
        return

    try:
        settings.get_model(args.model)
    except Exception as e:  # noqa: BLE001
        console.print(f"[red]{e}[/red]")
        sys.exit(1)

    if args.command == "run":
        task = " ".join(args.task)
        if task.startswith("@") and Path(task[1:]).exists():
            task = Path(task[1:]).read_text(encoding="utf-8")

        async def go():
            agent, _ = build_agent(args, settings, workspace, interactive=False)
            try:
                result = await run_task(agent, task)
            finally:
                await agent.close()
            if args.json:
                print(json.dumps({"session_id": agent.session_id, "result": result, "usage": agent.usage.__dict__},
                                 ensure_ascii=False))
            return result

        result = asyncio.run(go())
        sys.exit(0 if result is not None else 1)

    try:
        asyncio.run(interactive(args, settings, workspace))
    except KeyboardInterrupt:
        console.print("\n再见 👋")


if __name__ == "__main__":
    main()
