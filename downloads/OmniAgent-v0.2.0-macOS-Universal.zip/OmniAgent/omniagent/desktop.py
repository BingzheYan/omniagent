"""OmniAgent 电脑桌面端（Native Desktop App）。

架构：
1. 在后台线程启动内嵌的本地 FastAPI/Uvicorn 服务（自动分配空闲端口 + 一次性本机安全令牌免密登录）；
2. 在 macOS 上优先使用原生编译的 Cocoa + WKWebView 桌面窗口（支持原生菜单栏、快捷键复制粘贴、原生 Finder 文件选择框、深色标题栏）；
   在其他系统（Windows/Linux）自动依次回退到 pywebview 原生窗口 → Chrome/Edge 独立 App 窗口 (--app=) → 系统窗口；
3. 支持 `omni desktop --build-app` 一键生成可双击运行的 macOS `dist/OmniAgent.app` 应用包。
"""
from __future__ import annotations

import os
import platform
import secrets
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.request
from pathlib import Path

from omniagent import __version__
from omniagent.config import Settings

SWIFT_WEBVIEW_SOURCE = r'''
import Cocoa
import WebKit

class AppDelegate: NSObject, NSApplicationDelegate, WKUIDelegate, WKNavigationDelegate {
    var window: NSWindow!
    var webView: WKWebView!
    let startURL: String

    init(url: String) {
        self.startURL = url
    }

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.appearance = NSAppearance(named: .darkAqua)
        setupMenu()

        let cfg = WKWebViewConfiguration()
        cfg.preferences.setValue(true, forKey: "developerExtrasEnabled")

        let rect = NSRect(x: 0, y: 0, width: 1440, height: 920)
        window = NSWindow(
            contentRect: rect,
            styleMask: [.titled, .closable, .miniaturizable, .resizable, .fullSizeContentView],
            backing: .buffered,
            defer: false
        )
        window.title = "OmniAgent · 自主执行型 AI 智能体工作台"
        window.titlebarAppearsTransparent = false
        window.minSize = NSSize(width: 960, height: 640)
        window.center()

        webView = WKWebView(frame: rect, configuration: cfg)
        webView.autoresizingMask = [.width, .height]
        webView.uiDelegate = self
        webView.navigationDelegate = self
        window.contentView = webView
        window.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)

        if let u = URL(string: startURL) {
            webView.load(URLRequest(url: u))
        }
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        return true
    }

    // 支持 HTML <input type="file"> 调起 macOS 原生文件选择器
    func webView(_ webView: WKWebView,
                 runOpenPanelWith parameters: WKOpenPanelParameters,
                 initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping ([URL]?) -> Void) {
        let panel = NSOpenPanel()
        panel.canChooseFiles = true
        panel.canChooseDirectories = parameters.allowsDirectories
        panel.allowsMultipleSelection = parameters.allowsMultipleSelection
        panel.beginSheetModal(for: window) { result in
            completionHandler(result == .OK ? panel.urls : nil)
        }
    }

    func webView(_ webView: WKWebView,
                 runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping () -> Void) {
        let alert = NSAlert()
        alert.messageText = "OmniAgent"
        alert.informativeText = message
        alert.runModal()
        completionHandler()
    }

    func webView(_ webView: WKWebView,
                 runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping (Bool) -> Void) {
        let alert = NSAlert()
        alert.messageText = "确认操作"
        alert.informativeText = message
        alert.addButton(withTitle: "确定")
        alert.addButton(withTitle: "取消")
        completionHandler(alert.runModal() == .alertFirstButtonReturn)
    }

    private func setupMenu() {
        let mainMenu = NSMenu()
        NSApp.mainMenu = mainMenu

        let appItem = NSMenuItem()
        mainMenu.addItem(appItem)
        let appMenu = NSMenu()
        appItem.submenu = appMenu
        appMenu.addItem(withTitle: "关于 OmniAgent", action: #selector(NSApplication.orderFrontStandardAboutPanel(_:)), keyEquivalent: "")
        appMenu.addItem(NSMenuItem.separator())
        appMenu.addItem(withTitle: "刷新页面", action: #selector(reloadPage), keyEquivalent: "r")
        appMenu.addItem(NSMenuItem.separator())
        appMenu.addItem(withTitle: "退出 OmniAgent", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")

        let editItem = NSMenuItem()
        mainMenu.addItem(editItem)
        let editMenu = NSMenu(title: "编辑")
        editItem.submenu = editMenu
        editMenu.addItem(withTitle: "撤销", action: Selector(("undo:")), keyEquivalent: "z")
        editMenu.addItem(withTitle: "重做", action: Selector(("redo:")), keyEquivalent: "Z")
        editMenu.addItem(NSMenuItem.separator())
        editMenu.addItem(withTitle: "剪切", action: #selector(NSText.cut(_:)), keyEquivalent: "x")
        editMenu.addItem(withTitle: "复制", action: #selector(NSText.copy(_:)), keyEquivalent: "c")
        editMenu.addItem(withTitle: "粘贴", action: #selector(NSText.paste(_:)), keyEquivalent: "v")
        editMenu.addItem(withTitle: "全选", action: #selector(NSText.selectAll(_:)), keyEquivalent: "a")
    }

    @objc func reloadPage() {
        webView.reload()
    }
}

let urlArg = CommandLine.arguments.count > 1 ? CommandLine.arguments[1] : "http://127.0.0.1:8765"
let app = NSApplication.shared
app.setActivationPolicy(.regular)
let delegate = AppDelegate(url: urlArg)
app.delegate = delegate
app.run()
'''


def _free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return int(s.getsockname()[1])


def ensure_macos_native_shell(cache_dir: Path | None = None, *, universal: bool = False) -> Path | None:
    """在 macOS 上编译轻量原生 WKWebView 桌面壳（仅首次编译约 2 秒，后续直接复用二进制）。"""
    if platform.system() != "Darwin":
        return None
    swiftc = shutil.which("swiftc")
    if not swiftc:
        return None
    target_dir = cache_dir or (Path.home() / ".omniagent" / "bin")
    target_dir.mkdir(parents=True, exist_ok=True)
    bin_path = target_dir / "OmniAgentDesktopShell"
    src_path = target_dir / "OmniAgentDesktopShell.swift"
    if not universal and bin_path.is_file() and src_path.is_file() and src_path.read_text(encoding="utf-8") == SWIFT_WEBVIEW_SOURCE:
        return bin_path
    src_path.write_text(SWIFT_WEBVIEW_SOURCE, encoding="utf-8")
    lipo = shutil.which("lipo")
    if universal and lipo:
        arm_bin = target_dir / "OmniAgentDesktopShell.arm64"
        x64_bin = target_dir / "OmniAgentDesktopShell.x86_64"
        r1 = subprocess.run(
            [swiftc, "-O", "-target", "arm64-apple-macos12.0", "-framework", "Cocoa", "-framework", "WebKit", str(src_path), "-o", str(arm_bin)],
            capture_output=True, text=True,
        )
        r2 = subprocess.run(
            [swiftc, "-O", "-target", "x86_64-apple-macos12.0", "-framework", "Cocoa", "-framework", "WebKit", str(src_path), "-o", str(x64_bin)],
            capture_output=True, text=True,
        )
        if r1.returncode == 0 and r2.returncode == 0:
            r3 = subprocess.run([lipo, "-create", str(arm_bin), str(x64_bin), "-output", str(bin_path)], capture_output=True, text=True)
            arm_bin.unlink(missing_ok=True)
            x64_bin.unlink(missing_ok=True)
            if r3.returncode == 0 and bin_path.is_file():
                src_path.unlink(missing_ok=True)
                return bin_path
        arm_bin.unlink(missing_ok=True)
        x64_bin.unlink(missing_ok=True)
    res = subprocess.run(
        [swiftc, "-O", "-framework", "Cocoa", "-framework", "WebKit", str(src_path), "-o", str(bin_path)],
        capture_output=True, text=True,
    )
    if res.returncode != 0 or not bin_path.is_file():
        return None
    return bin_path


def build_macos_app_bundle(output_dir: Path | str = "dist", *, portable: bool = False) -> Path:
    """构建标准 macOS 双击应用包 `OmniAgent.app`。"""
    out_root = Path(output_dir).expanduser().resolve()
    app_dir = out_root / "OmniAgent.app"
    contents = app_dir / "Contents"
    macos_dir = contents / "MacOS"
    res_dir = contents / "Resources"
    macos_dir.mkdir(parents=True, exist_ok=True)
    res_dir.mkdir(parents=True, exist_ok=True)

    # 编译原生窗口二进制进入 App Bundle（优先构建 Apple Silicon + Intel 通用二进制）
    shell_bin = ensure_macos_native_shell(macos_dir, universal=True)

    project_root = Path(__file__).resolve().parent.parent
    venv_py = project_root / ".venv" / "bin" / "python"
    python_bin = venv_py if venv_py.exists() else Path(sys.executable)
    fallback_root = "$HOME/Applications/OmniAgent" if portable else str(project_root)
    fallback_py = "python3" if portable else str(python_bin)
    launcher = macos_dir / "OmniAgent"
    launcher.write_text(
        f"""#!/bin/bash
set -e
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT=""
for cand in "$SCRIPT_DIR/../../.." "$SCRIPT_DIR/../../../.."; do
  abs_c="$(cd "$cand" 2>/dev/null && pwd || true)"
  if [ -n "$abs_c" ] && [ -f "$abs_c/omniagent/__init__.py" ]; then
    ROOT="$abs_c"
    break
  fi
done
if [ -z "$ROOT" ]; then
  ROOT="{fallback_root}"
fi
unset ANTHROPIC_AUTH_TOKEN ANTHROPIC_API_KEY ANTHROPIC_BASE_URL
export OMNIAGENT_NATIVE_SHELL="$SCRIPT_DIR/OmniAgentDesktopShell"
cd "$ROOT"
if [ -x "$ROOT/.venv/bin/python" ] && [ -w "$ROOT" ]; then
  PY="$ROOT/.venv/bin/python"
elif [ -f "$ROOT/scripts/mac_bootstrap.sh" ]; then
  osascript -e 'tell application "Terminal" to activate' -e "tell application \\"Terminal\\" to do script \\"bash '$ROOT/scripts/mac_bootstrap.sh' desktop\\""
  exit 0
else
  PY="{fallback_py}"
fi
if [ -d "$ROOT/demo_data" ]; then
  exec "$PY" -m omniagent desktop -m deepseek --data-dir "$ROOT/demo_data"
else
  exec "$PY" -m omniagent desktop -m deepseek
fi
""",
        encoding="utf-8",
    )
    os.chmod(launcher, 0o755)

    plist = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleName</key><string>OmniAgent</string>
    <key>CFBundleDisplayName</key><string>OmniAgent</string>
    <key>CFBundleIdentifier</key><string>ai.omniagent.desktop</string>
    <key>CFBundleVersion</key><string>{__version__}</string>
    <key>CFBundleShortVersionString</key><string>{__version__}</string>
    <key>CFBundlePackageType</key><string>APPL</string>
    <key>CFBundleExecutable</key><string>OmniAgent</string>
    <key>NSHighResolutionCapable</key><true/>
    <key>NSAppTransportSecurity</key>
    <dict><key>NSAllowsLocalNetworking</key><true/></dict>
</dict>
</plist>
"""
    (contents / "Info.plist").write_text(plist, encoding="utf-8")
    if shell_bin:
        os.chmod(shell_bin, 0o755)
    return app_dir


def build_windows_app_bundle(output_dir: Path | str = "dist", *, portable: bool = False) -> Path:
    """构建 Windows 可双击无黑框启动的桌面应用启动器（OmniAgent.vbs + OmniAgent.bat）。"""
    out_root = Path(output_dir).expanduser().resolve()
    out_root.mkdir(parents=True, exist_ok=True)
    project_root = Path(__file__).resolve().parent.parent
    fallback_win_root = r"%USERPROFILE%\Desktop\OmniAgent" if portable else str(project_root)

    bat_path = out_root / "OmniAgent.bat"
    bat_content = (
        "@echo off\r\n"
        "chcp 65001 >nul\r\n"
        "setlocal\r\n"
        "set \"SCRIPT_DIR=%~dp0\"\r\n"
        "set \"ROOT=%SCRIPT_DIR%..\"\r\n"
        "if not exist \"%ROOT%\\omniagent\\__init__.py\" set \"ROOT=" + fallback_win_root + "\"\r\n"
        "cd /d \"%ROOT%\"\r\n"
        "set ANTHROPIC_AUTH_TOKEN=\r\n"
        "set ANTHROPIC_API_KEY=\r\n"
        "set ANTHROPIC_BASE_URL=\r\n"
        "set PYTHONUTF8=1\r\n"
        "set PYTHONIOENCODING=utf-8\r\n"
        "if exist \"%ROOT%\\.venv\\Scripts\\python.exe\" (\r\n"
        "  set \"PY=%ROOT%\\.venv\\Scripts\\python.exe\"\r\n"
        ") else (\r\n"
        "  set \"PY=python\"\r\n"
        ")\r\n"
        "if exist \"%ROOT%\\demo_data\" (\r\n"
        "  \"%PY%\" -m omniagent desktop -m deepseek --data-dir \"%ROOT%\\demo_data\"\r\n"
        ") else (\r\n"
        "  \"%PY%\" -m omniagent desktop -m deepseek\r\n"
        ")\r\n"
    )
    bat_path.write_bytes(bat_content.encode("utf-8"))

    vbs_path = out_root / "OmniAgent.vbs"
    vbs_content = (
        'Set fso = CreateObject("Scripting.FileSystemObject")\r\n'
        'Set sh = CreateObject("WScript.Shell")\r\n'
        'dir = fso.GetParentFolderName(WScript.ScriptFullName)\r\n'
        'sh.Run """" & dir & "\\OmniAgent.bat""", 0, False\r\n'
    )
    vbs_path.write_bytes(vbs_content.encode("ascii"))
    return vbs_path


def build_desktop_app(output_dir: Path | str = "dist") -> Path:
    """按当前操作系统构建可双击运行的桌面启动包（macOS `.app` / Windows `.vbs`+`.bat`）。"""
    if platform.system() == "Windows":
        return build_windows_app_bundle(output_dir)
    return build_macos_app_bundle(output_dir)


def _wait_server(url: str, timeout: float = 15.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=1.0) as r:
                if r.status == 200:
                    return True
        except Exception:  # noqa: BLE001
            time.sleep(0.1)
    return False


def _find_chromium_app_browser() -> str | None:
    pf = os.environ.get("ProgramFiles", r"C:\Program Files")
    pfx86 = os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")
    local_app = os.environ.get("LOCALAPPDATA", "")
    for cand in (
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
        "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser",
        str(Path(pf) / "Google" / "Chrome" / "Application" / "chrome.exe"),
        str(Path(pfx86) / "Google" / "Chrome" / "Application" / "chrome.exe"),
        str(Path(local_app) / "Google" / "Chrome" / "Application" / "chrome.exe") if local_app else None,
        str(Path(pfx86) / "Microsoft" / "Edge" / "Application" / "msedge.exe"),
        str(Path(pf) / "Microsoft" / "Edge" / "Application" / "msedge.exe"),
        str(Path(pf) / "BraveSoftware" / "Brave-Browser" / "Application" / "brave.exe"),
        shutil.which("google-chrome"),
        shutil.which("chrome"),
        shutil.which("chromium"),
        shutil.which("msedge"),
    ):
        if cand and Path(cand).exists():
            return cand
    return None


def launch_desktop(
    settings: Settings,
    *,
    port: int = 0,
    data_dir: str | Path | None = None,
    default_model: str | None = None,
    auto_login: bool = True,
) -> int:
    import uvicorn
    from rich.console import Console

    from omniagent.web.server import create_app, default_data_dir

    # Windows pythonw.exe 无控制台模式下 stdout/stderr 可能为 None，重定向到日志避免 uvicorn/rich 报错
    if sys.stdout is None or sys.stderr is None:
        log_dir = Path.home() / ".omniagent" / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        fh = open(log_dir / "desktop.log", "a", encoding="utf-8")
        if sys.stdout is None:
            sys.stdout = fh
        if sys.stderr is None:
            sys.stderr = fh

    console = Console()
    actual_port = port or _free_port()
    d_dir = Path(data_dir) if data_dir else default_data_dir()
    desk_token = secrets.token_urlsafe(24) if auto_login else None
    app = create_app(d_dir, settings, default_model=default_model, desktop_token=desk_token)

    cfg = uvicorn.Config(app, host="127.0.0.1", port=actual_port, log_level="warning", log_config=None)
    server = uvicorn.Server(cfg)
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()

    base_url = f"http://127.0.0.1:{actual_port}"
    if not _wait_server(f"{base_url}/api/health"):
        console.print("[red]启动本地桌面后端服务超时[/red]")
        return 1

    entry_url = f"{base_url}/api/auth/desktop-login?token={desk_token}" if desk_token else base_url
    console.print(f"[bold cyan]OmniAgent 桌面端已启动[/bold cyan] · 本地服务 {base_url} · 数据目录 {d_dir}")

    # 1) macOS 原生 Cocoa WKWebView 桌面窗口
    env_shell = os.environ.get("OMNIAGENT_NATIVE_SHELL")
    bundled_shell = Path(env_shell) if env_shell else (Path(sys.executable).resolve().parent / "OmniAgentDesktopShell")
    native_shell = bundled_shell if bundled_shell.is_file() else ensure_macos_native_shell()
    if native_shell:
        try:
            proc = subprocess.Popen([str(native_shell), entry_url])
            proc.wait()
            server.should_exit = True
            return 0
        except KeyboardInterrupt:
            server.should_exit = True
            return 0

    # 2) pywebview（跨平台原生窗口）
    try:
        import webview  # type: ignore

        webview.create_window("OmniAgent", entry_url, width=1440, height=920, min_size=(960, 640))
        webview.start()
        server.should_exit = True
        return 0
    except ImportError:
        pass

    # 3) Chrome / Edge 独立 App 窗口模式（无地址栏）
    browser = _find_chromium_app_browser()
    if browser:
        profile_dir = d_dir / "desktop_window_profile"
        proc = subprocess.Popen([
            browser,
            f"--app={entry_url}",
            f"--user-data-dir={profile_dir}",
            "--window-size=1440,920",
            "--no-first-run",
            "--no-default-browser-check",
            "--disable-background-mode",
            "--disable-features=msEdgeSidebarV2,TranslateUI",
        ])
        try:
            proc.wait()
        except KeyboardInterrupt:
            proc.terminate()
        server.should_exit = True
        return 0

    # 4) 兜底：系统默认浏览器打开并保持服务运行
    import webbrowser

    webbrowser.open(entry_url)
    console.print("已在默认窗口打开，按 Ctrl+C 退出服务。")
    try:
        while thread.is_alive():
            time.sleep(0.5)
    except KeyboardInterrupt:
        server.should_exit = True
    return 0
